<?php
/**
 * Template Name: 02 - The Blind Ballot
 * Description: Ideas-First Manifesto & Policy Arena where party colors and names are hidden first.
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$issues = qt_get_blind_ballot_issues();
$first  = $issues[0];
?>

<section class="qt-page-hero">
	<div class="qt-page-hero-copy">
		<div class="qt-eyebrow"><?php esc_html_e( 'Page 02 · Ideas-First Manifesto & Policy Arena', 'quiettruths' ); ?></div>
		<h2 class="qt-h2"><?php esc_html_e( 'The Blind Ballot: Judge the Position Before the Party Color.', 'quiettruths' ); ?></h2>
		<p class="qt-lead">
			<?php esc_html_e( 'In Kenyan politics, ideas are often dismissed or applauded the instant we hear who spoke them. Below, party symbols, coalition colors, and portraits are hidden first—so you can compare competing political positions side by side on substance alone.', 'quiettruths' ); ?>
		</p>
	</div>

	<div class="qt-card" style="padding:0.9rem 1.35rem;">
		<div class="qt-stat-label"><?php esc_html_e( 'Your Blind Ballot Progress', 'quiettruths' ); ?></div>
		<div id="qt-bb-progress" style="font-family:var(--qt-font-serif); font-size:1.3rem; font-weight:700; color:var(--qt-emerald-dark); margin-top:0.2rem;">
			<?php echo esc_html( '0 of ' . count( $issues ) . ' Issues Evaluated' ); ?>
		</div>
	</div>
</section>

<!-- Political Issue Selector -->
<section style="margin-bottom:1.75rem;">
	<div class="qt-role-label" style="color:var(--qt-ink-subtle); margin-bottom:0.65rem;">
		<?php esc_html_e( 'Select a Live Kenyan Political Battleground', 'quiettruths' ); ?>
	</div>
	<div class="qt-grid-4" id="qt-bb-issue-tabs">
		<?php foreach ( $issues as $idx => $iss ) : ?>
			<button type="button" class="qt-selector-card <?php echo 0 === $idx ? 'is-active' : ''; ?>" data-issue-id="<?php echo esc_attr( $iss['id'] ); ?>">
				<div style="display:flex; justify-content:space-between; align-items:center; width:100%; margin-bottom:0.45rem;">
					<span class="qt-role-label" style="opacity:0.9;"><?php echo esc_html( 'ISSUE 0' . ( $idx + 1 ) ); ?></span>
					<span class="qt-bb-tab-picked" data-picked-badge="<?php echo esc_attr( $iss['id'] ); ?>" style="font-family:var(--qt-font-mono); font-size:0.65rem;"></span>
				</div>
				<strong style="font-family:var(--qt-font-serif); font-size:0.95rem; line-height:1.3;"><?php echo esc_html( $iss['title'] ); ?></strong>
			</button>
		<?php endforeach; ?>
	</div>
</section>

<!-- Active Blind Ballot Arena -->
<section class="qt-card-lg qt-pad" id="qt-blind-ballot-arena">
	<!-- Anti-bot Honeypot (hidden from real readers) -->
	<div style="position:absolute; left:-9999px; width:1px; height:1px; overflow:hidden;" aria-hidden="true">
		<input type="text" id="qt-bb-hp" name="website_url_hp" tabindex="-1" autocomplete="off">
	</div>

	<div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:1rem; border-bottom:1px solid var(--qt-border); padding-bottom:1.2rem; margin-bottom:1.25rem;">
		<div>
			<div class="qt-role-label" id="qt-bb-anchor" style="color:var(--qt-azure);"><?php echo esc_html( $first['constitutionalAnchor'] ); ?></div>
			<h3 id="qt-bb-title" style="margin:0.3rem 0 0; font-family:var(--qt-font-serif); font-size:1.75rem;"><?php echo esc_html( $first['title'] ); ?></h3>
			<p id="qt-bb-subtitle" style="margin:0.3rem 0 0; font-size:0.9rem; color:var(--qt-ink-muted);"><?php echo esc_html( $first['subtitle'] ); ?></p>
		</div>

		<button type="button" id="qt-bb-reveal-btn" class="qt-btn qt-btn-primary">
			<?php esc_html_e( 'Reveal Political Source', 'quiettruths' ); ?>
		</button>
	</div>

	<div id="qt-bb-step-hint" class="qt-subpanel" style="margin-bottom:1.25rem; font-family:var(--qt-font-mono); font-size:0.75rem; background:var(--qt-emerald-soft); border-color:rgba(5,150,105,0.25);">
		<?php esc_html_e( 'Step 1: Read Positions A, B, and C below in neutral typography and bookmark the position you agree with most—before revealing which coalition or caucus authored it.', 'quiettruths' ); ?>
	</div>

	<!-- 3 Position Cards Rendered Server-Side for SEO & Updated Dynamically via JS -->
	<div class="qt-grid-3" id="qt-bb-cards-grid">
		<?php foreach ( $first['positions'] as $pos ) : ?>
			<div class="qt-position-card" data-pos-label="<?php echo esc_attr( $pos['label'] ); ?>">
				<div>
					<div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--qt-border); padding-bottom:0.65rem; margin-bottom:0.85rem;">
						<span class="qt-badge qt-badge-emerald"><?php echo esc_html( $pos['label'] ); ?></span>
						<span class="qt-role-label" style="color:var(--qt-ink-subtle);"><?php esc_html_e( 'Identity Blinded', 'quiettruths' ); ?></span>
					</div>
					<h4 style="margin:0 0 0.85rem; font-family:var(--qt-font-serif); font-size:1.12rem; line-height:1.35;"><?php echo esc_html( $pos['headline'] ); ?></h4>
					<div class="qt-role-label" style="color:var(--qt-ink-subtle);"><?php esc_html_e( 'What This Camp Proposes', 'quiettruths' ); ?></div>
					<p style="font-size:0.82rem; color:var(--qt-ink-muted); margin:0.25rem 0 0.85rem;"><?php echo esc_html( $pos['proposal'] ); ?></p>
					<div class="qt-role-label" style="color:var(--qt-ink-subtle);"><?php esc_html_e( 'Laws or Institutions Changed', 'quiettruths' ); ?></div>
					<p style="font-size:0.82rem; font-weight:600; margin:0.25rem 0 0.9rem;"><?php echo esc_html( $pos['institutionsChanged'] ); ?></p>

					<div class="qt-subpanel" style="background:#FFFFFF; margin-bottom:0.55rem; padding:0.75rem;">
						<div class="qt-role-label" style="color:var(--qt-azure);"><?php esc_html_e( 'Stated Political Case For', 'quiettruths' ); ?></div>
						<p style="font-size:0.76rem; color:var(--qt-ink-muted); margin:0.25rem 0 0;"><?php echo esc_html( $pos['argumentFor'] ); ?></p>
					</div>
					<div class="qt-subpanel" style="background:#FFFFFF; padding:0.75rem;">
						<div class="qt-role-label" style="color:var(--qt-crimson);"><?php esc_html_e( 'Main Criticism Raised By Opponents', 'quiettruths' ); ?></div>
						<p style="font-size:0.76rem; color:var(--qt-ink-muted); margin:0.25rem 0 0;"><?php echo esc_html( $pos['mainCriticism'] ); ?></p>
					</div>
				</div>

				<div style="margin-top:1.1rem; padding-top:0.9rem; border-top:1px solid var(--qt-border);">
					<button type="button" class="qt-btn qt-btn-outline qt-bb-pick-btn" data-pick="<?php echo esc_attr( $pos['label'] ); ?>" style="width:100%;">
						<?php echo esc_html( 'Bookmark ' . $pos['label'] . ' on Substance' ); ?>
					</button>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<!-- Where Rival Camps Quietly Agree -->
	<div class="qt-subpanel" style="margin-top:1.5rem; background:var(--qt-azure-soft); border-color:rgba(2,132,199,0.28);">
		<div class="qt-role-label" style="color:var(--qt-azure);"><?php esc_html_e( 'Where Rival Political Camps Quietly Agree in Writing', 'quiettruths' ); ?></div>
		<p id="qt-bb-agreement" style="margin:0.4rem 0 0; font-size:0.9rem; color:var(--qt-ink);"><?php echo esc_html( $first['quietAgreement'] ); ?></p>
	</div>
</section>

<?php
get_footer();
