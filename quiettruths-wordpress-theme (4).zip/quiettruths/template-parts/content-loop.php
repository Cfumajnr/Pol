<?php
/**
 * Quiet Truths — Shared Post, Archive & Search Loop Partial
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="qt-page-hero">
	<div class="qt-page-hero-copy">
		<div class="qt-eyebrow"><?php esc_html_e( 'Editorial Dispatches & Political Archive', 'quiettruths' ); ?></div>
		<h2 class="qt-h2">
			<?php
			if ( is_search() ) {
				printf(
					esc_html__( 'Search Results for: %s', 'quiettruths' ),
					esc_html( get_search_query() )
				);
			} elseif ( is_archive() ) {
				echo wp_kses_post( get_the_archive_title() );
			} elseif ( is_home() ) {
				esc_html_e( 'Quiet Truths Political Dispatches', 'quiettruths' );
			} else {
				esc_html_e( 'Quiet Truths Political Archive', 'quiettruths' );
			}
			?>
		</h2>
		<p class="qt-lead">
			<?php esc_html_e( 'Primary-source political records, editorial dispatches, and institutional filings from the Quiet Truths civic desk.', 'quiettruths' ); ?>
		</p>
	</div>
</section>

<?php if ( have_posts() ) : ?>
	<div class="qt-grid-2">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'qt-card qt-pad' ); ?>>
				<div class="qt-role-label" style="color:var(--qt-azure);"><?php echo esc_html( get_the_date() ); ?></div>
				<h3 style="margin:0.4rem 0 0.65rem; font-family:var(--qt-font-serif); font-size:1.35rem;">
					<a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( get_the_title() ); ?></a>
				</h3>
				<div style="font-size:0.9rem; color:var(--qt-ink-muted); margin-bottom:1rem;">
					<?php echo wp_kses_post( get_the_excerpt() ); ?>
				</div>
				<a href="<?php echo esc_url( get_permalink() ); ?>" class="qt-btn qt-btn-outline"><?php esc_html_e( 'Read Full Record →', 'quiettruths' ); ?></a>
			</article>
			<?php
		endwhile;
		?>
	</div>
	<div style="margin-top:2rem;">
		<?php the_posts_pagination(); ?>
	</div>
<?php else : ?>
	<div class="qt-card qt-pad">
		<p><?php esc_html_e( 'No political records matched your query. Return to The Ground to explore all 47 counties.', 'quiettruths' ); ?></p>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="qt-btn qt-btn-primary"><?php esc_html_e( 'Return to The Ground', 'quiettruths' ); ?></a>
	</div>
<?php endif; ?>
