<?php
/**
 * Quiet Truths — Multi-Page Theme Footer & WordPress Footer Menu
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
	</div><!-- /.qt-container -->
</main><!-- /#qt-main-content -->

<footer class="qt-footer" role="contentinfo">
	<div class="qt-container">
		<div class="qt-grid-3">
			<div>
				<div style="display:flex; align-items:center; gap:0.65rem; margin-bottom:0.6rem;">
					<img src="<?php echo esc_url( QT_THEME_URI . '/assets/favicons/favicon.svg' ); ?>" alt="" width="34" height="34" style="border-radius:8px;">
					<strong style="font-family:var(--qt-font-serif); font-size:1.2rem;">QUIET TRUTHS · quiettruths.co.ke</strong>
				</div>
				<div class="qt-footer-identity"><?php esc_html_e( 'Quiet Truths — The Record Speaks, County by County.', 'quiettruths' ); ?></div>
				<p style="font-size:0.78rem; color:rgba(236,253,245,0.82); margin:0; line-height:1.6;">
					<?php esc_html_e( 'An independent, non-partisan English-language Kenyan political platform anchored strictly in primary constitutional texts, Parliamentary Hansard transcripts, IEBC gazette notices, and official party manifestos.', 'quiettruths' ); ?>
				</p>
			</div>

			<div>
				<div style="font-family:var(--qt-font-mono); font-size:0.7rem; text-transform:uppercase; letter-spacing:0.08em; color:var(--qt-gold-bright); font-weight:700;">
					<?php esc_html_e( 'All 6 Civic Destinations', 'quiettruths' ); ?>
				</div>
				<?php
				if ( has_nav_menu( 'footer' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'footer',
							'container'      => false,
							'menu_class'     => 'qt-footer-menu',
							'depth'          => 1,
							'fallback_cb'    => 'qt_footer_menu_fallback',
						)
					);
				} else {
					qt_footer_menu_fallback();
				}
				?>
			</div>

			<div>
				<div style="font-family:var(--qt-font-mono); font-size:0.7rem; text-transform:uppercase; letter-spacing:0.08em; color:var(--qt-gold-bright); font-weight:700;">
					<?php esc_html_e( 'Primary Institutional Sources & Security', 'quiettruths' ); ?>
				</div>
				<p style="font-size:0.78rem; color:rgba(236,253,245,0.82); margin:0.55rem 0 0; line-height:1.6;">
					<?php esc_html_e( 'Constitution of Kenya (2010) · Parliament of Kenya Hansard & Bills Tracker · Kenya Gazette · IEBC Notices · Office of the Registrar of Political Parties (ORPP). Protected by nonce-verified forms & strict security headers.', 'quiettruths' ); ?>
				</p>
			</div>
		</div>

		<div style="border-top:1px solid rgba(255,255,255,0.14); margin-top:1.75rem; padding-top:1.1rem; display:flex; flex-wrap:wrap; justify-content:space-between; gap:0.75rem; font-family:var(--qt-font-mono); font-size:0.7rem; color:rgba(236,253,245,0.7);">
			<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> quiettruths.co.ke — <?php esc_html_e( 'Built for Informed Kenyan Citizenship.', 'quiettruths' ); ?></span>
			<span><?php esc_html_e( 'Articles 10, 38 & 118 Civic Access Standard', 'quiettruths' ); ?></span>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
