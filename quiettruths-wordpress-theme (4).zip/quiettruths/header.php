<?php
/**
 * Quiet Truths — Multi-Page Theme Header & WordPress Primary Menu
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link" href="#qt-main-content"><?php esc_html_e( 'Skip to main political content', 'quiettruths' ); ?></a>

<!-- Top Institutional Utility & Data-Lite Bar -->
<div class="qt-utility-bar">
	<div class="qt-container qt-utility-inner">
		<div class="qt-utility-meta">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="qt-domain-badge">
				<span class="qt-gold-dot" aria-hidden="true"></span>
				<span>quiettruths.co.ke</span>
			</a>
			<span class="qt-sep" aria-hidden="true">|</span>
			<span><?php esc_html_e( 'Nairobi, Kenya', 'quiettruths' ); ?></span>
			<span class="qt-sep" aria-hidden="true">|</span>
			<span><?php esc_html_e( 'Gazetted Poll:', 'quiettruths' ); ?> <strong>Tue, 10 Aug 2027</strong></span>
			<span class="qt-sep" aria-hidden="true">|</span>
			<span><?php esc_html_e( 'Sec. 26 Harambee Cutoff:', 'quiettruths' ); ?> <strong style="color:var(--qt-crimson);">9 Dec 2026</strong></span>
		</div>

		<button type="button" id="qt-datalite-toggle" class="qt-datalite-btn" aria-pressed="false" title="<?php esc_attr_e( 'Strip vector maps and graphics for low-bundle mobile browsing', 'quiettruths' ); ?>">
			<span id="qt-datalite-label"><?php esc_html_e( 'Data-Lite Mode', 'quiettruths' ); ?></span>
		</button>
	</div>
</div>

<!-- Signature Highland Emerald Masthead -->
<header class="qt-masthead" role="banner">
	<div class="qt-container qt-masthead-top">
		<div>
			<div class="qt-brand-pill">
				<span class="qt-gold-dot" aria-hidden="true"></span>
				<span><?php esc_html_e( 'Independent Kenyan Political Atlas & Official Record', 'quiettruths' ); ?></span>
			</div>
			<div class="qt-brand-row">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Quiet Truths Home', 'quiettruths' ); ?>">
					<img src="<?php echo esc_url( QT_THEME_URI . '/assets/favicons/favicon.svg?ver=' . QT_THEME_VERSION ); ?>" alt="" class="qt-brand-logo" width="48" height="48">
				</a>

				<div>
					<h1 class="qt-site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'QUIET TRUTHS', 'quiettruths' ); ?></a>
					</h1>
				</div>
			</div>
		</div>

		<div style="display:flex; flex-direction:column; align-items:flex-end; gap:0.75rem;">
			<p class="qt-site-tagline">
				<strong><?php esc_html_e( 'Quiet Truths — The Record Speaks, County by County.', 'quiettruths' ); ?></strong>
				<span><?php esc_html_e( '“From county hall to every ward: named offices, named sources, named gaps.”', 'quiettruths' ); ?></span>
			</p>
			<button type="button" id="qt-mobile-menu-btn" class="qt-mobile-menu-toggle" aria-expanded="false" aria-controls="qt-nav-drawer">
				<span>&#9776; <?php esc_html_e( 'Pages Menu (6)', 'quiettruths' ); ?></span>
			</button>
		</div>
	</div>

	<!-- Multi-Page WordPress Navigation Menu -->
	<nav id="qt-nav-drawer" class="qt-nav-wrap" role="navigation" aria-label="<?php esc_attr_e( 'Primary Civic Pages', 'quiettruths' ); ?>">
		<div class="qt-container">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_id'        => 'qt-primary-menu',
						'menu_class'     => 'qt-primary-menu',
						'depth'          => 1,
						'walker'         => new QT_Primary_Nav_Walker(),
						'fallback_cb'    => 'qt_primary_menu_fallback',
					)
				);
			} else {
				qt_primary_menu_fallback();
			}
			?>
		</div>
	</nav>
</header>

<main id="qt-main-content" class="qt-main" role="main">
	<div class="qt-container">
