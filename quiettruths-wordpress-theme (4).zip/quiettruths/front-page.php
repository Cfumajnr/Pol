<?php
/**
 * Quiet Truths — Static Front Page Template (Loads Page 01: The Ground)
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'page', 'the-ground' );
