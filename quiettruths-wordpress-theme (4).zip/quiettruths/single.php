<?php
/**
 * Quiet Truths — Single Article / Political Dispatch Template
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	$pt_obj   = get_post_type_object( get_post_type() );
	$pt_label = ( $pt_obj && isset( $pt_obj->labels->singular_name ) ) ? $pt_obj->labels->singular_name : __( 'Dispatch', 'quiettruths' );
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'qt-card-lg qt-pad' ); ?> style="max-width:880px; margin:0 auto;">
		<header style="border-bottom:1px solid var(--qt-border); padding-bottom:1.25rem; margin-bottom:1.5rem;">
			<div class="qt-role-label" style="color:var(--qt-azure);">
				<?php echo esc_html( get_the_date() . ' · ' . $pt_label ); ?>
			</div>
			<h2 class="qt-h2" style="margin-top:0.4rem;"><?php echo esc_html( get_the_title() ); ?></h2>
		</header>
		<div style="font-size:1.02rem; line-height:1.8; color:var(--qt-ink);">
			<?php the_content(); ?>
		</div>
	</article>
	<?php
endwhile;

get_footer();
