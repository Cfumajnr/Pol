<?php
/**
 * Quiet Truths — Default Standard Page Template
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'qt-card-lg qt-pad' ); ?>>
		<header style="border-bottom:1px solid var(--qt-border); padding-bottom:1.1rem; margin-bottom:1.4rem;">
			<div class="qt-eyebrow"><?php esc_html_e( 'Quiet Truths Official Page', 'quiettruths' ); ?></div>
			<h2 class="qt-h2"><?php echo esc_html( get_the_title() ); ?></h2>
		</header>
		<div style="font-size:1rem; line-height:1.75; color:var(--qt-ink);">
			<?php the_content(); ?>
		</div>
	</article>
	<?php
endwhile;

get_footer();
