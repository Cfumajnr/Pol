<?php
/**
 * Quiet Truths — Political Archive Template
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/content', 'loop' );
get_footer();
