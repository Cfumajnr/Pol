<?php
/**
 * Quiet Truths — Secure Search Results Template
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/content', 'loop' );
get_footer();
