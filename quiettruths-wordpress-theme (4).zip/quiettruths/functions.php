<?php
/**
 * Quiet Truths — Highland Emerald WordPress Theme Functions
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'QT_THEME_VERSION', '1.1.2' );
define( 'QT_THEME_DIR', get_template_directory() );
define( 'QT_THEME_URI', get_template_directory_uri() );

require_once QT_THEME_DIR . '/inc/security.php';
require_once QT_THEME_DIR . '/inc/political-data.php';
require_once QT_THEME_DIR . '/inc/cpt-and-meta.php';
require_once QT_THEME_DIR . '/inc/theme-setup-pages-menus.php';

/**
 * Core Theme Setup & WordPress Menu Locations
 */
function qt_theme_setup() {
	load_theme_textdomain( 'quiettruths', QT_THEME_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
	// The Quiet Truths wordmark and QT record mark are hard-locked: no WP Custom Logo override.
	remove_theme_support( 'custom-logo' );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Civic Navigation (6 Core Pages)', 'quiettruths' ),
			'footer'  => __( 'Footer Civic Navigation', 'quiettruths' ),
		)
	);
}
add_action( 'after_setup_theme', 'qt_theme_setup' );

/**
 * Repair the stored WordPress site identity left over from the rejected old wordmark.
 *
 * The masthead itself is hard-coded, but the stale database option can still appear in
 * WordPress-generated titles, feeds, emails and admin screens. We only overwrite the
 * old/default values; a legitimate custom site name set by the owner is preserved.
 */
function qt_repair_stale_site_identity() {
	// PCRE hex spelling keeps the rejected wordmark out of the theme source entirely.
	$stale_pattern     = '/\x6b\x65\x6e\x79\x61\s*47/i';
	$campaign_pattern  = '/every\s+county.*every\s+leader.*every\s+story/i';
	$site_name         = (string) get_option( 'blogname' );
	$site_description  = (string) get_option( 'blogdescription' );

	if ( preg_match( $stale_pattern, $site_name ) || '' === trim( $site_name ) || 'WordPress' === $site_name ) {
		update_option( 'blogname', __( 'Quiet Truths', 'quiettruths' ) );
	}

	if (
		preg_match( $stale_pattern, $site_description )
		|| preg_match( $campaign_pattern, $site_description )
		|| 'Just another WordPress site' === $site_description
	) {
		update_option( 'blogdescription', __( 'Quiet Truths — The Record Speaks, County by County.', 'quiettruths' ) );
	}
}
add_action( 'after_switch_theme', 'qt_repair_stale_site_identity' );
add_action( 'init', 'qt_repair_stale_site_identity', 1 );

/**
 * Ensure WP's optional Site Icon cannot override the bundled QT record-mark suite.
 */
add_filter( 'get_site_icon_url', '__return_empty_string', 99 );

/**
 * Inject Bespoke Highland Emerald Favicon Suite in <head> with a version cache-buster.
 */
function qt_output_favicons() {
	$fav_base = trailingslashit( QT_THEME_URI ) . 'assets/favicons/';
	$fav_ver  = '?ver=' . rawurlencode( QT_THEME_VERSION );
	echo '<meta name="theme-color" content="#06221B">' . "\n";
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( $fav_base . 'favicon.svg' . $fav_ver ) . '">' . "\n";
		echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $fav_base . 'favicon-32x32.png' . $fav_ver ) . '">' . "\n";
		echo '<link rel="icon" type="image/png" sizes="16x16" href="' . esc_url( $fav_base . 'favicon-16x16.png' . $fav_ver ) . '">' . "\n";
		echo '<link rel="shortcut icon" href="' . esc_url( $fav_base . 'favicon.ico' . $fav_ver ) . '">' . "\n";
		echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url( $fav_base . 'apple-touch-icon.png' . $fav_ver ) . '">' . "\n";
		echo '<link rel="manifest" href="' . esc_url( $fav_base . 'site.webmanifest' . $fav_ver ) . '">' . "\n";
	}
}
add_action( 'wp_head', 'qt_output_favicons', 5 );

/**
 * Front-page exact Quiet Truths link title + zero-dependency SEO / Open Graph metadata.
 */
function qt_pre_get_document_title( $title ) {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) ) {
		return $title;
	}

	if ( is_front_page() ) {
		return __( 'Quiet Truths — The Record Speaks, County by County. | Quiet Truths', 'quiettruths' );
	}

	return $title;
}
add_filter( 'pre_get_document_title', 'qt_pre_get_document_title', 20 );

function qt_output_seo_meta() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) ) {
		return;
	}

	$is_front    = is_front_page();
	$title       = $is_front ? __( 'Quiet Truths — The Record Speaks, County by County. | Quiet Truths', 'quiettruths' ) : wp_get_document_title();
	$description = $is_front
		? __( 'Quiet Truths — The Record Speaks, County by County. Trace all 47 counties, 290 constituencies and 1,450 wards through source-backed representation, from governor and senator to MP and MCA, with gaps marked plainly on quiettruths.co.ke.', 'quiettruths' )
		: __( 'Independent, non-partisan Kenyan political records, parliamentary comparisons, coalition mapping, public participation tools, and primary-source verification.', 'quiettruths' );
	$url         = $is_front ? home_url( '/' ) : ( is_singular() ? get_permalink() : home_url( '/' ) );
	$image       = add_query_arg( 'ver', QT_THEME_VERSION, QT_THEME_URI . '/screenshot.png' );

	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . PHP_EOL;
	echo '<meta property="og:type" content="website">' . PHP_EOL;
	echo '<meta property="og:site_name" content="' . esc_attr( __( 'Quiet Truths', 'quiettruths' ) ) . '">' . PHP_EOL;
	echo '<meta property="og:locale" content="en_KE">' . PHP_EOL;
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . PHP_EOL;
	echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . PHP_EOL;
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . PHP_EOL;
	echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . PHP_EOL;
	echo '<meta property="og:image:width" content="1200">' . PHP_EOL;
	echo '<meta property="og:image:height" content="900">' . PHP_EOL;
	echo '<meta name="twitter:card" content="summary_large_image">' . PHP_EOL;
	echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . PHP_EOL;
	echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '">' . PHP_EOL;
	echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . PHP_EOL;
}
add_action( 'wp_head', 'qt_output_seo_meta', 2 );

/**
 * Enqueue Theme Styles & Interactive Civic Scripts
 */
function qt_enqueue_assets() {
	// Typography is fully self-contained: native serif / sans / mono stacks in main.css.

	wp_enqueue_style(
		'qt-main-style',
		QT_THEME_URI . '/assets/css/main.css',
		array(),
		QT_THEME_VERSION
	);

	wp_enqueue_script(
		'qt-main-script',
		QT_THEME_URI . '/assets/js/main.js',
		array(),
		QT_THEME_VERSION,
		true
	);

	wp_localize_script(
		'qt-main-script',
		'QuietTruthsData',
		array(
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'nonce'        => wp_create_nonce( 'qt_civic_nonce' ),
			'homeUrl'      => home_url( '/' ),
			'counties'     => qt_get_all_47_counties(),
			'hierarchyUrl' => QT_THEME_URI . '/assets/data/kenya-representation.json',
			'countyLeadership' => qt_get_county_leadership(),
			'representationSources' => qt_get_representation_sources(),
			'blindBallot'  => qt_get_blind_ballot_issues(),
			'coalitions'   => qt_get_coalition_data(),
			'bills'        => qt_get_open_floor_bills(),
			'tallies'      => get_option( 'qt_blind_ballot_tallies', array() ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'qt_enqueue_assets' );
