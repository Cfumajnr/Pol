<?php
/**
 * Template Name: 06 - The Quiet Record
 * Description: Primary-Source Political Verification pairing viral claims with Kenya Gazette notices, Statutes & shareable Evidence Cards.
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$verifications = qt_get_quiet_record_verifications();
?>

<section class="qt-page-hero">
	<div class="qt-page-hero-copy">
		<div class="qt-eyebrow"><?php esc_html_e( 'Page 06 · Primary-Source Political Verification', 'quiettruths' ); ?></div>
		<h2 class="qt-h2"><?php esc_html_e( 'The Quiet Record: Rumour Placed Beside the Gazette & Statute Book.', 'quiettruths' ); ?></h2>
		<p class="qt-lead">
			<?php esc_html_e( 'Doctored gazette notices, clipped rally videos, and fabricated party circulars travel fastest in closed messaging groups. Each verification file below pairs a viral political claim directly with the unedited primary institutional document—and generates a lightweight Evidence Card ready to paste into WhatsApp or Telegram.', 'quiettruths' ); ?>
		</p>
	</div>

	<div style="width:300px; max-width:100%;">
		<input type="search" id="qt-qr-search" class="qt-input" placeholder="<?php esc_attr_e( 'Search gazette, IEBC, ORPP, harambee...', 'quiettruths' ); ?>" aria-label="<?php esc_attr_e( 'Search Quiet Record Verifications', 'quiettruths' ); ?>">
	</div>
</section>

<section style="display:flex; flex-direction:column; gap:1.5rem;" id="qt-qr-list">
	<?php foreach ( $verifications as $item ) : ?>
		<?php
		$badge_class = 'qt-badge-solid-gold';
		if ( false !== strpos( $item['badge'], 'CONTRADICTED' ) ) {
			$badge_class = 'qt-badge-solid-crimson';
		} elseif ( false !== strpos( $item['badge'], 'CONFIRMED' ) ) {
			$badge_class = 'qt-badge-solid-emerald';
		}
		?>
		<article class="qt-card-lg qt-qr-item">
			<div style="background:var(--qt-bg-subtle); border-bottom:1px solid var(--qt-border); padding:0.85rem 1.5rem; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:0.75rem;">
				<span class="qt-badge <?php echo esc_attr( $badge_class ); ?>"><?php echo esc_html( $item['badge'] ); ?></span>
				<span style="font-family:var(--qt-font-mono); font-size:0.74rem; color:var(--qt-ink-subtle);">
					<?php echo esc_html( 'Circulating In: ' . $item['where'] ); ?>
				</span>
			</div>

			<div class="qt-split-ledger">
				<div class="qt-pad" style="background:rgba(242,247,245,0.55);">
					<span class="qt-badge qt-badge-crimson"><?php esc_html_e( 'Viral Claim Circulating Online', 'quiettruths' ); ?></span>
					<blockquote class="qt-quote" style="margin-top:0.85rem;">
						<?php echo esc_html( $item['claim'] ); ?>
					</blockquote>
				</div>

				<div class="qt-pad">
					<span class="qt-badge qt-badge-azure"><?php esc_html_e( 'Unedited Primary Institutional Record', 'quiettruths' ); ?></span>
					<h3 style="margin:0.75rem 0 0.2rem; font-family:var(--qt-font-serif); font-size:1.12rem;">
						<?php echo esc_html( $item['docTitle'] ); ?>
					</h3>
					<div style="font-family:var(--qt-font-mono); font-size:0.72rem; color:var(--qt-ink-subtle); margin-bottom:0.75rem;">
						<?php echo esc_html( 'Issuing Authority: ' . $item['authority'] ); ?>
					</div>
					<p style="font-size:0.9rem; color:var(--qt-ink-muted); margin:0 0 1rem;">
						<?php echo esc_html( $item['finding'] ); ?>
					</p>

					<div class="qt-subpanel" style="background:var(--qt-emerald-soft); border-color:rgba(5,150,105,0.28);">
						<div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:0.5rem; margin-bottom:0.5rem;">
							<span class="qt-role-label" style="color:var(--qt-emerald-dark);"><?php esc_html_e( 'Shareable WhatsApp / Telegram Evidence Card', 'quiettruths' ); ?></span>
							<button type="button" class="qt-btn qt-btn-primary qt-copy-evidence-btn" data-share-text="<?php echo esc_attr( $item['shareText'] ); ?>" style="padding:0.38rem 0.85rem; font-size:0.7rem;">
								<?php esc_html_e( 'Copy Evidence Card', 'quiettruths' ); ?>
							</button>
						</div>
						<div style="font-family:var(--qt-font-mono); font-size:0.74rem; color:var(--qt-ink);">
							<?php echo esc_html( $item['shareText'] ); ?>
						</div>
					</div>
				</div>
			</div>
		</article>
	<?php endforeach; ?>
</section>

<?php
get_footer();
