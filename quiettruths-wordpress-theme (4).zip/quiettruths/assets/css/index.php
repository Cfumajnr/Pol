<?php
/**
 * Quiet Truths — Directory Silence Guard
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Silence is golden.
