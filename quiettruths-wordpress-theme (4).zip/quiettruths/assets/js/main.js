/**
 * Quiet Truths (quiettruths.co.ke) — Interactive Multi-Page WordPress Civic Engine
 * Built from scratch · Zero external JS dependencies · XSS-safe DOM updates
 */
(function () {
  'use strict';

  var cfg = window.QuietTruthsData || {};

  function copySafe(text, onDone) {
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(onDone).catch(function () {
        fallbackCopy(text, onDone);
      });
    } else {
      fallbackCopy(text, onDone);
    }
  }

  function fallbackCopy(text, onDone) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
    } catch (e) {}
    document.body.removeChild(ta);
    if (onDone) onDone();
  }

  /* 1. Mobile Navigation Drawer */
  var mobileBtn = document.getElementById('qt-mobile-menu-btn');
  var navDrawer = document.getElementById('qt-nav-drawer');
  if (mobileBtn && navDrawer) {
    mobileBtn.addEventListener('click', function () {
      var open = navDrawer.classList.toggle('is-open');
      mobileBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* 2. Persistent Data-Lite Mode Across Multi-Page Navigation */
  var dlBtn = document.getElementById('qt-datalite-toggle');
  var dlLabel = document.getElementById('qt-datalite-label');
  function applyDataLite(enabled) {
    document.body.classList.toggle('qt-data-lite', enabled);
    if (dlBtn) dlBtn.setAttribute('aria-pressed', enabled ? 'true' : 'false');
    if (dlLabel) dlLabel.textContent = enabled ? 'Data-Lite: ON (~14 KB)' : 'Data-Lite Mode';
  }
  var savedDL = false;
  try {
    savedDL = window.localStorage.getItem('qt_data_lite') === '1';
  } catch (e) {}
  applyDataLite(savedDL);

  if (dlBtn) {
    dlBtn.addEventListener('click', function () {
      savedDL = !savedDL;
      try {
        window.localStorage.setItem('qt_data_lite', savedDL ? '1' : '0');
      } catch (e) {}
      applyDataLite(savedDL);
      if (!savedDL && window.qtLoadHierarchy) {
        window.qtLoadHierarchy();
      }
    });
  }

  /* 3. Page 01 — The Ground: 47-County Atlas & 47 / 290 / 1,450 Representation Explorer */
  var atlasEl = document.getElementById('qt-ground-atlas');
  if (atlasEl && Array.isArray(cfg.counties) && cfg.counties.length) {
    var activeRegion = 'All';
    var searchInput = document.getElementById('qt-county-search');
    var countyButtons = Array.prototype.slice.call(document.querySelectorAll('.qt-county-btn'));
    var mapNodes = Array.prototype.slice.call(document.querySelectorAll('.qt-map-node'));
    var leadershipCards = Array.prototype.slice.call(document.querySelectorAll('#qt-leadership-grid .qt-leader-card'));
    var explorerSearch = document.getElementById('qt-explorer-search');
    var explorerResults = document.getElementById('qt-explorer-results');
    var explorerDetail = document.getElementById('qt-explorer-detail');
    var explorerStatus = document.getElementById('qt-explorer-status');
    var breadcrumbEl = document.getElementById('qt-explorer-breadcrumb');
    var explorerTabButtons = Array.prototype.slice.call(document.querySelectorAll('[data-explorer-tab]'));
    var selectedCountyBtn = document.querySelector('.qt-county-btn.is-selected');

    var leadershipByCode = {};
    (cfg.countyLeadership || []).forEach(function (row) {
      leadershipByCode[row.code] = row;
    });
    var sourceById = {};
    (cfg.representationSources || []).forEach(function (source) {
      sourceById[source.id] = source;
    });

    var hierarchy = null;
    var hierarchyLoading = false;
    var hierarchyError = '';
    var countyByCode = {};
    var hierarchySearchIndex = {};
    var connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    var lazyHierarchy = document.body.classList.contains('qt-data-lite') || Boolean(connection && connection.saveData);
    var state = {
      countyCode: selectedCountyBtn ? selectedCountyBtn.getAttribute('data-code') : '047',
      tab: 'constituencies',
      conCode: '',
      wardCode: '',
      query: ''
    };

    function makeEl(tag, className, text) {
      var node = document.createElement(tag);
      if (className) node.className = className;
      if (typeof text !== 'undefined') node.textContent = text;
      return node;
    }

    function setTxt(id, value) {
      var node = document.getElementById(id);
      if (node) node.textContent = value;
    }

    function cleanBits(values) {
      var out = [];
      values.forEach(function (value) {
        if (value) out.push(String(value));
      });
      return out;
    }

    function personText(person) {
      if (!person) return '';
      return cleanBits([person.name, person.party, person.statusLabel, person.sourceLabel, person.note]).join(' ');
    }

    function personMeta(person) {
      if (!person) return 'Record pending verification';
      var source = sourceById[person.source];
      return cleanBits([
        person.party,
        person.statusLabel,
        person.sourceLabel || (source ? source.short : ''),
        person.verified ? 'Checked ' + person.verified : ''
      ]).join(' · ');
    }

    function renderLeadership(code) {
      var record = leadershipByCode[code];
      if (!record) return;
      leadershipCards.forEach(function (card) {
        var role = card.getAttribute('data-role');
        var person = record[role] || {};
        var nameEl = card.querySelector('[data-leader-name]');
        var metaEl = card.querySelector('[data-leader-meta]');
        if (nameEl) nameEl.textContent = person.name || 'Record pending verification';
        if (metaEl) metaEl.textContent = personMeta(person);
      });
    }

    function findCountySummary(code) {
      for (var i = 0; i < cfg.counties.length; i++) {
        if (cfg.counties[i].code === code) return cfg.counties[i];
      }
      return cfg.counties[cfg.counties.length - 1];
    }

    function setExplorerStatus(message, tone) {
      if (!explorerStatus) return;
      explorerStatus.textContent = message;
      explorerStatus.className = 'qt-explorer-status' + (tone ? ' is-' + tone : '');
    }

    function selectCounty(code) {
      var found = findCountySummary(code);
      if (!found) return;

      setTxt('qt-det-code-region', 'COUNTY ' + found.code + ' · ' + found.region.toUpperCase());
      setTxt('qt-det-name', found.name + ' County');
      setTxt('qt-det-const', String(found.constituencies));
      setTxt('qt-det-wards', String(found.wards));
      setTxt('qt-det-voters', found.voters);
      setTxt('qt-det-pulse', found.localPulse);
      renderLeadership(found.code);

      countyButtons.forEach(function (button) {
        button.classList.toggle('is-selected', button.getAttribute('data-code') === code);
      });
      mapNodes.forEach(function (node) {
        var isSel = node.getAttribute('data-code') === code;
        var halo = node.querySelector('.qt-node-halo');
        var dot = node.querySelector('.qt-node-dot');
        if (halo) halo.setAttribute('r', isSel ? '12' : '0');
        if (dot) {
          dot.setAttribute('r', isSel ? '6.5' : '4.2');
          dot.setAttribute('fill', isSel ? '#D97706' : '#059669');
        }
      });

      state.countyCode = code;
      state.conCode = '';
      state.wardCode = '';
      state.query = '';
      if (explorerSearch) explorerSearch.value = '';
      renderExplorer();
      if (hierarchy || !lazyHierarchy) loadHierarchy();
    }

    function filterCounties() {
      var q = searchInput ? searchInput.value.toLowerCase().trim() : '';
      countyButtons.forEach(function (button) {
        var code = button.getAttribute('data-code');
        var county = findCountySummary(code);
        var regMatch = activeRegion === 'All' || county.region === activeRegion;
        var baseText = cleanBits([
          county.name, county.code, county.region, county.governor, county.senator,
          county.womanRep, county.localPulse, hierarchySearchIndex[code] || ''
        ]).join(' ').toLowerCase();
        button.style.display = regMatch && (!q || baseText.indexOf(q) !== -1) ? 'flex' : 'none';
      });
    }

    function buildHierarchyIndex(data) {
      countyByCode = {};
      hierarchySearchIndex = {};
      data.counties.forEach(function (county) {
        countyByCode[county.code] = county;
        var parts = [
          county.name, county.code, county.region,
          county.leadership.governor.name,
          county.leadership.deputyGovernor.name,
          county.leadership.senator.name,
          county.leadership.womanRep.name,
          county.leadership.speaker.name,
          county.leadership.clerk.name
        ];
        county.constituencies.forEach(function (constituency) {
          parts.push(constituency.name, constituency.code, personText(constituency.mp));
          constituency.wards.forEach(function (ward) {
            parts.push(ward.name, ward.code, personText(ward.mca));
          });
        });
        hierarchySearchIndex[county.code] = parts.join(' ').toLowerCase();
      });
    }

    function loadHierarchy() {
      if (hierarchy || hierarchyLoading || !cfg.hierarchyUrl) return;
      hierarchyLoading = true;
      hierarchyError = '';
      setExplorerStatus('Loading the complete 47 / 290 / 1,450 representation directory…', 'loading');
      renderExplorerShell('Loading the local directory. This is a same-origin theme file; no external service is called.');

      function onLoaded(data) {
        if (!data || !Array.isArray(data.counties) || data.counties.length !== 47) {
          throw new Error('Unexpected directory format');
        }
        hierarchy = data;
        buildHierarchyIndex(data);
        hierarchyLoading = false;
        filterCounties();
        renderExplorer();
      }

      function onFailed(message) {
        hierarchyLoading = false;
        hierarchyError = message || 'The local directory could not be loaded.';
        setExplorerStatus(hierarchyError, 'error');
        renderExplorerShell('The local directory could not be loaded. Try again; county leadership remains available above.');
      }

      if (window.fetch) {
        window.fetch(cfg.hierarchyUrl, { credentials: 'same-origin', cache: 'force-cache' })
          .then(function (response) {
            if (!response.ok) throw new Error('Directory request failed (' + response.status + ')');
            return response.json();
          })
          .then(onLoaded)
          .catch(function (error) {
            onFailed(error && error.message ? error.message : 'Network error');
          });
      } else if (window.XMLHttpRequest) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', cfg.hierarchyUrl, true);
        xhr.onreadystatechange = function () {
          if (xhr.readyState !== 4) return;
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              onLoaded(JSON.parse(xhr.responseText));
            } catch (error) {
              onFailed('Directory JSON could not be parsed.');
            }
          } else {
            onFailed('Directory request failed (' + xhr.status + ')');
          }
        };
        xhr.send();
      } else {
        onFailed('This browser cannot load the local directory.');
      }
    }
    window.qtLoadHierarchy = loadHierarchy;

    function currentHierarchyCounty() {
      return hierarchy ? countyByCode[state.countyCode] : null;
    }

    function findConstituency(county, code) {
      if (!county || !code) return null;
      for (var i = 0; i < county.constituencies.length; i++) {
        if (county.constituencies[i].code === code) return county.constituencies[i];
      }
      return null;
    }

    function findWard(county, code) {
      if (!county || !code) return null;
      for (var i = 0; i < county.constituencies.length; i++) {
        var wards = county.constituencies[i].wards;
        for (var j = 0; j < wards.length; j++) {
          if (wards[j].code === code) return { ward: wards[j], constituency: county.constituencies[i] };
        }
      }
      return null;
    }

    function matchesQuery(text) {
      var q = state.query.toLowerCase().trim();
      return !q || String(text).toLowerCase().indexOf(q) !== -1;
    }

    function renderExplorerShell(message) {
      if (explorerResults) {
        explorerResults.textContent = '';
        var note = makeEl('p', 'qt-explorer-empty', message);
        explorerResults.appendChild(note);
        if (!hierarchyLoading) {
          var retry = makeEl('button', 'qt-btn qt-btn-outline', hierarchyError ? 'Retry directory' : 'Load full directory');
          retry.type = 'button';
          retry.addEventListener('click', loadHierarchy);
          explorerResults.appendChild(retry);
        }
      }
      if (explorerDetail) {
        explorerDetail.textContent = '';
        explorerDetail.appendChild(makeEl('p', 'qt-explorer-empty', 'The named leadership chain appears here once a constituency or ward is selected.'));
      }
    }

    function renderBreadcrumb() {
      if (!breadcrumbEl) return;
      breadcrumbEl.textContent = '';
      var summary = findCountySummary(state.countyCode);
      var county = currentHierarchyCounty();
      var constituency = county ? findConstituency(county, state.conCode) : null;
      var found = county ? findWard(county, state.wardCode) : null;
      var crumbs = [
        { label: 'Kenya', action: 'kenya' },
        { label: summary.name + ' County', action: 'county' }
      ];
      if (constituency) crumbs.push({ label: constituency.name, action: 'constituency' });
      if (found) crumbs.push({ label: found.ward.name + ' Ward', action: 'ward' });

      crumbs.forEach(function (crumb, index) {
        if (index) breadcrumbEl.appendChild(document.createTextNode(' › '));
        var button = makeEl('button', 'qt-breadcrumb-btn', crumb.label);
        button.type = 'button';
        if (index === crumbs.length - 1) button.setAttribute('aria-current', 'page');
        button.addEventListener('click', function () {
          if (crumb.action === 'kenya' || crumb.action === 'county') {
            state.conCode = '';
            state.wardCode = '';
          } else if (crumb.action === 'constituency') {
            state.wardCode = '';
          }
          renderExplorer();
        });
        breadcrumbEl.appendChild(button);
      });
    }

    function resultButton(title, subtitle, badge, isActive, onClick) {
      var button = makeEl('button', 'qt-explorer-result' + (isActive ? ' is-active' : ''));
      button.type = 'button';
      var top = makeEl('span', 'qt-explorer-result-top');
      top.appendChild(makeEl('strong', '', title));
      if (badge) top.appendChild(makeEl('span', 'qt-explorer-badge', badge));
      button.appendChild(top);
      button.appendChild(makeEl('span', 'qt-explorer-result-sub', subtitle));
      button.addEventListener('click', onClick);
      return button;
    }

    function renderConstituencyView(county) {
      explorerResults.textContent = '';
      var selected = findConstituency(county, state.conCode);
      if (selected) {
        var back = makeEl('button', 'qt-explorer-back', '← All constituencies');
        back.type = 'button';
        back.addEventListener('click', function () {
          state.conCode = '';
          state.wardCode = '';
          renderExplorer();
        });
        explorerResults.appendChild(back);

        var heading = makeEl('div', 'qt-explorer-group', selected.name + ' · MP ' + selected.mp.name);
        explorerResults.appendChild(heading);
        var shown = 0;
        selected.wards.forEach(function (ward) {
          var text = cleanBits([ward.name, ward.code, personText(ward.mca)]).join(' ');
          if (!matchesQuery(text)) return;
          shown++;
          explorerResults.appendChild(resultButton(
            ward.name + ' Ward',
            personMeta(ward.mca),
            'WARD ' + ward.code,
            state.wardCode === ward.code,
            function () {
              state.conCode = selected.code;
              state.wardCode = ward.code;
              renderExplorer();
            }
          ));
        });
        if (!shown) explorerResults.appendChild(makeEl('p', 'qt-explorer-empty', 'No wards in this constituency match the filter.'));
        setExplorerStatus(county.name + ' · ' + selected.name + ' · ' + shown + ' of ' + selected.wards.length + ' wards shown.', 'ready');
        return;
      }

      var count = 0;
      county.constituencies.forEach(function (constituency) {
        var wardText = constituency.wards.map(function (ward) {
          return cleanBits([ward.name, personText(ward.mca)]).join(' ');
        }).join(' ');
        var text = cleanBits([constituency.name, constituency.code, personText(constituency.mp), wardText]).join(' ');
        if (!matchesQuery(text)) return;
        count++;
        explorerResults.appendChild(resultButton(
          constituency.name,
          'MP: ' + constituency.mp.name + (constituency.mp.party ? ' (' + constituency.mp.party + ')' : '') + ' · ' + constituency.wardsCount + ' wards',
          'CON ' + constituency.code,
          false,
          (function (code) {
            return function () {
              state.conCode = code;
              state.wardCode = '';
              renderExplorer();
            };
          })(constituency.code)
        ));
      });
      if (!count) explorerResults.appendChild(makeEl('p', 'qt-explorer-empty', 'No constituencies match the filter.'));
      setExplorerStatus(county.name + ' · ' + count + ' of ' + county.constituenciesCount + ' constituencies shown.', 'ready');
    }

    function renderAssemblyView(county) {
      explorerResults.textContent = '';
      var shown = 0;
      county.constituencies.forEach(function (constituency) {
        var wardButtons = [];
        constituency.wards.forEach(function (ward) {
          var text = cleanBits([ward.name, ward.code, constituency.name, personText(ward.mca)]).join(' ');
          if (!matchesQuery(text)) return;
          wardButtons.push(resultButton(
            ward.name,
            'MCA: ' + ward.mca.name + (ward.mca.party ? ' (' + ward.mca.party + ')' : '') + ' · ' + personMeta(ward.mca),
            'WARD ' + ward.code,
            state.wardCode === ward.code,
            (function (conCode, wardCode) {
              return function () {
                state.conCode = conCode;
                state.wardCode = wardCode;
                state.tab = 'assembly';
                renderExplorer();
              };
            })(constituency.code, ward.code)
          ));
        });
        if (!wardButtons.length) return;
        shown += wardButtons.length;
        explorerResults.appendChild(makeEl('div', 'qt-explorer-group', constituency.name + ' · ' + wardButtons.length + ' wards'));
        wardButtons.forEach(function (button) {
          explorerResults.appendChild(button);
        });
      });
      if (!shown) explorerResults.appendChild(makeEl('p', 'qt-explorer-empty', 'No wards or MCA records match the filter.'));
      setExplorerStatus(county.name + ' County Assembly · ' + shown + ' of ' + county.wardsCount + ' wards shown.', 'ready');
    }

    function chainRow(label, person) {
      var row = makeEl('div', 'qt-chain-row');
      row.appendChild(makeEl('div', 'qt-role-label', label));
      row.appendChild(makeEl('div', 'qt-chain-name', person && person.name ? person.name : 'Record pending verification'));
      row.appendChild(makeEl('div', 'qt-chain-meta', personMeta(person)));
      if (person && person.note) row.appendChild(makeEl('div', 'qt-chain-note', person.note));
      return row;
    }

    function renderDetail(county) {
      explorerDetail.textContent = '';
      var leadership = leadershipByCode[state.countyCode] || {};
      var constituency = findConstituency(county, state.conCode);
      var found = findWard(county, state.wardCode);
      var title = found ? 'Ward-to-county chain' : constituency ? 'Constituency-to-county chain' : 'Choose a place to trace the chain';
      explorerDetail.appendChild(makeEl('h4', 'qt-chain-title', title));

      if (!found && !constituency) {
        explorerDetail.appendChild(makeEl('p', 'qt-explorer-empty', 'Select a constituency in the Constituencies tab, or a ward in the County Assembly tab, to see the named representative and the offices above them.'));
        var legend = makeEl('div', 'qt-status-legend');
        ['13th Parliament roster · 12 Aug 2026', '2022 gazette · verify', 'Record gap · verify with assembly', 'Vacancy recorded'].forEach(function (label) {
          legend.appendChild(makeEl('span', 'qt-status-chip', label));
        });
        explorerDetail.appendChild(legend);
        return;
      }

      if (found) {
        explorerDetail.appendChild(chainRow('MCA · ' + found.ward.name + ' Ward', found.ward.mca));
      }
      if (constituency) {
        explorerDetail.appendChild(chainRow('MP · ' + constituency.name, constituency.mp));
      }
      explorerDetail.appendChild(chainRow('County Assembly Speaker', leadership.speaker));
      explorerDetail.appendChild(chainRow('County Assembly Clerk', leadership.clerk));
      explorerDetail.appendChild(chainRow('County Governor', leadership.governor));
      explorerDetail.appendChild(chainRow('Deputy Governor', leadership.deputyGovernor));
      explorerDetail.appendChild(chainRow('County Senator', leadership.senator));
      explorerDetail.appendChild(chainRow('Woman Representative', leadership.womanRep));
    }

    function renderExplorer() {
      renderBreadcrumb();
      explorerTabButtons.forEach(function (button) {
        var isActive = button.getAttribute('data-explorer-tab') === state.tab;
        button.classList.toggle('is-active', isActive);
        button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
      });
      if (explorerSearch) {
        explorerSearch.placeholder = state.tab === 'assembly'
          ? 'Filter wards, MCAs or constituencies...'
          : 'Filter constituencies, MPs or wards...';
      }

      if (!hierarchy) {
        var message = hierarchyLoading
          ? 'Loading the same-origin representation directory…'
          : hierarchyError
            ? hierarchyError
            : lazyHierarchy
              ? 'Data-Lite is on. Open a tab or load the directory on demand; the full text drill-down remains available.'
              : 'Opening the representation directory…';
        setExplorerStatus(message, hierarchyError ? 'error' : hierarchyLoading ? 'loading' : '');
        renderExplorerShell(message);
        return;
      }

      var county = currentHierarchyCounty();
      if (!county) {
        setExplorerStatus('No hierarchy found for this county.', 'error');
        renderExplorerShell('No hierarchy found for this county.');
        return;
      }
      if (state.tab === 'assembly') renderAssemblyView(county);
      else renderConstituencyView(county);
      renderDetail(county);
    }

    countyButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        selectCounty(button.getAttribute('data-code'));
      });
    });
    mapNodes.forEach(function (node) {
      node.addEventListener('click', function () {
        selectCounty(node.getAttribute('data-code'));
      });
    });
    if (searchInput) searchInput.addEventListener('input', filterCounties);

    var regionPills = document.querySelectorAll('#qt-region-pills .qt-pill');
    Array.prototype.forEach.call(regionPills, function (pill) {
      pill.addEventListener('click', function () {
        activeRegion = pill.getAttribute('data-region') || 'All';
        Array.prototype.forEach.call(regionPills, function (item) {
          item.classList.toggle('is-active', item === pill);
        });
        filterCounties();
      });
    });

    explorerTabButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        state.tab = button.getAttribute('data-explorer-tab') || 'constituencies';
        state.conCode = '';
        state.wardCode = '';
        renderExplorer();
        loadHierarchy();
      });
    });

    if (explorerSearch) {
      explorerSearch.addEventListener('input', function () {
        state.query = explorerSearch.value;
        renderExplorer();
      });
    }

    Array.prototype.forEach.call(document.querySelectorAll('[data-explorer-scope]'), function (link) {
      link.addEventListener('click', function () {
        var scope = link.getAttribute('data-explorer-scope');
        if (scope === 'counties') {
          activeRegion = 'All';
          Array.prototype.forEach.call(regionPills, function (pill) {
            pill.classList.toggle('is-active', pill.getAttribute('data-region') === 'All');
          });
          filterCounties();
          return;
        }
        state.tab = scope === 'wards' ? 'assembly' : 'constituencies';
        state.conCode = '';
        state.wardCode = '';
        renderExplorer();
        loadHierarchy();
      });
    });

    renderLeadership(state.countyCode);
    renderExplorer();
    if (!lazyHierarchy) loadHierarchy();
  }

  /* 4. Page 02 — The Blind Ballot */
  var bbArena = document.getElementById('qt-blind-ballot-arena');
  if (bbArena && Array.isArray(cfg.blindBallot) && cfg.blindBallot.length) {
    var activeIssueId = cfg.blindBallot[0].id;
    var picksByIssue = {};
    var revealedByIssue = {};
    var talliesByIssue = cfg.tallies || {};

    var revealBtn = document.getElementById('qt-bb-reveal-btn');
    var cardsGrid = document.getElementById('qt-bb-cards-grid');
    var progressEl = document.getElementById('qt-bb-progress');
    var stepHint = document.getElementById('qt-bb-step-hint');
    var bbHpIn = document.getElementById('qt-bb-hp');

    function getActiveIssue() {
      for (var i = 0; i < cfg.blindBallot.length; i++) {
        if (cfg.blindBallot[i].id === activeIssueId) return cfg.blindBallot[i];
      }
      return cfg.blindBallot[0];
    }

    function renderBlindBallot() {
      var issue = getActiveIssue();
      var picked = picksByIssue[issue.id] || '';
      var revealed = Boolean(revealedByIssue[issue.id]);

      var setTxt = function (id, val) {
        var el = document.getElementById(id);
        if (el) el.textContent = val;
      };
      setTxt('qt-bb-anchor', issue.constitutionalAnchor);
      setTxt('qt-bb-title', issue.title);
      setTxt('qt-bb-subtitle', issue.subtitle);
      setTxt('qt-bb-agreement', issue.quietAgreement);

      var totalPicked = Object.keys(picksByIssue).length;
      if (progressEl) {
        progressEl.textContent = totalPicked + ' of ' + cfg.blindBallot.length + ' Issues Evaluated';
      }
      if (stepHint) {
        stepHint.style.display = !picked && !revealed ? 'block' : 'none';
      }
      if (revealBtn) {
        revealBtn.textContent = revealed ? 'Hide Political Sources' : 'Reveal Political Source';
        revealBtn.className = revealed ? 'qt-btn qt-btn-azure' : 'qt-btn qt-btn-primary';
      }

      // Update issue tab badges
      Array.prototype.forEach.call(document.querySelectorAll('#qt-bb-issue-tabs .qt-selector-card'), function (tab) {
        var tid = tab.getAttribute('data-issue-id');
        tab.classList.toggle('is-active', tid === issue.id);
        var b = tab.querySelector('[data-picked-badge]');
        if (b) b.textContent = picksByIssue[tid] ? 'Picked ' + picksByIssue[tid] : '';
      });

      if (!cardsGrid) return;
      cardsGrid.textContent = '';

      issue.positions.forEach(function (pos) {
        var isChosen = picked === pos.label;
        var card = document.createElement('div');
        card.className = 'qt-position-card' + (isChosen ? ' is-picked' : '');

        var topWrap = document.createElement('div');

        var hdr = document.createElement('div');
        hdr.style.cssText = 'display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--qt-border);padding-bottom:0.65rem;margin-bottom:0.85rem;';
        var badge = document.createElement('span');
        badge.className = 'qt-badge qt-badge-emerald';
        badge.textContent = pos.label;
        var stateLbl = document.createElement('span');
        stateLbl.className = 'qt-role-label';
        stateLbl.style.color = isChosen ? 'var(--qt-azure)' : 'var(--qt-ink-subtle)';
        stateLbl.textContent = isChosen ? '✓ Your Substance Pick' : revealed ? 'Source Disclosed' : 'Identity Blinded';
        hdr.appendChild(badge);
        hdr.appendChild(stateLbl);
        topWrap.appendChild(hdr);

        var h4 = document.createElement('h4');
        h4.style.cssText = 'margin:0 0 0.85rem;font-family:var(--qt-font-serif);font-size:1.12rem;line-height:1.35;';
        h4.textContent = pos.headline;
        topWrap.appendChild(h4);

        var addSection = function (label, body, strong) {
          var l = document.createElement('div');
          l.className = 'qt-role-label';
          l.style.color = 'var(--qt-ink-subtle)';
          l.textContent = label;
          var p = document.createElement('p');
          p.style.cssText = 'font-size:0.82rem;margin:0.25rem 0 0.85rem;' + (strong ? 'font-weight:600;color:var(--qt-ink);' : 'color:var(--qt-ink-muted);');
          p.textContent = body;
          topWrap.appendChild(l);
          topWrap.appendChild(p);
        };

        addSection('What This Camp Proposes', pos.proposal, false);
        addSection('Laws or Institutions Changed', pos.institutionsChanged, true);

        var addBox = function (title, body, color) {
          var bx = document.createElement('div');
          bx.className = 'qt-subpanel';
          bx.style.cssText = 'background:#FFFFFF;margin-bottom:0.55rem;padding:0.75rem;';
          var tl = document.createElement('div');
          tl.className = 'qt-role-label';
          tl.style.color = color;
          tl.textContent = title;
          var bp = document.createElement('p');
          bp.style.cssText = 'font-size:0.76rem;color:var(--qt-ink-muted);margin:0.25rem 0 0;';
          bp.textContent = body;
          bx.appendChild(tl);
          bx.appendChild(bp);
          topWrap.appendChild(bx);
        };

        addBox('Stated Political Case For', pos.argumentFor, 'var(--qt-azure)');
        addBox('Main Criticism Raised By Opponents', pos.mainCriticism, 'var(--qt-crimson)');

        var footWrap = document.createElement('div');
        footWrap.style.cssText = 'margin-top:1.1rem;padding-top:0.9rem;border-top:1px solid var(--qt-border);';

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = isChosen ? 'qt-btn qt-btn-azure' : 'qt-btn qt-btn-outline';
        btn.style.width = '100%';
        btn.textContent = isChosen ? 'Selected: ' + pos.label : 'Bookmark ' + pos.label + ' on Substance';
        btn.addEventListener('click', function () {
          picksByIssue[issue.id] = pos.label;
          sendBlindVoteAjax(issue.id, pos.label);
          renderBlindBallot();
        });
        footWrap.appendChild(btn);

        if (revealed) {
          var rev = document.createElement('div');
          rev.className = 'qt-source-reveal-box';
          var rl = document.createElement('div');
          rl.className = 'qt-role-label';
          rl.style.color = 'var(--qt-gold-bright)';
          rl.textContent = 'Authored / Championed By';
          var rp = document.createElement('div');
          rp.style.cssText = 'font-family:var(--qt-font-serif);font-weight:700;font-size:0.95rem;margin-top:0.25rem;';
          rp.textContent = pos.sourceParty;
          var rc = document.createElement('div');
          rc.style.cssText = 'font-family:var(--qt-font-mono);font-size:0.68rem;color:rgba(236,253,245,0.82);margin-top:0.4rem;';
          rc.textContent = 'Record Ref: ' + pos.sourceCitation;
          rev.appendChild(rl);
          rev.appendChild(rp);
          rev.appendChild(rc);

          if (talliesByIssue[issue.id] && talliesByIssue[issue.id][pos.label]) {
            var tallyNote = document.createElement('div');
            tallyNote.style.cssText = 'margin-top:0.45rem;padding-top:0.4rem;border-top:1px solid rgba(255,255,255,0.18);font-family:var(--qt-font-mono);font-size:0.66rem;color:#A7F3D0;';
            tallyNote.textContent = 'Reader Blind Picks Recorded: ' + talliesByIssue[issue.id][pos.label];
            rev.appendChild(tallyNote);
          }

          footWrap.appendChild(rev);
        }

        card.appendChild(topWrap);
        card.appendChild(footWrap);
        cardsGrid.appendChild(card);
      });
    }

    function sendBlindVoteAjax(issueId, choice) {
      if (!cfg.ajaxUrl || !cfg.nonce) return;
      var fd = new FormData();
      fd.append('action', 'qt_blind_vote');
      fd.append('nonce', cfg.nonce);
      fd.append('issue_id', issueId);
      fd.append('choice', choice);
      fd.append('website_url_hp', (bbHpIn && bbHpIn.value) || '');
      fetch(cfg.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res && res.success && res.data && res.data.tallies) {
            talliesByIssue[issueId] = res.data.tallies;
            if (revealedByIssue[issueId]) renderBlindBallot();
          }
        })
        .catch(function () {});
    }

    Array.prototype.forEach.call(document.querySelectorAll('#qt-bb-issue-tabs .qt-selector-card'), function (tab) {
      tab.addEventListener('click', function () {
        activeIssueId = tab.getAttribute('data-issue-id');
        renderBlindBallot();
      });
    });

    if (revealBtn) {
      revealBtn.addEventListener('click', function () {
        revealedByIssue[activeIssueId] = !revealedByIssue[activeIssueId];
        renderBlindBallot();
      });
    }

    renderBlindBallot();
  }

  /* 5. Page 03 — Podium vs. Parliament Category Filter */
  var pvpFilters = document.querySelectorAll('#qt-pvp-filters .qt-pill');
  if (pvpFilters.length) {
    var pvpItems = document.querySelectorAll('.qt-pvp-item');
    Array.prototype.forEach.call(pvpFilters, function (btn) {
      btn.addEventListener('click', function () {
        var cat = btn.getAttribute('data-pvp-cat') || 'All';
        Array.prototype.forEach.call(pvpFilters, function (b) {
          b.classList.toggle('is-active', b === btn);
        });
        Array.prototype.forEach.call(pvpItems, function (item) {
          var match = cat === 'All' || item.getAttribute('data-category') === cat;
          item.style.display = match ? 'block' : 'none';
        });
      });
    });
  }

  /* 6. Page 04 — Coalition Compass & 1991-2026 Timeline */
  var compassEl = document.getElementById('qt-coalition-compass');
  if (compassEl && cfg.coalitions) {
    var blocs = cfg.coalitions.blocs || [];
    var timeline = cfg.coalitions.timeline || [];

    Array.prototype.forEach.call(document.querySelectorAll('.qt-bloc-trigger'), function (trig) {
      trig.addEventListener('click', function () {
        var bid = trig.getAttribute('data-bloc-id');
        var bloc = null;
        for (var i = 0; i < blocs.length; i++) {
          if (blocs[i].id === bid) bloc = blocs[i];
        }
        if (!bloc) return;

        Array.prototype.forEach.call(document.querySelectorAll('.qt-bloc-card'), function (c) {
          c.classList.toggle('is-active', c.getAttribute('data-bloc-id') === bid);
        });

        var setTxt = function (id, val) {
          var el = document.getElementById(id);
          if (el) el.textContent = val;
        };
        setTxt('qt-bloc-status', bloc.status);
        setTxt('qt-bloc-name', bloc.name);
        setTxt('qt-bloc-posture', bloc.posture);
        setTxt('qt-bloc-offices', ' ' + bloc.offices);

        var ul = document.getElementById('qt-bloc-parties');
        if (ul) {
          ul.textContent = '';
          bloc.parties.forEach(function (pty) {
            var li = document.createElement('li');
            li.textContent = pty;
            ul.appendChild(li);
          });
        }
      });
    });

    Array.prototype.forEach.call(document.querySelectorAll('.qt-era-btn'), function (ebtn) {
      ebtn.addEventListener('click', function () {
        var idx = parseInt(ebtn.getAttribute('data-era-idx') || '0', 10);
        var era = timeline[idx];
        if (!era) return;
        Array.prototype.forEach.call(document.querySelectorAll('.qt-era-btn'), function (b) {
          b.classList.toggle('is-active', b === ebtn);
        });
        var m = document.getElementById('qt-era-meta');
        var ms = document.getElementById('qt-era-milestone');
        var sm = document.getElementById('qt-era-summary');
        if (m) m.textContent = era.year + ' · ' + era.era;
        if (ms) ms.textContent = era.milestone;
        if (sm) sm.textContent = era.summary;
      });
    });
  }

  /* 7. Page 05 — The Open Floor: Live Bills & Articles 10/118 Memorandum Builder */
  var memoBuilder = document.getElementById('qt-memorandum-builder');
  if (memoBuilder && Array.isArray(cfg.bills) && cfg.bills.length) {
    var activeBill = cfg.bills[0];

    var nameIn = document.getElementById('qt-memo-name');
    var countyIn = document.getElementById('qt-memo-county');
    var constIn = document.getElementById('qt-memo-const');
    var stanceIn = document.getElementById('qt-memo-stance');
    var notesIn = document.getElementById('qt-memo-notes');
    var hpIn = document.getElementById('qt-memo-hp');
    var previewEl = document.getElementById('qt-memo-preview');
    var statusMsg = document.getElementById('qt-memo-status-msg');

    function buildMemoString() {
      var nm = (nameIn && nameIn.value.trim()) || '[Insert Full Name]';
      var ct = (countyIn && countyIn.value.trim()) || '[Insert County]';
      var cs = (constIn && constIn.value.trim()) || '[Insert Constituency / Ward]';
      var st = (stanceIn && stanceIn.value) || 'Support with Specific Amendments';
      var nt = (notesIn && notesIn.value.trim()) || '[State specific clause numbers, constitutional considerations, and your proposed wording or objection concisely here.]';
      var dateStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });

      return [
        'PUBLIC PARTICIPATION MEMORANDUM PURSUANT TO ARTICLES 10 & 118 OF THE CONSTITUTION OF KENYA',
        '================================================================================',
        'DATE: ' + dateStr,
        'TO: ' + activeBill.clerk,
        '',
        'RE: CITIZEN MEMORANDUM ON ' + activeBill.title.toUpperCase() + ' (' + activeBill.house.toUpperCase() + ')',
        '',
        '1. SUBMITTING CITIZEN PARTICULARS',
        '   Name: ' + nm,
        '   County: ' + ct,
        '   Constituency / Ward: ' + cs,
        '',
        '2. GENERAL POSITION ON THE LEGISLATIVE PROPOSAL',
        '   Position: ' + st,
        '',
        '3. CONSTITUTIONAL & SUBSTANTIVE GROUNDS (' + activeBill.articles.join(', ') + ')',
        '   ' + nt,
        '',
        '4. PRAYER / RECOMMENDATION TO THE COMMITTEE',
        '   Pursuant to Articles 10(2)(a) and 118(1)(b) of the Constitution of Kenya, 2010, I respectfully request the Committee to record and consider these submissions prior to tabling its report before ' + activeBill.house + '.',
        '',
        'Signed,',
        nm,
        'Prepared via Quiet Truths Civic Floor (quiettruths.co.ke)'
      ].join('\n');
    }

    function refreshMemoPreview() {
      if (previewEl) previewEl.textContent = buildMemoString();
    }

    [nameIn, countyIn, constIn, stanceIn, notesIn].forEach(function (el) {
      if (el) el.addEventListener('input', refreshMemoPreview);
      if (el) el.addEventListener('change', refreshMemoPreview);
    });

    Array.prototype.forEach.call(document.querySelectorAll('.qt-bill-tab'), function (tab) {
      tab.addEventListener('click', function () {
        var bid = tab.getAttribute('data-bill-id');
        for (var i = 0; i < cfg.bills.length; i++) {
          if (cfg.bills[i].id === bid) activeBill = cfg.bills[i];
        }
        Array.prototype.forEach.call(document.querySelectorAll('.qt-bill-tab'), function (t) {
          t.classList.toggle('is-active', t === tab);
        });
        var setTxt = function (id, val) {
          var el = document.getElementById(id);
          if (el) el.textContent = val;
        };
        setTxt('qt-bill-house-win', activeBill.house + ' · ' + activeBill.window);
        setTxt('qt-bill-title', activeBill.title);
        setTxt('qt-bill-sponsor', 'Sponsor: ' + activeBill.sponsor + ' · Stage: ' + activeBill.stage);
        setTxt('qt-bill-summary', activeBill.summary);
        setTxt('qt-bill-contested', activeBill.contested);

        var artWrap = document.getElementById('qt-bill-articles');
        if (artWrap) {
          artWrap.textContent = '';
          activeBill.articles.forEach(function (a) {
            var sp = document.createElement('span');
            sp.className = 'qt-badge qt-badge-emerald';
            sp.textContent = a;
            artWrap.appendChild(sp);
          });
        }
        refreshMemoPreview();
      });
    });

    var copyBtn = document.getElementById('qt-memo-copy-btn');
    if (copyBtn) {
      copyBtn.addEventListener('click', function () {
        copySafe(buildMemoString(), function () {
          copyBtn.textContent = '✓ Memorandum Copied';
          setTimeout(function () {
            copyBtn.textContent = 'Copy Memorandum Text';
          }, 2400);
        });
      });
    }

    var dlMemoBtn = document.getElementById('qt-memo-download-btn');
    if (dlMemoBtn) {
      dlMemoBtn.addEventListener('click', function () {
        var blob = new Blob([buildMemoString()], { type: 'text/plain;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'Public-Participation-Memorandum-' + activeBill.id + '.txt';
        a.click();
        URL.revokeObjectURL(url);
      });
    }

    var logBtn = document.getElementById('qt-memo-log-btn');
    if (logBtn && cfg.ajaxUrl) {
      logBtn.addEventListener('click', function () {
        if (!notesIn || !notesIn.value.trim()) {
          if (statusMsg) statusMsg.textContent = 'Please enter your clause-specific arguments first before logging in the registry.';
          return;
        }
        logBtn.disabled = true;
        if (statusMsg) statusMsg.textContent = 'Submitting securely via WordPress nonce verification...';
        var fd = new FormData();
        fd.append('action', 'qt_submit_memorandum');
        fd.append('nonce', cfg.nonce || '');
        fd.append('website_url_hp', (hpIn && hpIn.value) || '');
        fd.append('bill_title', activeBill.title);
        fd.append('citizen_name', (nameIn && nameIn.value) || 'Anonymous Citizen');
        fd.append('county', (countyIn && countyIn.value) || '');
        fd.append('constituency', (constIn && constIn.value) || '');
        fd.append('stance', (stanceIn && stanceIn.value) || '');
        fd.append('memo_body', buildMemoString());

        fetch(cfg.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            logBtn.disabled = false;
            if (res && res.success && res.data) {
              if (statusMsg) statusMsg.textContent = '✓ ' + res.data.message + ' (' + res.data.ref_id + ')';
            } else {
              var msg = (res && res.data && res.data.message) || 'Could not log submission.';
              if (statusMsg) statusMsg.textContent = msg;
            }
          })
          .catch(function () {
            logBtn.disabled = false;
            if (statusMsg) statusMsg.textContent = 'Network unavailable. You can still copy or download your .TXT file immediately.';
          });
      });
    }

    refreshMemoPreview();
  }

  /* 8. Page 06 — The Quiet Record Search & Evidence Card Copy */
  var qrSearch = document.getElementById('qt-qr-search');
  if (qrSearch) {
    var qrItems = document.querySelectorAll('.qt-qr-item');
    qrSearch.addEventListener('input', function () {
      var q = qrSearch.value.toLowerCase().trim();
      Array.prototype.forEach.call(qrItems, function (card) {
        var txt = (card.textContent || '').toLowerCase();
        card.style.display = !q || txt.indexOf(q) !== -1 ? 'block' : 'none';
      });
    });
  }

  Array.prototype.forEach.call(document.querySelectorAll('.qt-copy-evidence-btn'), function (cbtn) {
    cbtn.addEventListener('click', function () {
      var shareText = cbtn.getAttribute('data-share-text') || '';
      copySafe(shareText, function () {
        var orig = cbtn.textContent;
        cbtn.textContent = '✓ Copied for WhatsApp / Telegram';
        setTimeout(function () {
          cbtn.textContent = orig;
        }, 2400);
      });
    });
  });
})();
