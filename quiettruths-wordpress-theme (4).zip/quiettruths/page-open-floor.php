<?php
/**
 * Template Name: 05 - The Open Floor
 * Description: Live Politically Contested Bills, Constitutional Decoder & Articles 10/118 Public Participation Memorandum Builder.
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$bills = qt_get_open_floor_bills();
$first = $bills[0];
?>

<section class="qt-page-hero">
	<div class="qt-page-hero-copy">
		<div class="qt-eyebrow"><?php esc_html_e( 'Page 05 · Live Bills, Constitutional Boundaries & Public Voice', 'quiettruths' ); ?></div>
		<h2 class="qt-h2"><?php esc_html_e( 'The Open Floor: Where Political Contests Become Binding Law.', 'quiettruths' ); ?></h2>
		<p class="qt-lead">
			<?php esc_html_e( 'Politics becomes permanent the day a Bill receives assent. Inspect politically contested Bills currently before the Senate and National Assembly, read the exact Articles of the 2010 Constitution they engage, and build a formal Articles 10 & 118 Public Participation Memorandum in plain English.', 'quiettruths' ); ?>
		</p>
	</div>
</section>

<section class="qt-grid-atlas" style="margin-bottom:2rem;">
	<!-- Left: Bill Selector -->
	<div style="display:flex; flex-direction:column; gap:0.75rem;">
		<div class="qt-role-label" style="color:var(--qt-ink-subtle);">
			<?php esc_html_e( 'Select an Active Parliamentary Bill / Docket', 'quiettruths' ); ?>
		</div>
		<?php foreach ( $bills as $idx => $b ) : ?>
			<button type="button" class="qt-selector-card qt-bill-tab <?php echo 0 === $idx ? 'is-active' : ''; ?>" data-bill-id="<?php echo esc_attr( $b['id'] ); ?>">
				<div style="display:flex; justify-content:space-between; width:100%; font-family:var(--qt-font-mono); font-size:0.66rem; font-weight:700; text-transform:uppercase; margin-bottom:0.35rem;">
					<span><?php echo esc_html( $b['house'] ); ?></span>
					<span><?php echo esc_html( $b['stage'] ); ?></span>
				</div>
				<strong style="font-family:var(--qt-font-serif); font-size:1rem; line-height:1.32;"><?php echo esc_html( $b['title'] ); ?></strong>
				<span style="font-size:0.76rem; opacity:0.82; margin-top:0.35rem;"><?php echo esc_html( 'Sponsor: ' . $b['sponsor'] ); ?></span>
			</button>
		<?php endforeach; ?>
	</div>

	<!-- Right: Bill Constitutional Analysis -->
	<div class="qt-card-lg qt-pad" id="qt-bill-detail-card">
		<div style="border-bottom:1px solid var(--qt-border); padding-bottom:0.9rem; margin-bottom:1rem;">
			<div class="qt-role-label" id="qt-bill-house-win" style="color:var(--qt-azure);"><?php echo esc_html( $first['house'] . ' · ' . $first['window'] ); ?></div>
			<h3 id="qt-bill-title" style="margin:0.3rem 0 0; font-family:var(--qt-font-serif); font-size:1.55rem;"><?php echo esc_html( $first['title'] ); ?></h3>
			<div id="qt-bill-sponsor" style="font-family:var(--qt-font-mono); font-size:0.74rem; color:var(--qt-ink-subtle); margin-top:0.3rem;">
				<?php echo esc_html( 'Sponsor: ' . $first['sponsor'] . ' · Stage: ' . $first['stage'] ); ?>
			</div>
		</div>

		<div class="qt-role-label" style="color:var(--qt-ink-subtle);"><?php esc_html_e( 'Plain-English Legislative Summary', 'quiettruths' ); ?></div>
		<p id="qt-bill-summary" style="font-size:0.92rem; margin:0.35rem 0 1.1rem;"><?php echo esc_html( $first['summary'] ); ?></p>

		<div class="qt-subpanel" style="background:var(--qt-crimson-soft); border-color:rgba(220,38,38,0.22); margin-bottom:1.1rem;">
			<div class="qt-role-label" style="color:var(--qt-crimson);"><?php esc_html_e( 'Why It Is Politically Contested', 'quiettruths' ); ?></div>
			<p id="qt-bill-contested" style="font-size:0.84rem; color:var(--qt-ink-muted); margin:0.3rem 0 0;"><?php echo esc_html( $first['contested'] ); ?></p>
		</div>

		<div class="qt-role-label" style="color:var(--qt-ink-subtle); margin-bottom:0.5rem;"><?php esc_html_e( 'Constitutional Articles Directly Engaged', 'quiettruths' ); ?></div>
		<div class="qt-pill-row" id="qt-bill-articles">
			<?php foreach ( $first['articles'] as $art ) : ?>
				<span class="qt-badge qt-badge-emerald"><?php echo esc_html( $art ); ?></span>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<!-- Guided Articles 10 & 118 Public Participation Memorandum Builder -->
<section class="qt-card-lg qt-pad" id="qt-memorandum-builder">
	<div style="border-bottom:1px solid var(--qt-border); padding-bottom:0.9rem; margin-bottom:1.35rem;">
		<div class="qt-role-label" style="color:var(--qt-emerald-dark);"><?php esc_html_e( 'Articles 10 & 118 Constitutional Tool', 'quiettruths' ); ?></div>
		<h3 style="margin:0.25rem 0 0; font-family:var(--qt-font-serif); font-size:1.6rem;"><?php esc_html_e( 'Guided Public Participation Memorandum Builder', 'quiettruths' ); ?></h3>
		<p style="margin:0.3rem 0 0; font-size:0.84rem; color:var(--qt-ink-muted);">
			<?php esc_html_e( 'Format your citizen submission into a formal legislative memorandum addressed directly to the Clerk of the Senate or Clerk of the National Assembly.', 'quiettruths' ); ?>
		</p>
	</div>

	<div class="qt-grid-2">
		<form id="qt-memo-form" onsubmit="return false;" style="display:flex; flex-direction:column; gap:0.9rem;">
			<!-- Anti-bot Honeypot field (hidden from real readers) -->
			<div style="position:absolute; left:-9999px;" aria-hidden="true">
				<input type="text" id="qt-memo-hp" name="website_url_hp" tabindex="-1" autocomplete="off">
			</div>

			<div class="qt-grid-2">
				<div>
					<label for="qt-memo-name" class="qt-role-label" style="display:block; margin-bottom:0.3rem; color:var(--qt-ink-subtle);"><?php esc_html_e( 'Your Full Name', 'quiettruths' ); ?></label>
					<input type="text" id="qt-memo-name" class="qt-input" placeholder="<?php esc_attr_e( 'e.g. Wanjiku Mwangi', 'quiettruths' ); ?>">
				</div>
				<div>
					<label for="qt-memo-county" class="qt-role-label" style="display:block; margin-bottom:0.3rem; color:var(--qt-ink-subtle);"><?php esc_html_e( 'County', 'quiettruths' ); ?></label>
					<input type="text" id="qt-memo-county" class="qt-input" value="Nairobi City">
				</div>
			</div>

			<div class="qt-grid-2">
				<div>
					<label for="qt-memo-const" class="qt-role-label" style="display:block; margin-bottom:0.3rem; color:var(--qt-ink-subtle);"><?php esc_html_e( 'Constituency & Ward', 'quiettruths' ); ?></label>
					<input type="text" id="qt-memo-const" class="qt-input" placeholder="<?php esc_attr_e( 'e.g. Chuka / Karingani Ward', 'quiettruths' ); ?>">
				</div>
				<div>
					<label for="qt-memo-stance" class="qt-role-label" style="display:block; margin-bottom:0.3rem; color:var(--qt-ink-subtle);"><?php esc_html_e( 'Formal Position', 'quiettruths' ); ?></label>
					<select id="qt-memo-stance" class="qt-select">
						<option value="Support as Drafted"><?php esc_html_e( 'Support as Drafted', 'quiettruths' ); ?></option>
						<option value="Support with Specific Amendments" selected><?php esc_html_e( 'Support with Specific Amendments', 'quiettruths' ); ?></option>
						<option value="Oppose on Constitutional / Policy Grounds"><?php esc_html_e( 'Oppose on Constitutional / Policy Grounds', 'quiettruths' ); ?></option>
					</select>
				</div>
			</div>

			<div>
				<label for="qt-memo-notes" class="qt-role-label" style="display:block; margin-bottom:0.3rem; color:var(--qt-ink-subtle);"><?php esc_html_e( 'Clause-Specific Arguments & Proposed Remedy', 'quiettruths' ); ?></label>
				<textarea id="qt-memo-notes" rows="4" class="qt-textarea" placeholder="<?php esc_attr_e( 'State specific clause numbers, constitutional considerations, and your proposed wording or objection clearly...', 'quiettruths' ); ?>"></textarea>
			</div>
		</form>

		<div class="qt-subpanel" style="display:flex; flex-direction:column; justify-content:space-between;">
			<div>
				<div style="display:flex; justify-content:space-between; border-bottom:1px solid var(--qt-border); padding-bottom:0.55rem; margin-bottom:0.75rem;">
					<span class="qt-role-label"><?php esc_html_e( 'Formatted Clerk Submission Preview', 'quiettruths' ); ?></span>
				</div>
				<pre id="qt-memo-preview" class="qt-memo-pre"></pre>
			</div>

			<div style="margin-top:1rem; padding-top:0.85rem; border-top:1px solid var(--qt-border); display:flex; flex-wrap:wrap; gap:0.6rem;">
				<button type="button" id="qt-memo-copy-btn" class="qt-btn qt-btn-primary">
					<?php esc_html_e( 'Copy Memorandum Text', 'quiettruths' ); ?>
				</button>
				<button type="button" id="qt-memo-download-btn" class="qt-btn qt-btn-outline">
					<?php esc_html_e( 'Download .TXT for Clerk Email', 'quiettruths' ); ?>
				</button>
				<button type="button" id="qt-memo-log-btn" class="qt-btn qt-btn-azure">
					<?php esc_html_e( 'Log in Civic Registry', 'quiettruths' ); ?>
				</button>
				<div id="qt-memo-status-msg" style="width:100%; font-family:var(--qt-font-mono); font-size:0.74rem; color:var(--qt-emerald-dark);"></div>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
