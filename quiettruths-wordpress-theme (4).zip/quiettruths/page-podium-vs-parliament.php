<?php
/**
 * Template Name: 03 - Podium vs. Parliament
 * Description: Rhetoric vs. The Official Parliamentary Hansard, Tabled Bills & Statute Book.
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$records    = qt_get_podium_vs_parliament_records();
$categories = array( 'All' );
foreach ( $records as $r ) {
	if ( ! in_array( $r['category'], $categories, true ) ) {
		$categories[] = $r['category'];
	}
}
?>

<section class="qt-page-hero">
	<div class="qt-page-hero-copy">
		<div class="qt-eyebrow"><?php esc_html_e( 'Page 03 · Rhetoric vs. The Official Record', 'quiettruths' ); ?></div>
		<h2 class="qt-h2"><?php esc_html_e( 'Podium vs. Parliament: Sunday Rally Speech Beside Tuesday’s Record.', 'quiettruths' ); ?></h2>
		<p class="qt-lead">
			<?php esc_html_e( 'No partisan commentary or opinion scores. We place public political statements directly beside the official Parliamentary Hansard, tabled Bills, Supreme Court rulings, and the Statute Book—so citizens can compare political speech with legislative reality for themselves.', 'quiettruths' ); ?>
		</p>

		<div class="qt-pill-row" id="qt-pvp-filters" style="margin-top:1.15rem;">
			<?php foreach ( $categories as $idx => $cat ) : ?>
				<button type="button" class="qt-pill <?php echo 0 === $idx ? 'is-active' : ''; ?>" data-pvp-cat="<?php echo esc_attr( $cat ); ?>">
					<?php echo esc_html( $cat ); ?>
				</button>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section style="display:flex; flex-direction:column; gap:1.5rem;" id="qt-pvp-ledger-list">
	<?php foreach ( $records as $idx => $rec ) : ?>
		<article class="qt-card-lg qt-pvp-item" data-category="<?php echo esc_attr( $rec['category'] ); ?>">
			<div style="background:var(--qt-bg-subtle); border-bottom:1px solid var(--qt-border); padding:0.95rem 1.5rem; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:0.75rem;">
				<div style="display:flex; align-items:center; gap:0.75rem;">
					<span class="qt-badge qt-badge-solid-emerald"><?php echo esc_html( 'FILE ' . str_pad( (string) ( $idx + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
					<h3 style="margin:0; font-family:var(--qt-font-serif); font-size:1.25rem;"><?php echo esc_html( $rec['topic'] ); ?></h3>
				</div>
				<span style="font-family:var(--qt-font-mono); font-size:0.75rem; color:var(--qt-ink-subtle);">
					<?php echo esc_html( $rec['category'] . ' · ' . $rec['dateWindow'] ); ?>
				</span>
			</div>

			<div class="qt-split-ledger">
				<div class="qt-pad" style="background:rgba(242,247,245,0.55);">
					<span class="qt-badge qt-badge-crimson"><?php esc_html_e( 'On The Public Podium', 'quiettruths' ); ?></span>
					<div style="font-family:var(--qt-font-mono); font-size:0.72rem; color:var(--qt-ink-subtle); margin-top:0.55rem;">
						<?php echo esc_html( $rec['podiumSetting'] ); ?>
					</div>
					<blockquote class="qt-quote">
						<?php echo esc_html( $rec['podiumQuote'] ); ?>
					</blockquote>
				</div>

				<div class="qt-pad">
					<span class="qt-badge qt-badge-azure"><?php esc_html_e( 'In The Official Institutional Record', 'quiettruths' ); ?></span>
					<div style="font-family:var(--qt-font-mono); font-size:0.72rem; color:var(--qt-ink-subtle); margin-top:0.55rem;">
						<?php echo esc_html( $rec['recordSetting'] ); ?>
					</div>
					<p style="font-size:0.9rem; color:var(--qt-ink); margin:0.75rem 0;">
						<?php echo esc_html( $rec['recordSummary'] ); ?>
					</p>

					<div class="qt-subpanel" style="font-size:0.78rem;">
						<div style="font-family:var(--qt-font-mono);">
							<strong><?php esc_html_e( 'Primary Citation:', 'quiettruths' ); ?></strong> <?php echo esc_html( $rec['docRef'] ); ?>
						</div>
						<div style="margin-top:0.35rem; color:var(--qt-ink-muted);">
							<strong><?php esc_html_e( 'Current Legal / Floor Status:', 'quiettruths' ); ?></strong> <?php echo esc_html( $rec['floorStatus'] ); ?>
						</div>
					</div>
				</div>
			</div>
		</article>
	<?php endforeach; ?>
</section>

<?php
get_footer();
