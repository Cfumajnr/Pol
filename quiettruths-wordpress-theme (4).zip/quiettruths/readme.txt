=== Quiet Truths — Highland Emerald | Representation Explorer (WordPress Theme for quiettruths.co.ke) ===
Contributors: Quiet Truths Civic Engineering Desk
Requires at least: WordPress 6.0
Tested up to: WordPress 6.7
Requires PHP: 7.4
Version: 1.1.2
License: GPLv2 or later

== One-Click Upload & Activation Instructions ==

1. Log in to your WordPress Dashboard at `https://quiettruths.co.ke/wp-admin`.
2. Navigate to **Appearance -> Themes -> Add New Theme -> Upload Theme**.
3. Select **`quiettruths-wordpress-theme.zip`** and click **Install Now**.
4. Click **Activate**.

== Critical 1.1.2: Remove the Stale Old Masthead / Logo ==

The live masthead was still printing the WordPress `blogname` option, which contained a rejected old campaign wordmark. Version 1.1.2 hard-codes **QUIET TRUTHS** in `header.php`, uses the bundled **QT record mark** instead of any WP Custom Logo or Site Icon, and automatically repairs stale `blogname` / `blogdescription` values in the database when the theme is activated or any front-end / admin request runs.

After uploading and activating the ZIP:

1. In **Settings -> General**, confirm **Site Title** is `Quiet Truths` and **Tagline** is `Quiet Truths — The Record Speaks, County by County.`. The theme performs this repair automatically when the stored value is stale or a WordPress default.
2. In **Appearance -> Customize -> Site Identity**, remove any old Custom Logo and Site Icon if present. This theme ignores both and always renders its own QT wordmark and versioned QT favicon suite.
3. **Purge every cache**: any WordPress page-cache plugin, host/CDN cache (for example Cloudflare), object cache, and browser cache. A cached copy of the old homepage HTML can otherwise remain visible even after the theme files are correct. Then hard-refresh `https://quiettruths.co.ke/`.
4. Verify the raw homepage HTML: `h1.qt-site-title` must contain `QUIET TRUTHS`, and the rejected old wordmark must be absent. The masthead image must be the `favicon.svg?ver=1.1.2` QT record mark.

Optional WP-CLI repair:

`wp option update blogname 'Quiet Truths' && wp option update blogdescription 'Quiet Truths — The Record Speaks, County by County.' && wp cache flush`

== Identity ==

**Official browser / link title:** `Quiet Truths — The Record Speaks, County by County. | Quiet Truths` — applied exactly to the front-page document title, Open Graph title and Twitter title.

**Identity line:** `Quiet Truths — The Record Speaks, County by County.` is applied to the masthead, hero, description, footer, theme screenshot and standalone preview. The identity follows the domain and the editorial method: named offices, named places, named sources and named gaps.

== What Happens Automatically on Activation ==

Upon activation, the theme automatically configures your multi-page Kenyan political website:
- Creates all **6 Core WordPress Pages** as real, separate multi-page URLs:
  1. `The Ground` (`/` — automatically set as your Static Front Page, featuring the 47-county atlas, county leadership chain and full representation explorer)
  2. `The Blind Ballot` (`/blind-ballot/`)
  3. `Podium vs. Parliament` (`/podium-vs-parliament/`)
  4. `Coalition Compass` (`/coalition-compass/`)
  5. `The Open Floor` (`/open-floor/`)
  6. `The Quiet Record` (`/quiet-record/`)
- Creates and assigns **WordPress Menus** (`Appearance -> Menus`):
  - `Quiet Truths Primary Menu` (assigned to Primary Civic Navigation)
  - `Quiet Truths Footer Menu` (assigned to Footer Civic Navigation)
- Registers Editorial **Custom Post Types** in your WP Admin sidebar:
  - **Quiet Briefs** (Add daily 3-minute political digests)
  - **Podium vs. Parliament** (Publish new rally-vs-Hansard comparisons)
  - **Quiet Record Checks** (Publish new primary-source verifications with WhatsApp Evidence Cards)
  - **Citizen Memoranda** (Private admin log of public participation memoranda)
- Enables **Bespoke Favicons** (`SVG`, `ICO`, `PNG`, `Apple Touch Icon`, `Web Manifest`) and **Security Hardening** (HTTP security headers, XML-RPC disabled, user-enumeration protection, cryptographic nonces, honeypots & transient rate-limiting on both AJAX endpoints).
- Ships **zero external runtime dependencies**: no CDN fonts, frameworks, analytics, or trackers — all typography, styles, scripts and representation data are self-contained inside the theme.

== Comprehensive Political Drill-Down ==

The Ground is a working representation explorer, not a set of national totals:
- Select any of the **47 counties** from the interactive SVG map or the searchable county index.
- See the county leadership chain: **Governor, Deputy Governor, Senator, Woman Representative, County Assembly Speaker and Clerk**, each with source and freshness labels.
- Open **Constituencies & MPs** to browse every constituency in the selected county, the named MP, and the wards under that constituency.
- Open **County Assembly & Wards** to browse all **1,450 wards** nationally, grouped by constituency, with the named MCA where the source extract provides one.
- Use breadcrumbs, search and region filters to move from Kenya → County → Constituency → Ward and back again.
- Data-Lite mode keeps the entire text directory functional while hiding the vector map; the same-origin JSON directory can be loaded on demand.

The bundled `assets/data/kenya-representation.json` contains **47 counties, 290 constituencies and 1,450 wards**, plus **290 MP seats, 47 County Women Representatives, 47 Governors, 47 Deputy Governors, 47 elected Senators, 47 Assembly Speakers, 47 Assembly Clerks and 1,433 named elected MCA records**. One MP vacancy and 17 MCA record gaps are labelled honestly rather than filled with guessed names. Full URLs, retrieval date and status policy are documented in `data-sources.txt` and inside the explorer's Sources panel.

== Security & Data Notes ==

- Both public AJAX actions (`qt_blind_vote`, `qt_submit_memorandum`) use nonces, honeypots and transient rate-limiting.
- Dynamic DOM updates use `textContent` and created elements; no untrusted HTML is injected.
- The representation directory is a same-origin static JSON asset. Source links are outbound references only and are not runtime dependencies.
- This is a non-partisan representation directory, not an endorsement or a live election-result service. Verify time-sensitive officeholder records against the named institutional sources.
