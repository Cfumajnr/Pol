<?php
/**
 * Quiet Truths — 404 Not Found Template
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<section class="qt-card-lg qt-pad" style="text-align:center; max-width:680px; margin:2rem auto;">
	<div class="qt-eyebrow"><?php esc_html_e( '404 · Record Not Found', 'quiettruths' ); ?></div>
	<h2 class="qt-h2"><?php esc_html_e( 'This Political File Was Not Found on the Floor.', 'quiettruths' ); ?></h2>
	<p class="qt-lead" style="margin-bottom:1.5rem;">
		<?php esc_html_e( 'The page you requested may have moved. Use the primary civic menu above or return directly to Kenya’s 47-County Political Atlas.', 'quiettruths' ); ?>
	</p>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="qt-btn qt-btn-primary">
		<?php esc_html_e( 'Return to Page 01: The Ground →', 'quiettruths' ); ?>
	</a>
</section>

<?php
get_footer();
