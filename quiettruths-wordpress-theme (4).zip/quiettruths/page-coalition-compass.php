<?php
/**
 * Template Name: 04 - Coalition Compass
 * Description: 13th Parliament Bicameral Seat Balance & 35-Year Kenyan Alliance Timeline (1991–2026).
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$coalition_data = qt_get_coalition_data();
$blocs          = $coalition_data['blocs'];
$timeline       = $coalition_data['timeline'];
$active_bloc    = $blocs[0];
$active_era     = $timeline[ count( $timeline ) - 1 ];
?>

<section class="qt-page-hero">
	<div class="qt-page-hero-copy">
		<div class="qt-eyebrow"><?php esc_html_e( 'Page 04 · Mapping Alliances, Shifts & Party History', 'quiettruths' ); ?></div>
		<h2 class="qt-h2"><?php esc_html_e( 'The Coalition Compass: Following Power Across Mergers & Handshakes.', 'quiettruths' ); ?></h2>
		<p class="qt-lead">
			<?php esc_html_e( 'Kenyan politics moves through shifting alliances, coalition charters, cross-aisle agreements, and pre-election realignments. Explore how the 13th Parliament is currently configured ahead of August 2027—and trace every major alliance wave since 1991.', 'quiettruths' ); ?>
		</p>
	</div>
</section>

<!-- 13th Parliament Bicameral Seat Balance -->
<section class="qt-card-lg qt-pad" id="qt-coalition-compass">
	<div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:0.75rem; border-bottom:1px solid var(--qt-border); padding-bottom:1rem; margin-bottom:1.25rem;">
		<div>
			<div class="qt-role-label" style="color:var(--qt-azure);"><?php esc_html_e( '13th Parliament Configuration · Pre-2027 Realignment Map', 'quiettruths' ); ?></div>
			<h3 style="margin:0.25rem 0 0; font-family:var(--qt-font-serif); font-size:1.65rem;"><?php esc_html_e( 'Bicameral Seat Balance & Executive Posture', 'quiettruths' ); ?></h3>
		</div>
		<span style="font-family:var(--qt-font-mono); font-size:0.76rem; color:var(--qt-ink-subtle);">
			<?php esc_html_e( 'National Assembly: 349 Seats · The Senate: 67 Seats', 'quiettruths' ); ?>
		</span>
	</div>

	<div class="qt-datalite-notice">
		<?php esc_html_e( '[Data-Lite Mode Active] Proportional seat bars simplified. Click any parliamentary bloc card below for exact seat counts.', 'quiettruths' ); ?>
	</div>

	<div class="qt-graphic-heavy" style="margin-bottom:1.35rem; display:flex; flex-direction:column; gap:1rem;">
		<div>
			<div style="display:flex; justify-content:space-between; font-family:var(--qt-font-mono); font-size:0.74rem; margin-bottom:0.35rem;">
				<strong><?php esc_html_e( 'NATIONAL ASSEMBLY (349 MEMBERS)', 'quiettruths' ); ?></strong>
				<span style="color:var(--qt-ink-subtle);"><?php esc_html_e( '2/3 Constitutional Threshold: 233 MPs', 'quiettruths' ); ?></span>
			</div>
			<div class="qt-seat-bar">
				<?php foreach ( $blocs as $b ) : ?>
					<?php $pct = round( ( $b['na'] / 349 ) * 100, 2 ); ?>
					<button type="button" class="qt-seat-seg qt-bloc-trigger" data-bloc-id="<?php echo esc_attr( $b['id'] ); ?>" style="width:<?php echo esc_attr( $pct ); ?>%; background:<?php echo esc_attr( $b['color'] ); ?>;" title="<?php echo esc_attr( $b['name'] . ': ' . $b['na'] . ' NA Seats' ); ?>"></button>
				<?php endforeach; ?>
			</div>
		</div>

		<div>
			<div style="display:flex; justify-content:space-between; font-family:var(--qt-font-mono); font-size:0.74rem; margin-bottom:0.35rem;">
				<strong><?php esc_html_e( 'THE SENATE (67 SENATORS — 47 ELECTED + 20 DELEGATION)', 'quiettruths' ); ?></strong>
				<span style="color:var(--qt-ink-subtle);"><?php esc_html_e( '2/3 Constitutional Threshold: 45 Senators', 'quiettruths' ); ?></span>
			</div>
			<div class="qt-seat-bar">
				<?php foreach ( $blocs as $b ) : ?>
					<?php $pct_s = round( ( $b['senate'] / 67 ) * 100, 2 ); ?>
					<button type="button" class="qt-seat-seg qt-bloc-trigger" data-bloc-id="<?php echo esc_attr( $b['id'] ); ?>" style="width:<?php echo esc_attr( $pct_s ); ?>%; background:<?php echo esc_attr( $b['color'] ); ?>;" title="<?php echo esc_attr( $b['name'] . ': ' . $b['senate'] . ' Senate Seats' ); ?>"></button>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="qt-grid-4" style="margin-bottom:1.35rem;">
		<?php foreach ( $blocs as $idx => $b ) : ?>
			<button type="button" class="qt-selector-card qt-bloc-card qt-bloc-trigger <?php echo 0 === $idx ? 'is-active' : ''; ?>" data-bloc-id="<?php echo esc_attr( $b['id'] ); ?>">
				<div>
					<div style="display:flex; align-items:center; gap:0.45rem; margin-bottom:0.4rem;">
						<span style="width:11px; height:11px; border-radius:999px; background:<?php echo esc_attr( $b['color'] ); ?>; border:2px solid #fff; display:inline-block;"></span>
						<span class="qt-role-label" style="font-size:0.62rem; opacity:0.85;"><?php esc_html_e( 'Inspect Bloc', 'quiettruths' ); ?></span>
					</div>
					<div style="font-family:var(--qt-font-serif); font-weight:700; font-size:0.98rem; line-height:1.3;"><?php echo esc_html( $b['name'] ); ?></div>
				</div>
				<div style="margin-top:0.75rem; padding-top:0.55rem; border-top:1px solid rgba(167,196,185,0.45); font-family:var(--qt-font-mono); font-size:0.74rem; width:100%;">
					NA: <strong><?php echo esc_html( $b['na'] ); ?></strong> · Senate: <strong><?php echo esc_html( $b['senate'] ); ?></strong>
				</div>
			</button>
		<?php endforeach; ?>
	</div>

	<!-- Selected Bloc Detail Box -->
	<div class="qt-subpanel qt-grid-atlas" id="qt-bloc-detail">
		<div>
			<div class="qt-role-label" id="qt-bloc-status" style="color:var(--qt-azure);"><?php echo esc_html( $active_bloc['status'] ); ?></div>
			<h4 id="qt-bloc-name" style="margin:0.35rem 0; font-family:var(--qt-font-serif); font-size:1.5rem;"><?php echo esc_html( $active_bloc['name'] ); ?></h4>
			<p id="qt-bloc-posture" style="font-size:0.88rem; color:var(--qt-ink-muted); margin:0.5rem 0;"><?php echo esc_html( $active_bloc['posture'] ); ?></p>
			<div style="font-size:0.8rem; margin-top:0.65rem;">
				<strong><?php esc_html_e( 'Key Parliamentary Offices Held:', 'quiettruths' ); ?></strong>
				<span id="qt-bloc-offices"><?php echo esc_html( $active_bloc['offices'] ); ?></span>
			</div>
		</div>
		<div style="border-left:1px solid var(--qt-border); padding-left:1.25rem;">
			<div class="qt-role-label" style="color:var(--qt-ink-subtle); margin-bottom:0.5rem;">
				<?php esc_html_e( 'Constituent / Affiliated Registered Parties', 'quiettruths' ); ?>
			</div>
			<ul id="qt-bloc-parties" style="margin:0; padding-left:1.1rem; font-size:0.82rem; line-height:1.7;">
				<?php foreach ( $active_bloc['parties'] as $pty ) : ?>
					<li><?php echo esc_html( $pty ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
</section>

<!-- 35-Year Historical Alliance Stepper -->
<section style="margin-top:2.5rem;">
	<div style="margin-bottom:1rem;">
		<div class="qt-role-label" style="color:var(--qt-emerald-dark);"><?php esc_html_e( 'Institutional Memory · 1991 to 2026', 'quiettruths' ); ?></div>
		<h3 style="margin:0.2rem 0 0; font-family:var(--qt-font-serif); font-size:1.65rem;"><?php esc_html_e( 'Thirty-Five Years of Kenyan Coalition Architecture', 'quiettruths' ); ?></h3>
	</div>

	<div class="qt-grid-6" id="qt-era-tabs" style="margin-bottom:1rem;">
		<?php foreach ( $timeline as $idx => $era ) : ?>
			<?php $is_last = ( $idx === count( $timeline ) - 1 ); ?>
			<button type="button" class="qt-selector-card qt-era-btn <?php echo $is_last ? 'is-active' : ''; ?>" data-era-idx="<?php echo esc_attr( $idx ); ?>">
				<div style="font-family:var(--qt-font-mono); font-size:0.75rem; font-weight:700;"><?php echo esc_html( $era['year'] ); ?></div>
				<div style="font-family:var(--qt-font-serif); font-size:0.8rem; font-weight:600; margin-top:0.25rem; line-height:1.25;"><?php echo esc_html( $era['era'] ); ?></div>
			</button>
		<?php endforeach; ?>
	</div>

	<div class="qt-card-lg qt-pad" id="qt-era-detail">
		<div class="qt-role-label" id="qt-era-meta" style="color:var(--qt-azure);"><?php echo esc_html( $active_era['year'] . ' · ' . $active_era['era'] ); ?></div>
		<h4 id="qt-era-milestone" style="margin:0.35rem 0 0; font-family:var(--qt-font-serif); font-size:1.5rem;"><?php echo esc_html( $active_era['milestone'] ); ?></h4>
		<p id="qt-era-summary" style="margin:0.65rem 0 0; font-size:0.94rem; color:var(--qt-ink-muted); max-width:860px;"><?php echo esc_html( $active_era['summary'] ); ?></p>
	</div>
</section>

<?php
get_footer();
