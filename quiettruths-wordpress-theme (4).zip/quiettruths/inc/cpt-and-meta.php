<?php
/**
 * Quiet Truths — Custom Post Types & Secure Editorial Meta Boxes
 *
 * Allows editors on quiettruths.co.ke to publish new Quiet Briefs,
 * Podium vs. Parliament comparisons, and Quiet Record verifications directly in WP Admin.
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function qt_register_civic_cpts() {
	// 1. Daily Quiet Briefs
	register_post_type(
		'qt_brief',
		array(
			'labels'       => array(
				'name'          => __( 'Quiet Briefs', 'quiettruths' ),
				'singular_name' => __( 'Quiet Brief', 'quiettruths' ),
				'add_new_item'  => __( 'Add New Quiet Brief Item', 'quiettruths' ),
			),
			'public'       => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-megaphone',
			'supports'     => array( 'title', 'editor', 'excerpt' ),
			'has_archive'  => true,
			'rewrite'      => array( 'slug' => 'briefs' ),
		)
	);

	// 2. Podium vs. Parliament Dossiers
	register_post_type(
		'qt_hansard',
		array(
			'labels'       => array(
				'name'          => __( 'Podium vs. Parliament', 'quiettruths' ),
				'singular_name' => __( 'Hansard Comparison', 'quiettruths' ),
				'add_new_item'  => __( 'Add New Podium vs. Parliament File', 'quiettruths' ),
			),
			'public'       => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-book-alt',
			'supports'     => array( 'title', 'editor' ),
			'has_archive'  => false,
		)
	);

	// 3. Quiet Record Primary Verifications
	register_post_type(
		'qt_verification',
		array(
			'labels'       => array(
				'name'          => __( 'Quiet Record Checks', 'quiettruths' ),
				'singular_name' => __( 'Record Verification', 'quiettruths' ),
				'add_new_item'  => __( 'Add New Primary-Source Verification', 'quiettruths' ),
			),
			'public'       => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-yes-alt',
			'supports'     => array( 'title', 'editor' ),
			'has_archive'  => false,
		)
	);

	// 4. Private Citizen Public Participation Memoranda Log (Admin-only)
	register_post_type(
		'qt_memorandum',
		array(
			'labels'          => array(
				'name'          => __( 'Citizen Memoranda', 'quiettruths' ),
				'singular_name' => __( 'Citizen Memorandum', 'quiettruths' ),
			),
			'public'          => false,
			'show_ui'         => true,
			'capability_type' => 'post',
			'menu_icon'       => 'dashicons-media-text',
			'supports'        => array( 'title', 'editor', 'custom-fields' ),
		)
	);
}
add_action( 'init', 'qt_register_civic_cpts' );

/**
 * Custom Meta Boxes for Editorial CPTs
 */
function qt_add_editorial_meta_boxes() {
	add_meta_box(
		'qt_hansard_details',
		__( 'Podium Speech vs. Official Institutional Record', 'quiettruths' ),
		'qt_render_hansard_meta_box',
		'qt_hansard',
		'normal',
		'high'
	);

	add_meta_box(
		'qt_verification_details',
		__( 'Primary-Source Verification & Shareable Evidence Card', 'quiettruths' ),
		'qt_render_verification_meta_box',
		'qt_verification',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'qt_add_editorial_meta_boxes' );

function qt_render_hansard_meta_box( $post ) {
	wp_nonce_field( 'qt_save_hansard_meta', 'qt_hansard_nonce' );
	$category     = get_post_meta( $post->ID, '_qt_category', true );
	$date_win     = get_post_meta( $post->ID, '_qt_date_window', true );
	$podium_quote = get_post_meta( $post->ID, '_qt_podium_quote', true );
	$doc_ref      = get_post_meta( $post->ID, '_qt_doc_ref', true );
	$floor_status = get_post_meta( $post->ID, '_qt_floor_status', true );
	?>
	<p>
		<label><strong><?php esc_html_e( 'Category (e.g. Constitutional Amendments, Electoral Law):', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_category" value="<?php echo esc_attr( $category ); ?>" style="width:100%;">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Date Window (e.g. October – November 2026):', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_date_window" value="<?php echo esc_attr( $date_win ); ?>" style="width:100%;">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Public Podium Statement / Rally Quote:', 'quiettruths' ); ?></strong></label><br>
		<textarea name="qt_podium_quote" rows="3" style="width:100%;"><?php echo esc_textarea( $podium_quote ); ?></textarea>
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Primary Hansard / Bill / Court Citation:', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_doc_ref" value="<?php echo esc_attr( $doc_ref ); ?>" style="width:100%;">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Recorded Floor / Legal Status:', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_floor_status" value="<?php echo esc_attr( $floor_status ); ?>" style="width:100%;">
	</p>
	<p><em><?php esc_html_e( 'Use the main post editor above for the neutral Official Institutional Record summary.', 'quiettruths' ); ?></em></p>
	<?php
}

function qt_render_verification_meta_box( $post ) {
	wp_nonce_field( 'qt_save_verification_meta', 'qt_verification_nonce' );
	$badge      = get_post_meta( $post->ID, '_qt_status_badge', true );
	$circ       = get_post_meta( $post->ID, '_qt_where_circulating', true );
	$doc_title  = get_post_meta( $post->ID, '_qt_primary_doc_title', true );
	$authority  = get_post_meta( $post->ID, '_qt_issuing_authority', true );
	$share_card = get_post_meta( $post->ID, '_qt_share_card', true );
	?>
	<p>
		<label><strong><?php esc_html_e( 'Verdict Badge (e.g. CONTRADICTED BY GAZETTE RECORD / CONFIRMED IN STATUTE):', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_status_badge" value="<?php echo esc_attr( $badge ); ?>" style="width:100%;">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Where Circulating (e.g. WhatsApp Groups & County Blogs):', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_where_circulating" value="<?php echo esc_attr( $circ ); ?>" style="width:100%;">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Primary Document Title:', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_primary_doc_title" value="<?php echo esc_attr( $doc_title ); ?>" style="width:100%;">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Issuing Constitutional Authority:', 'quiettruths' ); ?></strong></label><br>
		<input type="text" name="qt_issuing_authority" value="<?php echo esc_attr( $authority ); ?>" style="width:100%;">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'WhatsApp / Telegram Evidence Card Copy Text:', 'quiettruths' ); ?></strong></label><br>
		<textarea name="qt_share_card" rows="3" style="width:100%;"><?php echo esc_textarea( $share_card ); ?></textarea>
	</p>
	<p><em><?php esc_html_e( 'Enter the Viral Claim in the Post Title and the Exact Primary Record Finding in the main editor.', 'quiettruths' ); ?></em></p>
	<?php
}

function qt_save_editorial_meta_boxes( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['qt_hansard_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qt_hansard_nonce'] ) ), 'qt_save_hansard_meta' ) ) {
		$fields = array(
			'qt_category'     => '_qt_category',
			'qt_date_window'  => '_qt_date_window',
			'qt_doc_ref'      => '_qt_doc_ref',
			'qt_floor_status' => '_qt_floor_status',
		);
		foreach ( $fields as $input => $meta_key ) {
			if ( isset( $_POST[ $input ] ) ) {
				update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $input ] ) ) );
			}
		}
		if ( isset( $_POST['qt_podium_quote'] ) ) {
			update_post_meta( $post_id, '_qt_podium_quote', sanitize_textarea_field( wp_unslash( $_POST['qt_podium_quote'] ) ) );
		}
	}

	if ( isset( $_POST['qt_verification_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qt_verification_nonce'] ) ), 'qt_save_verification_meta' ) ) {
		$fields = array(
			'qt_status_badge'      => '_qt_status_badge',
			'qt_where_circulating' => '_qt_where_circulating',
			'qt_primary_doc_title' => '_qt_primary_doc_title',
			'qt_issuing_authority' => '_qt_issuing_authority',
		);
		foreach ( $fields as $input => $meta_key ) {
			if ( isset( $_POST[ $input ] ) ) {
				update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $input ] ) ) );
			}
		}
		if ( isset( $_POST['qt_share_card'] ) ) {
			update_post_meta( $post_id, '_qt_share_card', sanitize_textarea_field( wp_unslash( $_POST['qt_share_card'] ) ) );
		}
	}
}
add_action( 'save_post', 'qt_save_editorial_meta_boxes' );
