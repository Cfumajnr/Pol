<?php
/**
 * Quiet Truths — Structured Non-Partisan Kenyan Political Repository (All 47 Counties + 6 Core Pages)
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function qt_get_all_47_counties() {
	$json = <<<'QTJSON'
[
  {
    "code": "001",
    "name": "Mombasa",
    "region": "Coast",
    "constituencies": 6,
    "wards": 30,
    "voters": "658K",
    "x": 342,
    "y": 422,
    "governor": "Abdulswamad Sherrif Nassir (ODM)",
    "senator": "Mohamed Faki (ODM)",
    "womanRep": "Zamzam Mohammed (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Port services intergovernmental petitions and Coast 2027 ward nomination contests across all 30 wards."
  },
  {
    "code": "002",
    "name": "Kwale",
    "region": "Coast",
    "constituencies": 4,
    "wards": 20,
    "voters": "328K",
    "x": 326,
    "y": 442,
    "governor": "Fatuma Achani (UDA)",
    "senator": "Issa Juma Boy (ODM)",
    "womanRep": "Fatuma Masito (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Mining royalty benefit-sharing oversight and coastal land adjudication motions before the County Assembly."
  },
  {
    "code": "003",
    "name": "Kilifi",
    "region": "Coast",
    "constituencies": 7,
    "wards": 35,
    "voters": "588K",
    "x": 348,
    "y": 396,
    "governor": "Gideon Mung'aro (ODM)",
    "senator": "Stewart Madzayo (ODM — Senate Minority Leader)",
    "womanRep": "Gertrude Mbeyu (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Coastal coalition realignments and municipal charter governance across Malindi and Kilifi towns."
  },
  {
    "code": "004",
    "name": "Tana River",
    "region": "Coast",
    "constituencies": 3,
    "wards": 15,
    "voters": "141K",
    "x": 344,
    "y": 344,
    "governor": "Dhadho Godhana (ODM)",
    "senator": "Danson Mungatana (UDA)",
    "womanRep": "Amina Dika (KANU)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited gubernatorial succession race for 2027 and Tana Delta riparian settlement frameworks."
  },
  {
    "code": "005",
    "name": "Lamu",
    "region": "Coast",
    "constituencies": 2,
    "wards": 10,
    "voters": "81K",
    "x": 382,
    "y": 368,
    "governor": "Issa Timamy (ANC/UDA)",
    "senator": "Joseph Githuku Kamau (Jubilee)",
    "womanRep": "Monica Muthoni Marubu (Independent)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "LAPSSET corridor oversight motions and protected Article 89 low-population constituency safeguards."
  },
  {
    "code": "006",
    "name": "Taita-Taveta",
    "region": "Coast",
    "constituencies": 4,
    "wards": 20,
    "voters": "182K",
    "x": 298,
    "y": 404,
    "governor": "Andrew Mwadime (Independent)",
    "senator": "Jones Mwaruma (ODM)",
    "womanRep": "Lydia Haika (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Tsavo conservation revenue-sharing petitions before Parliament and independent executive-assembly collaboration."
  },
  {
    "code": "007",
    "name": "Garissa",
    "region": "North Eastern",
    "constituencies": 6,
    "wards": 30,
    "voters": "205K",
    "x": 368,
    "y": 274,
    "governor": "Nathif Jama Adam (ODM)",
    "senator": "Abdul Haji (NAP-K)",
    "womanRep": "Amina Udgoon Siyad (Jubilee)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Article 89 frontier landmass quota defense and Senate Devolution Committee review of County Public Service Board tenure."
  },
  {
    "code": "008",
    "name": "Wajir",
    "region": "North Eastern",
    "constituencies": 6,
    "wards": 30,
    "voters": "207K",
    "x": 374,
    "y": 198,
    "governor": " Ahmed Abdullahi (ODM — Former CoG Chair)",
    "senator": "Mohamed Abass Sheikh (UDM — Chair, Senate Devolution Committee)",
    "womanRep": "Fatuma Abdi Jehow (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Dryland water infrastructure oversight and negotiated democracy council endorsements ahead of 2027."
  },
  {
    "code": "009",
    "name": "Mandera",
    "region": "North Eastern",
    "constituencies": 6,
    "wards": 30,
    "voters": "217K",
    "x": 396,
    "y": 128,
    "governor": "Mohamed Adan Khalif (UDM)",
    "senator": "Ali Roba (UDM)",
    "womanRep": "Umulkheir Kassim (UDM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "UDM parliamentary bloc leverage and Senate debate over former governors serving in Senate oversight committees."
  },
  {
    "code": "010",
    "name": "Marsabit",
    "region": "Eastern",
    "constituencies": 4,
    "wards": 20,
    "voters": "166K",
    "x": 268,
    "y": 146,
    "governor": "Mohamud Mohamed Ali (UDM)",
    "senator": "Mohamed Said Chute (UDA)",
    "womanRep": "Naomi Jillo Waqo (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited 2027 gubernatorial transition and cross-constituency peace & grazing accords."
  },
  {
    "code": "011",
    "name": "Isiolo",
    "region": "Eastern",
    "constituencies": 2,
    "wards": 10,
    "voters": "89K",
    "x": 286,
    "y": 232,
    "governor": "Abdi Ibrahim Guyo (Jubilee)",
    "senator": "Fatuma Dullo (Jubilee)",
    "womanRep": "Mumina Bonaya (Jubilee)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "County Assembly-Executive impeachment litigation precedents and Article 89 protected constituency thresholds."
  },
  {
    "code": "012",
    "name": "Meru",
    "region": "Eastern",
    "constituencies": 9,
    "wards": 45,
    "voters": "772K",
    "x": 286,
    "y": 256,
    "governor": "Isaac Mutuma M'Ethingia (UDA)",
    "senator": "Kathuri Murungi (UDA — Deputy Speaker, Senate)",
    "womanRep": "Elizabeth Kailemia (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Post-impeachment county executive stabilization, miraa & tea statutory reforms, and Mt. Kenya East 2027 party positioning."
  },
  {
    "code": "013",
    "name": "Tharaka-Nithi",
    "region": "Eastern",
    "constituencies": 3,
    "wards": 15,
    "voters": "238K",
    "x": 282,
    "y": 272,
    "governor": "Muthomi Njuki (UDA — Chair, Council of Governors)",
    "senator": "Mwenda Gataya MoFire (UDA)",
    "womanRep": "Susan Ngugi (TSP)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Council of Governors national chairmanship (elected Oct 2026) and direct test case for the Senate 5-year cooling-off Bill."
  },
  {
    "code": "014",
    "name": "Embu",
    "region": "Eastern",
    "constituencies": 4,
    "wards": 20,
    "voters": "334K",
    "x": 274,
    "y": 286,
    "governor": "Cecily Mbarire (UDA — UDA National Chairperson)",
    "senator": "Alexander Mundigi (DP)",
    "womanRep": "Pamela Njoki Njeru (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Muguka/agricultural crop regulation intergovernmental disputes and governing party grassroots primary rules."
  },
  {
    "code": "015",
    "name": "Kitui",
    "region": "Eastern",
    "constituencies": 8,
    "wards": 40,
    "voters": "532K",
    "x": 302,
    "y": 326,
    "governor": "Julius Malombe (Wiper)",
    "senator": "Enock Wambua (Wiper — Deputy Minority Leader, Senate)",
    "womanRep": "Irene Kasalu (Wiper)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Lower Eastern opposition caucus anchor and county health & water ward equalization motions."
  },
  {
    "code": "016",
    "name": "Machakos",
    "region": "Eastern",
    "constituencies": 8,
    "wards": 40,
    "voters": "698K",
    "x": 274,
    "y": 332,
    "governor": "Wavinya Ndeti (Wiper)",
    "senator": "Agnes Kavindu Muthama (Wiper)",
    "womanRep": "Joyce Kamene (Wiper)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Senate Devolution Committee inquiry on County Public Service Board autonomy and Nairobi-metro urban spillover governance."
  },
  {
    "code": "017",
    "name": "Makueni",
    "region": "Eastern",
    "constituencies": 6,
    "wards": 30,
    "voters": "479K",
    "x": 284,
    "y": 362,
    "governor": "Mutula Kilonzo Jr. (Wiper)",
    "senator": "Dan Maanzo (Wiper)",
    "womanRep": "Rose Museo (Wiper)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Pioneering ward-based public participation budgeting model and inter-county boundary & water-sharing accords."
  },
  {
    "code": "018",
    "name": "Nyandarua",
    "region": "Central",
    "constituencies": 5,
    "wards": 25,
    "voters": "361K",
    "x": 226,
    "y": 272,
    "governor": "Moses Kiarie Badilisha (UDA)",
    "senator": "John Methu (UDA)",
    "womanRep": "Faith Gitau (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Potato & dairy cooperative statutory pricing motions and Central Rift/Mt. Kenya parliamentary realignments."
  },
  {
    "code": "019",
    "name": "Nyeri",
    "region": "Central",
    "constituencies": 6,
    "wards": 30,
    "voters": "481K",
    "x": 248,
    "y": 268,
    "governor": "Mutahi Kahiga (UDA)",
    "senator": "Wahome Wamatinga (UDA)",
    "womanRep": "Rahab Mukami (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited 2027 gubernatorial succession and post-October 2024 Mt. Kenya political bloc realignments."
  },
  {
    "code": "020",
    "name": "Kirinyaga",
    "region": "Central",
    "constituencies": 4,
    "wards": 20,
    "voters": "376K",
    "x": 262,
    "y": 276,
    "governor": "Anne Waiguru (UDA)",
    "senator": "Kamau Murango (UDA — Sponsor, 2026 Cooling-Off Amendment Bill)",
    "womanRep": "Jane Njeri Maina (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Home county of the Constitution of Kenya (Amendment) Bill, 2026 proposing a 5-year bar before outgoing governors vie for Senate."
  },
  {
    "code": "021",
    "name": "Murang'a",
    "region": "Central",
    "constituencies": 7,
    "wards": 35,
    "voters": "620K",
    "x": 252,
    "y": 286,
    "governor": "Irungu Kang'ata (UDA)",
    "senator": "Joe Nyutu (UDA)",
    "womanRep": "Betty Maina (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "County automated revenue & maternal healthcare governance models alongside intense 2027 parliamentary alliance debates."
  },
  {
    "code": "022",
    "name": "Kiambu",
    "region": "Central",
    "constituencies": 12,
    "wards": 60,
    "voters": "1.31M",
    "x": 246,
    "y": 298,
    "governor": "Kimani Wamatangi (UDA)",
    "senator": "Karungo wa Thang'wa (UDA)",
    "womanRep": "Anne Wamuratha (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Kenya's second-largest county vote basket; epicenter of competing Mt. Kenya parliamentary caucuses and 60-ward oversight motions."
  },
  {
    "code": "023",
    "name": "Turkana",
    "region": "Rift Valley",
    "constituencies": 6,
    "wards": 30,
    "voters": "242K",
    "x": 172,
    "y": 128,
    "governor": "Jeremiah Lomorukai (ODM)",
    "senator": "James Lomenen (UDA)",
    "womanRep": "Cecilia Asinyen (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Cross-party cooperation on frontier security, LAPSSET corridors, and extractive resource local benefit-sharing laws."
  },
  {
    "code": "024",
    "name": "West Pokot",
    "region": "Rift Valley",
    "constituencies": 4,
    "wards": 20,
    "voters": "221K",
    "x": 162,
    "y": 188,
    "governor": "Simon Kachapin (UDA)",
    "senator": "Julius Murgor (UDA)",
    "womanRep": "Rael Aleutum (KUP)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "North Rift peace & livestock corridor initiatives and 2027 multi-party competition between UDA and KUP."
  },
  {
    "code": "025",
    "name": "Samburu",
    "region": "Rift Valley",
    "constituencies": 3,
    "wards": 15,
    "voters": "102K",
    "x": 236,
    "y": 198,
    "governor": "Jonathan Lelelit (UDA)",
    "senator": "Steve Lelegwe (UDA)",
    "womanRep": "Pauline Lenguris (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Pastoralist parliamentary caucus advocacy on conservancy governance and equalization fund disbursements."
  },
  {
    "code": "026",
    "name": "Trans Nzoia",
    "region": "Rift Valley",
    "constituencies": 5,
    "wards": 25,
    "voters": "402K",
    "x": 160,
    "y": 214,
    "governor": "George Natembeya (DAP-K)",
    "senator": "Allan Chesang (UDA)",
    "womanRep": "Lillian Siyoi (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Four-party competitive microcosm (DAP-K, UDA, ODM, FORD-K) and Senate review of county public service board litigation."
  },
  {
    "code": "027",
    "name": "Uasin Gishu",
    "region": "Rift Valley",
    "constituencies": 6,
    "wards": 30,
    "voters": "523K",
    "x": 178,
    "y": 235,
    "governor": "Jonathan Bii Chelilim (UDA)",
    "senator": "Jackson Mandago (UDA)",
    "womanRep": "Gladys Boss (UDA — Deputy Speaker, NA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Eldoret City Charter municipal transition and national cereal/fertilizer subsidy oversight motions."
  },
  {
    "code": "028",
    "name": "Elgeyo-Marakwet",
    "region": "Rift Valley",
    "constituencies": 4,
    "wards": 20,
    "voters": "214K",
    "x": 188,
    "y": 222,
    "governor": "Wisley Rotich (UDA)",
    "senator": "William Kisang (UDA)",
    "womanRep": "Caroline Ng'elechei (Independent)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Kerio Valley security & irrigation development frameworks and athletic high-altitude infrastructure oversight."
  },
  {
    "code": "029",
    "name": "Nandi",
    "region": "Rift Valley",
    "constituencies": 6,
    "wards": 30,
    "voters": "409K",
    "x": 172,
    "y": 252,
    "governor": "Stephen Sang (UDA)",
    "senator": "Samson Cherargei (UDA)",
    "womanRep": "Cynthia Muge (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited 2027 gubernatorial succession and vocal Senate-County Executive oversight exchanges."
  },
  {
    "code": "030",
    "name": "Baringo",
    "region": "Rift Valley",
    "constituencies": 6,
    "wards": 30,
    "voters": "282K",
    "x": 204,
    "y": 228,
    "governor": "Benjamin Cheboi (UDA)",
    "senator": "Vincent Kiprono Chemitei (UDA)",
    "womanRep": "Florence Jematia (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Rift Valley lake-rise resettlement petitions and Kerio Valley peace-building parliamentary inquiries."
  },
  {
    "code": "031",
    "name": "Laikipia",
    "region": "Rift Valley",
    "constituencies": 3,
    "wards": 15,
    "voters": "264K",
    "x": 242,
    "y": 242,
    "governor": "Joshua Irungu (UDA)",
    "senator": "John Kinyua (UDA)",
    "womanRep": "Jane Kagiri (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Rangeland land-use coexistence legislation and cosmopolitan three-constituency ward representation."
  },
  {
    "code": "032",
    "name": "Nakuru",
    "region": "Rift Valley",
    "constituencies": 11,
    "wards": 55,
    "voters": "1.09M",
    "x": 214,
    "y": 282,
    "governor": "Susan Kihika (UDA)",
    "senator": "Tabitha Karanja (UDA)",
    "womanRep": "Liza Chelule (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Kenya's third-largest voting basket and cosmopolitan bellwether ahead of the December 9, 2026 harambee cutoff."
  },
  {
    "code": "033",
    "name": "Narok",
    "region": "Rift Valley",
    "constituencies": 6,
    "wards": 30,
    "voters": "412K",
    "x": 198,
    "y": 332,
    "governor": "Patrick Ole Ntutu (UDA)",
    "senator": "Ledama Olekina (ODM — Senate Minority Whip)",
    "womanRep": "Rebecca Tonkei (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Maasai Mara conservation management statutes, Mau forest boundary protections, and UDA-ODM split-ticket county representation."
  },
  {
    "code": "034",
    "name": "Kajiado",
    "region": "Rift Valley",
    "constituencies": 5,
    "wards": 25,
    "voters": "466K",
    "x": 244,
    "y": 362,
    "governor": "Joseph Ole Lenku (ODM)",
    "senator": "Samuel Seki Kanar (UDA)",
    "womanRep": "Leah Sankaire (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited 2027 open gubernatorial contest and rapid metropolitan urbanization across Kitengela, Ngong, and Ongata Rongai."
  },
  {
    "code": "035",
    "name": "Kericho",
    "region": "Rift Valley",
    "constituencies": 6,
    "wards": 30,
    "voters": "428K",
    "x": 182,
    "y": 278,
    "governor": "Dr. Erick Mutai (UDA)",
    "senator": "Aaron Cheruiyot (UDA — Senate Majority Leader)",
    "womanRep": "Beatrice Kemei (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Constitutional threshold precedents in Senate impeachment hearings and Tea Act smallholder reform debates."
  },
  {
    "code": "036",
    "name": "Bomet",
    "region": "Rift Valley",
    "constituencies": 5,
    "wards": 25,
    "voters": "385K",
    "x": 184,
    "y": 302,
    "governor": "Prof. Hillary Barchok (UDA)",
    "senator": "Hillary Sigei (UDA — Chair, Senate JLAC)",
    "womanRep": "Linet Chepkorir Toto (UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited 2027 gubernatorial transition and Senate Justice & Legal Affairs Committee constitutional reform docket."
  },
  {
    "code": "037",
    "name": "Kakamega",
    "region": "Western",
    "constituencies": 12,
    "wards": 60,
    "voters": "854K",
    "x": 146,
    "y": 248,
    "governor": "Fernandes Barasa (ODM)",
    "senator": "Dr. Boni Khalwale (UDA — Senate Majority Whip)",
    "womanRep": "Elsie Muhanda (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Split-ticket executive vs. Senate scrutiny, sugar sector revitalization bills, and Western Kenya multi-party realignments."
  },
  {
    "code": "038",
    "name": "Vihiga",
    "region": "Western",
    "constituencies": 5,
    "wards": 25,
    "voters": "312K",
    "x": 144,
    "y": 260,
    "governor": "Dr. Wilber Ottichilo (ODM)",
    "senator": "Godfrey Osotsi (ODM — Chair, Senate CPAC)",
    "womanRep": "Beatrice Adagala (ANC/UDA)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited 2027 gubernatorial succession and post-ANC merger grassroots competition across Sabatia and Vihiga."
  },
  {
    "code": "039",
    "name": "Bungoma",
    "region": "Western",
    "constituencies": 9,
    "wards": 45,
    "voters": "646K",
    "x": 142,
    "y": 228,
    "governor": "Kenneth Lusaka (FORD-Kenya)",
    "senator": "David Wakoli Wafula (FORD-Kenya)",
    "womanRep": "Catherine Wambilianga (FORD-Kenya)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "FORD-Kenya stronghold dynamics (home of National Assembly Speaker Moses Wetang'ula) and term-limited 2027 governor race."
  },
  {
    "code": "040",
    "name": "Busia",
    "region": "Western",
    "constituencies": 7,
    "wards": 35,
    "voters": "418K",
    "x": 126,
    "y": 248,
    "governor": "Dr. Paul Otuoma (ODM)",
    "senator": "Okiya Omtatah (NRA — Constitutional Litigator)",
    "womanRep": "Catherine Omanyo (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "High-profile constitutional petitions originating from Senator Omtatah's docket and East African cross-border trade governance."
  },
  {
    "code": "041",
    "name": "Siaya",
    "region": "Nyanza",
    "constituencies": 6,
    "wards": 30,
    "voters": "534K",
    "x": 128,
    "y": 266,
    "governor": "James Orengo (ODM)",
    "senator": "Dr. Oburu Oginga (ODM)",
    "womanRep": "Christine Ombaka (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Constitutionalists' debate within ODM over the Broad-Based Government posture versus strict 2010 Constitutional opposition lines."
  },
  {
    "code": "042",
    "name": "Kisumu",
    "region": "Nyanza",
    "constituencies": 7,
    "wards": 35,
    "voters": "621K",
    "x": 142,
    "y": 278,
    "governor": "Prof. Anyang' Nyong'o (ODM)",
    "senator": "Prof. Tom Ojienda (ODM)",
    "womanRep": "Ruth Odinga (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Open-seat 2027 gubernatorial succession as Prof. Nyong'o concludes his second term; Lakefront economic & municipal governance."
  },
  {
    "code": "043",
    "name": "Homa Bay",
    "region": "Nyanza",
    "constituencies": 8,
    "wards": 40,
    "voters": "551K",
    "x": 132,
    "y": 294,
    "governor": "Gladys Wanga (ODM — ODM National Chairperson)",
    "senator": "Moses Kajwang' (ODM)",
    "womanRep": "Joyce Bensuda Atieno (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "National party leadership seat of ODM Chairperson Gladys Wanga and blue-economy Lake Victoria ward initiatives."
  },
  {
    "code": "044",
    "name": "Migori",
    "region": "Nyanza",
    "constituencies": 8,
    "wards": 40,
    "voters": "474K",
    "x": 136,
    "y": 314,
    "governor": "Dr. Ochilo Ayacko (ODM)",
    "senator": "Eddy Oketch (ODM)",
    "womanRep": "Fatuma Mohammed (Independent)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Pluralistic Nyanza border politics combining ODM parliamentary leadership, Kuria constituency debates, and independent winners."
  },
  {
    "code": "045",
    "name": "Kisii",
    "region": "Nyanza",
    "constituencies": 9,
    "wards": 45,
    "voters": "637K",
    "x": 154,
    "y": 298,
    "governor": "Simba Arati (ODM)",
    "senator": "Richard Onyonka (ODM)",
    "womanRep": "Dorice Donya Toto (Wiper)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "High-energy bipartisan competition across Gusii's 9 constituencies ahead of the August 10, 2027 General Election."
  },
  {
    "code": "046",
    "name": "Nyamira",
    "region": "Nyanza",
    "constituencies": 4,
    "wards": 20,
    "voters": "324K",
    "x": 162,
    "y": 292,
    "governor": "Amos Nyaribo (UPA)",
    "senator": "Okong'o Omogeni (ODM)",
    "womanRep": "Jerusha Momanyi (Jubilee)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Term-limited 2027 gubernatorial race, County Assembly-Executive oversight motions, and Gusii regional alliance talks."
  },
  {
    "code": "047",
    "name": "Nairobi",
    "region": "Nairobi Metro",
    "constituencies": 17,
    "wards": 85,
    "voters": "2.48M",
    "x": 248,
    "y": 318,
    "governor": "Johnson Sakaja (UDA)",
    "senator": "Edwin Sifuna (ODM)",
    "womanRep": "Esther Passaris (ODM)",
    "mpsSample": "Open the full constituency and ward directory.",
    "localPulse": "Nairobi City County Urban Renewal & 85-Ward Mobility Oversight Motions; high-growth eastern wards operating under the retained 2027 IEBC boundary map."
  }
]
QTJSON;
	$decoded = json_decode( $json, true );
	return is_array( $decoded ) ? $decoded : array();
}


function qt_get_national_stage_updates() {
	return array(
		array(
			'institution' => 'IEBC Electoral Calendar',
			'date'        => 'November 2026',
			'headline'    => '2027 General Election Map Retained at 290 Constituencies & 1,450 Wards; December 9 Fundraising Cutoff Approaches',
			'detail'      => 'Following gazette notices setting Tuesday, August 10, 2027 as the General Election date and certifying party nomination rules in November 2026, aspirants face the statutory December 9, 2026 prohibition on public harambee fundraising under Section 26 of the Elections Act.',
		),
		array(
			'institution' => 'The Senate of Kenya',
			'date'        => 'November 2026',
			'headline'    => 'Constitution of Kenya (Amendment) Bill, 2026 Tests Five-Year Cooling-Off Period for Outgoing Governors',
			'detail'      => 'Awaiting Second Reading in the Senate, the Bill seeks to amend Articles 99 and 193 of the Constitution to bar serving and recently retired governors from contesting Senate or County Assembly seats for five years after leaving office.',
		),
		array(
			'institution' => 'Parliamentary Coalitions',
			'date'        => 'November 2026',
			'headline'    => '13th Parliament Balances Broad-Based Executive Cooperation With Independent 2027 Party Primaries',
			'detail'      => 'While Cabinet and parliamentary committee leadership reflect cross-aisle cooperation between UDA and segments of ODM, individual parties filed separate nomination rules with the IEBC ahead of the 2027 electoral cycle.',
		),
	);
}

function qt_get_quiet_brief_items() {
	$items = array();
	$custom = get_posts(
		array(
			'post_type'      => 'qt_brief',
			'posts_per_page' => 5,
			'post_status'    => 'publish',
		)
	);
	if ( ! empty( $custom ) ) {
		foreach ( $custom as $idx => $p ) {
			$items[] = array(
				'num'      => str_pad( (string) ( $idx + 1 ), 2, '0', STR_PAD_LEFT ),
				'category' => get_the_title( $p ),
				'summary'  => wp_strip_all_tags( $p->post_content ),
			);
		}
	}
	if ( empty( $items ) ) {
		$items = array(
			array(
				'num'      => '01',
				'category' => 'Gazette & Statutory Deadlines',
				'summary'  => 'Party nomination rules certification window closed November 6, 2026; statutory ban on aspirant participation in public harambees takes effect December 9, 2026 (eight months prior to the August 10, 2027 General Election).',
			),
			array(
				'num'      => '02',
				'category' => 'Senate Floor & Committees',
				'summary'  => 'Senate Committee on Devolution and Intergovernmental Relations prepares legislative safeguards addressing recurring litigation between County Executives and County Public Service Boards (CPSBs).',
			),
			array(
				'num'      => '03',
				'category' => 'Judiciary & Constitutional Law',
				'summary'  => 'Constitutional petitions regarding the deferral of constituency boundary delimitation remain under judicial review following the Supreme Court September 2025 advisory ruling.',
			),
		);
	}
	return $items;
}

function qt_get_blind_ballot_issues() {
	return array(
		array(
			'id'                   => 'electoral-reform',
			'title'                => 'Electoral Governance & Constituency Boundary Review',
			'subtitle'             => 'How should Kenya handle overdue boundary delimitation, IEBC independence, and result verification for August 2027?',
			'constitutionalAnchor' => 'Articles 81, 88 & 89 — Constitution of Kenya',
			'quietAgreement'       => 'All three major political camps formally endorse biometric voter identification at polling stations, polling-station finality of presidential results, and post-2027 digital geo-mapping of all 1,450 wards.',
			'positions'            => array(
				array(
					'label'               => 'Position A',
					'headline'            => 'Phased Continuity First: Hold 2027 Under Existing 290 Constituencies, Delimit Immediately After',
					'proposal'            => 'Proceed with the August 10, 2027 General Election using the existing 2012 map of 290 constituencies and 1,450 wards to protect electoral certainty, restricting immediate pre-election changes to voter registration and polling-station gazettement.',
					'institutionsChanged' => 'Elections Act operational timelines; IEBC Phased Delimitation Roadmap (deferring substantive Article 89 boundary redrawing to 2028–2029).',
					'argumentFor'         => 'Attempting a contested nationwide boundary redraw less than a year before a general election invites hundreds of High Court injunctions that could paralyze the 2027 ballot.',
					'mainCriticism'       => 'Leaves high-population urban constituencies under-represented for a fourth consecutive cycle while risking constitutional litigation over missed Article 89 deadlines.',
					'sourceParty'         => 'Governing Parliamentary Majority & IEBC Operational Posture',
					'sourceCitation'      => 'Kenya Kwanza Parliamentary Caucus Statements & IEBC Phased Operational Roadmap (2026 Gazette Notices)',
				),
				array(
					'label'               => 'Position B',
					'headline'            => 'Bipartisan Statutory Safeguards & Mandatory Multi-Party Audit of the Voter Register',
					'proposal'            => 'Accept the practical freeze on constituency boundaries for 2027 only when paired with binding statutory implementation of the National Dialogue Committee (NADCO) electoral package—including an independent forensic audit of the voter roll.',
					'institutionsChanged' => 'IEBC (Amendment) Act; Elections Offences Act; Statutory Independent Electoral Audit Mechanism 6 months prior to polling day.',
					'argumentFor'         => 'Institutional trust depends less on rushed map lines and more on verifiable voter rolls, open server logs, and multi-party selection panels.',
					'mainCriticism'       => 'Critics argue bipartisan pacts between the two largest parliamentary blocs exclude newer parties and civic groups from shaping electoral oversight.',
					'sourceParty'         => 'ODM / Broad-Based NADCO Reform Signatories',
					'sourceCitation'      => 'National Dialogue Committee (NADCO) Report Electoral Reform Pillar & ODM NEC Resolutions',
				),
				array(
					'label'               => 'Position C',
					'headline'            => 'Strict Constitutionalism, Open Result Portals & Ban on State-Resource Campaigning',
					'proposal'            => 'Enforce statutory firewalls barring public officers and state vehicles from party campaigns, mandate real-time public portal publication of polling-station forms with observer API access, and require explicit constitutional cure for missed deadlines.',
					'institutionsChanged' => 'Election Campaign Financing Act activation; Leadership and Integrity Act enforcement rules; Public Officer Ethics Act penalties.',
					'argumentFor'         => 'Administrative convenience must never normalize missing mandatory constitutional timelines or allow incumbency to tilt the electoral playing field.',
					'mainCriticism'       => 'Opponents argue sweeping campaign-finance caps inside an election window create compliance traps that disproportionately burden first-time challengers.',
					'sourceParty'         => 'Wiper / DAP-K / Independent Constitutionalist Opposition Bloc',
					'sourceCitation'      => 'Minority Caucus Submissions & Joint Opposition Electoral Integrity Charter (2025–2026)',
				),
			),
		),
		array(
			'id'                   => 'devolution-oversight',
			'title'                => 'Devolution Power Balance: Governors, Senators & County Boards',
			'subtitle'             => 'Where should accountability stop and interference begin between County Executives, County Public Service Boards, and the Senate?',
			'constitutionalAnchor' => 'Articles 6(2), 96, 174, 193 & 235 — Constitution of Kenya',
			'quietAgreement'       => 'Every parliamentary grouping agrees in writing that county governments are distinct—not subordinate—levels of government under Article 6(2), and that devolved functions require predictable institutional coordination.',
			'positions'            => array(
				array(
					'label'               => 'Position A',
					'headline'            => 'Enforce a 5-Year Cooling-Off Period Before Outgoing Governors Can Sit in the Senate',
					'proposal'            => 'Amend Articles 99 and 193 of the Constitution so serving governors—and former governors within five years of leaving office—cannot run for the Senate or County Assembly, preventing conflicts of interest during county audit hearings.',
					'institutionsChanged' => 'Constitution of Kenya (Amendment) Bill, 2026 (Articles 99 & 193); Elections Act Sections 24 & 25.',
					'argumentFor'         => 'When an immediate former governor becomes Senator, County Public Accounts hearings face direct conflicts of interest when auditing the preceding term.',
					'mainCriticism'       => 'Restricts voters constitutional freedom under Article 38 to elect leaders of their choice and targets experienced county chiefs ahead of 2027.',
					'sourceParty'         => 'Senate Oversight Reform Caucus (Cross-Party Senate Sponsors)',
					'sourceCitation'      => 'The Constitution of Kenya (Amendment) Bill, 2026 — Sponsored in the Senate by Sen. Kamau Murango',
				),
				array(
					'label'               => 'Position B',
					'headline'            => 'Protect Executive Mandate of Governors & Reform County Boards Without Career Bans',
					'proposal'            => 'Reject political disqualifications under Article 38, and instead amend the County Governments Act to align County Public Service Board transitions with clear performance accountability while curbing repetitive Senate summonses.',
					'institutionsChanged' => 'County Governments Act (Section 58); Intergovernmental Relations Act dispute-resolution protocols.',
					'argumentFor'         => 'Voters—not Senators—hold the ballot power to judge a former governor record, while turf wars between governors, inherited boards, and Senators stall county services.',
					'mainCriticism'       => 'Weakening County Public Service Board tenure insulation risks enabling incoming governors to purge career county staff after elections.',
					'sourceParty'         => 'Council of Governors (Bipartisan County Executives Position)',
					'sourceCitation'      => 'Council of Governors Legislative Memoranda to the Senate (2025–2026)',
				),
				array(
					'label'               => 'Position C',
					'headline'            => 'Strengthen Ward-Level Devolution & Financial Autonomy of All 47 County Assemblies',
					'proposal'            => 'Entrench full financial autonomy for all 47 County Assemblies and statutory Ward planning committees so oversight happens locally across the 1,450 wards rather than exclusively in Nairobi committee rooms.',
					'institutionsChanged' => 'County Assemblies Services Act; Ward-Based Participatory Governance Statute.',
					'argumentFor'         => 'MCAs live directly among citizens; giving County Assemblies calendar and budget independence stops executive capture at the county level.',
					'mainCriticism'       => 'Critics warn expanding ward-level executive funds managed by MCAs blurs constitutional separation of powers between lawmaking and execution.',
					'sourceParty'         => 'County Assemblies Forum & Grassroots Devolution Caucus',
					'sourceCitation'      => 'County Assemblies Forum Constitutional Submissions & Senate Devolution Reports',
				),
			),
		),
		array(
			'id'                   => 'executive-structure',
			'title'                => 'Executive Architecture & Parliamentary Opposition Recognition',
			'subtitle'             => 'Should Kenya remain strictly presidential, or constitutionally entrench a Prime Cabinet Secretary and Official Leader of the Opposition?',
			'constitutionalAnchor' => 'Chapters 8 & 9 (Articles 93–155) — Constitution of Kenya',
			'quietAgreement'       => 'Across manifesto traditions, parties acknowledge that winner-takes-all presidential anxiety every five years fuels post-election polarization and requires stronger institutional room for parliamentary scrutiny.',
			'positions'            => array(
				array(
					'label'               => 'Position A',
					'headline'            => 'Codify Both the Prime Cabinet Secretary & Office of the Leader of the Official Opposition',
					'proposal'            => 'Anchor both the Prime Cabinet Secretary (coordinating ministries) and a publicly funded Office of the Leader of the Official Opposition—allowing the presidential runner-up to lead structured accountability inside constitutional institutions.',
					'institutionsChanged' => 'National Government Coordination Act; Proposed Constitutional Amendment on Executive & Official Opposition Offices.',
					'argumentFor'         => 'Gives millions of voters who backed the runner-up formal constitutional voice while keeping Cabinet Secretaries accountable to Parliament.',
					'mainCriticism'       => 'Expands apex political offices and elite accommodation without submitting structural changes of the 2010 Constitution to a popular referendum.',
					'sourceParty'         => 'Kenya Kwanza & NADCO Bipartisan Governance Framework',
					'sourceCitation'      => 'Kenya Kwanza Charter & NADCO Final Report Governance Recommendations',
				),
				array(
					'label'               => 'Position B',
					'headline'            => 'Hybrid Parliamentary Question Time: Require Cabinet Secretaries on the House Floor',
					'proposal'            => 'Maintain Standing Order reforms requiring Cabinet Secretaries to appear live on the floor of the National Assembly and Senate during Question Time, blending presidential stability with direct floor questioning.',
					'institutionsChanged' => 'National Assembly & Senate Standing Orders; Parliamentary Powers and Privileges Act.',
					'argumentFor'         => 'Direct floor questioning speeds urgent public accountability compared to slow written committee correspondence.',
					'mainCriticism'       => 'Constitutional purists warn the 2010 Constitution deliberately separated Cabinet from Parliament so MPs audit ministers rather than defend them.',
					'sourceParty'         => '13th Parliament Procedural Consensus (Majority & Cooperating Leadership)',
					'sourceCitation'      => 'National Assembly Standing Orders Amendments on Wednesday Cabinet Question Time',
				),
				array(
					'label'               => 'Position C',
					'headline'            => 'Defend Pure 2010 Separation of Powers & Prohibit Cross-Aisle Cabinet Co-optation',
					'proposal'            => 'Enforce an unmistakable wall between Government and Opposition: prohibit opposition parties from nominating Cabinet Secretaries while simultaneously retaining Minority oversight chairmanships in Parliament.',
					'institutionsChanged' => 'Political Parties Act (Minority Designation Rules); Parliamentary Standing Orders.',
					'argumentFor'         => 'When opposition parties join Cabinet while keeping Minority watchdog chairs, legislative checks and balances collapse.',
					'mainCriticism'       => 'Proponents of broad-based governments counter that moments of national polarization require cross-aisle cooperation to preserve stability.',
					'sourceParty'         => 'Strict Constitutionalist Minority Bloc (Wiper / DAP-K / Civic Constitutionalists)',
					'sourceCitation'      => 'National Assembly Minority Leadership Legal Filings & High Court Submissions (2024–2026)',
				),
			),
		),
		array(
			'id'                   => 'party-discipline',
			'title'                => 'Political Party Mergers, Coalition Hopping & Voter Mandate',
			'subtitle'             => 'When an MP or party switches alliances mid-term, do they owe their seat to the voter or the party ticket?',
			'constitutionalAnchor' => 'Articles 38, 91, 92 & 103(1)(e) — Constitution of Kenya',
			'quietAgreement'       => 'All camps endorse digital ORPP party-membership verification via eCitizen and USSD *509# so no Kenyan citizen is ever listed in a political party register without informed consent.',
			'positions'            => array(
				array(
					'label'               => 'Position A',
					'headline'            => 'Consolidate Into Large, National Programmatic Parties Over Regional Micro-Parties',
					'proposal'            => 'Encourage voluntary mergers of smaller regional outfits into permanent national parties with offices across all 47 counties, reducing personality-owned pre-election bargaining vehicles.',
					'institutionsChanged' => 'Political Parties Act merger frameworks; ORPP 47-County Branch Compliance Rules.',
					'argumentFor'         => 'Enduring democracies organize around two or three national ideological parties rather than dozens of regional ethnic vehicles.',
					'mainCriticism'       => 'Smaller coalition partners warn pressured mergers silence pluralistic voices and echo single-party centralization.',
					'sourceParty'         => 'UDA National Party Consolidation Doctrine',
					'sourceCitation'      => 'UDA National Governing Council Resolutions & Merger Instruments (2024–2025)',
				),
				array(
					'label'               => 'Position B',
					'headline'            => 'Preserve Coalition Political Parties Allowing Constituent Parties to Keep Their Identity',
					'proposal'            => 'Retain the 2022 Political Parties (Amendment) Act model allowing constituent parties to keep independent primaries, symbols, and Political Parties Fund shares while entering joint presidential coalitions.',
					'institutionsChanged' => 'Political Parties (Amendment) Act Coalition Registry & Dispute Clauses.',
					'argumentFor'         => 'Respects regional pluralism and protects mid-sized parties while enabling broad national presidential coalitions.',
					'mainCriticism'       => 'Creates post-election legal battles over which bloc holds the Parliamentary Majority when constituent parties shift allegiance after swearing-in.',
					'sourceParty'         => 'ODM / Multi-Party Coalition Charter Tradition',
					'sourceCitation'      => 'Political Parties (Amendment) Act, 2022 Hansard Debates',
				),
				array(
					'label'               => 'Position C',
					'headline'            => 'Mandatory By-Election Under Article 103 When Elected Leaders Cross the Floor Mid-Term',
					'proposal'            => 'Enforce Article 103(1)(e) strictly so any MP, Senator, or MCA who switches political camp mid-term must seek a fresh mandate from voters in a constituency or ward by-election.',
					'institutionsChanged' => 'Elections Act Floor-Crossing Enforcement Timeline; Mandatory 21-Day Speaker Ruling Window.',
					'argumentFor'         => 'Voters elect representatives on a specific platform; mid-term defections without a by-election nullify voter sovereignty.',
					'mainCriticism'       => 'Strict party-boss expulsion powers risk turning MPs into rubber stamps afraid to vote their constituency conscience.',
					'sourceParty'         => 'Reformist Party-Discipline & Independent Constitutionalist Caucus',
					'sourceCitation'      => 'High Court Rulings on Article 108 Majority Status & Article 103 Petitions',
				),
			),
		),
	);
}

function qt_get_podium_vs_parliament_records() {
	$records = array();
	$custom  = get_posts(
		array(
			'post_type'      => 'qt_hansard',
			'posts_per_page' => 20,
			'post_status'    => 'publish',
		)
	);
	foreach ( $custom as $p ) {
		$records[] = array(
			'topic'         => get_the_title( $p ),
			'category'      => get_post_meta( $p->ID, '_qt_category', true ) ?: 'Parliamentary Record',
			'dateWindow'    => get_post_meta( $p->ID, '_qt_date_window', true ) ?: get_the_date( 'F Y', $p ),
			'podiumSetting' => 'Public Political Platform',
			'podiumQuote'   => get_post_meta( $p->ID, '_qt_podium_quote', true ),
			'recordSetting' => 'Parliament of Kenya / Official Record',
			'recordSummary' => wp_strip_all_tags( $p->post_content ),
			'docRef'        => get_post_meta( $p->ID, '_qt_doc_ref', true ),
			'floorStatus'   => get_post_meta( $p->ID, '_qt_floor_status', true ),
		);
	}

	$defaults = array(
		array(
			'topic'         => 'Outgoing Governors Contesting Senate Seats in 2027',
			'category'      => 'Constitutional Amendments',
			'dateWindow'    => 'May – November 2026',
			'podiumSetting' => 'Public Rallies & County Executive Briefings (Cross-Coalition Second-Term Governors)',
			'podiumQuote'   => '"Every citizen—including an outgoing two-term Governor—has an unfettered constitutional right under Article 38 to vie for any seat voters choose. Proposals to lock governors out of the Senate are schemes to protect incumbents in 2027."',
			'recordSetting' => 'The Senate of Kenya — Legislative Docket & CPAC Proceedings',
			'recordSummary' => 'In County Public Accounts Committee (CPAC) sittings, Senators from both sides documented recurring procedural conflicts whenever former Governors now serving as Senators review Auditor-General queries from their own preceding county administrations. The tabled Bill proposes amending Articles 99 and 193 to introduce a 5-year cooling-off window.',
			'docRef'        => 'The Constitution of Kenya (Amendment) Bill, 2026 (Senate Bills, 2026) & CPAC Hansard Reports',
			'floorStatus'   => 'Published & awaiting Second Reading; requires 2/3 supermajority (45 Senators & 233 MPs) under Article 256.',
		),
		array(
			'topic'         => 'Parliamentary Majority vs. Minority Status After Cross-Aisle Cooperation',
			'category'      => 'House Leadership & Coalitions',
			'dateWindow'    => '2024 – 2026',
			'podiumSetting' => 'Weekend Townhalls & National Broadcast Interviews',
			'podiumQuote'   => '"Joining hands on broad-based national stability does not mean folding our party or surrendering our parliamentary role checking government excesses ahead of 2027."',
			'recordSetting' => 'National Assembly Floor Rulings, Committee Reconstitutions & High Court Record',
			'recordSummary' => 'Following the High Court judgment on Article 108 Majority determination and subsequent Speaker communications in the National Assembly, Departmental Committee leadership was formally reorganized in 2025–2026—with cooperating opposition MPs assuming key committee chairs alongside Majority members.',
			'docRef'        => 'National Assembly Hansard (Speaker Communications, 2025–2026) & High Court Judgment on Article 108',
			'floorStatus'   => 'Recorded in National Assembly Votes and Proceedings: bipartisan reconstitution of Departmental Committees.',
		),
		array(
			'topic'         => '2027 Constituency Boundary Review & Protected Rural Quotas',
			'category'      => 'Electoral Law',
			'dateWindow'    => 'January – August 2026',
			'podiumSetting' => 'Regional Delegations & Constituency Rallies',
			'podiumQuote'   => '"We will demand new constituencies before 2027 for high-population areas" — countered at rival rallies by — "Not a single protected constituency will be merged on our watch."',
			'recordSetting' => 'Supreme Court Advisory Reference & IEBC Gazette Notices',
			'recordSummary' => 'Because the 30-month absence of sworn IEBC commissioners pushed Kenya past the mandatory March 2024 constitutional 12-year review deadline, the Supreme Court struck out requests for a deadline extension in September 2025. The reconstituted IEBC formally gazetted all existing 290 constituencies and 1,450 wards unchanged for August 10, 2027.',
			'docRef'        => 'Supreme Court Reference No. E004 of 2024 (Sept 5, 2025) & IEBC 2027 Gazette Notices (Aug 2026)',
			'floorStatus'   => 'Zero constituencies added or merged for 2027; substantive delimitation legally deferred until post-2027.',
		),
		array(
			'topic'         => 'Public Harambees & Early Fundraising by 2027 Aspirants',
			'category'      => 'Elections Act Compliance',
			'dateWindow'    => 'August – December 2026',
			'podiumSetting' => 'Community Fundraisers & Weekend Empowerment Drives',
			'podiumQuote'   => '"Standing with local community groups and churches at weekend fundraisers is cultural solidarity, not election campaigning."',
			'recordSetting' => 'Statute Book of Kenya (Elections Act) & IEBC Statutory Calendar',
			'recordSummary' => 'Under Section 26 of the Elections Act enacted by Parliament itself, any person who directly or indirectly participates in a public fundraising or harambee within eight months preceding a General Election—except an official registered political party fundraiser—faces statutory disqualification.',
			'docRef'        => 'Section 26 of the Elections Act, No. 24 of 2011 & IEBC 2027 Election Calendar Gazette Notice',
			'floorStatus'   => 'Hard statutory prohibition takes legal force on December 9, 2026 ahead of the August 10, 2027 poll.',
		),
	);

	return array_merge( $records, $defaults );
}

function qt_get_coalition_data() {
	return array(
		'blocs'    => array(
			array(
				'id'      => 'kenya-kwanza',
				'name'    => 'Kenya Kwanza Alliance',
				'status'  => 'Governing Parliamentary Coalition',
				'na'      => 179,
				'senate'  => 33,
				'color'   => '#047857',
				'offices' => "Speaker of National Assembly (Moses Wetang'ula), Speaker of Senate (Amason Kingi), NA Majority Leader (Kimani Ichung'wah), Senate Majority Leader (Aaron Cheruiyot)",
				'parties' => array( 'UDA (United Democratic Alliance — merged with ANC)', 'FORD–Kenya', 'UDM', 'PAA', 'TSP', 'MCC', 'CCK', 'DP' ),
				'posture' => 'Consolidating national governing apparatus while navigating regional caucus dynamics across Rift Valley, Mt. Kenya, Western, and Northern Kenya ahead of 2027 primaries.',
			),
			array(
				'id'      => 'broad-based-odm',
				'name'    => 'ODM (Broad-Based Parliamentary Partner)',
				'status'  => 'Largest Single Minority Party — In Structured Executive & Committee Cooperation',
				'na'      => 89,
				'senate'  => 20,
				'color'   => '#0284C7',
				'offices' => 'NA Minority Leader (Junet Mohamed), Senate Minority Leader (Stewart Madzayo), Key Departmental Oversight Chairs',
				'parties' => array( 'Orange Democratic Movement (ODM)' ),
				'posture' => 'Retains independent registered party status and filed separate November 2026 IEBC nomination rules, while participating in the post-2024 broad-based Cabinet and House committee leadership.',
			),
			array(
				'id'      => 'azimio-non-aligned',
				'name'    => 'Non-Aligned Azimio & Constitutional Opposition Caucus',
				'status'  => 'Parliamentary Opposition Outside Broad-Based Executive',
				'na'      => 69,
				'senate'  => 12,
				'color'   => '#D97706',
				'offices' => 'NA Deputy Minority Leader (Robert Mbui — Wiper), Senate Deputy Minority Leader (Enock Wambua — Wiper)',
				'parties' => array( 'Wiper Democratic Movement', 'Jubilee Party', 'DAP–Kenya', 'KANU', 'UPA', 'KUP' ),
				'posture' => 'Rejects executive co-optation, maintaining strict floor opposition and negotiating a unified challenger coalition slate for the August 10, 2027 General Election.',
			),
			array(
				'id'      => 'independents',
				'name'    => 'Independents & Emerging 2027 Vehicles',
				'status'  => 'Unaligned Legislators & Newly Gazetted Parties',
				'na'      => 12,
				'senate'  => 2,
				'color'   => '#64748B',
				'offices' => 'Cross-bench Parliamentary Caucus & Constitutional Litigators',
				'parties' => array( 'Independent MPs & Senators', 'NRA & Newly Registered 2025–2026 Contender Parties' ),
				'posture' => 'Vote independently of major coalition whips while serving as critical vehicles for aspirants ahead of 2027 nomination lock-in deadlines.',
			),
		),
		'timeline' => array(
			array(
				'year'      => '1991–1992',
				'era'       => 'Repeal of Section 2A',
				'milestone' => 'FORD Splits into FORD–Kenya & FORD–Asili; DP Emerges',
				'summary'   => 'Following repeal of single-party rule in December 1991, opposition fragmentation prior to the 1992 poll established the enduring rule of Kenyan coalition politics: divided oppositions rarely defeat an organized incumbent.',
			),
			array(
				'year'      => '2002',
				'era'       => 'The Rainbow Unification',
				'milestone' => 'NAK + LDP Form the National Rainbow Coalition (NARC)',
				'summary'   => 'Unified opposition backing Mwai Kibaki ended 39 years of KANU rule in a peaceful transfer of power, before internal strain over the unimplemented 2002 MoU.',
			),
			array(
				'year'      => '2005–2008',
				'era'       => 'Referendum & Grand Coalition',
				'milestone' => 'Birth of ODM, PNU & The 2008 National Accord',
				'summary'   => 'The 2005 draft constitution referendum reshaped party lines; after the 2007–2008 crisis, the National Accord Grand Coalition delivered institutional reforms culminating in the 2010 Constitution.',
			),
			array(
				'year'      => '2013–2017',
				'era'       => 'Devolution First Cycle',
				'milestone' => 'Jubilee Alliance / Party Faces CORD & NASA',
				'summary'   => 'Under the 2010 Constitution creating 47 counties and a bicameral Parliament, TNA and URP formed Jubilee (merging 11 parties in 2016) against CORD (2013) and NASA (2017).',
			),
			array(
				'year'      => '2018–2022',
				'era'       => 'Handshake & Bottom-Up Shift',
				'milestone' => 'March 2018 Handshake; Kenya Kwanza Defeats Azimio in 2022',
				'summary'   => 'President Uhuru Kenyatta and Raila Odinga rapprochement produced the 26-party Azimio coalition, while William Ruto built UDA and Kenya Kwanza—winning a narrow, Supreme Court-affirmed victory in August 2022.',
			),
			array(
				'year'      => '2024–2026',
				'era'       => 'Broad-Based Realignment',
				'milestone' => 'Gen-Z Civic Protests, DP Impeachment & Pre-2027 Flux',
				'summary'   => 'Mid-2024 youth-led civic protests, the October 2024 impeachment of the Deputy President (succeeded by Kithure Kindiki), and ODM figures entering a Broad-Based Cabinet redrew alliance lines ahead of August 10, 2027.',
			),
		),
	);
}

function qt_get_open_floor_bills() {
	return array(
		array(
			'id'        => 'bill-2026-gov-senate',
			'house'     => 'The Senate',
			'title'     => 'The Constitution of Kenya (Amendment) Bill, 2026',
			'sponsor'   => 'Sen. Kamau Murango (Kirinyaga County)',
			'stage'     => 'Awaiting Second Reading',
			'window'    => 'Open for Written Committee Memoranda',
			'articles'  => array( 'Article 38 (Political Rights)', 'Article 99 (MP/Senator Qualifications)', 'Article 193 (MCA Qualifications)', 'Article 256 (Parliamentary Initiative)' ),
			'summary'   => 'Proposes amending Articles 99 and 193 of the Constitution and Sections 24 and 25 of the Elections Act to impose a five-year waiting period barring serving governors—and former governors within five years of leaving office—from contesting Senate or County Assembly seats.',
			'contested' => 'Supporters argue former governors sitting in the Senate compromise County Public Accounts audits of their own immediate tenures; opponents argue it restricts voters constitutional freedom under Article 38 ahead of 2027.',
			'clerk'     => 'The Clerk of the Senate, Parliament Buildings, P.O. Box 41842-00100, Nairobi (clerk.senate@parliament.go.ke)',
		),
		array(
			'id'        => 'bill-2026-cpsb',
			'house'     => 'The Senate',
			'title'     => 'County Governments (County Public Service Boards Governance) Amendment Proposals, 2026',
			'sponsor'   => 'Senate Standing Committee on Devolution & Intergovernmental Relations',
			'stage'     => 'Committee Report & Legislative Drafting Stage',
			'window'    => 'Public Stakeholder Submissions Open',
			'articles'  => array( 'Article 174 (Objects of Devolution)', 'Article 232 (Values of Public Service)', 'Article 235 (Staffing of County Governments)' ),
			'summary'   => 'Addresses recurring litigation and administrative paralysis between County Governors and inherited County Public Service Boards (CPSBs) over hiring, chief officer appointments, and payroll controls.',
			'contested' => 'Governors seek administrative alignment to deliver manifesto pledges; unions and Senators warn weakening board tenure protections invites post-election purges of career county workers.',
			'clerk'     => 'The Clerk of the Senate, Parliament Buildings, P.O. Box 41842-00100, Nairobi (clerk.senate@parliament.go.ke)',
		),
		array(
			'id'        => 'bill-2026-electoral-timelines',
			'house'     => 'National Assembly & Senate',
			'title'     => 'Electoral Laws (2027 Preparedness & Nomination Dispute Timelines) Package',
			'sponsor'   => 'Departmental Committee on Justice and Legal Affairs (JLAC)',
			'stage'     => 'Committee Consideration & Statutory Alignment',
			'window'    => 'Active Pre-2027 Statutory Window',
			'articles'  => array( 'Article 81 (Electoral Principles)', 'Article 82 (Legislation on Elections)', 'Article 88 (IEBC Mandate)', 'Article 118 (Public Participation)' ),
			'summary'   => 'Harmonizes dispute resolution windows between IEBC, the Office of the Registrar of Political Parties (ORPP), and the Political Parties Disputes Tribunal (PPDT) ahead of the August 10, 2027 General Election.',
			'contested' => 'Smaller parties and independent aspirants scrutinize clauses governing party-hopping cutoff deadlines after contested party primaries.',
			'clerk'     => 'The Clerk of the National Assembly, Parliament Buildings, P.O. Box 41842-00100, Nairobi (cna@parliament.go.ke)',
		),
	);
}

function qt_get_quiet_record_verifications() {
	$items  = array();
	$custom = get_posts(
		array(
			'post_type'      => 'qt_verification',
			'posts_per_page' => 20,
			'post_status'    => 'publish',
		)
	);
	foreach ( $custom as $p ) {
		$items[] = array(
			'id'        => 'qr-post-' . $p->ID,
			'badge'     => get_post_meta( $p->ID, '_qt_status_badge', true ) ?: 'VERIFIED PRIMARY RECORD',
			'where'     => get_post_meta( $p->ID, '_qt_where_circulating', true ) ?: 'Online Forums',
			'claim'     => get_the_title( $p ),
			'docTitle'  => get_post_meta( $p->ID, '_qt_primary_doc_title', true ),
			'authority' => get_post_meta( $p->ID, '_qt_issuing_authority', true ),
			'finding'   => wp_strip_all_tags( $p->post_content ),
			'shareText' => get_post_meta( $p->ID, '_qt_share_card', true ),
		);
	}

	$defaults = array(
		array(
			'id'        => 'qr-01',
			'badge'     => 'CONTRADICTED BY GAZETTE RECORD',
			'where'     => 'Forwarded WhatsApp PDFs & Constituency Telegram Groups',
			'claim'     => '"A leaked IEBC map has quietly dissolved 27 low-population constituencies and created 40 new urban constituencies for the August 2027 General Election."',
			'docTitle'  => 'IEBC Official Gazette Notices on the 2027 General Election & Phased Delimitation Statement (2026)',
			'authority' => 'Independent Electoral and Boundaries Commission (IEBC) & Supreme Court of Kenya (SC Ref. No. E004 of 2024)',
			'finding'   => 'Zero constituencies or wards have been dissolved, merged, or added for the August 10, 2027 General Election. Following the Supreme Court September 5, 2025 ruling, IEBC Chairperson Erastus Edung Ethekon confirmed substantive delimitation is deferred until after the 2027 polls. All 290 constituencies and 1,450 wards remain unchanged.',
			'shareText' => 'QUIET TRUTHS RECORD CHECK (quiettruths.co.ke): Claim that 27 constituencies were dissolved or 40 added for 2027 is FALSE. Primary Source: IEBC 2027 Election Gazette Notice confirms all 290 constituencies & 1,450 wards remain unchanged for the Tue, Aug 10, 2027 General Election.',
		),
		array(
			'id'        => 'qr-02',
			'badge'     => 'CONFIRMED IN STATUTE & GAZETTE',
			'where'     => 'County Townhall Debates & Community Committee Chats',
			'claim'     => '"Politicians running in 2027 are legally barred from participating in public harambees starting December 9, 2026."',
			'docTitle'  => 'Elections Act, No. 24 of 2011 (Section 26) & IEBC 2027 Election Calendar Gazette Notice',
			'authority' => 'Parliament of Kenya (Statute Book) & Independent Electoral and Boundaries Commission',
			'finding'   => 'Accurate. Section 26(1) of the Elections Act disqualifies any person who directly or indirectly participates in a public fundraising or harambee within eight months preceding a general election (exempting official fundraisers for a registered political party). Eight months prior to August 10, 2027 begins December 9, 2026.',
			'shareText' => 'QUIET TRUTHS RECORD CHECK (quiettruths.co.ke): CONFIRMED IN LAW. Under Section 26 of the Elections Act & IEBC gazetted Aug 10, 2027 poll date, aspirants participating in public harambees from Dec 9, 2026 risk statutory disqualification (official party fundraisers exempted).',
		),
		array(
			'id'        => 'qr-03',
			'badge'     => 'MISLEADING — BILL IS NOT YET LAW',
			'where'     => 'Short-Form Video Clips & County Political Blogs',
			'claim'     => '"Second-term Governors have already been banned by the Senate from vying for Senator or MCA seats in 2027."',
			'docTitle'  => 'The Constitution of Kenya (Amendment) Bill, 2026 — Senate Bills Tracker',
			'authority' => 'The Senate of Kenya — Directorate of Legislative & Procedural Services',
			'finding'   => 'No such ban is currently in force. The Constitution of Kenya (Amendment) Bill, 2026 is a proposed Senate Bill awaiting Second Reading. Under Article 256 of the Constitution, a parliamentary amendment requires at least a two-thirds supermajority vote in BOTH the Senate and the National Assembly before assent.',
			'shareText' => 'QUIET TRUTHS RECORD CHECK (quiettruths.co.ke): NOT YET LAW. Outgoing governors are NOT currently barred from running for Senate in 2027. The Constitution of Kenya (Amendment) Bill, 2026 is a proposed Bill requiring a 2/3 supermajority in both Houses under Article 256.',
		),
		array(
			'id'        => 'qr-04',
			'badge'     => 'VERIFIABLE VIA OFFICIAL PORTAL',
			'where'     => 'Youth Voter Groups & University Forums',
			'claim'     => '"Once your ID number is added to a political party register without your consent, you cannot resign before primary deadlines."',
			'docTitle'  => 'Political Parties Act, Cap 7D (Section 14) & ORPP IPPMS Portal',
			'authority' => 'Office of the Registrar of Political Parties (ORPP)',
			'finding'   => 'False. Under Section 14 of the Political Parties Act and the Data Protection Act, unauthorized registration is unlawful, and any Kenyan citizen can verify party membership status and trigger immediate electronic resignation via the ORPP eCitizen portal or USSD *509#.',
			'shareText' => 'QUIET TRUTHS RECORD CHECK (quiettruths.co.ke): FALSE. Under Section 14 of the Political Parties Act, citizens can verify party membership and immediately cancel unauthorized listings via the Registrar of Political Parties (ORPP) USSD *509# or eCitizen.',
		),
	);

	return array_merge( $items, $defaults );
}

/* QT_REPRESENTATION_DATA_START */
/** Source-backed county leadership chain. The full 47 / 290 / 1,450 tree lives in assets/data/kenya-representation.json. */
function qt_get_county_leadership() {
	$json = <<<'QTLEADERSHIP'
[
  {
    "code": "001",
    "name": "Mombasa",
    "governor": {
      "name": "AbdullSwamad Shariff Nassir",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Francis Thoya Foleni",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Mohamed Faki Mwinyihaji",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Zamzam Mohamed Chimba",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Arub Ibrahim Khatri",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Salim Juma",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "002",
    "name": "Kwale",
    "governor": {
      "name": "Fatuma Mohamed Achani",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Josphat Chirema Kombo",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Boy Issa Juma",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Fatuma Hamisi Masito",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Seth Mwatela Kamanza",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Fatma Mwalupa",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "003",
    "name": "Kilifi",
    "governor": {
      "name": "Gideon Maitha Mung'aro",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Flora Mbetsa Chibule",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Stewart Madzayo",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Gertrude Mbeyu Mwanyanje",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Catherine Kenga",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Michael Ngala",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "004",
    "name": "Tana River",
    "governor": {
      "name": "Maj. (Rtd) Dr. Dhadho Gaddae Godhana",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Mahadh Ali Loka",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Danson Mungatana",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Amina Dika Abdullahi",
      "party": "KANU",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Osman Noor Galole",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Abdullahi-Dayib",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "005",
    "name": "Lamu",
    "governor": {
      "name": "Issa Abdalla Timamy",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Dr. Mbarak M Bahjaj",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Joseph Githuku",
      "party": "JP",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Monicah Muthoni Marubu",
      "party": "Independent",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Azhar Ali Mbarak",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Ali Godana",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "006",
    "name": "Taita-Taveta",
    "governor": {
      "name": "Dr. Andrew Mwadime",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Christine Saru Kilalo",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Johnes Mwashushe Mwarume",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Lydia Haika Mnene Mizighi",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Wisdom Mwamburi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Gadiel Maganga",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "007",
    "name": "Garissa",
    "governor": {
      "name": "Nathif Adam Jama",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Abdi Dagane Muhumed",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Abdulkadir Haji",
      "party": "JP",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Amina Udgoon Siyad",
      "party": "JP",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Abdi Idle Gure",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Mahmoud Santur",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "008",
    "name": "Wajir",
    "governor": {
      "name": "Ahmed Abdullahi",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Ahmed Muhumed Abdi",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Abass Mohamed",
      "party": "UDM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Fatuma Abdi Jehow",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Abdille Yusuf Mohamed",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Shalle Sheikh Mursal",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "009",
    "name": "Mandera",
    "governor": {
      "name": "Mohamed Adan Khalif",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Ali Maalim Mohamud",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Ali Roba",
      "party": "UDM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Umul Ker Kassim Sheikh",
      "party": "UDM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Omar Mohamed",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Ahmed Surrow",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "010",
    "name": "Marsabit",
    "governor": {
      "name": "Mohamud Mohamed Ali",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Solomon Gubo Riwe",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Mohamed Said Chute",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Naomi Jillo Waqo",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Edin Wario Dida",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Chare Mato",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "011",
    "name": "Isiolo",
    "governor": {
      "name": "Abdi Ibrahim Hassan",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Dr. James Lowasa",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Adan Dullo Fatuma",
      "party": "JP",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Mumina Gollo Bonaya",
      "party": "JP",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Abdullahi Jaldesa Banticha",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Salad Boru",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "012",
    "name": "Meru",
    "governor": {
      "name": "Isaac Mutuma M'ethingia",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Linda Kiome",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Kathuri Murungi",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Elizabeth Karambu Kailema",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Ayub Bundi Solomon",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Jacob Kirari",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "013",
    "name": "Tharaka-Nithi",
    "governor": {
      "name": "Muthomi Njuki",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Muisrael Nyagah Derebia",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Gataya Mwenda",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Susan Ngugi Nduyo",
      "party": "TSP",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "John Mbabu",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Paul Thirika",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "014",
    "name": "Embu",
    "governor": {
      "name": "Cecily Mutitu Mbarire",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Justus Kinyua Mugo",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Alexander Mundigi",
      "party": "DP",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Pamela Njoki Njeru Double N",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Josiah Murithi Thiriku",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Jim Kauma",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "015",
    "name": "Kitui",
    "governor": {
      "name": "Dr. Julius Makau Malombe",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Augustine Wambua Kanani",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Enoch Kiio Wambua",
      "party": "WDM-K",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Irene Muthoni Kasalu",
      "party": "WDM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Kevin Katisya Kinengo",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Chris Mwangangi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "016",
    "name": "Machakos",
    "governor": {
      "name": "Wavinya Ndeti",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Francis Mwangangi",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Agnes Kavindu Muthama",
      "party": "WDM-K",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Joyce Kamene",
      "party": "WDM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Ann Mwikali Kiusya",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Peter Mbatha",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "017",
    "name": "Makueni",
    "governor": {
      "name": "Mutula Kilonzo JR",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Lucy Mulili",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Dan Maanzo",
      "party": "WDM-K",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Rose Museo Mumo",
      "party": "WDM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Douglas Mbilu",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Kevin Mutuku",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "018",
    "name": "Nyandarua",
    "governor": {
      "name": "Dr. Moses Ndirangu Kiarie Badilisha",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "John Mathara Mwangi",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "John Penninah Methu",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Faith Wairimu Gitau",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Stephen Wachira Waiganjo",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Muchiri Mukiri",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "019",
    "name": "Nyeri",
    "governor": {
      "name": "Dr. Edward Mutahi Kahiga",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "David Kinaniri Waroe Mwangi",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Wahome Wamatinga",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Rahab Mukami Wachira",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "James Gichuhi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Jenard Mwiggeh",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "020",
    "name": "Kirinyaga",
    "governor": {
      "name": "Anne Mumbi Waiguru",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "David Githanda Wachira",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "James Murango",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Jane Njeri Maina",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Julius Muteti Murimi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Kamau Aidi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "021",
    "name": "Murang'a",
    "governor": {
      "name": "Dr. Irungu Kangata",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Stephen Mburu Munania",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Joe Nyutu",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Betty Njeri Maina",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Johnson Mukuha",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Anne Macharia",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "022",
    "name": "Kiambu",
    "governor": {
      "name": "Dr. Paul Kimani Wamatangi",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Rosemary Njeri Kirika",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Paul Karungo Thang'wa",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Anne Wanjiku Mugo Muratha",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Charles Murungaru Thiongo",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "John Mutie",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "023",
    "name": "Turkana",
    "governor": {
      "name": "Jeremiah Ekamais Lomorukai",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "John Lopeyok Erus",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "James Lomenen Ekomwa",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Cecilia Asinyen Ngitit",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Christopher Nakuleu Doye",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Linus Minyaan",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "024",
    "name": "West Pokot",
    "governor": {
      "name": "Simon Kachapin Kitalei",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Hon. Robert Achaule Komole",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "James Murgor",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Rael Chepkemoi Kasiwai",
      "party": "KUP",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Fredrick Plimo Kaptui",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Leonard Lemareng",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "025",
    "name": "Samburu",
    "governor": {
      "name": "Jonathan Lelelit Lati",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Gabriel Lenengwesi Samia",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Steve Ltumbesi Lelegwe",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Pauline Lenguris",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Steve Lenamarle",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Fred Lenapeer",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "026",
    "name": "Trans Nzoia",
    "governor": {
      "name": "George Natembeya MBS",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Hon. Philomena Bineah",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Allan Chesang",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Lillian Chebet Siyoi",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Andrew Mkhisa Wanyonyi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Moses Lupao",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "027",
    "name": "Uasin Gishu",
    "governor": {
      "name": "Jonathan Bii",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Hon. Evans Kapkea",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Jackson Mandago",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Gladys Jepkosgei Boss Shollei",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Philip Kipng'etich Muigei",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Shadrack Choge",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "028",
    "name": "Elgeyo-Marakwet",
    "governor": {
      "name": "Wisley Rotich",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Prof. Grace Jerotich Cheserek",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "William Kisang",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Jeptoo Ng'Elechei Caroline",
      "party": "Independent",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Kibire Kipng'etich Lawi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Jane Mutai",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "029",
    "name": "Nandi",
    "governor": {
      "name": "Stephen Kipyego Sang",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Dr. Yulita C. Mitei Cheruiyot",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Samson Cherarkey",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Cynthia Jepkosgei Muge",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Philemon Cheruiyot Melly",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Barnaba Kosgei",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "030",
    "name": "Baringo",
    "governor": {
      "name": "Benjamin Chesire Cheboi",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Felix Kiplagat Maiyo",
      "party": "",
      "status": "secondary_supplement",
      "statusLabel": "2022 supplementary list · verify",
      "source": "dg-supplement",
      "sourceLabel": "2022 gazette supplement",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "William Cheptumo",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Flowrence Jematiah Sergon",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Vincent Kemboi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Winnie Chemase",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "031",
    "name": "Laikipia",
    "governor": {
      "name": "Joshua Wakahora Irungu",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Reuben Kamuri Ngatia",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "John Nderitu",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Jane Wangechi Kagiri",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Lantano Nabaala",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Moses Waweru",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "032",
    "name": "Nakuru",
    "governor": {
      "name": "Susan Wakarura Kihika",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "David Kipkemoi Kones",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Tabitha Keroche",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Liza Chepkorir Chelule",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Joel Karuri Maina",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Joseph Malinda",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "033",
    "name": "Narok",
    "governor": {
      "name": "Patrick Keturet Ole Ntutu",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Koech Kiprono Tamalinye",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Olekina Ledama",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Rebecca Noonaishi Tonkei",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Davis Ole Dikkir",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Kasaina Lengeny",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "034",
    "name": "Kajiado",
    "governor": {
      "name": "Joseph Jama Ole Lenku",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Martin Moshisho Martin",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Samuel Kanar Seki",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Leah Sopiato Sankaire",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Julius Ngossor",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Leboo Saisa",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "035",
    "name": "Kericho",
    "governor": {
      "name": "Dr. Erick Kipkoech Mutai",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Eng. Fredrick Kipngetich Kirui",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Aaron Cheruiyot",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Beatrice Chepng'Eno Kemei",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Dr Patrick Mutai",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Martin Epus",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "036",
    "name": "Bomet",
    "governor": {
      "name": "Prof. Hillary K Barchok",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Hon. David Shadrack Rotich",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Hillary Sigei",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Linet Chepkorir",
      "party": "UDA",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Cosmas Korir",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Isaac Kitur",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "037",
    "name": "Kakamega",
    "governor": {
      "name": "Fernandes Barasa",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Hon. Ayub ANGATIA Savula",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Bonny Khalwale",
      "party": "UDA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Elsie Busihile Muhanda",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "James Wanzala Namatsi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Dr. Donald Manyala",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "038",
    "name": "Vihiga",
    "governor": {
      "name": "Dr. Wilber Khasilwa Ottichilo",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Wilberforce Kitiezo Gwadoya",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Geoffrey Osotsi",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Beatrice Kahai Adagala",
      "party": "ANC",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Christopher Omuelele",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Ambaka Kilinga",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "039",
    "name": "Bungoma",
    "governor": {
      "name": "Kenneth Makelo Lusaka",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Janepher Chemtai Mbatiany",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "David Wakoli Wafula",
      "party": "FORD-KENYA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Catherine Nanjala Wambilianga",
      "party": "FORD-K",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Emmanuel Mukhebi Situma",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Charles Wafula",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "040",
    "name": "Busia",
    "governor": {
      "name": "Dr. Paul Nyongesa Otuoma",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Hon. Arthur Odera",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Okiya Omtatah",
      "party": "NRA",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Catherine Nakhabi Omanyo",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Fredrick Wafula Odilo",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Allan Mabuka",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "041",
    "name": "Siaya",
    "governor": {
      "name": "James Orengo",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "William Oduol",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Oburu Odinga",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Christine Ombaka Oduor",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "George Okode",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Eric Ogenga",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "042",
    "name": "Kisumu",
    "governor": {
      "name": "Prof. Peter Anyang' Nyong'o",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Dr. Matthew Ochieng Owili",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Tom Ojienda",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Ruth Adhiambo Odinga Busia",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Elisha Oraro",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Owen Ojuok",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "043",
    "name": "Homa Bay",
    "governor": {
      "name": "Gladys Atieno Nyasuna Wanga",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Joseph Oyugi Magwanga",
      "party": "",
      "status": "secondary_supplement",
      "statusLabel": "2022 supplementary list · verify",
      "source": "dg-supplement",
      "sourceLabel": "2022 gazette supplement",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Moses Otieno Kajwang",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Bensuda Joyce Atieno Osogo",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Pholycarp Okombo",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Hannington Day",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  },
  {
    "code": "044",
    "name": "Migori",
    "governor": {
      "name": "Dr. George Ochilo M. Ayacko",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Dr. Joseph Gimunta Mahiri",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Eddy Oketch",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Fatuma Zainabu Mohammed",
      "party": "Independent",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Christopher Russana",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Collins Omondi Bala",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "045",
    "name": "Kisii",
    "governor": {
      "name": "Paul Simba Arati",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Elijah Chweya Obebo",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Richard Onyonka",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Donya Dorice Aburi",
      "party": "WDM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Philip Machuki Nyanumba",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Jacob Onkeo",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "046",
    "name": "Nyamira",
    "governor": {
      "name": "Amos Kimwomi Nyaribo",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "Dr. James Ondicho Gesami",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Kennedy Mong'are Okong'o",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Jerusha Momanyi Mongina",
      "party": "JP",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Thaddeus Nyabaro",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Duke Onyari",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Acting Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": "Acting appointment in source directory."
    }
  },
  {
    "code": "047",
    "name": "Nairobi",
    "governor": {
      "name": "Sakaja Arthur Johnson",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-governors",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "deputyGovernor": {
      "name": "James Njoroge Muchiri",
      "party": "",
      "status": "official_directory",
      "statusLabel": "2022–2027 official directory",
      "source": "cog-deputies",
      "sourceLabel": "Council of Governors",
      "verified": "2026-11-14",
      "note": ""
    },
    "senator": {
      "name": "Edwin Sifuna",
      "party": "ODM",
      "status": "secondary_current",
      "statusLabel": "13th Parliament roster · verify",
      "source": "senate-roster",
      "sourceLabel": "Senate roster",
      "verified": "2026-11-14",
      "note": ""
    },
    "womanRep": {
      "name": "Esther Muthomi Passaris",
      "party": "ODM",
      "status": "current_roster",
      "statusLabel": "13th Parliament roster · 12 Aug 2026",
      "source": "parliament-roster",
      "sourceLabel": "Parliament roster",
      "verified": "2026-08-12",
      "note": ""
    },
    "speaker": {
      "name": "Kennedy Ng'ondi",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Speakers Chapter directory",
      "source": "caf-speakers",
      "sourceLabel": "County Assemblies Forum",
      "verified": "2026-11-14",
      "note": ""
    },
    "clerk": {
      "name": "Edward Gichana",
      "party": "",
      "status": "assembly_directory",
      "statusLabel": "Clerk · SOCATT(K)",
      "source": "socatt-clerks",
      "sourceLabel": "SOCATT(K)",
      "verified": "2026-11-14",
      "note": ""
    }
  }
]
QTLEADERSHIP;
	$data = json_decode( $json, true );
	return is_array( $data ) ? $data : array();
}

function qt_get_representation_sources() {
	return array(
		array(
			'id'    => "boundaries-2012",
			'label' => "Kenya Counties, Constituencies & Wards hierarchy",
			'short' => "2012 Boundaries Order",
			'url'   => "https://raw.githubusercontent.com/pkiage/data-Kenya-Counties-Constituencies-Wards/main/csv-Kenya-Counties-Constituencies-Wards.csv",
			'note'  => "47 counties, 290 constituencies and 1,450 wards; source repository cites The National Assembly Constituencies and County Assembly Wards Order, 2012.",
		),
		array(
			'id'    => "kda-registry",
			'label' => "Kenya Data Atlas representation registry",
			'short' => "KDA registry",
			'url'   => "https://github.com/dansamuka/kenya-data-atlas",
			'note'  => "Role-tagged registry used to join 290 MPs, 47 County Women Representatives and 1,433 gazetted elected MCAs to boundary codes.",
		),
		array(
			'id'    => "parliament-roster",
			'label' => "Parliament of Kenya \u2014 13th Parliament roster as at 12 Aug 2026",
			'short' => "Parliament roster",
			'url'   => "https://www.parliament.go.ke/sites/default/files/2026-08/List%20of%20Members%20by%20Parties%2013th%20Parliament%20as%20at%2012082026_1.pdf",
			'note'  => "Source cited by the KDA registry for constituency MPs and County Women Representatives.",
		),
		array(
			'id'    => "iebc-mca",
			'label' => "IEBC \u2014 2022 declared Members of County Assembly",
			'short' => "IEBC 2022 gazette",
			'url'   => "https://www.iebc.or.ke/uploads/resources/t5KQ6O4YGp.pdf",
			'note'  => "Source cited by the KDA registry for 1,433 elected MCA records; the registry marks these stale_unverified, so the UI labels them \u201cverify\u201d.",
		),
		array(
			'id'    => "senate-roster",
			'label' => "13th Parliament elected senators roster",
			'short' => "Senate roster",
			'url'   => "https://en.wikipedia.org/wiki/Senate_(Kenya)",
			'note'  => "Secondary compilation of the 47 elected senators and parties; shown as a roster to verify against Parliament.",
		),
		array(
			'id'    => "cog-governors",
			'label' => "Council of Governors \u2014 2022\u20132027 Governors",
			'short' => "Council of Governors",
			'url'   => "https://cog.go.ke/current-governors/",
			'note'  => "Official Council directory, retrieved 14 Nov 2026.",
		),
		array(
			'id'    => "cog-deputies",
			'label' => "Council of Governors \u2014 2022\u20132027 Deputy Governors",
			'short' => "Council of Governors",
			'url'   => "https://cog.go.ke/current-deputy-governors/",
			'note'  => "Official Council directory, retrieved 14 Nov 2026; 45 entries were present at retrieval.",
		),
		array(
			'id'    => "dg-supplement",
			'label' => "2022 Deputy Governors supplementary list",
			'short' => "2022 gazette supplement",
			'url'   => "https://www.businessradar.co.ke/blog/2025/05/22/full-list-of-all-deputy-governors-in-kenya-everything-you-need-to-know/",
			'note'  => "Used only for Baringo and Homa Bay, which were absent from the Council directory at retrieval; deliberately marked \u201cverify\u201d.",
		),
		array(
			'id'    => "caf-speakers",
			'label' => "County Assemblies Forum \u2014 Speakers Chapter",
			'short' => "County Assemblies Forum",
			'url'   => "https://www.countyassembliesforum.org/about-us/chapters/",
			'note'  => "47-member Speakers Chapter directory, retrieved 14 Nov 2026.",
		),
		array(
			'id'    => "socatt-clerks",
			'label' => "SOCATT(K) \u2014 County Assembly Clerks directory",
			'short' => "SOCATT(K)",
			'url'   => "https://www.socattkenya.org/pages/team/",
			'note'  => "47-entry Clerks-at-the-Table directory; acting appointments are labelled in the data.",
		),
	);
}
/* QT_REPRESENTATION_DATA_END */
