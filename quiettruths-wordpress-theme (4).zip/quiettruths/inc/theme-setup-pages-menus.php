<?php
/**
 * Quiet Truths — Multi-Page & WordPress Navigation Menu Provisioner + Custom Nav Walker
 *
 * Automatically creates all 6 core WordPress pages, sets "The Ground" as the Static Front Page,
 * assigns dedicated templates, and populates both Primary & Footer WordPress Menus upon activation.
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Canonical 6-Page Architecture Blueprint for quiettruths.co.ke
 */
function qt_get_core_pages_blueprint() {
	return array(
		'the-ground'           => array(
			'num'      => '01',
			'title'    => 'The Ground',
			'subtitle' => '47 Counties & Map',
			'slug'     => 'the-ground',
			'template' => 'page-the-ground.php',
			'is_front' => true,
			'excerpt'  => 'Interactive political map of all 47 Kenyan counties, elected leadership chains, County Assembly pulse, and The Quiet Brief.',
		),
		'blind-ballot'         => array(
			'num'      => '02',
			'title'    => 'The Blind Ballot',
			'subtitle' => 'Ideas Before Party Colors',
			'slug'     => 'blind-ballot',
			'template' => 'page-blind-ballot.php',
			'is_front' => false,
			'excerpt'  => 'Compare competing Kenyan party manifestos and legislative stances side by side before revealing political branding.',
		),
		'podium-vs-parliament' => array(
			'num'      => '03',
			'title'    => 'Podium vs. Parliament',
			'subtitle' => 'Rhetoric vs. Hansard',
			'slug'     => 'podium-vs-parliament',
			'template' => 'page-podium-vs-parliament.php',
			'is_front' => false,
			'excerpt'  => 'Public political rally statements placed directly beside the official Parliamentary Hansard, tabled Bills, and Statute Book.',
		),
		'coalition-compass'    => array(
			'num'      => '04',
			'title'    => 'Coalition Compass',
			'subtitle' => 'Alliances & Seat Balance',
			'slug'     => 'coalition-compass',
			'template' => 'page-coalition-compass.php',
			'is_front' => false,
			'excerpt'  => '13th Parliament bicameral seat balance, party coalitions, and 35 years of Kenyan alliance realignments (1991–2026).',
		),
		'open-floor'           => array(
			'num'      => '05',
			'title'    => 'The Open Floor',
			'subtitle' => 'Live Bills & Public Voice',
			'slug'     => 'open-floor',
			'template' => 'page-open-floor.php',
			'is_front' => false,
			'excerpt'  => 'Track active Parliamentary Bills against the 2010 Constitution and build formal Articles 10 & 118 Public Participation Memoranda.',
		),
		'quiet-record'         => array(
			'num'      => '06',
			'title'    => 'The Quiet Record',
			'subtitle' => 'Primary Verification',
			'slug'     => 'quiet-record',
			'template' => 'page-quiet-record.php',
			'is_front' => false,
			'excerpt'  => 'Primary-source verification pairing viral political claims with unedited Kenya Gazette notices, IEBC directives, and statutes.',
		),
	);
}

/**
 * Resolve clean permalink URL for any of the 6 core pages
 */
function qt_get_page_url_by_slug( $slug ) {
	if ( 'the-ground' === $slug ) {
		return home_url( '/' );
	}
	$page = get_page_by_path( $slug );
	if ( $page instanceof WP_Post ) {
		return get_permalink( $page->ID );
	}
	return home_url( '/' . trim( $slug, '/' ) . '/' );
}

/**
 * Provision all 6 WordPress Pages, Front Page Reading Settings & Primary/Footer Menus
 */
function qt_provision_pages_and_menus() {
	$blueprint    = qt_get_core_pages_blueprint();
	$created_ids  = array();
	$menu_order   = 1;
	$front_page_id = 0;

	foreach ( $blueprint as $key => $cfg ) {
		$existing = get_page_by_path( $cfg['slug'] );
		if ( ! ( $existing instanceof WP_Post ) ) {
			$page_id = wp_insert_post(
				array(
					'post_title'   => $cfg['title'],
					'post_name'    => $cfg['slug'],
					'post_excerpt' => $cfg['excerpt'],
					'post_content' => '<!-- wp:paragraph --><p>' . esc_html( $cfg['excerpt'] ) . '</p><!-- /wp:paragraph -->',
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'menu_order'   => $menu_order,
					'comment_status' => 'closed',
					'ping_status'    => 'closed',
				)
			);
		} else {
			$page_id = $existing->ID;
			if ( 'publish' !== $existing->post_status ) {
				wp_update_post(
					array(
						'ID'          => $page_id,
						'post_status' => 'publish',
					)
				);
			}
		}

		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_post_meta( $page_id, '_wp_page_template', $cfg['template'] );
			update_post_meta( $page_id, '_qt_nav_num', $cfg['num'] );
			update_post_meta( $page_id, '_qt_nav_subtitle', $cfg['subtitle'] );
			$created_ids[ $key ] = (int) $page_id;
			if ( ! empty( $cfg['is_front'] ) ) {
				$front_page_id = (int) $page_id;
			}
		}
		$menu_order++;
	}

	// Set "The Ground" as WordPress Static Front Page
	if ( $front_page_id > 0 ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id );
	}

	// Ensure pretty permalinks default if none set yet
	if ( '' === get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}

	// Create and assign Primary & Footer WordPress Menus
	$locations = get_theme_mod( 'nav_menu_locations', array() );
	if ( ! is_array( $locations ) ) {
		$locations = array();
	}

	$menus_to_setup = array(
		'primary' => 'Quiet Truths Primary Menu',
		'footer'  => 'Quiet Truths Footer Menu',
	);

	foreach ( $menus_to_setup as $loc_key => $menu_name ) {
		$menu_obj = wp_get_nav_menu_object( $menu_name );
		if ( ! $menu_obj ) {
			$menu_id = wp_create_nav_menu( $menu_name );
		} else {
			$menu_id = (int) $menu_obj->term_id;
		}

		if ( $menu_id && ! is_wp_error( $menu_id ) ) {
			$existing_items = wp_get_nav_menu_items( $menu_id );
			$existing_obj_ids = array();
			if ( is_array( $existing_items ) ) {
				foreach ( $existing_items as $m_item ) {
					$existing_obj_ids[] = (int) $m_item->object_id;
				}
			}

			$pos = 1;
			foreach ( $blueprint as $key => $cfg ) {
				if ( isset( $created_ids[ $key ] ) && ! in_array( $created_ids[ $key ], $existing_obj_ids, true ) ) {
					wp_update_nav_menu_item(
						$menu_id,
						0,
						array(
							'menu-item-title'       => $cfg['title'],
							'menu-item-object-id'   => $created_ids[ $key ],
							'menu-item-object'      => 'page',
							'menu-item-type'        => 'post_type',
							'menu-item-status'      => 'publish',
							'menu-item-position'    => $pos,
							'menu-item-description' => $cfg['subtitle'],
						)
					);
				}
				$pos++;
			}

			$locations[ $loc_key ] = $menu_id;
		}
	}

	set_theme_mod( 'nav_menu_locations', $locations );
	flush_rewrite_rules();
	update_option( 'qt_pages_menus_provisioned', '1.0.0' );
}
add_action( 'after_switch_theme', 'qt_provision_pages_and_menus' );

/**
 * Also auto-provision once on admin_init if freshly uploaded and not yet provisioned,
 * plus provide a manual one-click Re-Sync action in WP Admin -> Appearance.
 */
function qt_maybe_auto_provision_in_admin() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( '1.0.0' !== get_option( 'qt_pages_menus_provisioned' ) ) {
		qt_provision_pages_and_menus();
	}
	if ( isset( $_GET['qt_resync_pages'] ) && isset( $_GET['_wpnonce'] ) ) {
		if ( wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'qt_resync_pages_action' ) ) {
			qt_provision_pages_and_menus();
			wp_safe_redirect( admin_url( 'themes.php?qt_synced=1' ) );
			exit;
		}
	}
}
add_action( 'admin_init', 'qt_maybe_auto_provision_in_admin' );

function qt_admin_setup_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || 'themes' !== $screen->id ) {
		return;
	}
	$resync_url = wp_nonce_url( admin_url( 'themes.php?qt_resync_pages=1' ), 'qt_resync_pages_action' );
	?>
	<div class="notice notice-success is-dismissible">
		<p>
			<strong><?php esc_html_e( 'Quiet Truths — Highland Emerald Active:', 'quiettruths' ); ?></strong>
			<?php esc_html_e( 'All 6 core political pages (The Ground, The Blind Ballot, Podium vs. Parliament, Coalition Compass, The Open Floor, and The Quiet Record) and WordPress Navigation Menus are configured.', 'quiettruths' ); ?>
			<a href="<?php echo esc_url( $resync_url ); ?>" class="button button-small" style="margin-left:8px;">
				<?php esc_html_e( 'Verify / Re-Sync Pages & Menus', 'quiettruths' ); ?>
			</a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'qt_admin_setup_notice' );

/**
 * Custom WordPress Primary Menu Walker rendering PAGE 01–06 Badges & Subtitles
 */
class QT_Primary_Nav_Walker extends Walker_Nav_Menu {
	private $counter = 1;

	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$classes     = empty( $item->classes ) ? array() : (array) $item->classes;
		$class_names = implode( ' ', array_map( 'sanitize_html_class', array_filter( $classes ) ) );

		$num = '';
		$sub = ! empty( $item->description ) ? $item->description : '';
		if ( ! empty( $item->object_id ) ) {
			$meta_num = get_post_meta( (int) $item->object_id, '_qt_nav_num', true );
			$meta_sub = get_post_meta( (int) $item->object_id, '_qt_nav_subtitle', true );
			if ( $meta_num ) {
				$num = $meta_num;
			}
			if ( empty( $sub ) && $meta_sub ) {
				$sub = $meta_sub;
			}
		}
		if ( empty( $num ) ) {
			$num = str_pad( (string) $this->counter, 2, '0', STR_PAD_LEFT );
		}
		$this->counter++;

		$output .= '<li class="' . esc_attr( $class_names ) . '">';
		$url     = ! empty( $item->url ) ? $item->url : '#';
		$title   = apply_filters( 'the_title', $item->title, $item->ID );

		$output .= '<a href="' . esc_url( $url ) . '">';
		$output .= '<span class="qt-nav-num"><span>PAGE ' . esc_html( $num ) . '</span><span>&#8599;</span></span>';
		$output .= '<span class="qt-nav-title">' . esc_html( $title ) . '</span>';
		if ( ! empty( $sub ) ) {
			$output .= '<span class="qt-nav-sub">' . esc_html( $sub ) . '</span>';
		}
		$output .= '</a>';
	}

	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= "</li>\n";
	}
}

/**
 * Fallback Primary Menu if Admin temporarily clears menu assignment
 */
function qt_primary_menu_fallback() {
	$blueprint = qt_get_core_pages_blueprint();
	echo '<ul id="qt-primary-menu" class="qt-primary-menu">';
	foreach ( $blueprint as $slug => $cfg ) {
		$url       = qt_get_page_url_by_slug( $slug );
		$is_active = ( $cfg['is_front'] && is_front_page() ) || is_page( $slug );
		$li_class  = $is_active ? 'qt-active-nav current-menu-item' : '';
		echo '<li class="' . esc_attr( $li_class ) . '">';
		echo '<a href="' . esc_url( $url ) . '">';
		echo '<span class="qt-nav-num"><span>PAGE ' . esc_html( $cfg['num'] ) . '</span><span>&#8599;</span></span>';
		echo '<span class="qt-nav-title">' . esc_html( $cfg['title'] ) . '</span>';
		echo '<span class="qt-nav-sub">' . esc_html( $cfg['subtitle'] ) . '</span>';
		echo '</a></li>';
	}
	echo '</ul>';
}

/**
 * Fallback Footer Menu
 */
function qt_footer_menu_fallback() {
	$blueprint = qt_get_core_pages_blueprint();
	echo '<ul class="qt-footer-menu">';
	foreach ( $blueprint as $slug => $cfg ) {
		$url = qt_get_page_url_by_slug( $slug );
		echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $cfg['num'] . '. ' . $cfg['title'] ) . '</a></li>';
	}
	echo '</ul>';
}
