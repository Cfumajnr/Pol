<?php
/**
 * Quiet Truths — WordPress Security Hardening & Protected AJAX Endpoints
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * 1. Defensive HTTP Security Headers
 */
function qt_send_security_headers() {
	if ( headers_sent() || is_admin() ) {
		return;
	}
	header( 'X-Content-Type-Options: nosniff' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()' );
	header( "Content-Security-Policy: frame-ancestors 'self';" );
}
add_action( 'send_headers', 'qt_send_security_headers' );

/**
 * 2. Disable XML-RPC & Pingback attack surface
 */
add_filter( 'xmlrpc_enabled', '__return_false' );

function qt_remove_x_pingback( $headers ) {
	unset( $headers['X-Pingback'] );
	return $headers;
}
add_filter( 'wp_headers', 'qt_remove_x_pingback' );

/**
 * 3. Remove WordPress Version Fingerprinting & Legacy Discovery Tags
 */
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
add_filter( 'the_generator', '__return_empty_string' );

function qt_strip_wp_ver_from_assets( $src ) {
	if ( strpos( $src, 'ver=' . get_bloginfo( 'version' ) ) !== false ) {
		$src = remove_query_arg( 'ver', $src );
	}
	return $src;
}
add_filter( 'style_loader_src', 'qt_strip_wp_ver_from_assets', 9999 );
add_filter( 'script_loader_src', 'qt_strip_wp_ver_from_assets', 9999 );

/**
 * 4. Block Unauthenticated User Enumeration (REST API & ?author=N scans)
 */
function qt_restrict_rest_user_endpoints( $endpoints ) {
	if ( ! is_user_logged_in() ) {
		if ( isset( $endpoints['/wp/v2/users'] ) ) {
			unset( $endpoints['/wp/v2/users'] );
		}
		if ( isset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] ) ) {
			unset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );
		}
	}
	return $endpoints;
}
add_filter( 'rest_endpoints', 'qt_restrict_rest_user_endpoints' );

function qt_block_author_scan() {
	if ( is_admin() ) {
		return;
	}
	if ( isset( $_GET['author'] ) && ! is_user_logged_in() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'qt_block_author_scan' );

/**
 * 5. Generic Login Error Message to Prevent Username Probing
 */
function qt_generic_login_error() {
	return esc_html__( 'Invalid credentials provided. Please verify your login details and try again.', 'quiettruths' );
}
add_filter( 'login_errors', 'qt_generic_login_error' );

/**
 * Helper: Lightweight hashed client IP for transient rate-limiting (privacy-safe)
 */
function qt_get_client_rate_key( $action_slug ) {
	$raw_ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0.0.0.0';
	return 'qt_rl_' . sanitize_key( $action_slug ) . '_' . substr( wp_hash( $raw_ip ), 0, 16 );
}

/**
 * 6. Protected AJAX Endpoint: Record Citizen Public Participation Memorandum Log
 */
function qt_ajax_submit_memorandum() {
	check_ajax_referer( 'qt_civic_nonce', 'nonce' );

	// Honeypot check against automated bots
	$honeypot = isset( $_POST['website_url_hp'] ) ? sanitize_text_field( wp_unslash( $_POST['website_url_hp'] ) ) : '';
	if ( ! empty( $honeypot ) ) {
		wp_send_json_error( array( 'message' => 'Automated submission rejected.' ), 400 );
	}

	// Rate limit: max 5 submissions per 10 minutes per hashed IP
	$rate_key = qt_get_client_rate_key( 'memo' );
	$count    = (int) get_transient( $rate_key );
	if ( $count >= 5 ) {
		wp_send_json_error( array( 'message' => 'Rate limit reached. Please wait a few minutes before submitting again.' ), 429 );
	}
	set_transient( $rate_key, $count + 1, 10 * MINUTE_IN_SECONDS );

	$bill_title   = isset( $_POST['bill_title'] ) ? sanitize_text_field( wp_unslash( $_POST['bill_title'] ) ) : '';
	$citizen_name = isset( $_POST['citizen_name'] ) ? sanitize_text_field( wp_unslash( $_POST['citizen_name'] ) ) : 'Anonymous Citizen';
	$county       = isset( $_POST['county'] ) ? sanitize_text_field( wp_unslash( $_POST['county'] ) ) : '';
	$constituency = isset( $_POST['constituency'] ) ? sanitize_text_field( wp_unslash( $_POST['constituency'] ) ) : '';
	$stance       = isset( $_POST['stance'] ) ? sanitize_text_field( wp_unslash( $_POST['stance'] ) ) : '';
	$memo_body    = isset( $_POST['memo_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['memo_body'] ) ) : '';

	if ( empty( $bill_title ) || empty( $memo_body ) ) {
		wp_send_json_error( array( 'message' => 'Please include both a target Bill and your clause-specific memorandum notes.' ), 422 );
	}

	$post_id = wp_insert_post(
		array(
			'post_type'    => 'qt_memorandum',
			'post_status'  => 'private',
			'post_title'   => sprintf( '%s — %s (%s)', $bill_title, $citizen_name, $county ),
			'post_content' => $memo_body,
			'meta_input'   => array(
				'_qt_memo_county'       => $county,
				'_qt_memo_constituency' => $constituency,
				'_qt_memo_stance'       => $stance,
				'_qt_memo_bill'         => $bill_title,
			),
		),
		true
	);

	if ( is_wp_error( $post_id ) ) {
		wp_send_json_error( array( 'message' => 'Could not log memorandum right now.' ), 500 );
	}

	wp_send_json_success(
		array(
			'message' => 'Your memorandum has been securely logged in the Quiet Truths Civic Registry. Remember to also email or deliver your downloaded copy to the Clerk.',
			'ref_id'  => 'QT-MEMO-' . (int) $post_id,
		)
	);
}
add_action( 'wp_ajax_qt_submit_memorandum', 'qt_ajax_submit_memorandum' );
add_action( 'wp_ajax_nopriv_qt_submit_memorandum', 'qt_ajax_submit_memorandum' );

/**
 * 7. Protected AJAX Endpoint: Anonymous Blind Ballot Substance Tally
 */
function qt_ajax_blind_vote() {
	check_ajax_referer( 'qt_civic_nonce', 'nonce' );

	// Honeypot check against automated bots
	$honeypot = isset( $_POST['website_url_hp'] ) ? sanitize_text_field( wp_unslash( $_POST['website_url_hp'] ) ) : '';
	if ( ! empty( $honeypot ) ) {
		wp_send_json_error( array( 'message' => 'Automated submission rejected.' ), 400 );
	}

	$issue_id = isset( $_POST['issue_id'] ) ? sanitize_key( wp_unslash( $_POST['issue_id'] ) ) : '';
	$choice   = isset( $_POST['choice'] ) ? sanitize_text_field( wp_unslash( $_POST['choice'] ) ) : '';

	$allowed_choices = array( 'Position A', 'Position B', 'Position C' );
	if ( empty( $issue_id ) || ! in_array( $choice, $allowed_choices, true ) ) {
		wp_send_json_error( array( 'message' => 'Invalid selection.' ), 400 );
	}

	$rate_key = qt_get_client_rate_key( 'vote_' . $issue_id );
	if ( get_transient( $rate_key ) ) {
		$tallies = get_option( 'qt_blind_ballot_tallies', array() );
		wp_send_json_success( array( 'tallies' => isset( $tallies[ $issue_id ] ) ? $tallies[ $issue_id ] : array() ) );
	}
	set_transient( $rate_key, 1, HOUR_IN_SECONDS );

	$tallies = get_option( 'qt_blind_ballot_tallies', array() );
	if ( ! isset( $tallies[ $issue_id ] ) || ! is_array( $tallies[ $issue_id ] ) ) {
		$tallies[ $issue_id ] = array(
			'Position A' => 14,
			'Position B' => 16,
			'Position C' => 15,
		);
	}
	$tallies[ $issue_id ][ $choice ] = isset( $tallies[ $issue_id ][ $choice ] ) ? ( (int) $tallies[ $issue_id ][ $choice ] + 1 ) : 1;
	update_option( 'qt_blind_ballot_tallies', $tallies, false );

	wp_send_json_success( array( 'tallies' => $tallies[ $issue_id ] ) );
}
add_action( 'wp_ajax_qt_blind_vote', 'qt_ajax_blind_vote' );
add_action( 'wp_ajax_nopriv_qt_blind_vote', 'qt_ajax_blind_vote' );
