<?php
/**
 * Template Name: 01 - The Ground (Representation Explorer)
 * Description: Home & interactive 47-county Kenyan political atlas with a source-backed county, constituency, ward and leadership drill-down.
 *
 * @package QuietTruths
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$counties          = qt_get_all_47_counties();
$leadership_index  = qt_get_county_leadership();
$sources           = qt_get_representation_sources();
$default_county    = null;
$default_leadership = null;

foreach ( $counties as $c ) {
	if ( '047' === $c['code'] ) {
		$default_county = $c;
		break;
	}
}
if ( ! $default_county && ! empty( $counties ) ) {
	$default_county = $counties[0];
}

foreach ( $leadership_index as $row ) {
	if ( $default_county && $row['code'] === $default_county['code'] ) {
		$default_leadership = $row;
		break;
	}
}
if ( ! $default_leadership && ! empty( $leadership_index ) ) {
	$default_leadership = $leadership_index[0];
}

$leader_roles = array(
	'governor'       => __( 'County Governor', 'quiettruths' ),
	'deputyGovernor' => __( 'Deputy Governor', 'quiettruths' ),
	'senator'        => __( 'County Senator', 'quiettruths' ),
	'womanRep'       => __( 'Woman Representative', 'quiettruths' ),
	'speaker'        => __( 'Assembly Speaker', 'quiettruths' ),
	'clerk'          => __( 'Assembly Clerk', 'quiettruths' ),
);

$national_updates = qt_get_national_stage_updates();
$quiet_briefs     = qt_get_quiet_brief_items();
$regions          = array( 'All', 'Nairobi Metro', 'Coast', 'Nyanza', 'Rift Valley', 'Central', 'Eastern', 'Western', 'North Eastern' );
?>

<section class="qt-page-hero">
	<div class="qt-page-hero-copy">
		<div class="qt-eyebrow"><?php esc_html_e( 'Page 01 · Quiet Truths Representation Explorer', 'quiettruths' ); ?></div>
		<h2 class="qt-h2"><?php esc_html_e( 'Quiet Truths — The Record Speaks, County by County.', 'quiettruths' ); ?></h2>
		<p class="qt-lead">
			<strong><?php esc_html_e( 'Start with the ground:', 'quiettruths' ); ?></strong>
			<?php esc_html_e( 'Choose Nairobi, Mombasa or any of the 47 counties. Follow the whole chain of named offices, open every constituency and ward, and see the source and freshness of each record instead of a row of national numbers.', 'quiettruths' ); ?>
		</p>
	</div>

	<div class="qt-stat-strip" aria-label="<?php esc_attr_e( 'Open the Kenyan representation directory', 'quiettruths' ); ?>">
		<a class="qt-stat-button" href="#qt-ground-atlas" data-explorer-scope="counties">
			<div class="qt-stat-num">47</div>
			<div class="qt-stat-label"><?php esc_html_e( 'Counties · open index', 'quiettruths' ); ?></div>
		</a>
		<a class="qt-stat-button" href="#qt-representation-explorer" data-explorer-scope="constituencies">
			<div class="qt-stat-num" style="color:var(--qt-azure);">290</div>
			<div class="qt-stat-label"><?php esc_html_e( 'Constituencies · open MPs', 'quiettruths' ); ?></div>
		</a>
		<a class="qt-stat-button" href="#qt-representation-explorer" data-explorer-scope="wards">
			<div class="qt-stat-num" style="color:var(--qt-ink);">1,450</div>
			<div class="qt-stat-label"><?php esc_html_e( 'Wards · open MCAs', 'quiettruths' ); ?></div>
		</a>
	</div>
</section>

<section class="qt-identity-strip" aria-label="<?php esc_attr_e( 'The Quiet Truths method', 'quiettruths' ); ?>">
	<a class="qt-identity-pillar" href="#qt-ground-atlas">
		<span class="qt-pillar-num">01</span>
		<span>
			<strong><?php esc_html_e( 'Name the office', 'quiettruths' ); ?></strong>
			<small><?php esc_html_e( 'Governor · Deputy · Senator · Woman Rep · Speaker · Clerk', 'quiettruths' ); ?></small>
		</span>
	</a>
	<a class="qt-identity-pillar" href="#qt-representation-explorer" data-explorer-scope="constituencies">
		<span class="qt-pillar-num">02</span>
		<span>
			<strong><?php esc_html_e( 'Open the place', 'quiettruths' ); ?></strong>
			<small><?php esc_html_e( 'Constituencies → wards → the named MP or MCA', 'quiettruths' ); ?></small>
		</span>
	</a>
	<a class="qt-identity-pillar" href="#qt-explorer-sources">
		<span class="qt-pillar-num">03</span>
		<span>
			<strong><?php esc_html_e( 'Show the source', 'quiettruths' ); ?></strong>
			<small><?php esc_html_e( 'Roster dates, acting roles, vacancies and verification gaps', 'quiettruths' ); ?></small>
		</span>
	</a>
</section>

<!-- Interactive 47-County Map + Source-Backed Representation Chain -->
<section class="qt-grid-atlas" id="qt-ground-atlas">
	<div class="qt-card qt-pad">
		<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.65rem;">
			<strong style="font-family:var(--qt-font-mono); font-size:0.75rem; text-transform:uppercase;">
				<?php esc_html_e( 'Locate Any of the 47 Counties', 'quiettruths' ); ?>
			</strong>
			<span style="font-family:var(--qt-font-mono); font-size:0.68rem; color:var(--qt-azure); font-weight:700;">
				<?php esc_html_e( 'Source-backed directory', 'quiettruths' ); ?>
			</span>
		</div>

		<div style="margin-bottom:0.75rem;">
			<input type="search" id="qt-county-search" class="qt-input" placeholder="<?php esc_attr_e( 'Search counties, leaders, constituencies, wards, MPs or MCAs...', 'quiettruths' ); ?>" aria-label="<?php esc_attr_e( 'Search Kenyan representation records', 'quiettruths' ); ?>">
		</div>

		<div class="qt-pill-row" id="qt-region-pills" style="margin-bottom:0.75rem;">
			<?php foreach ( $regions as $idx => $reg ) : ?>
				<button type="button" class="qt-pill <?php echo 0 === $idx ? 'is-active' : ''; ?>" data-region="<?php echo esc_attr( $reg ); ?>">
					<?php echo esc_html( $reg ); ?>
				</button>
			<?php endforeach; ?>
		</div>

		<div class="qt-datalite-notice">
			<?php esc_html_e( '[Data-Lite Mode Active] Vector map hidden to conserve mobile browsing. All 47 counties and the full text drill-down remain available below.', 'quiettruths' ); ?>
		</div>

		<div class="qt-map-frame qt-graphic-heavy">
			<div class="qt-map-hint"><?php esc_html_e( 'Click any of the 47 county beacons', 'quiettruths' ); ?></div>
			<svg id="qt-kenya-svg" viewBox="85 65 355 405" style="width:100%; height:310px; display:block;" role="img" aria-label="<?php esc_attr_e( 'Quiet Truths — Interactive Political Map of All 47 Counties', 'quiettruths' ); ?>">
				<path d="M148,75 L212,88 L235,108 L312,108 L405,128 L398,215 L395,315 L362,402 L328,452 L285,405 L218,365 L145,312 L122,272 L135,232 L145,190 L132,128 Z" fill="#ECFDF5" stroke="#047857" stroke-width="2"></path>
				<line x1="100" y1="268" x2="415" y2="268" stroke="#5C7A71" stroke-opacity="0.4" stroke-dasharray="4 4" stroke-width="1"></line>
				<text x="103" y="263" font-size="8" font-family="monospace" fill="#5C7A71">EQUATOR 0°</text>
				<path d="M188,92 C194,118 197,145 204,166 C196,168 189,142 182,98 Z" fill="#BAE6FD" stroke="#0284C7" stroke-width="0.9"></path>
				<path d="M122,272 L146,274 L144,304 L132,298 Z" fill="#BAE6FD" stroke="#0284C7" stroke-width="0.9"></path>

				<?php foreach ( $counties as $c ) : ?>
					<?php $is_sel = ( $default_county && $c['code'] === $default_county['code'] ); ?>
					<g class="qt-map-node" data-code="<?php echo esc_attr( $c['code'] ); ?>" style="cursor:pointer;">
						<title><?php echo esc_html( $c['code'] . ' — ' . $c['name'] . ' County' ); ?></title>
						<circle class="qt-node-halo" cx="<?php echo esc_attr( $c['x'] ); ?>" cy="<?php echo esc_attr( $c['y'] ); ?>" r="<?php echo $is_sel ? '12' : '0'; ?>" fill="#D97706" fill-opacity="0.26"></circle>
						<circle class="qt-node-dot" cx="<?php echo esc_attr( $c['x'] ); ?>" cy="<?php echo esc_attr( $c['y'] ); ?>" r="<?php echo $is_sel ? '6.5' : '4.2'; ?>" fill="<?php echo $is_sel ? '#D97706' : '#059669'; ?>" stroke="#FFFFFF" stroke-width="1.5"></circle>
					</g>
				<?php endforeach; ?>
			</svg>
		</div>

		<div class="qt-county-list" id="qt-county-list">
			<?php foreach ( $counties as $c ) : ?>
				<?php $is_sel = ( $default_county && $c['code'] === $default_county['code'] ); ?>
				<button type="button" class="qt-county-btn <?php echo $is_sel ? 'is-selected' : ''; ?>" data-code="<?php echo esc_attr( $c['code'] ); ?>" data-region="<?php echo esc_attr( $c['region'] ); ?>">
					<span><span style="font-family:var(--qt-font-mono); opacity:0.78; margin-right:0.4rem;"><?php echo esc_html( $c['code'] ); ?></span><?php echo esc_html( $c['name'] ); ?></span>
					<span style="font-family:var(--qt-font-mono); font-size:0.68rem; opacity:0.84;"><?php echo esc_html( $c['constituencies'] . ' Const. · ' . $c['wards'] . ' Wards' ); ?></span>
				</button>
			<?php endforeach; ?>
		</div>
	</div>

	<?php if ( $default_county && $default_leadership ) : ?>
	<div class="qt-card-lg" id="qt-county-detail-card" aria-live="polite">
		<div class="qt-card-accent-bar"></div>
		<div class="qt-pad">
			<div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:flex-start; gap:1rem; border-bottom:1px solid var(--qt-border); padding-bottom:1.1rem;">
				<div>
					<span class="qt-badge qt-badge-azure" id="qt-det-code-region">
						<?php echo esc_html( 'COUNTY ' . $default_county['code'] . ' · ' . strtoupper( $default_county['region'] ) ); ?>
					</span>
					<h3 id="qt-det-name" style="margin:0.45rem 0 0; font-family:var(--qt-font-serif); font-size:1.95rem;">
						<?php echo esc_html( $default_county['name'] . ' County' ); ?>
					</h3>
				</div>

				<div class="qt-stat-strip" style="padding:0.6rem 1rem; box-shadow:none; background:var(--qt-bg);">
					<div class="qt-stat-item">
						<div class="qt-stat-label"><?php esc_html_e( 'Constituencies', 'quiettruths' ); ?></div>
						<div class="qt-stat-num" id="qt-det-const" style="font-size:1.05rem;"><?php echo esc_html( $default_county['constituencies'] ); ?></div>
					</div>
					<div class="qt-stat-item">
						<div class="qt-stat-label"><?php esc_html_e( 'Wards', 'quiettruths' ); ?></div>
						<div class="qt-stat-num" id="qt-det-wards" style="font-size:1.05rem; color:var(--qt-azure);"><?php echo esc_html( $default_county['wards'] ); ?></div>
					</div>
					<div class="qt-stat-item">
						<div class="qt-stat-label"><?php esc_html_e( 'Voter Est.', 'quiettruths' ); ?></div>
						<div class="qt-stat-num" id="qt-det-voters" style="font-size:1.05rem; color:var(--qt-ink);"><?php echo esc_html( $default_county['voters'] ); ?></div>
					</div>
				</div>
			</div>

			<section id="qt-county-leadership" style="margin-top:1.25rem;">
				<div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:baseline; gap:0.5rem; margin-bottom:0.65rem;">
					<div class="qt-role-label" style="color:var(--qt-ink-subtle);">
						<?php esc_html_e( 'County leadership chain · named offices, not just totals', 'quiettruths' ); ?>
					</div>
					<span class="qt-badge qt-badge-emerald"><?php esc_html_e( 'Sources named', 'quiettruths' ); ?></span>
				</div>
				<div class="qt-grid-3" id="qt-leadership-grid">
					<?php foreach ( $leader_roles as $key => $label ) : ?>
						<?php
						$person = isset( $default_leadership[ $key ] ) ? $default_leadership[ $key ] : array();
						$meta   = array_filter(
							array(
								isset( $person['party'] ) ? $person['party'] : '',
								isset( $person['statusLabel'] ) ? $person['statusLabel'] : '',
								isset( $person['sourceLabel'] ) ? $person['sourceLabel'] : '',
							)
						);
						?>
						<div class="qt-subpanel qt-leader-card" data-role="<?php echo esc_attr( $key ); ?>">
							<div class="qt-role-label" style="color:var(--qt-emerald-dark);"><?php echo esc_html( $label ); ?></div>
							<div class="qt-leader-name" data-leader-name style="font-family:var(--qt-font-serif); font-weight:700; font-size:1rem; margin-top:0.35rem;">
								<?php echo esc_html( isset( $person['name'] ) ? $person['name'] : __( 'Record pending verification', 'quiettruths' ) ); ?>
							</div>
							<div class="qt-leader-meta" data-leader-meta style="font-family:var(--qt-font-mono); font-size:0.67rem; color:var(--qt-ink-subtle); line-height:1.5; margin-top:0.4rem;">
								<?php echo esc_html( implode( ' · ', $meta ) ); ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</section>

			<section id="qt-representation-explorer" class="qt-explorer" aria-labelledby="qt-explorer-title">
				<div class="qt-explorer-head">
					<div>
						<div class="qt-role-label" style="color:var(--qt-azure);"><?php esc_html_e( 'Representation drill-down', 'quiettruths' ); ?></div>
						<h3 id="qt-explorer-title" style="margin:0.2rem 0 0; font-family:var(--qt-font-serif); font-size:1.5rem;">
							<?php esc_html_e( 'Constituencies, Assembly & Wards', 'quiettruths' ); ?>
						</h3>
					</div>
					<span class="qt-badge qt-badge-emerald"><?php esc_html_e( '47 / 290 / 1,450', 'quiettruths' ); ?></span>
				</div>

				<nav id="qt-explorer-breadcrumb" class="qt-breadcrumb" aria-label="<?php esc_attr_e( 'Representation breadcrumb', 'quiettruths' ); ?>"></nav>

				<div class="qt-explorer-controls">
					<button type="button" id="qt-explorer-tab-constituencies" class="qt-pill is-active" data-explorer-tab="constituencies" aria-pressed="true">
						<?php esc_html_e( 'Constituencies & MPs', 'quiettruths' ); ?>
					</button>
					<button type="button" id="qt-explorer-tab-assembly" class="qt-pill" data-explorer-tab="assembly" aria-pressed="false">
						<?php esc_html_e( 'County Assembly & Wards', 'quiettruths' ); ?>
					</button>
					<input type="search" id="qt-explorer-search" class="qt-input" placeholder="<?php esc_attr_e( 'Filter this county’s constituencies, wards, MPs or MCAs...', 'quiettruths' ); ?>" aria-label="<?php esc_attr_e( 'Filter representation records', 'quiettruths' ); ?>">
				</div>

				<div id="qt-explorer-status" class="qt-explorer-status" aria-live="polite">
					<?php esc_html_e( 'Choose a constituency or ward tab to open the source-backed directory.', 'quiettruths' ); ?>
				</div>

				<noscript>
					<div class="qt-source-note"><?php esc_html_e( 'JavaScript is needed for the constituency and ward drill-down. The county leadership chain above remains fully readable without scripts.', 'quiettruths' ); ?></div>
				</noscript>

				<div class="qt-explorer-layout">
					<div id="qt-explorer-results" class="qt-explorer-results" aria-live="polite">
						<p class="qt-explorer-empty"><?php esc_html_e( 'Open Constituencies & MPs or County Assembly & Wards to browse the full local chain.', 'quiettruths' ); ?></p>
					</div>
					<aside id="qt-explorer-detail" class="qt-explorer-detail" aria-live="polite">
						<p class="qt-explorer-empty"><?php esc_html_e( 'A selected constituency or ward will show its representative, party, source and freshness here.', 'quiettruths' ); ?></p>
					</aside>
				</div>

				<div id="qt-explorer-sources" class="qt-explorer-sources">
					<div class="qt-role-label" style="color:var(--qt-ink-subtle); margin-bottom:0.55rem;">
						<?php esc_html_e( 'Sources & honest status labels · checked 14 Nov 2026', 'quiettruths' ); ?>
					</div>
					<div class="qt-source-link-grid">
						<?php foreach ( $sources as $source ) : ?>
							<a class="qt-source-link" href="<?php echo esc_url( $source['url'] ); ?>" target="_blank" rel="noopener noreferrer">
								<strong><?php echo esc_html( $source['short'] ); ?></strong>
								<span><?php echo esc_html( $source['note'] ); ?></span>
							</a>
						<?php endforeach; ?>
					</div>
					<p class="qt-source-note">
						<?php esc_html_e( '1,433 elected MCA names come from the 2022 IEBC extract and are labelled “verify”. Seventeen wards have complete boundaries but no named elected MCA in that extract; they are shown as explicit record gaps, never filled with guesses.', 'quiettruths' ); ?>
					</p>
				</div>
			</section>

			<div style="margin-top:1.25rem; padding-top:1.1rem; border-top:1px solid var(--qt-border);">
				<div class="qt-role-label" style="color:var(--qt-crimson); margin-bottom:0.45rem;">
					<?php esc_html_e( 'On Your Ground · Active Local Political Stakes & Assembly Oversight', 'quiettruths' ); ?>
				</div>
				<div class="qt-subpanel" id="qt-det-pulse" style="font-size:0.88rem; color:var(--qt-ink); line-height:1.6;">
					<?php echo esc_html( $default_county['localPulse'] ); ?>
				</div>
			</div>
		</div>
	</div>
	<?php endif; ?>
</section>

<!-- National Political Record + Daily 3-Minute Quiet Brief -->
<section class="qt-grid-atlas" style="margin-top:2.75rem; padding-top:2rem; border-top:2px solid var(--qt-border);">
	<!-- Left 5 cols: The Quiet Brief + Next Page CTA -->
	<div style="display:flex; flex-direction:column; gap:1.5rem;">
		<div class="qt-card qt-pad" id="qt-quiet-brief">
			<div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--qt-border); padding-bottom:0.8rem;">
				<div>
					<div class="qt-role-label" style="color:var(--qt-azure);"><?php esc_html_e( 'Daily 3-Minute Political Digest', 'quiettruths' ); ?></div>
					<h3 style="margin:0.2rem 0 0; font-family:var(--qt-font-serif); font-size:1.5rem;"><?php esc_html_e( 'The Quiet Brief', 'quiettruths' ); ?></h3>
				</div>
				<span class="qt-badge qt-badge-emerald"><?php esc_html_e( '3 Min Read', 'quiettruths' ); ?></span>
			</div>

			<p style="font-size:0.8rem; font-style:italic; color:var(--qt-ink-muted); margin:0.75rem 0 1rem;">
				<?php esc_html_e( 'What formally changed in gazettes, parliamentary committees, and courts—stripped of rally insults and unverified speculation.', 'quiettruths' ); ?>
			</p>

			<div style="display:flex; flex-direction:column; gap:1rem;">
				<?php foreach ( $quiet_briefs as $b ) : ?>
					<div style="display:flex; gap:0.75rem;">
						<span class="qt-badge qt-badge-emerald" style="height:26px; width:26px; justify-content:center; flex-shrink:0;">
							<?php echo esc_html( $b['num'] ); ?>
						</span>
						<div>
							<div style="font-family:var(--qt-font-mono); font-size:0.72rem; font-weight:700; text-transform:uppercase;">
								<?php echo esc_html( $b['category'] ); ?>
							</div>
							<p style="margin:0.2rem 0 0; font-size:0.82rem; color:var(--qt-ink-muted);">
								<?php echo esc_html( $b['summary'] ); ?>
							</p>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<!-- Bridge to Page 02 -->
		<div class="qt-source-reveal-box" style="padding:1.5rem;">
			<div class="qt-role-label" style="color:var(--qt-gold-bright);"><?php esc_html_e( 'Up Next · Page 02', 'quiettruths' ); ?></div>
			<h4 style="margin:0.35rem 0 0; font-family:var(--qt-font-serif); font-size:1.35rem;">
				<?php esc_html_e( 'Test Your Politics Without Party Colors', 'quiettruths' ); ?>
			</h4>
			<p style="font-size:0.84rem; color:rgba(236,253,245,0.88); margin:0.55rem 0 1.1rem;">
				<?php esc_html_e( 'Open The Blind Ballot to evaluate competing Kenyan manifestos and legislative stances side by side before revealing who authored them.', 'quiettruths' ); ?>
			</p>
			<a href="<?php echo esc_url( qt_get_page_url_by_slug( 'blind-ballot' ) ); ?>" class="qt-btn" style="background:#FFFFFF; color:var(--qt-ink);">
				<?php esc_html_e( 'Enter The Blind Ballot →', 'quiettruths' ); ?>
			</a>
		</div>
	</div>

	<!-- Right 7 cols: On the National Stage -->
	<div>
		<div style="display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:0.75rem; margin-bottom:1rem;">
			<div>
				<div class="qt-role-label" style="color:var(--qt-emerald-dark);"><?php esc_html_e( 'National Political Record', 'quiettruths' ); ?></div>
				<h3 style="margin:0.15rem 0 0; font-family:var(--qt-font-serif); font-size:1.65rem;"><?php esc_html_e( 'On the National Stage This Week', 'quiettruths' ); ?></h3>
			</div>
			<a href="<?php echo esc_url( qt_get_page_url_by_slug( 'podium-vs-parliament' ) ); ?>" class="qt-btn qt-btn-outline">
				<?php esc_html_e( 'Compare with Hansard →', 'quiettruths' ); ?>
			</a>
		</div>

		<div class="qt-card-lg">
			<?php foreach ( $national_updates as $idx => $upd ) : ?>
				<article class="qt-pad" style="<?php echo $idx > 0 ? 'border-top:1px solid var(--qt-border);' : ''; ?>">
					<div class="qt-role-label" style="color:var(--qt-azure);">
						<?php echo esc_html( $upd['institution'] . ' · ' . $upd['date'] ); ?>
					</div>
					<h4 style="margin:0.4rem 0 0; font-family:var(--qt-font-serif); font-size:1.18rem; line-height:1.35;">
						<?php echo esc_html( $upd['headline'] ); ?>
					</h4>
					<p style="margin:0.5rem 0 0; font-size:0.9rem; color:var(--qt-ink-muted);">
						<?php echo esc_html( $upd['detail'] ); ?>
					</p>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php
get_footer();
