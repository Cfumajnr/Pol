# Changelog

## 1.2.2 — 21 September 2026

### Navigation + footer menus fix
- The top nav is now exactly the 7-item spec on existing installs, not just fresh ones: Analysis · Profiles · Economy · Explainers · Opinion · 2027 (accent button) · About. A one-time auto-repair on the first admin load rebuilds the assigned primary menu when it does not match; a "Repair navigation menu" notice offers the same fix manually. Hand-built correct menus are detected and left untouched.
- The 2027 link is always the canonical `/2027/` (nav fallback, seeded menu, footer, hub template) regardless of the stored page slug (`election-2027`, `2027-2`). The rewrite flushes automatically on update.
- About menu label fixed to "About" (was the full page title "About Quiet Truths").
- Footer grid corrected to 3 columns (brand + Sections + Outlet) with the bottom bar `© 2026 Quiet Truths · quiettruths.co.ke · Corrections: corrections@quiettruths.co.ke`.
- Header keeps the search icon; hamburger shows the same 7 in the same order; menu stays flat (depth 1) and capped at 7.

## 1.2.1 — 21 September 2026

### Layout, navigation and dates
- Close the site header before the main landmark.
- Remove the filter that replaced every post date with the literal `j M Y`.
- Fix a runtime fatal error discovered in staging: `wp_nav_menu_objects` supplies an argument object, not an array.
- Make the fallback menu actually output markup, and make the saved-menu election setting/demotion consistent with the fallback.
- Keep mobile navigation available without JavaScript; enhanced menu still supports Escape.
- Apply saved color preference early and respect reduced-motion scrolling.
- Guard form enhancements when Fetch/URLSearchParams are unavailable.
- Use unique tip/newsletter label IDs.
- Resolve election links from the saved page instead of assuming a numeric slug survived WordPress slug validation. Preserve existing page data.

### Newsletter
- Shared validation, feature-enable checks and rate limiting for AJAX/native POST.
- Correct error propagation for database and mail-submission failures.
- Rate-limited confirmation resend, 24-hour expiry and single-use confirmation tokens.
- Honest pending/confirmed/invalid/error notices; no false success on failed updates.
- Additive schema migration on activation and authenticated administrator visits.
- Consent-version recording and scheduled pending-record cleanup.
- Confirmed-only, batched, formula-safe CSV export via authenticated admin-post handler.
- POST-only, capability- and nonce-checked admin deletion before rendering.
- Private unsubscribe URLs in exports; confirmation POST removes records.
- Privacy/consent messaging reflects implementation; existing edited pages are not overwritten.

### Polls
- Serialize all theme-controlled poll mutations with a MySQL/MariaDB named lock, preserving existing store and counts.
- Check database write success; fresh reads avoid stale object-cache option values.
- Strict option validation, explicit public poll-token checks, correct REST status codes.
- Load scripts wherever poll widgets render and add a real native POST vote handler.
- Respect the existing show-results setting.
- Add Close voting action and SameSite cookie attributes.
- Remove claims of verified one-vote-per-device protection.

### Archives, metadata and caching
- Add leader pagination and upcoming/ongoing versus past event views.
- Use site timezone in event helpers; allow clearing optional dates and reject invalid calendar dates on save.
- Emit explicit archive canonicals, preserving page numbers, and defer theme metadata to recognized SEO plugins.
- Replace direct transient-row deletion with versioned query-cache keys.
- Use conservative private/no-store behavior for active interactive features and token responses.

### Documentation and source safety
- Replace unsupported secure-email claims and remove the ineffective tip-email nonce.
- Correct stale county counts, missing lint-tool references and child-theme instructions.
- Document tested versions, cache tradeoffs, existing pending-link behavior, and external newsletter-provider responsibilities.

### Deliberately not changed
- No removal or overwrite of editorial content, theme settings, existing menus, or historical poll results.
- No automatic migration of durable features into a companion plugin.
- No SMTP service, anonymous submission system, or external mailing-platform synchronization is bundled.
