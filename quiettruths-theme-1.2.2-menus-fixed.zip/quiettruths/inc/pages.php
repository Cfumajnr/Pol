<?php
/**
 * Core pages and the navigation that points to them.
 *
 * A site that links to /corrections/ and /contact/ must actually have those
 * pages, and a footer that says "we publish our corrections" is a promise the
 * site has to be able to keep on day one. These pages are seeded with real,
 * editable content on activation — not lorem ipsum, and not dead links.
 *
 * Seeding is idempotent and matched by slug, so re-activation never duplicates
 * a page and never overwrites an editor's changes.
 *
 * @package QuietTruths
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * The core pages this theme creates, keyed by slug.
 *
 * @since 1.1.0
 * @return array<string, array<string, string>> Page definitions.
 */
function quiettruths_core_pages() {
	$tip_email   = get_theme_mod( 'qt_tip_email', 'tips@quiettruths.co.ke' );
	$news_email  = get_theme_mod( 'qt_news_email', 'news@quiettruths.co.ke' );
	$collections = get_theme_mod( 'qt_corrections_email', 'corrections@quiettruths.co.ke' );

	$pages = array(
		'about' => array(
			'title'   => __( 'About Quiet Truths', 'quiettruths' ),
			'content' => '<!-- wp:paragraph -->
<p><strong>Quiet Truths reports on five counties: Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We are deliberately narrow. Five counties covered properly will tell you more about how power works in Western Kenya than forty-seven covered thinly. Every budget line, tender award, land transaction and promise made in those five counties is our beat, and we intend to be the record of it.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Investigations.</strong> Long-form reporting built on documents and data. Where we cannot name a source, we say why.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Analysis.</strong> What a decision in Nairobi or a county assembly actually changes on the ground.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Opinion.</strong> Argument from the region, not about it. Contributors keep their disagreements with us.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>The Leaders Directory.</strong> Who represents the five counties, which party sent them, and how to reach their office.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Barazas &amp; events.</strong> Public meetings, county assembly sittings and campaign stops, published before they happen.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Why Trans Nzoia</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Trans Nzoia sat in the former Rift Valley Province, which was abolished in 2013. By economy, politics and electorate it is Western Kenya, and leaving it out on the strength of a provincial line that no longer exists would be administrative nostalgia rather than journalism. It is in scope, and it is covered to the same standard.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="standards">Our standards</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This is the part worth reading before you cite us.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Name the source.</strong> Where we can name a source, we do. Where we cannot, we say why in the piece itself rather than leaving the reader to guess.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Publish the document.</strong> If a story rests on a tender award, an audit query or a land title, the document goes up alongside it.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Put it to the subject.</strong> Before we publish criticism of a person or an office, we seek their response and give them a fair window to give one.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Separate reporting from opinion.</strong> Opinion is labelled Opinion and lives on its own shelf. It does not borrow the authority of our reporting.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Correct in the open.</strong> A correction states what was wrong, what it now says, and when it changed. We never silently edit, and we do not rewrite the record. See our <a href="/corrections/">corrections policy</a>.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Protect sources absolutely.</strong> A source\'s identity is the most important fact in most of our stories. We do not log it unless asked to.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Get the small facts right.</strong> Names, figures, dates and county headquarters. Our readers use these pages as a reference, so a wrong population figure is a correction, not a typo.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>If you think we have fallen short of any of this, write to the newsroom. We would rather hear it from you than discover it later.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sources are the most important fact in most of our stories. How to reach the desk safely is on the <a href="/contact/">contact page</a>.</p>
<!-- /wp:paragraph -->',
		),

		'contact' => array(
			'title'   => __( 'Contact', 'quiettruths' ),
			'content' => '<!-- wp:paragraph -->
<p>Three mailboxes, one desk. Use the one that fits.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"qt-data-callout"} -->
<div class="wp-block-group qt-data-callout"><!-- wp:paragraph -->
<p><strong>Tips and documents</strong><br><a href="mailto:' . esc_attr( $tip_email ) . '">' . esc_html( $tip_email ) . '</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p class="has-small-font-size">For anything sensitive. Use a personal email address on a personal device, never one issued by your employer. See the source safety guidance below.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"qt-data-callout"} -->
<div class="wp-block-group qt-data-callout"><!-- wp:paragraph -->
<p><strong>Newsroom</strong><br><a href="mailto:' . esc_attr( $news_email ) . '">' . esc_html( $news_email ) . '</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p class="has-small-font-size">Story leads, press releases, right of reply, interview requests.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"qt-data-callout"} -->
<div class="wp-block-group qt-data-callout"><!-- wp:paragraph -->
<p><strong>Corrections</strong><br><a href="mailto:' . esc_attr( $collections ) . '">' . esc_html( $collections ) . '</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p class="has-small-font-size">If we got something wrong, tell us here. How we handle it is set out in our <a href="/corrections/">corrections policy</a>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Source safety</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item">Use a personal email address, not one issued by your employer. Work email is routinely monitored.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">Do not send documents from a work computer or a work network.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">Tell us if you want to speak on background. We will agree terms before you say anything substantive.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">We do not log or store the identity of a source unless you ask us to.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Right of reply</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If we are about to publish something that criticises you or your office, we will try to put it to you first and give you a fair window to respond. If you believe you have been treated unfairly, write to the newsroom and we will consider it seriously.</p>
<!-- /wp:paragraph -->',
		),

		'corrections' => array(
			'title'   => __( 'Corrections policy', 'quiettruths' ),
			'content' => '<!-- wp:paragraph -->
<p>Quiet Truths aims to be the record of what happened in Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia. A record that quietly rewrites itself is worthless, so our corrections are made in the open.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">How to tell us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Email <a href="mailto:' . esc_attr( $collections ) . '">' . esc_html( $collections ) . '</a>, or use the "Report a correction" link at the foot of any article. Every correction request is read by an editor, not filtered by a form.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We acknowledge.</strong> You get a reply, even if we conclude we were right.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We check against the primary source.</strong> The document, the transcript, the statute — not against what we remember writing.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We correct on the record.</strong> The correction appears at the top of the article, states what was wrong and what it has been changed to, and carries the date it was made.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We never silently edit.</strong> The text may change, but the fact that it changed does not disappear.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We withdraw what cannot stand.</strong> If a central claim fails, the story comes down and a notice explains why.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Mistakes we treat as serious</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Getting a name, a figure, a date or a county headquarters wrong matters more here than it would elsewhere, because our readers use these pages as a reference. A wrong population figure or a wrong officeholder is a correction, not a typo.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Corrections log</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><em>Editors: list material corrections here, newest first, as "Date — Article — What changed and why". An empty log is fine at launch; a hidden one is not.</em></p>
<!-- /wp:paragraph -->',
		),
	);

	/*
	 * The election hub sits at /2027/ — a page slug, not a category, because
	 * the spec calls for that exact URL and the hub is more than a listing.
	 * It uses the election template, which queries the Election 2027 category.
	 */
	$pages['2027'] = array(
		'title'    => __( 'Election 2027', 'quiettruths' ),
		'template' => 'templates/election-hub.php',
		'content'  => '<!-- wp:paragraph -->
<p>Everything Quiet Truths publishes about the 2027 general election across Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia: the contests, the money, the machinery and the count.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This page updates itself as election coverage is published. Below it you will find the latest reporting, the candidate profiles we have filed, and the county-by-county picture.</p>
<!-- /wp:paragraph -->',
	);

	// Privacy, in the footer by legal convention.
	$pages['privacy'] = array(
		'title'   => __( 'Privacy', 'quiettruths' ),
		'content' => '<!-- wp:paragraph -->
<p>This page explains what Quiet Truths collects, why, and what you can ask us to do about it. It is written for readers in Kenya and reflects the Data Protection Act, 2019.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we collect</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Email address</strong>, if you sign up to the newsletter. Only once you have confirmed it by email.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Comments</strong> you choose to leave, along with the name you give and your IP address, which WordPress stores for spam filtering.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Poll votes.</strong> A cookie on your device records that you voted so the tally is not padded. It contains no personal information.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Standard server logs</strong>, such as your IP address and browser, kept by our hosting provider for security.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we do not do</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item">We do not sell or share the subscriber list. Not with parties, not with candidates, not with advertisers.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">We do not run third-party advertising trackers.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">We do not record the identity of a source unless you explicitly ask us to.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Sources</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If you send us a document or speak to us on background, protecting you matters more than the story. Use a personal email address on a personal device, not one issued by your employer. Practical guidance is on the <a href="/contact/">contact page</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Your rights</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You can ask us what we hold about you, ask us to correct it, or ask us to delete it. Write to <a href="mailto:privacy@quiettruths.co.ke">privacy@quiettruths.co.ke</a> and we will respond within thirty days. Newsletter subscribers can follow the unsubscribe link in each newsletter and confirm removal.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Retention</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Confirmed subscriber records are kept until you unsubscribe or ask us to delete them. Unconfirmed signup requests are removed after approximately thirty days by a scheduled task. Poll vote cookies expire after a year. Comments remain published unless you ask us to remove them.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Cookies</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We use two kinds: a colour-scheme preference, so the site stays in the mode you chose, and a poll-vote marker. Neither identifies you and neither is shared with anyone.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Data protection questions go to <a href="mailto:privacy@quiettruths.co.ke">privacy@quiettruths.co.ke</a>. If you are not satisfied with our response you can complain to the Office of the Data Protection Commissioner in Kenya.</p>
<!-- /wp:paragraph -->',
	);

	/**
	 * Filter the core pages before they are seeded.
	 *
	 * @since 1.1.0
	 * @param array $pages Page definitions keyed by slug.
	 */
	return apply_filters( 'quiettruths_core_pages', $pages );
}

/**
 * Create the core pages if they are missing.
 *
 * Matched by slug, so an editor who renames a page's title keeps their work and
 * re-activation does not create a second copy.
 *
 * @since 1.1.0
 */
function quiettruths_seed_core_pages() {
	foreach ( quiettruths_core_pages() as $slug => $page ) {
		if ( ( '2027' === (string) $slug && quiettruths_election_page() ) || get_page_by_path( $slug ) ) {
			continue;
		}

		$post_id = wp_insert_post( array(
			'post_title'   => $page['title'],
			'post_name'    => '2027' === (string) $slug ? 'election-2027' : $slug,
			'post_content' => isset( $page['content'] ) ? $page['content'] : '',
			'post_status'  => 'publish',
			'post_type'    => 'page',
		) );

		// A page can declare its own template, which is how the /2027/ hub gets
		// a self-updating listing instead of static content.
		if ( ! is_wp_error( $post_id ) && $post_id && ! empty( $page['template'] ) ) {
			update_post_meta( (int) $post_id, '_wp_page_template', $page['template'] );
		}
	}

	quiettruths_maybe_create_primary_menu();
}
add_action( 'after_switch_theme', 'quiettruths_seed_core_pages' );

/**
 * Build the primary menu from the spec: five sections, Elections 2027, About.
 *
 * Only runs when nothing is assigned to the primary location, so an editor's own
 * menu is never replaced. The fallback in inc/helpers.php still covers the case
 * where the menu exists but is empty.
 *
 * @since 1.1.0
 */
function quiettruths_maybe_create_primary_menu() {
	if ( has_nav_menu( 'primary' ) ) {
		return;
	}

	$menu = quiettruths_get_or_create_primary_menu();

	if ( ! $menu ) {
		return;
	}

	quiettruths_build_primary_menu_items( (int) $menu );

	$locations            = get_theme_mod( 'nav_menu_locations' );
	$locations            = is_array( $locations ) ? $locations : array();
	$locations['primary'] = (int) $menu;

	set_theme_mod( 'nav_menu_locations', $locations );
}

/**
 * Get the "Quiet Truths primary" menu, creating it when missing.
 *
 * @since 1.2.2
 * @return int Menu term ID, or 0 on failure.
 */
function quiettruths_get_or_create_primary_menu() {
	$menu_name = __( 'Quiet Truths primary', 'quiettruths' );
	$menu      = wp_get_nav_menu_object( $menu_name );

	if ( $menu && ! is_wp_error( $menu ) ) {
		return (int) $menu->term_id;
	}

	$menu_id = wp_create_nav_menu( $menu_name );

	if ( is_wp_error( $menu_id ) ) {
		return 0;
	}

	return (int) $menu_id;
}

/**
 * (Re)build the seven primary-menu items in spec order.
 *
 * Deletes every existing item first, then adds:
 * Analysis, Profiles, Economy, Explainers, Opinion, 2027, About.
 *
 * Shelves are linked as real category terms and About as a real page, which
 * keeps WordPress's current-menu-item highlighting working. The 2027 hub is a
 * custom link to the spec URL /2027/ (served by the rewrite rule), because the
 * stored page slug varies by install history (/election-2027/, /2027-2/) and
 * the nav must always show the canonical URL. The 2027 button styling is
 * applied by quiettruths_nav_item_classes() on the path, not by the menu item.
 *
 * @since 1.2.2
 * @param int $menu_id Menu term ID.
 * @return int Number of items created.
 */
function quiettruths_build_primary_menu_items( $menu_id ) {
	$menu_id = (int) $menu_id;

	if ( ! $menu_id ) {
		return 0;
	}

	// Make sure the five shelf categories exist before linking to them.
	if ( function_exists( 'quiettruths_seed_terms' ) ) {
		quiettruths_seed_terms();
	}

	$existing = wp_get_nav_menu_items( $menu_id );

	if ( is_array( $existing ) ) {
		foreach ( $existing as $item ) {
			wp_delete_post( (int) $item->ID, true );
		}
	}

	$created = 0;

	foreach ( array( 'analysis', 'profiles', 'economy', 'explainers', 'opinion' ) as $cat_slug ) {
		$category = get_category_by_slug( $cat_slug );

		if ( ! $category || is_wp_error( $category ) ) {
			continue;
		}

		$item_id = wp_update_nav_menu_item( $menu_id, 0, array(
			'menu-item-title'     => $category->name,
			'menu-item-object-id' => (int) $category->term_id,
			'menu-item-object'    => 'category',
			'menu-item-type'      => 'taxonomy',
			'menu-item-status'    => 'publish',
		) );

		if ( $item_id && ! is_wp_error( $item_id ) ) {
			$created++;
		}
	}

	// 2027: custom link so the URL is exactly /2027/ on every install.
	$item_id = wp_update_nav_menu_item( $menu_id, 0, array(
		'menu-item-title'  => __( '2027', 'quiettruths' ),
		'menu-item-url'    => home_url( '/2027/' ),
		'menu-item-type'   => 'custom',
		'menu-item-status' => 'publish',
	) );

	if ( $item_id && ! is_wp_error( $item_id ) ) {
		$created++;
	}

	// About last. Label is the short "About", not the page title.
	$about = get_page_by_path( 'about' );

	if ( $about && ! is_wp_error( $about ) ) {
		$item_id = wp_update_nav_menu_item( $menu_id, 0, array(
			'menu-item-title'     => __( 'About', 'quiettruths' ),
			'menu-item-object-id' => (int) $about->ID,
			'menu-item-object'    => 'page',
			'menu-item-type'      => 'post_type',
			'menu-item-status'    => 'publish',
		) );

		if ( $item_id && ! is_wp_error( $item_id ) ) {
			$created++;
		}
	}

	return $created;
}

/**
 * Whether the assigned primary menu already matches the seven-item spec.
 *
 * Compares top-level item URLs against the nav spec, so an editor who rebuilt
 * the menu by hand in the right order is left alone.
 *
 * @since 1.2.2
 * @return bool True when the menu is complete and correctly ordered.
 */
function quiettruths_primary_menu_is_complete() {
	$locations = get_theme_mod( 'nav_menu_locations' );

	if ( ! is_array( $locations ) || empty( $locations['primary'] ) ) {
		return false;
	}

	$items = wp_get_nav_menu_items( (int) $locations['primary'] );

	if ( ! is_array( $items ) ) {
		return false;
	}

	$top = array_values( array_filter( $items, static function ( $item ) {
		return ! (int) $item->menu_item_parent;
	} ) );

	if ( count( $top ) !== 7 ) {
		return false;
	}

	$spec_paths = array(
		'/category/analysis',
		'/category/profiles',
		'/category/economy',
		'/category/explainers',
		'/category/opinion',
		'__election__',
		'/about',
	);

	foreach ( $top as $index => $item ) {
		$want = $spec_paths[ $index ];

		if ( '__election__' === $want ) {
			if ( ! quiettruths_is_election_url( $item->url ) ) {
				return false;
			}
			continue;
		}

		$path = untrailingslashit( (string) wp_parse_url( (string) $item->url, PHP_URL_PATH ) );

		if ( $path !== $want ) {
			return false;
		}
	}

	return true;
}

/**
 * One-click repair for sites whose menu was seeded before the shelves existed.
 *
 * Runs automatically, once, on the first admin page load after the 1.2.2
 * update — but only when the assigned menu does NOT already match the spec, so
 * a hand-built correct menu is never touched. An admin notice offers the same
 * repair manually.
 *
 * @since 1.2.2
 */
function quiettruths_maybe_repair_primary_menu() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// Manual trigger from the admin notice.
	if ( isset( $_GET['qt_repair_menu'] ) ) {
		check_admin_referer( 'qt_repair_menu' );

		quiettruths_repair_primary_menu_now();

		wp_safe_redirect( remove_query_arg( array( 'qt_repair_menu', '_wpnonce' ) ) );
		exit;
	}

	if ( '1.2.2' === get_option( 'qt_menu_version' ) ) {
		return;
	}

	if ( ! quiettruths_primary_menu_is_complete() ) {
		quiettruths_repair_primary_menu_now();
	}

	update_option( 'qt_menu_version', '1.2.2', false );
}
add_action( 'admin_init', 'quiettruths_maybe_repair_primary_menu' );

/**
 * Rebuild the assigned primary menu (or create and assign one) right now.
 *
 * @since 1.2.2
 * @return int Number of items created.
 */
function quiettruths_repair_primary_menu_now() {
	$menu_id = quiettruths_get_or_create_primary_menu();

	if ( ! $menu_id ) {
		return 0;
	}

	$created = quiettruths_build_primary_menu_items( $menu_id );

	$locations            = get_theme_mod( 'nav_menu_locations' );
	$locations            = is_array( $locations ) ? $locations : array();
	$locations['primary'] = (int) $menu_id;

	set_theme_mod( 'nav_menu_locations', $locations );

	update_option( 'qt_menu_version', '1.2.2', false );

	return $created;
}

/**
 * Show a repair notice while the primary menu does not match the spec.
 *
 * @since 1.2.2
 */
function quiettruths_menu_repair_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( quiettruths_primary_menu_is_complete() ) {
		return;
	}

	$url = wp_nonce_url( add_query_arg( 'qt_repair_menu', '1' ), 'qt_repair_menu' );

	printf(
		'<div class="notice notice-warning"><p><strong>%1$s</strong> %2$s</p><p><a class="button button-primary" href="%3$s">%4$s</a></p></div>',
		esc_html__( 'Quiet Truths:', 'quiettruths' ),
		esc_html__( 'The top navigation does not match the 7-item spec (Analysis · Profiles · Economy · Explainers · Opinion · 2027 · About). One click rebuilds it in the right order; nothing else on the site changes.', 'quiettruths' ),
		esc_url( $url ),
		esc_html__( 'Repair navigation menu', 'quiettruths' )
	);
}
add_action( 'admin_notices', 'quiettruths_menu_repair_notice' );

/**
 * The archive URL for a topic term.
 *
 * @since 1.1.0
 * @param string $slug Topic slug.
 * @return string URL, or '' when the term does not exist.
 */
function quiettruths_topic_link( $slug ) {
	$link = get_term_link( sanitize_title( (string) $slug ), 'qt_topic' );

	if ( is_wp_error( $link ) ) {
		return '';
	}

	return (string) $link;
}

/** Legacy numeric URL resolves to the saved page, without renaming editor data. */
function quiettruths_election_rewrite() {
	$page = quiettruths_election_page();
	if ( $page ) { add_rewrite_rule( '^2027/?$', 'index.php?page_id=' . (int) $page->ID, 'top' ); }
}
add_action( 'init', 'quiettruths_election_rewrite', 20 );
function quiettruths_upgrade_rewrites() {
	if ( current_user_can( 'manage_options' ) && '1.2.2' !== get_option( 'qt_rewrite_version' ) ) {
		flush_rewrite_rules( false );
		update_option( 'qt_rewrite_version', '1.2.2', false );
	}
}
add_action( 'admin_init', 'quiettruths_upgrade_rewrites' );
