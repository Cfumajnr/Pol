<?php
/**
 * Template helpers.
 *
 * Every function here is prefixed `quiettruths_` so the theme can coexist with
 * plugins without collisions, and so a child theme can override behaviour with
 * `remove_action`/`add_filter` rather than copying templates.
 *
 * Conventions used throughout:
 *  - Functions that PRINT are named `the_*` (matching core's vocabulary).
 *  - Functions that RETURN are named `get_*`.
 *  - All output is escaped at the point of echo. No exceptions.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------------------
 * Reading time & excerpts
 * ------------------------------------------------------------------------ */

/**
 * Estimate reading time in minutes for a post.
 *
 * @since 1.0.0
 * @param int $post_id Optional. Post ID. Defaults to the current post.
 * @return int Minutes, minimum 1.
 */
function quiettruths_reading_minutes( $post_id = 0 ) {
	$post = get_post( $post_id );

	if ( ! $post ) {
		return 1;
	}

	// strip_shortcodes + wp_strip_all_tags keeps embeds out of the count.
	$words = str_word_count( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) );

	return max( 1, (int) ceil( $words / 220 ) );
}

/**
 * Return a clean excerpt of a given word length.
 *
 * Falls back to a content-derived excerpt when the author left it blank.
 *
 * @since 1.0.0
 * @param int $words  Optional. Word count. Default 24.
 * @param int $post_id Optional. Post ID. Defaults to the current post.
 * @return string Excerpt text, unescaped.
 */
function quiettruths_get_excerpt( $words = 24, $post_id = 0 ) {
	$post = get_post( $post_id );

	if ( ! $post ) {
		return '';
	}

	$source = has_excerpt( $post ) ? $post->post_excerpt : $post->post_content;
	$source = wp_strip_all_tags( strip_shortcodes( $source ) );
	$source = str_replace( array( "\r", "\n" ), ' ', $source );
	$source = preg_replace( '/\s+/', ' ', $source );

	$parts = array_filter( explode( ' ', $source ) );

	if ( count( $parts ) <= $words ) {
		return implode( ' ', $parts );
	}

	return implode( ' ', array_slice( $parts, 0, $words ) ) . '&hellip;';
}

/**
 * Print an excerpt.
 *
 * @since 1.0.0
 * @param int $words   Optional. Word count.
 * @param int $post_id Optional. Post ID.
 */
function quiettruths_the_excerpt( $words = 24, $post_id = 0 ) {
	echo esc_html( quiettruths_get_excerpt( $words, $post_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_html applied to full string.
}

/* ---------------------------------------------------------------------------
 * Taxonomy chips
 * ------------------------------------------------------------------------ */

/**
 * Print linked chips for a taxonomy on a post.
 *
 * @since 1.0.0
 * @param string $taxonomy Taxonomy slug.
 * @param int    $post_id  Optional. Post ID.
 * @param int    $limit    Optional. Max chips. Default 3.
 */
function quiettruths_the_terms_chips( $taxonomy, $post_id = 0, $limit = 3 ) {
	$terms = get_the_terms( $post_id ? $post_id : get_the_ID(), $taxonomy );

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return;
	}

	$terms = array_slice( $terms, 0, max( 1, (int) $limit ) );

	echo '<ul class="qt-chips">';
	foreach ( $terms as $term ) {
		printf(
			'<li class="qt-chip"><a href="%1$s" rel="tag">%2$s</a></li>',
			esc_url( get_term_link( $term ) ),
			esc_html( $term->name )
		);
	}
	echo '</ul>';
}

/* ---------------------------------------------------------------------------
 * Byline / meta
 * ------------------------------------------------------------------------ */

/**
 * Print the byline and dateline for a post.
 *
 * @since 1.0.0
 * @param int  $post_id   Optional. Post ID.
 * @param bool $show_time Optional. Show updated time. Default true.
 */
function quiettruths_the_meta( $post_id = 0, $show_time = true ) {
	$post_id = $post_id ? $post_id : get_the_ID();

	if ( ! $post_id ) {
		return;
	}

	$time = sprintf(
		'<time class="qt-meta__time" datetime="%1$s">%2$s</time>',
		esc_attr( get_the_date( 'c', $post_id ) ),
		esc_html( get_the_date( 'j M Y', $post_id ) )
	);

	printf( '<div class="qt-meta"><span class="qt-meta__by">%1$s</span>%2$s',
		esc_html( sprintf(
			/* translators: %s: author name. */
			__( 'By %s', 'quiettruths' ),
			get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) )
		) ),
		$time // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_attr/esc_html above.
	);

	if ( $show_time ) {
		printf(
			'<span class="qt-meta__read">%s</span>',
			esc_html( sprintf(
				/* translators: %d: reading time in minutes. */
				_n( '%d min read', '%d min read', quiettruths_reading_minutes( $post_id ), 'quiettruths' ),
				quiettruths_reading_minutes( $post_id )
			) )
		);
	}

	echo '</div>';
}

/* ---------------------------------------------------------------------------
 * Post cards
 * ------------------------------------------------------------------------ */

/**
 * Print a post card.
 *
 * @since 1.0.0
 * @param string $variant One of 'lead', 'grid', 'list', 'compact'.
 * @param int    $post_id Optional. Post ID.
 */
function quiettruths_card( $variant = 'grid', $post_id = 0 ) {
	$allowed = array( 'lead', 'grid', 'list', 'compact' );
	$variant = in_array( $variant, $allowed, true ) ? $variant : 'grid';

	get_template_part( 'template-parts/content/card', $variant );
}

/**
 * Print a grid of post cards from the current query.
 *
 * @since 1.0.0
 * @param string $variant Card variant.
 * @param int    $count   Max cards to print.
 */
function quiettruths_card_loop( $variant = 'grid', $count = 6 ) {
	$printed = 0;

	while ( have_posts() && $printed < $count ) {
		the_post();
		quiettruths_card( $variant );
		$printed++;
	}

	if ( 0 === $printed ) {
		quiettruths_no_results();
	}

	// Reset so the page can run other queries afterwards.
	rewind_posts();
}

/**
 * Print a friendly "nothing here yet" block.
 *
 * @since 1.0.0
 */
function quiettruths_no_results() {
	get_template_part( 'template-parts/content/none' );
}

/* ---------------------------------------------------------------------------
 * Breadcrumbs
 * ------------------------------------------------------------------------ */

/**
 * Print breadcrumbs for archives, singles and search.
 *
 * Deliberately lightweight: no plugin, no schema duplication (JSON-LD is
 * emitted separately by inc/seo.php).
 *
 * @since 1.0.0
 */
function quiettruths_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}

	$items = array();
	$items[] = array(
		'label' => __( 'Home', 'quiettruths' ),
		'url'   => home_url( '/' ),
	);

	if ( is_singular( 'qt_investigation' ) ) {
		$items[] = array(
			'label' => __( 'Investigations', 'quiettruths' ),
			'url'   => get_post_type_archive_link( 'qt_investigation' ),
		);
	} elseif ( is_singular( 'qt_leader' ) ) {
		$items[] = array(
			'label' => __( 'Leaders Directory', 'quiettruths' ),
			'url'   => get_post_type_archive_link( 'qt_leader' ),
		);
	} elseif ( is_singular( 'qt_event' ) ) {
		$items[] = array(
			'label' => __( 'Barazas & Events', 'quiettruths' ),
			'url'   => get_post_type_archive_link( 'qt_event' ),
		);
	} elseif ( is_tax( 'qt_county' ) ) {
		$items[] = array(
			'label' => __( 'Counties', 'quiettruths' ),
			'url'   => home_url( '/#qt-counties' ),
		);
	} elseif ( is_category() ) {
		$items[] = array(
			'label' => __( 'News', 'quiettruths' ),
			'url'   => get_permalink( (int) get_option( 'page_for_posts' ) ),
		);
	}

	if ( is_singular() ) {
		$items[] = array(
			'label' => get_the_title(),
			'url'   => '',
		);
	} elseif ( is_search() ) {
		$items[] = array(
			/* translators: %s: search query. */
			'label' => sprintf( __( 'Search: %s', 'quiettruths' ), get_search_query() ),
			'url'   => '',
		);
	} else {
		$items[] = array(
			'label' => wp_get_document_title(),
			'url'   => '',
		);
	}

	// Rendered as "Home › Profiles › Name". The chevron is markup, not a CSS
	// pseudo-element, so it survives a stripped stylesheet and reads correctly
	// to a screen reader as a separator rather than as content.
	echo '<nav class="qt-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'quiettruths' ) . '"><ol>';
	$last = count( $items ) - 1;

	foreach ( $items as $index => $item ) {
		if ( $index > 0 ) {
			echo '<li class="qt-breadcrumbs__sep" aria-hidden="true">&rsaquo;</li>';
		}

		if ( $index === $last || '' === $item['url'] ) {
			printf( '<li aria-current="page">%s</li>', esc_html( $item['label'] ) );
		} else {
			printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( $item['url'] ), esc_html( $item['label'] ) );
		}
	}

	echo '</ol></nav>';
}

/* ---------------------------------------------------------------------------
 * Pagination
 * ------------------------------------------------------------------------ */

/**
 * Print accessible archive pagination.
 *
 * @since 1.0.0
 * @param string $query Optional. Query var to paginate. Default 'paged'.
 */
function quiettruths_pagination( $query = 'paged' ) {
	$big = 999999999;

	$links = paginate_links(
		array(
			'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format'    => '?paged=%#%',
			'current'   => max( 1, (int) get_query_var( $query ) ),
			'total'     => $GLOBALS['wp_query']->max_num_pages,
			'prev_text' => __( '&larr; Newer', 'quiettruths' ),
			'next_text' => __( 'Older &rarr;', 'quiettruths' ),
			'type'      => 'list',
		)
	);

	if ( empty( $links ) ) {
		return;
	}

	echo '<nav class="qt-pagination" aria-label="' . esc_attr__( 'Posts navigation', 'quiettruths' ) . '">';
	echo wp_kses_post( $links );
	echo '</nav>';
}

/* ---------------------------------------------------------------------------
 * County navigation
 * ------------------------------------------------------------------------ */

/**
 * Print the county navigation grid.
 *
 * @since 1.0.0
 * @param bool $with_stats Optional. Show population and governor. Default true.
 */
function quiettruths_county_grid( $with_stats = true ) {
	$counties = quiettruths_counties();
	$totals   = quiettruths_region_totals();

	echo '<section id="qt-counties" class="qt-counties">';

	printf(
		'<header class="qt-section-head"><h2>%1$s</h2><p>%2$s</p></header>',
		esc_html__( 'The five counties we cover', 'quiettruths' ),
		esc_html( sprintf(
			/* translators: 1: number of people, 2: number of constituencies. */
			__( '%1$s people across %2$s constituencies, covered properly rather than thinly.', 'quiettruths' ),
			quiettruths_number( $totals['population'] ),
			quiettruths_number( $totals['constituencies'] )
		) )
	);

	echo '<div class="qt-county-grid">';

	foreach ( $counties as $county ) {
		$link = quiettruths_county_link( $county['slug'] );

		/*
		 * When the county archive does not exist yet, render the card without a
		 * link rather than pointing it somewhere misleading. A dead or bait-and-
		 * switch link on a site whose brand is being the record costs more than
		 * a card that is not clickable for one release.
		 */
		if ( '' !== $link ) {
			echo '<a class="qt-county-card" href="' . esc_url( $link ) . '">';
		} else {
			echo '<span class="qt-county-card qt-county-card--static">';
		}

		echo '<span class="qt-county-card__code">' . esc_html( $county['code'] ) . '</span>';
		echo '<span class="qt-county-card__name">' . esc_html( $county['name'] ) . '</span>';
		echo '<span class="qt-county-card__capital">' . esc_html( $county['capital'] ) . '</span>';

		if ( $with_stats ) {
			echo '<span class="qt-county-card__stats">';
			echo '<span>' . esc_html( quiettruths_number( $county['population'] ) ) . '</span>';
			echo '<small>' . esc_html__( 'people', 'quiettruths' ) . '</small>';
			echo '</span>';
			echo '<span class="qt-county-card__gov">' . esc_html( $county['governor'] );

			if ( ! empty( $county['party'] ) ) {
				echo ' <em>' . esc_html( $county['party'] ) . '</em>';
			}

			echo '</span>';
		}

		echo '' !== $link ? '</a>' : '</span>';
	}

	echo '</div>';
	echo '<p class="qt-county-note">' . esc_html( sprintf(
		/* translators: %s: census year. */
		__( 'Population, land area and density: %s Kenya Population and Housing Census (KNBS). Officeholders are updated by our editors.', 'quiettruths' ),
		'2019'
	) ) . '</p>';
	echo '</section>';
}

/**
 * Print compact county filter chips, used on archives and the leaders directory.
 *
 * @since 1.0.0
 */
function quiettruths_county_chips() {
	echo '<ul class="qt-county-chips" aria-label="' . esc_attr__( 'Filter by county', 'quiettruths' ) . '">';
	printf(
		'<li><a class="qt-county-chip" href="%s">%s</a></li>',
		esc_url( home_url( '/#qt-counties' ) ),
		esc_html__( 'All counties', 'quiettruths' )
	);

	foreach ( quiettruths_counties() as $county ) {
		$link = quiettruths_county_link( $county['slug'] );

		if ( '' === $link ) {
			continue;
		}

		printf(
			'<li><a class="qt-county-chip" href="%1$s">%2$s</a></li>',
			esc_url( $link ),
			esc_html( $county['name'] )
		);
	}

	echo '</ul>';
}

/* ---------------------------------------------------------------------------
 * Email tip contact
 * ------------------------------------------------------------------------ */

/**
 * Build the "send us a document" mailto link.
 *
 * Ordinary email contact: no encryption, anonymity or expiry is provided.
 *
 * @since 1.0.0
 * @param string $subject Optional. Prefilled subject.
 * @return string Escaped URL.
 */
function quiettruths_tip_url( $subject = '' ) {
	$to = get_theme_mod( 'qt_tip_email', 'tips@quiettruths.co.ke' );

	$args = array(
		'subject' => $subject ? $subject : __( 'Tip for Quiet Truths', 'quiettruths' ),
		'body' => sprintf(
			__( "Sent: %1\$s\n\nYour message:\n\n---\n%2\$s email tip contact. Ordinary email is not anonymous or end-to-end encrypted.", 'quiettruths' ),
			gmdate( 'Y-m-d H:i' ), get_bloginfo( 'name' )
		),
	);

	return esc_url( add_query_arg( array_map( 'rawurlencode', $args ), 'mailto:' . $to ) );
}

/**
 * Print the tip-line call to action.
 *
 * @since 1.0.0
 */
function quiettruths_tip_cta() {
	get_template_part( 'template-parts/tip-cta' );
}

/* ---------------------------------------------------------------------------
 * JSON-LD
 * ------------------------------------------------------------------------ */

/**
 * Return a JSON-LD payload as a script tag.
 *
 * @since 1.0.0
 * @param array $data Schema.org array.
 * @return string Safe script tag, or an empty string for invalid input.
 */
function quiettruths_jsonld( array $data ) {
	if ( empty( $data ) ) {
		return '';
	}

	// JSON_UNESCAPED_SLASHES keeps URLs readable; UNESCAPED_UNICODE is safe for
	// the UTF-8 output we declare in the <meta charset>.
	$json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

	if ( ! $json ) {
		return '';
	}

	// Escape any closing script sequence so content cannot break out of the tag.
	$json = str_replace( '</', '<\/', $json );

	return '<script type="application/ld+json">' . $json . '</script>';
}

/* ---------------------------------------------------------------------------
 * Leaders directory
 * ------------------------------------------------------------------------ */

/**
 * Print a grid of leader profiles from the current query.
 *
 * @since 1.0.0
 * @param int $count Optional. Max cards. Default 12.
 */
function quiettruths_leaders_grid( $count = 12 ) {
	$printed = 0;

	while ( have_posts() && $printed < $count ) {
		the_post();
		get_template_part( 'template-parts/leader/card' );
		$printed++;
	}

	if ( 0 === $printed ) {
		printf(
			'<p class="qt-empty">%s</p>',
			esc_html__( 'No profiles match that filter yet. Our editors are adding leaders county by county.', 'quiettruths' )
		);
	}

	rewind_posts();
}

/* ---------------------------------------------------------------------------
 * Events / barazas
 * ------------------------------------------------------------------------ */

/**
 * Print a human-friendly event date, e.g. "Sat 4 Oct 2027 · 10:00".
 *
 * @since 1.0.0
 * @param int $post_id Optional. Post ID.
 */
function quiettruths_the_event_date( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$start   = get_post_meta( $post_id, '_qt_event_start', true );

	if ( ! $start ) {
		echo esc_html( get_the_date( 'j M Y', $post_id ) );
		return;
	}

	$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $start, wp_timezone() );
	$timestamp = $date ? $date->getTimestamp() : false;

	if ( false === $timestamp ) {
		echo esc_html( get_the_date( 'j M Y', $post_id ) );
		return;
	}

	/* translators: 1: day name, 2: date, 3: time. */
	echo esc_html( sprintf(
		__( '%1$s %2$s · %3$s', 'quiettruths' ),
		wp_date( 'D', $timestamp ),
		wp_date( 'j M Y', $timestamp ),
		wp_date( 'H:i', $timestamp )
	) );
}

/**
 * Whether an event is still upcoming.
 *
 * @since 1.0.0
 * @param int $post_id Optional. Post ID.
 * @return bool True when the start date is in the future, or unset.
 */
function quiettruths_event_is_upcoming( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$end = get_post_meta( $post_id, '_qt_event_end', true );
	$start = $end ? $end : get_post_meta( $post_id, '_qt_event_start', true );
	if ( ! $start ) { return true; }
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $start, wp_timezone() );
	return $date ? $date->getTimestamp() >= time() : true;
}

/* ---------------------------------------------------------------------------
 * Misc UI atoms
 * ------------------------------------------------------------------------ */

/**
 * Print the theme's inline SVG logo mark.
 *
 * Embedded rather than referenced as a file so it inherits currentColor, works
 * offline in the previewer, and costs no extra request on LiteSpeed.
 *
 * @since 1.0.0
 */
function quiettruths_logo_mark() {
	echo '<svg class="qt-mark" viewBox="0 0 32 32" role="img" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">';
	echo '<circle cx="16" cy="16" r="15" fill="none" stroke="currentColor" stroke-width="1.5"/>';
	echo '<path d="M9 20.5c2.4-3 4.2-9.2 7-9.2s4.6 6.2 7 9.2" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>';
	echo '<circle cx="16" cy="10.4" r="1.6" fill="currentColor"/>';
	echo '</svg>';
}

/**
 * Print the site brand block (mark + name + tagline).
 *
 * @since 1.0.0
 */
function quiettruths_branding() {
	$tagline = get_theme_mod( 'qt_tagline', __( 'Five counties, covered properly', 'quiettruths' ) );

	echo '<a class="qt-brand" href="' . esc_url( home_url( '/' ) ) . '" rel="home">';
	quiettruths_logo_mark();
	echo '<span class="qt-brand__text">';
	echo '<span class="qt-brand__name">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';

	if ( $tagline ) {
		echo '<span class="qt-brand__tag">' . esc_html( $tagline ) . '</span>';
	}

	echo '</span></a>';
}

/**
 * Print the breaking-news ticker strip.
 *
 * Reads comma-separated headlines from the Customizer. Renders nothing when the
 * control is empty or the feature is switched off, so there is no empty strip
 * on a fresh install.
 *
 * @since 1.0.0
 */
function quiettruths_breaking_news() {
	if ( ! get_theme_mod( 'qt_breaking_enable', false ) ) {
		return;
	}

	$raw = (string) get_theme_mod( 'qt_breaking_items', '' );

	if ( '' === trim( $raw ) ) {
		return;
	}

	$items = array_filter( array_map( 'trim', explode( '|', $raw ) ) );

	if ( empty( $items ) ) {
		return;
	}

	echo '<div class="qt-ticker" role="region" aria-label="' . esc_attr__( 'Breaking news', 'quiettruths' ) . '">';
	echo '<span class="qt-ticker__label">' . esc_html( get_theme_mod( 'qt_breaking_label', __( 'Breaking', 'quiettruths' ) ) ) . '</span>';
	echo '<div class="qt-ticker__track">';

	foreach ( $items as $item ) {
		// Each item is "Headline :: URL"; the URL half is optional.
		$parts = array_map( 'trim', explode( '::', $item, 2 ) );
		$label = isset( $parts[0] ) ? $parts[0] : '';
		$url   = isset( $parts[1] ) ? $parts[1] : '';

		if ( '' === $label ) {
			continue;
		}

		if ( $url ) {
			printf(
				'<a class="qt-ticker__item" href="%1$s">%2$s</a>',
				esc_url( $url ),
				esc_html( $label )
			);
		} else {
			printf( '<span class="qt-ticker__item">%s</span>', esc_html( $label ) );
		}
	}

	echo '</div></div>';
}

/**
 * Print social links from Customizer controls.
 *
 * @since 1.0.0
 */
function quiettruths_social_links() {
	$networks = array(
		'qt_x'        => __( 'X (Twitter)', 'quiettruths' ),
		'qt_facebook' => __( 'Facebook', 'quiettruths' ),
		'qt_youtube'  => __( 'YouTube', 'quiettruths' ),
		'qt_tiktok'   => __( 'TikTok', 'quiettruths' ),
		'qt_whatsapp' => __( 'WhatsApp', 'quiettruths' ),
	);

	$rendered = array();

	foreach ( $networks as $key => $label ) {
		$url = (string) get_theme_mod( $key, '' );

		if ( '' === trim( $url ) ) {
			continue;
		}

		$rendered[] = sprintf(
			'<li><a href="%1$s" rel="me noopener" target="_blank">%2$s</a></li>',
			esc_url( $url ),
			esc_html( $label )
		);
	}

	if ( empty( $rendered ) ) {
		return;
	}

	echo '<ul class="qt-social">' . implode( '', $rendered ) . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- each item escaped above.
}

/* ---------------------------------------------------------------------------
 * Menu fallbacks
 *
 * A fresh install has no menus assigned yet. Without a fallback the header
 * renders an empty strip and the site looks broken on day one, so these build a
 * sensible menu from the theme's own archives.
 * ------------------------------------------------------------------------ */

/**
 * The top navigation specification.
 *
 * Seven items, flat, in this order: five shelves ranked by expected output
 * share, then the election hub, then About. Outlet information sits at the right
 * end by convention; Corrections and Contact live in the footer only.
 *
 * This array is the single source of truth for the nav. Both the seeded menu and
 * the no-menu fallback read from it, so the two cannot drift apart.
 *
 * Order is load-bearing — see quiettruths_nav_spec() callers.
 *
 * @since 1.2.0
 * @return array<int, array<string, string>> Ordered nav items.
 */
function quiettruths_nav_spec() {
	$items = array(
		array(
			'label' => __( 'Analysis', 'quiettruths' ),
			'url'   => home_url( '/category/analysis/' ),
		),
		array(
			'label' => __( 'Profiles', 'quiettruths' ),
			'url'   => home_url( '/category/profiles/' ),
		),
		array(
			'label' => __( 'Economy', 'quiettruths' ),
			'url'   => home_url( '/category/economy/' ),
		),
		array(
			'label' => __( 'Explainers', 'quiettruths' ),
			'url'   => home_url( '/category/explainers/' ),
		),
		array(
			'label' => __( 'Opinion', 'quiettruths' ),
			'url'   => home_url( '/category/opinion/' ),
		),
		array(
			'label'  => __( '2027', 'quiettruths' ),
			'url'    => quiettruths_election_url(),
			'is_cta' => true,
		),
		array(
			'label' => __( 'About', 'quiettruths' ),
			'url'   => home_url( '/about/' ),
		),
	);

	/*
	 * The 2027 hub is time-sensitive. After August 2027 the election is over and
	 * the button should stop shouting, so it is demoted to a plain link. The
	 * Customizer lets an editor drop it from the nav entirely without a release.
	 */
	if ( time() >= strtotime( '2027-09-01 00:00:00' ) ) {
		foreach ( $items as $index => $item ) {
			if ( ! empty( $item['is_cta'] ) ) {
				$items[ $index ]['is_cta'] = false;
			}
		}
	}

	if ( ! get_theme_mod( 'qt_show_2027', true ) ) {
		$items = array_values( array_filter( $items, static function ( $item ) {
			return ! quiettruths_is_election_url( $item['url'] );
		} ) );
	}

	/*
	 * Rule: never an eighth top-nav item. If something new wants in, something
	 * old drops to the footer. Enforced here so a well-meaning editor cannot
	 * quietly break the header on a phone.
	 */
	return array_slice( $items, 0, 7 );
}

/**
 * Fallback for the primary menu.
 *
 * Renders the nav spec directly, so a fresh install with no menu assigned still
 * shows the correct seven items in the correct order.
 *
 * @since 1.0.0
 * @param array $args wp_nav_menu arguments.
 * @return string Menu markup.
 */
function quiettruths_primary_menu_fallback( $args = array() ) {
	$args = (array) $args;
	$class = isset( $args['menu_class'] ) ? $args['menu_class'] : 'qt-menu';

	$out = '<ul class="' . esc_attr( $class ) . '">';

	foreach ( quiettruths_nav_spec() as $item ) {
		$link_class = ! empty( $item['is_cta'] ) ? ' class="qt-menu__cta"' : '';

		$out .= '<li' . ( ! empty( $item['is_cta'] ) ? ' class="qt-menu__item--cta"' : '' ) . '>';
		$out .= '<a href="' . esc_url( $item['url'] ) . '"' . $link_class . '>' . esc_html( $item['label'] ) . '</a>';
		$out .= '</li>';
	}

	$out .= '</ul>';

	if ( ! isset( $args['echo'] ) || $args['echo'] ) { echo $out; }
	return $out;
}

/**
 * Mark the 2027 item as the nav's only button.
 *
 * Applies to a menu the editor built in the dashboard, not just the fallback, so
 * the button survives being managed by hand. Matched on path rather than label
 * so renaming the item does not silently lose the styling.
 *
 * @since 1.2.0
 * @param array   $classes Existing CSS classes.
 * @param WP_Post $item    Menu item.
 * @return array Filtered classes.
 */
function quiettruths_nav_item_classes( $classes, $item ) {
	if ( empty( $item->url ) ) {
		return $classes;
	}

	$path = (string) wp_parse_url( $item->url, PHP_URL_PATH );

	if ( quiettruths_is_election_url( $item->url ) && time() < strtotime( '2027-09-01T00:00:00+03:00' ) ) {
		$classes[] = 'qt-menu__item--cta';
	}

	return $classes;
}
add_filter( 'nav_menu_css_class', 'quiettruths_nav_item_classes', 10, 2 );

/**
 * Add the button class to the 2027 anchor itself.
 *
 * @since 1.2.0
 * @param array   $atts HTML attributes.
 * @param WP_Post $item Menu item.
 * @return array Filtered attributes.
 */
function quiettruths_nav_item_attrs( $atts, $item ) {
	if ( empty( $item->url ) ) {
		return $atts;
	}

	$path = (string) wp_parse_url( $item->url, PHP_URL_PATH );

	if ( quiettruths_is_election_url( $item->url ) && time() < strtotime( '2027-09-01T00:00:00+03:00' ) ) {
		$existing      = isset( $atts['class'] ) ? (string) $atts['class'] : '';
		$atts['class'] = trim( $existing . ' qt-menu__cta' );
	}

	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'quiettruths_nav_item_attrs', 10, 2 );

/**
 * Hard cap the primary menu at seven items.
 *
 * The spec is explicit: never an eighth. Anything past seven is dropped from the
 * header rather than wrapped onto a second row on a phone. The editor still sees
 * the item in the dashboard — it simply does not render — so nothing is silently
 * deleted from their menu.
 *
 * Scoped to the primary location. Without that check this would also truncate
 * the footer menu, which is supposed to carry everything the header drops.
 *
 * @since 1.2.0
 * @param array $items Menu items.
 * @param array $args  wp_nav_menu arguments.
 * @return array Capped items.
 */
function quiettruths_cap_primary_menu( $items, $args = array() ) {
	$args = (array) $args;
	if ( ! is_array( $items ) ) {
		return $items;
	}

	$location = isset( $args['theme_location'] ) ? (string) $args['theme_location'] : '';

	if ( 'primary' !== $location ) {
		return $items;
	}

	$items = array_filter( $items, function ( $item ) {
		return ! $item->menu_item_parent && ( get_theme_mod( 'qt_show_2027', true ) || ! quiettruths_is_election_url( $item->url ) );
	} );

	if ( count( $items ) <= 7 ) {
		return $items;
	}

	return array_slice( $items, 0, 7, true );
}
add_filter( 'wp_nav_menu_objects', 'quiettruths_cap_primary_menu', 10, 2 );

/** Resolve an existing hub without changing its content or permalink. */
function quiettruths_election_page() {
	$page = get_page_by_path( '2027' );
	if ( $page && 'publish' === $page->post_status ) { return $page; }
	$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 1, 'meta_key' => '_wp_page_template', 'meta_value' => 'templates/election-hub.php', 'orderby' => 'ID', 'order' => 'ASC' ) );
	return $pages ? $pages[0] : null;
}
/**
 * The public URL of the 2027 hub.
 *
 * Always the spec URL /2027/ (served by the rewrite in inc/pages.php), never
 * the storage slug (/election-2027/, /2027-2/). The nav spec, the footer and
 * the seeded menu all read from here so the three cannot drift apart.
 *
 * @since 1.2.2
 * @return string Absolute URL to the hub.
 */
function quiettruths_election_url() {
	return home_url( '/2027/' );
}
/**
 * Whether a URL points at the election hub, in any of its historical forms.
 *
 * Matches /2027/ (canonical), /election-2027/ (fresh-install slug),
 * /2027-2/ (WordPress numeric-slug suffixing on upgraded sites) and the
 * current saved permalink, so the 2027 button styling survives every install
 * history.
 *
 * @since 1.2.2
 * @param string $url URL to test.
 * @return bool True when the URL is the hub.
 */
function quiettruths_is_election_url( $url ) {
	$path = untrailingslashit( (string) wp_parse_url( (string) $url, PHP_URL_PATH ) );
	$path = '' === $path ? '/' : $path;

	$known = array( '/2027', '/2027-2', '/election-2027' );

	if ( in_array( $path, $known, true ) ) {
		return true;
	}

	$page = quiettruths_election_page();

	if ( $page ) {
		$permalink_path = untrailingslashit( (string) wp_parse_url( get_permalink( $page ), PHP_URL_PATH ) );
		if ( '' !== $permalink_path && $path === $permalink_path ) {
			return true;
		}
	}

	return untrailingslashit( (string) $url ) === untrailingslashit( quiettruths_election_url() );
}
