# Quiet Truths — WordPress theme 1.3.0

Independent reporting on Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.
This is a theme ZIP, not a full site/database/media backup.

## What is new in 1.3.0

- **Navigation and footer menus** are now real menu locations that the theme seeds for you: **Primary**, **Footer — Sections**, **Footer — Outlet** (Appearance → Menus).
- **Header search** is a working icon that opens a search field (focus, Escape, click-outside), instead of a link to `/?s=` that landed on the homepage.
- **Breadcrumbs** read `Home › Profiles › Story` and now match BreadcrumbList structured data.
- **Block patterns** register correctly (they were silently failing and logging notices on every page load).

## Install or update safely

1. Back up the **database, uploads, and existing theme**, including any edits made directly to theme files.
2. Test this update on staging first. Replacing the theme overwrites direct edits; child-theme customizations should also be tested.
3. In WordPress: **Appearance → Themes → Add New → Upload Theme**. Select the ZIP. If Quiet Truths is already installed, choose **Replace current with uploaded**.
4. Activate if this is a new installation. On an existing installation, visit the dashboard as an administrator. The additive subscriber-table migration also runs on `admin_init`, so reactivation is not necessary.
5. Visit **Settings → Permalinks → Save Changes**. Purge LiteSpeed/CDN/server/browser caches, including any cached forms.
6. Check your menus, homepage, article, county archive, leaders directory, events, polls and signup form before switching traffic.

Minimum declared compatibility: WordPress 6.0 / PHP 7.4. This release was functionally tested on **WordPress 7.1.1, PHP 8.4.24 and MariaDB 11.8.6**, plus headless Chromium (desktop, 360px mobile, and with JavaScript disabled). Minimum-version compatibility was not independently exercised. Use supported PHP/WordPress versions in production.

## Navigation and footer menus

The spec is fixed and enforced by the theme:

| # | Label | Goes to |
|---|---|---|
| 1 | Analysis | `/category/analysis/` |
| 2 | Profiles | `/category/profiles/` |
| 3 | Economy | `/category/economy/` |
| 4 | Explainers | `/category/explainers/` |
| 5 | Opinion | `/category/opinion/` |
| 6 | **2027** | the election hub page — styled as an accent button, the nav's only button |
| 7 | About | `/about/` |

Flat, no dropdowns. The hamburger shows the same seven in the same order. The header also carries a search icon.

Footer: brand column (wordmark, tagline, descriptor, socials), **Sections** (the five shelves plus Election 2027), **Outlet** (About · Standards `/about/#standards` · Corrections · Contact · Privacy), then the bottom bar `© {year} Quiet Truths · {domain} · Corrections: corrections@quiettruths.co.ke`. Corrections and Contact are footer-only by design.

**Three rules, enforced in code:**

1. 2027 is the only nav button. It demotes itself to a plain link after August 2027, and the Customizer control *Show the 2027 button in the nav* drops it entirely.
2. Never an eighth top-nav item: the header renders at most seven top-level items, so a new item cannot break the mobile header. It stays visible in the dashboard, so nothing is silently deleted — move the displaced item to a footer menu instead.
3. Breadcrumbs are on by default (`Home › Profiles › Story`). Turn them off in Appearance → Customize → Navigation if Rank Math or Yoast is already printing a trail, so readers never see two. Yoast is detected automatically; for other plugins use `add_filter( 'quiettruths_breadcrumbs_enabled', '__return_false' );`.

**How the menus are managed.** One spec per location (`inc/menus.php`) drives the seeded dashboard menu, the no-menu fallback and the footer columns, so they cannot drift apart. Seeding only fills locations that are empty — a menu you assign yourself always wins. On upgrade, a one-time pass adds the footer locations and restores any missing spec item in theme-owned menus; it never deletes items you added. To customize freely, copy a theme menu (give it a new name), edit the copy, and assign that instead.

The footer bottom bar shows this install's own domain by default (so staging does not advertise production); override it in Appearance → Customize → Navigation → *Footer domain*.

## Important operational changes

### Newsletter

- Off by default; enable in the Customizer only when ready to publish.
- Both AJAX and native POST use the same validation and throttling.
- Confirmation links expire after 24 hours and are single-use. Signing up again requests a fresh link, limited to once per address per five minutes and five attempts per IP per hour.
- Existing **pending** links from 1.2.0 have no expiry metadata and are invalidated by the stricter confirmation process. Readers can sign up again for a fresh link. Existing **confirmed** subscribers remain confirmed.
- Mail-submission failures now produce errors instead of success notices. Successful submission to `wp_mail()` does not establish inbox delivery: configure and test your mail transport, SPF/DKIM/DMARC and spam-folder behavior.
- Subscriber exports contain **confirmed records only**, plus each reader's private `unsubscribe_url`. CSV cells are protected against formula prefixes. Export is streamed in batches from an early authenticated handler.
- **Include each unsubscribe URL in every newsletter.** Following it shows a confirmation button; POST removes the subscriber. GET does not remove records, so ordinary mail-link scanning cannot unsubscribe a reader.
- This theme captures subscriptions; **it does not send newsletter campaigns**. Use a fresh export immediately before each mailing, not an old saved list. If an external email platform holds a copy, integrate its unsubscribe/suppression system and deletion workflow separately. The theme cannot automatically delete data in another service.
- Unconfirmed records are cleaned up after approximately 30 days by WP-Cron. Ensure cron runs on your host. Confirmed records are kept until removal.
- New consent records use `newsletter-1.2.1`, whose wording is: “By signing up, you request the Quiet Truths newsletter. Confirm by email before receiving it. Every newsletter must include an unsubscribe link. We never share the list.” Existing records are not retroactively given this consent version.
- Export files and unsubscribe links contain private data/access tokens. Store them securely and do not publish them.

### Polls and database locking

Polls retain the existing option storage, IDs and historical counts. Every theme-controlled mutation now uses a MySQL/MariaDB named lock around a fresh database read and checked write. This avoids lost concurrent increments **without replacing or migrating historical poll data**. Lock acquisition fails closed with a retryable error on incompatible databases. Test this on hosts using database proxies or nonstandard WordPress database backends.

Both REST voting and native no-JavaScript POST work. The script loads wherever the poll renders. An explicit poll nonce is checked, and inputs/errors are validated. A new **Close voting** admin action preserves results.

Cookies and IP throttling are lightweight anti-abuse measures, not voter identity verification. Shared networks may be rate-limited together. Do not trust arbitrary forwarded-IP headers; configure trusted proxies at the server level if required. These polls remain informal reader engagement, not election evidence or scientific surveys.

### Caching policy

This release takes a conservative correctness-first approach: while newsletter signup is enabled or a poll is active, front-end responses are marked private/no-store and signal LiteSpeed/DONOTCACHEPAGE. Token and status responses are also private. This reduces page-cache efficiency but avoids stale forms and shared cookie-dependent poll output.

An upstream CDN or pre-existing full-page cache may answer before WordPress runs. **Purge existing caches and configure upstream caches to honor these exclusions/headers.** Repeat tests with the real hosting stack. Disabling signup and closing polls restores ordinary host-controlled caching. Query-cache invalidation uses versioned keys through WordPress APIs and works with persistent object-cache storage.

### Source safety

The tip contact is ordinary email, not an anonymous or end-to-end-encrypted submission service. The nonce previously inserted in the email body has been removed. Configure any truly secure submission channel separately, with appropriate editorial procedures. Do not tell sources that email links protect their identity.

### Existing pages and menus

User-edited pages/menus are not overwritten. Review the existing Privacy/Contact pages manually: replace any old promises about “one click” removal or “secure” ordinary email, and publish your real retention and external-mail-provider practices.

WordPress can suffix numeric slugs such as `2027`. Fresh installs use `election-2027`; existing election-template pages keep their current URLs and content. Theme links resolve the actual saved page. The legacy `/2027/` route resolves to that page after permalinks are saved. If an old installation's seeded menu is missing the election page, add it under Appearance → Menus; the update does not replace an editor-managed menu.

The primary menu is flat and capped at seven top-level items. The election visibility setting and post-August-2027 CTA demotion apply to saved menus as well as the fallback.

Events have Upcoming/ongoing and Past views, based on the site's configured timezone. Use valid start/end times with end not before start. Leaders are paginated in groups of 60.

## Customization and SEO

Use a child theme for template changes. Included PHP modules are loaded from the parent directory and are **not** automatically overridden by a same-named child-theme module. Customize county data through the existing `quiettruths_counties` filter.

The theme suppresses its custom schema/social/archive-canonical output when common SEO plugins are detected (Yoast, Rank Math, AIOSEO, SEOPress). For another metadata provider:

```php
add_filter( 'quiettruths_output_metadata', '__return_false' );
```

Core remains responsible for singular canonical output. Check page source and structured data after enabling any SEO plugin.

## Scope and remaining work

This is a corrective theme release, not a redesign, a security certification, or a managed mail service. CPT/taxonomy registrations, subscriber handling and polls remain in the theme for upgrade continuity. A companion-plugin extraction is a separate future refactor; switching themes currently removes these features' registrations and screens without automatically deleting their stored data.

The ZIP has no development dependencies, database credentials, sample subscriber data, or local WordPress installation. `TEST-RESULTS.md` summarizes the executed checks; `CHANGELOG.md` lists corrections. Real SMTP deliverability, production LiteSpeed/CDN/Redis behavior, all plugin combinations, and complete accessibility certification remain deployment checks.
