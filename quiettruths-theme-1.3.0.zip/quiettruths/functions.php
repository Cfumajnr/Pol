<?php
/**
 * Quiet Truths — theme bootstrap.
 *
 * This file only defines constants and loads modules. Every feature lives in its
 * own file under /inc so that the theme can be audited, extended via a child
 * theme, or have individual features switched off without touching the rest.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Theme version. Used for cache-busting enqueued assets.
 */
define( 'QUIETTRUTHS_VERSION', '1.3.0' );

/**
 * Absolute path to the theme directory, with trailing slash.
 */
define( 'QUIETTRUTHS_DIR', trailingslashit( get_template_directory() ) );

/**
 * URI to the theme directory, with trailing slash.
 */
define( 'QUIETTRUTHS_URI', trailingslashit( get_template_directory_uri() ) );

/**
 * Minimum PHP version the theme is written for.
 */
define( 'QUIETTRUTHS_MIN_PHP', '7.4' );

/**
 * Menu spec version. Bumped when the nav/footer spec changes so an existing
 * install gets the new items without a re-activation.
 */
define( 'QUIETTRUTHS_MENU_VERSION', '1.3.0' );

/**
 * Load order matters: helpers are used by the registration files below.
 */
$quiettruths_modules = array(
	'inc/storage.php',     // Shared locking, input and cache utilities.
	'inc/data.php',        // County dataset + reference data. No hooks.
	'inc/helpers.php',     // Pure template helpers. No hooks.
	'inc/setup.php',       // Theme support, assets, menus, image sizes.
	'inc/content-types.php', // CPTs + taxonomies + default terms.
	'inc/pages.php',       // Core pages (About/Contact/Corrections).
	'inc/menus.php',       // Nav + footer menu specs, seeding, fallbacks.
	'inc/customizer.php',  // Customizer panels, controls, sanitizers.
	'inc/widgets.php',     // Sidebars + theme widgets.
	'inc/newsletter.php',  // Subscriber table, AJAX capture, admin CSV export.
	'inc/polls.php',       // Poll storage, REST endpoint, admin UI.
	'inc/seo.php',         // JSON-LD schema, Open Graph, feed/meta hygiene.
	'inc/performance.php', // LiteSpeed-friendly asset + query optimisations.
);

foreach ( $quiettruths_modules as $quiettruths_module ) {
	$quiettruths_path = QUIETTRUTHS_DIR . $quiettruths_module;

	if ( is_readable( $quiettruths_path ) ) {
		require_once $quiettruths_path;
	}
}

unset( $quiettruths_modules, $quiettruths_module, $quiettruths_path );

/*
 * Block patterns are registered from inc/setup.php after 'after_setup_theme'
 * so that the pattern category API is guaranteed to be available.
 */
