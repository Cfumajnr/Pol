# Changelog

## 1.3.0 — 21 September 2026

### Navigation and footer menus
- Register three menu locations: **Primary**, **Footer — Sections**, **Footer — Outlet**.
- Add `inc/menus.php`: one spec per location drives the dashboard menu, the no-menu fallback and the footer columns, so they cannot drift apart.
- Seed the three spec menus on activation and assign them to any unassigned location. An editor-assigned menu always wins.
- Add a non-destructive upgrade pass (`admin_init`) that creates the footer locations on existing installs and restores missing spec items, without deleting items an editor added.
- Footer Sections and Outlet columns now render from real menu locations with spec fallbacks; the brand column, tip contact and bottom bar are unchanged.
- Footer bottom bar derives the domain from the site (Customizer override available) instead of a hard-coded string.
- Enforce the two nav rules at render time as well as in the spec: never more than seven top-level items, and 2027 remains the only button (demoted after August 2027, removable via the Customizer).

### Header search
- The header search icon now opens a real search panel (focus, Escape, outside-click close) instead of linking to `/?s=`, which loaded the homepage on a static-front-page install.
- Without JavaScript the panel stays in flow, so search remains reachable.

### Block patterns
- Add the required `Title:`/`Slug:` headers to the four files in `/patterns`. WordPress scans that directory on every load; without headers each request logged a "Slug field missing" notice and the patterns were never registered.
- Stop registering the same patterns a second time from `inc/setup.php` (which would raise "already registered"); the theme now registers only the pattern category, on `after_setup_theme` so it exists before core reads the files.

### Breadcrumbs
- Corrected the trail: posts now read **Home › Profiles › Name** using the shelf category, category/tag/term archives show the term name (not the document title with the site name appended), pages include ancestor chains, and date/author archives use proper labels.
- Trail logic is shared with new BreadcrumbList JSON-LD, emitted only when the theme owns metadata.
- Customizer toggle plus `quiettruths_breadcrumbs_enabled` filter; Yoast breadcrumbs are detected automatically so a trail is never printed twice.

## 1.2.1 — 21 September 2026

### Layout, navigation and dates
- Close the site header before the main landmark.
- Remove the filter that replaced every post date with the literal `j M Y`.
- Fix a runtime fatal error discovered in staging: `wp_nav_menu_objects` supplies an argument object, not an array.
- Make the fallback menu actually output markup, and make the saved-menu election setting/demotion consistent with the fallback.
- Keep mobile navigation available without JavaScript; enhanced menu still supports Escape.
- Apply saved color preference early and respect reduced-motion scrolling.
- Guard form enhancements when Fetch/URLSearchParams are unavailable.
- Use unique tip/newsletter label IDs.
- Resolve election links from the saved page instead of assuming a numeric slug survived WordPress slug validation. Preserve existing page data.

### Newsletter
- Shared validation, feature-enable checks and rate limiting for AJAX/native POST.
- Correct error propagation for database and mail-submission failures.
- Rate-limited confirmation resend, 24-hour expiry and single-use confirmation tokens.
- Honest pending/confirmed/invalid/error notices; no false success on failed updates.
- Additive schema migration on activation and authenticated administrator visits.
- Consent-version recording and scheduled pending-record cleanup.
- Confirmed-only, batched, formula-safe CSV export via authenticated admin-post handler.
- POST-only, capability- and nonce-checked admin deletion before rendering.
- Private unsubscribe URLs in exports; confirmation POST removes records.
- Privacy/consent messaging reflects implementation; existing edited pages are not overwritten.

### Polls
- Serialize all theme-controlled poll mutations with a MySQL/MariaDB named lock, preserving existing store and counts.
- Check database write success; fresh reads avoid stale object-cache option values.
- Strict option validation, explicit public poll-token checks, correct REST status codes.
- Load scripts wherever poll widgets render and add a real native POST vote handler.
- Respect the existing show-results setting.
- Add Close voting action and SameSite cookie attributes.
- Remove claims of verified one-vote-per-device protection.

### Archives, metadata and caching
- Add leader pagination and upcoming/ongoing versus past event views.
- Use site timezone in event helpers; allow clearing optional dates and reject invalid calendar dates on save.
- Emit explicit archive canonicals, preserving page numbers, and defer theme metadata to recognized SEO plugins.
- Replace direct transient-row deletion with versioned query-cache keys.
- Use conservative private/no-store behavior for active interactive features and token responses.

### Documentation and source safety
- Replace unsupported secure-email claims and remove the ineffective tip-email nonce.
- Correct stale county counts, missing lint-tool references and child-theme instructions.
- Document tested versions, cache tradeoffs, existing pending-link behavior, and external newsletter-provider responsibilities.

### Deliberately not changed
- No removal or overwrite of editorial content, theme settings, existing menus, or historical poll results.
- No automatic migration of durable features into a companion plugin.
- No SMTP service, anonymous submission system, or external mailing-platform synchronization is bundled.
