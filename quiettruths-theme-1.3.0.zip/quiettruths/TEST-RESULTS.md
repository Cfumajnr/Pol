# Quiet Truths 1.3.0 — test results

Executed locally on 21 September 2026 against the corrected theme.

## Environment

- WordPress 7.1.1 (actual downloaded core and installed database, not API stubs)
- PHP 8.4.24
- MariaDB 11.8.6
- Headless Chromium through Playwright
- PHP development HTTP server; WordPress debug logging enabled
- Test-only interception of outgoing mail for successful-submission flows; separate failed-mail simulation

No test installation, development credentials, fixtures or email-interception plugin is included in this ZIP.

## Results

| Check | Result |
|---|---|
| PHP syntax | 49 files passed |
| JavaScript syntax | 2 files passed |
| Menu / breadcrumb / footer integration assertions (new in 1.3.0) | 54 passed, 0 failed |
| Newsletter / poll / date / event integration assertions | 40 passed, 0 failed |
| Navigation, footer, search and breadcrumb browser assertions (new in 1.3.0) | 39 passed, 0 failed |
| Core browser/HTTP assertions | 39 passed, 0 failed |
| Extended browser/HTTP assertions | 15 passed, 0 failed |
| Original subscriber-schema migration assertions | 2 passed |
| Concurrent vote test | 24 independent requests, 24 successful increments; total rose from 1 to 25 |
| Final WordPress debug log during test run | Only one WordPress core deprecation (`the_block_template_skip_link`) raised by calling `wp_footer()` inside WP-CLI; no theme warnings or fatals |

## Navigation behaviours verified (1.3.0)

- Seeding creates the three locations with exactly the spec items in spec order; re-running the seeder does not duplicate items.
- Header renders one list of seven items; 2027 is the only button; no dropdown markup.
- An editor can add an eighth item in the dashboard, and the rendered header still shows seven.
- The Customizer control removes 2027 from the nav entirely.
- With no menu assigned, the fallback renders the seven items exactly once (no duplication), in both header and footer.
- Deleting a spec item from a theme-owned menu and running the upgrade pass restores it in the correct position and records the spec version.
- Footer columns match the spec, Standards points at `/about/#standards`, and Corrections/Contact/Privacy appear only in the footer.
- Hamburger at 360px shows the same seven in the same order, opens/closes with Escape, no horizontal overflow.
- Search icon opens the panel, moves focus into the field, submits to a results page, closes on Escape; with JavaScript disabled the search box is visible and works.
- Breadcrumbs read `Home › Profiles › Story` on an article, `Home › Analysis` on a category, `Home › About` on a page; the front page has none; BreadcrumbList JSON-LD matches the visible trail; the filter suppresses the theme trail.
- All four block patterns register from their file headers, and the theme pattern category exists.

## Tested behaviours (1.2.1 scope, re-run against 1.3.0)

- Corrected theme activation and additive subscriber migration.
- Original-schema confirmed record retained and given an unsubscribe token when needed.
- Human/ISO date handling without the destructive global date filter.
- Strict poll index checks, missing/valid nonce checks, missing/closed/duplicate/rate-limited poll responses, Close/reopen behavior.
- Real browser REST/AJAX voting and native no-JavaScript POST voting both persist counts.
- Archive sidebar poll script loads and binds.
- Serialized concurrent voting across independent PHP processes.
- Newsletter shared service: enabled/disabled, valid/invalid nonce, email validation, resend limit, pending state, consent version, failed mail submission.
- Confirmation: wrong, valid, replayed and expired tokens.
- Unsubscribe: wrong token rejected; browser GET shows confirmation; POST deletes record.
- CSV streamed as a real download, beginning with CSV headers rather than dashboard HTML; only confirmed records; private unsubscribe URL per exported record.
- Spreadsheet-formula neutralization and unchanged normal email cells.
- Unauthenticated CSV access denied.
- Mobile navigation with JS on/off, opening/closing, Escape behavior.
- Main/header/footer sibling landmarks and no homepage horizontal overflow at 360px, 768px and 1440px.
- Homepage, article, page, search, county, leader, investigation, event, past-event and election views render.
- Leader page-2 link and response; county page-2 canonical preserved.
- Upcoming/ongoing versus past-event query behavior including missing/empty end dates.
- Cache namespace invalidation and private/no-store headers on interactive pages.

## Not certified by these tests

- Real email inbox delivery, SPF/DKIM/DMARC, campaign sending, or external subscriber-list synchronization.
- Production LiteSpeed, CDN, Redis, load balancer, database proxy, or multisite behavior.
- WordPress 6.0/PHP 7.4 minimum-version execution; this run used the versions above.
- All plugins, all browsers, complete WCAG conformance, security penetration testing, or legal compliance.
- A secure anonymous source-submission service (not part of the implementation).

Use a staging copy and the README's deployment checklist before updating the production site.
