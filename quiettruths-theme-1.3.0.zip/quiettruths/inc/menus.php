<?php
/**
 * Navigation and footer menus.
 *
 * The top navigation spec: seven flat items, in this order — five shelves
 * ranked by output share, then the 2027 election hub (the nav's only button),
 * then About. Corrections and Contact live in the footer only: Corrections in
 * the top nav reads as amateur, and omitting it hides accountability. Privacy
 * sits in the footer by legal convention.
 *
 * Everything here reads from one spec per location, so the dashboard menu, the
 * no-menu fallback and the footer columns cannot drift apart.
 *
 * @package QuietTruths
 * @since   1.3.0
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------------------
 * Specs — the single source of truth per location
 * ------------------------------------------------------------------------ */

/**
 * The top navigation specification.
 *
 * Seven items, flat, in this order: five shelves ranked by expected output
 * share, then the election hub, then About.
 *
 * Order is load-bearing — see quiettruths_nav_spec() callers.
 *
 * @since 1.2.0
 * @return array<int, array<string, mixed>> Ordered nav items.
 */
function quiettruths_nav_spec() {
	$items = array(
		array(
			'label' => __( 'Analysis', 'quiettruths' ),
			'type'  => 'category',
			'slug'  => 'analysis',
		),
		array(
			'label' => __( 'Profiles', 'quiettruths' ),
			'type'  => 'category',
			'slug'  => 'profiles',
		),
		array(
			'label' => __( 'Economy', 'quiettruths' ),
			'type'  => 'category',
			'slug'  => 'economy',
		),
		array(
			'label' => __( 'Explainers', 'quiettruths' ),
			'type'  => 'category',
			'slug'  => 'explainers',
		),
		array(
			'label' => __( 'Opinion', 'quiettruths' ),
			'type'  => 'category',
			'slug'  => 'opinion',
		),
		array(
			'label'  => __( '2027', 'quiettruths' ),
			'type'   => 'election',
			'is_cta' => true,
		),
		array(
			'label' => __( 'About', 'quiettruths' ),
			'type'  => 'page',
			'slug'  => 'about',
		),
	);

	/*
	 * The 2027 hub is time-sensitive. After August 2027 the election is over and
	 * the button should stop shouting, so it is demoted to a plain link. The
	 * Customizer lets an editor drop it from the nav entirely without a release.
	 */
	if ( time() >= strtotime( '2027-09-01 00:00:00' ) ) {
		foreach ( $items as $index => $item ) {
			if ( ! empty( $item['is_cta'] ) ) {
				$items[ $index ]['is_cta'] = false;
			}
		}
	}

	if ( ! get_theme_mod( 'qt_show_2027', true ) ) {
		$items = array_values(
			array_filter(
				$items,
				static function ( $item ) {
					return empty( $item['is_cta'] ) && 'election' !== $item['type'];
				}
			)
		);
	}

	/*
	 * Rule: never an eighth top-nav item. If something new wants in, something
	 * old drops to the footer. Enforced here so a well-meaning editor cannot
	 * quietly break the header on a phone. quiettruths_cap_primary_menu()
	 * enforces the same rule on menus built by hand.
	 */
	return apply_filters( 'quiettruths_nav_spec', array_slice( $items, 0, 7 ) );
}

/**
 * Footer "Sections" column: the five shelves plus the election hub.
 *
 * Derived from the nav spec so the two lists cannot disagree, with the election
 * hub spelled out in full because the footer has room for it.
 *
 * @since 1.3.0
 * @return array<int, array<string, mixed>> Ordered footer section items.
 */
function quiettruths_footer_sections_spec() {
	$items = array();

	// Only the five shelves belong here: not the 2027 hub (added below in full)
	// and not About, which is an outlet link rather than a section.
	foreach ( quiettruths_nav_spec() as $item ) {
		if ( 'category' !== $item['type'] ) {
			continue;
		}

		$items[] = $item;
	}

	$items[] = array(
		'label' => __( 'Election 2027', 'quiettruths' ),
		'type'  => 'election',
	);

	return apply_filters( 'quiettruths_footer_sections_spec', $items );
}

/**
 * Footer "Outlet" column: About, Standards, Corrections, Contact, Privacy.
 *
 * @since 1.3.0
 * @return array<int, array<string, mixed>> Ordered outlet items.
 */
function quiettruths_footer_outlet_spec() {
	$about   = quiettruths_page_url( 'about' );
	$items   = array(
		array(
			'label' => __( 'About', 'quiettruths' ),
			'type'  => 'page',
			'slug'  => 'about',
		),
		array(
			// An anchor inside About, not a separate page: standards are part of
			// the "who we are" story, and a dead anchor is worse than a section.
			'label'  => __( 'Standards', 'quiettruths' ),
			'type'   => 'custom',
			'url'    => $about . '#standards',
		),
		array(
			'label' => __( 'Corrections', 'quiettruths' ),
			'type'  => 'page',
			'slug'  => 'corrections',
		),
		array(
			'label' => __( 'Contact', 'quiettruths' ),
			'type'  => 'page',
			'slug'  => 'contact',
		),
		array(
			'label' => __( 'Privacy', 'quiettruths' ),
			'type'  => 'page',
			'slug'  => 'privacy',
		),
	);

	return apply_filters( 'quiettruths_footer_outlet_spec', $items );
}

/**
 * Registered menu locations, in dashboard order.
 *
 * @since 1.3.0
 * @return array<string, string> Location slug => description.
 */
function quiettruths_menu_locations() {
	return array(
		'primary'         => __( 'Primary menu (7 items, flat)', 'quiettruths' ),
		'footer_sections' => __( 'Footer — Sections column', 'quiettruths' ),
		'footer_outlet'   => __( 'Footer — Outlet column', 'quiettruths' ),
	);
}

/**
 * Spec for one location.
 *
 * @since 1.3.0
 * @param string $location Menu location.
 * @return array<int, array<string, mixed>> Ordered items.
 */
function quiettruths_menu_spec( $location ) {
	switch ( $location ) {
		case 'footer_sections':
			return quiettruths_footer_sections_spec();
		case 'footer_outlet':
			return quiettruths_footer_outlet_spec();
		case 'primary':
		default:
			return quiettruths_nav_spec();
	}
}

/**
 * Name used for the theme's own menu at a location.
 *
 * @since 1.3.0
 * @param string $location Menu location.
 * @return string Menu name.
 */
function quiettruths_menu_name( $location ) {
	$names = array(
		'primary'         => __( 'Quiet Truths primary', 'quiettruths' ),
		'footer_sections' => __( 'Quiet Truths footer sections', 'quiettruths' ),
		'footer_outlet'   => __( 'Quiet Truths footer outlet', 'quiettruths' ),
	);

	return isset( $names[ $location ] ) ? $names[ $location ] : $location;
}

/* ---------------------------------------------------------------------------
 * Spec -> menu item resolution
 * ------------------------------------------------------------------------ */

/**
 * Permalink for a core page, with a predictable path as fallback.
 *
 * @since 1.3.0
 * @param string $slug Page slug.
 * @return string URL.
 */
function quiettruths_page_url( $slug ) {
	$page = get_page_by_path( $slug );

	if ( $page && 'publish' === $page->post_status ) {
		return (string) get_permalink( $page );
	}

	return home_url( '/' . trim( $slug, '/' ) . '/' );
}

/**
 * Resolve one spec item into the URL that the no-menu fallback should print.
 *
 * @since 1.3.0
 * @param array<string, mixed> $item Spec item.
 * @return string URL.
 */
function quiettruths_menu_item_url( $item ) {
	if ( ! empty( $item['url'] ) ) {
		return (string) $item['url'];
	}

	switch ( isset( $item['type'] ) ? $item['type'] : 'custom' ) {
		case 'category':
			$category = get_category_by_slug( isset( $item['slug'] ) ? $item['slug'] : '' );

			if ( $category && ! is_wp_error( $category ) ) {
				$link = get_term_link( $category );

				return is_wp_error( $link ) ? home_url( '/' ) : $link;
			}

			return home_url( '/category/' . ( isset( $item['slug'] ) ? $item['slug'] : '' ) . '/' );

		case 'election':
			return quiettruths_election_url();

		case 'page':
			return quiettruths_page_url( isset( $item['slug'] ) ? $item['slug'] : '' );

		default:
			return home_url( '/' );
	}
}

/**
 * Arguments for wp_update_nav_menu_item() from one spec item.
 *
 * Categories and pages are attached as real objects rather than custom links so
 * WordPress's current-menu-item highlighting keeps working. Items that cannot be
 * resolved yet (a page an editor has not published) fall back to a custom link
 * pointing at the spec URL, so the nav never silently loses an entry.
 *
 * @since 1.3.0
 * @param array<string, mixed> $item Spec item.
 * @return array<string, mixed> Menu item arguments.
 */
function quiettruths_menu_item_args( $item ) {
	$label = isset( $item['label'] ) ? $item['label'] : '';
	$type  = isset( $item['type'] ) ? $item['type'] : 'custom';
	$slug  = isset( $item['slug'] ) ? $item['slug'] : '';

	if ( 'category' === $type ) {
		$category = get_category_by_slug( $slug );

		if ( $category && ! is_wp_error( $category ) ) {
			return array(
				'menu-item-title'     => $label,
				'menu-item-object'    => 'category',
				'menu-item-object-id' => (int) $category->term_id,
				'menu-item-type'      => 'taxonomy',
				'menu-item-status'    => 'publish',
			);
		}
	}

	if ( 'election' === $type || 'page' === $type ) {
		$page = 'election' === $type ? quiettruths_election_page() : get_page_by_path( $slug );

		if ( $page && 'publish' === $page->post_status ) {
			return array(
				'menu-item-title'     => $label,
				'menu-item-object'    => 'page',
				'menu-item-object-id' => (int) $page->ID,
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			);
		}
	}

	return array(
		'menu-item-title'  => $label,
		'menu-item-type'   => 'custom',
		'menu-item-url'    => quiettruths_menu_item_url( $item ),
		'menu-item-status' => 'publish',
	);
}

/* ---------------------------------------------------------------------------
 * Seeding and upgrades
 * ------------------------------------------------------------------------ */

/**
 * Build the three spec menus and assign them to any unassigned location.
 *
 * Never touches a location an editor has already assigned a menu to, so a
 * hand-built menu always wins. Runs on activation and again from
 * quiettruths_repair_menus() so an upgrade on an existing install picks up the
 * footer locations without a re-activation.
 *
 * @since 1.3.0
 */
function quiettruths_seed_menus() {
	foreach ( array_keys( quiettruths_menu_locations() ) as $location ) {
		if ( has_nav_menu( $location ) ) {
			continue;
		}

		$menu_id = quiettruths_ensure_spec_menu( $location );

		if ( ! $menu_id ) {
			continue;
		}

		quiettruths_sync_menu_items( $menu_id, $location );
		quiettruths_assign_menu_location( $location, $menu_id );
	}
}
add_action( 'after_switch_theme', 'quiettruths_seed_menus', 20 );

/**
 * Get or create the theme's menu for a location, remembering ownership.
 *
 * @since 1.3.0
 * @param string $location Menu location.
 * @return int Menu term ID, or 0 on failure.
 */
function quiettruths_ensure_spec_menu( $location ) {
	$name    = quiettruths_menu_name( $location );
	$owned   = (int) get_option( 'qt_owned_menu_' . $location, 0 );
	$existing = wp_get_nav_menu_object( $owned ? $owned : $name );

	if ( $existing && ! is_wp_error( $existing ) ) {
		$menu_id = (int) $existing->term_id;
	} else {
		$created = wp_create_nav_menu( $name );

		if ( is_wp_error( $created ) ) {
			return 0;
		}

		$menu_id = (int) $created;
	}

	update_option( 'qt_owned_menu_' . $location, $menu_id, false );

	return $menu_id;
}

/**
 * Assign a menu to a location without disturbing the other locations.
 *
 * @since 1.3.0
 * @param string $location Menu location.
 * @param int    $menu_id  Menu term ID.
 */
function quiettruths_assign_menu_location( $location, $menu_id ) {
	$locations = get_nav_menu_locations();

	if ( isset( $locations[ $location ] ) && (int) $locations[ $location ] === (int) $menu_id ) {
		return;
	}

	$locations[ $location ] = (int) $menu_id;

	set_theme_mod( 'nav_menu_locations', $locations );
}

/**
 * Make a menu's items match its spec: add what is missing, fix the order.
 *
 * Deliberately non-destructive. Extra items an editor added are kept (the
 * seven-item cap is enforced at render time, not by deleting their work), and
 * nothing is renamed except items whose spec label changed.
 *
 * @since 1.3.0
 * @param int    $menu_id  Menu term ID.
 * @param string $location Menu location.
 * @return int Number of spec items present afterwards.
 */
function quiettruths_sync_menu_items( $menu_id, $location ) {
	$existing = wp_get_nav_menu_items( $menu_id );
	$existing = is_array( $existing ) ? $existing : array();
	$used     = array();
	$position = 0;

	foreach ( quiettruths_menu_spec( $location ) as $spec_item ) {
		$args = quiettruths_menu_item_args( $spec_item );
		++$position;

		$match = quiettruths_find_menu_item( $existing, $args, $used );

		if ( $match ) {
			$used[] = (int) $match->ID;
			wp_update_nav_menu_item( $menu_id, (int) $match->ID, array_merge( $args, array( 'menu-item-position' => $position ) ) );
			continue;
		}

		wp_update_nav_menu_item( $menu_id, 0, array_merge( $args, array( 'menu-item-position' => $position ) ) );
	}

	return $position;
}

/**
 * Find an existing menu item that already represents a spec item.
 *
 * @since 1.3.0
 * @param array                $existing Existing menu items.
 * @param array<string, mixed> $args     Menu item arguments.
 * @param array<int, int>      $used     IDs already matched in this pass.
 * @return WP_Post|null Matching item.
 */
function quiettruths_find_menu_item( $existing, $args, $used ) {
	foreach ( $existing as $item ) {
		if ( in_array( (int) $item->ID, $used, true ) ) {
			continue;
		}

		if ( 'custom' === $args['menu-item-type'] ) {
			if ( 'custom' === $item->type && untrailingslashit( $item->url ) === untrailingslashit( $args['menu-item-url'] ) ) {
				return $item;
			}

			continue;
		}

		if (
			$item->type === $args['menu-item-type']
			&& $item->object === $args['menu-item-object']
			&& (int) $item->object_id === (int) $args['menu-item-object-id']
		) {
			return $item;
		}
	}

	return null;
}

/**
 * One-time upgrade pass for installs that already have the theme active.
 *
 * Adds the footer locations and restores any spec item missing from a menu the
 * theme created. Runs for administrators only and records the version so it does
 * not repeat on every dashboard request.
 *
 * @since 1.3.0
 */
function quiettruths_repair_menus() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( QUIETTRUTHS_MENU_VERSION === get_option( 'qt_menu_version' ) ) {
		return;
	}

	quiettruths_seed_menus();

	foreach ( array_keys( quiettruths_menu_locations() ) as $location ) {
		$menu_id = (int) get_option( 'qt_owned_menu_' . $location, 0 );

		if ( ! $menu_id ) {
			$named = wp_get_nav_menu_object( quiettruths_menu_name( $location ) );
			$menu_id = $named && ! is_wp_error( $named ) ? (int) $named->term_id : 0;

			if ( $menu_id ) {
				update_option( 'qt_owned_menu_' . $location, $menu_id, false );
			}
		}

		if ( $menu_id ) {
			quiettruths_sync_menu_items( $menu_id, $location );
		}
	}

	update_option( 'qt_menu_version', QUIETTRUTHS_MENU_VERSION, false );
}
add_action( 'admin_init', 'quiettruths_repair_menus' );

/**
 * Drop the theme's menus. Used by the test suite; safe to call from WP-CLI.
 *
 * @since 1.3.0
 */
function quiettruths_reset_menus() {
	foreach ( array_keys( quiettruths_menu_locations() ) as $location ) {
		$menu_id = (int) get_option( 'qt_owned_menu_' . $location, 0 );

		if ( $menu_id ) {
			wp_delete_nav_menu( $menu_id );
		}

		delete_option( 'qt_owned_menu_' . $location );
	}

	delete_option( 'qt_menu_version' );
	set_theme_mod( 'nav_menu_locations', array() );
}

/* ---------------------------------------------------------------------------
 * Rendering
 * ------------------------------------------------------------------------ */

/**
 * Fallback for any theme menu location.
 *
 * Renders the spec directly, so a fresh install with no menus assigned still
 * shows the correct items in the correct order. Echoes and returns, matching how
 * wp_nav_menu() uses a fallback callback (its return value replaces the menu).
 *
 * @since 1.0.0
 * @param array $args wp_nav_menu arguments.
 * @return string Menu markup.
 */
function quiettruths_menu_fallback( $args = array() ) {
	$args     = (array) $args;
	$location = isset( $args['theme_location'] ) ? (string) $args['theme_location'] : 'primary';
	$class    = isset( $args['menu_class'] ) ? (string) $args['menu_class'] : 'qt-menu';

	$out = '<ul class="' . esc_attr( $class ) . '">';

	foreach ( quiettruths_menu_spec( $location ) as $item ) {
		$is_cta = ! empty( $item['is_cta'] );
		$classes = array();

		if ( $is_cta ) {
			$classes[] = 'qt-menu__cta';
		}

		$out .= '<li' . ( $is_cta ? ' class="qt-menu__item--cta"' : '' ) . '>';
		$out .= '<a href="' . esc_url( quiettruths_menu_item_url( $item ) ) . '"'
			. ( $classes ? ' class="' . esc_attr( implode( ' ', $classes ) ) . '"' : '' ) . '>'
			. esc_html( isset( $item['label'] ) ? $item['label'] : '' ) . '</a>';
		$out .= '</li>';
	}

	$out .= '</ul>';

	if ( ! isset( $args['echo'] ) || $args['echo'] ) {
		echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
	}

	return $out;
}

/**
 * Backwards-compatible alias for the primary-location fallback.
 *
 * @since 1.0.0
 * @param array $args wp_nav_menu arguments.
 * @return string Menu markup.
 */
function quiettruths_primary_menu_fallback( $args = array() ) {
	$args                    = (array) $args;
	$args['theme_location']  = isset( $args['theme_location'] ) ? $args['theme_location'] : 'primary';

	return quiettruths_menu_fallback( $args );
}

/**
 * Mark the 2027 item as the nav's only button.
 *
 * Applies to a menu the editor built in the dashboard, not just the fallback, so
 * the button survives being managed by hand. Matched on URL rather than label so
 * renaming the item does not silently lose the styling — and scoped so no other
 * item can ever pick up the class.
 *
 * @since 1.2.0
 * @param array   $classes Existing CSS classes.
 * @param WP_Post $item    Menu item.
 * @return array Filtered classes.
 */
function quiettruths_nav_item_classes( $classes, $item ) {
	if ( empty( $item->url ) ) {
		return $classes;
	}

	if ( quiettruths_is_election_url( $item->url ) && time() < strtotime( '2027-09-01 00:00:00' ) ) {
		$classes[] = 'qt-menu__item--cta';
	}

	return $classes;
}
add_filter( 'nav_menu_css_class', 'quiettruths_nav_item_classes', 10, 2 );

/**
 * Add the button class to the 2027 anchor itself.
 *
 * @since 1.2.0
 * @param array   $atts HTML attributes.
 * @param WP_Post $item Menu item.
 * @return array Filtered attributes.
 */
function quiettruths_nav_item_attrs( $atts, $item ) {
	if ( empty( $item->url ) ) {
		return $atts;
	}

	if ( quiettruths_is_election_url( $item->url ) && time() < strtotime( '2027-09-01 00:00:00' ) ) {
		$existing      = isset( $atts['class'] ) ? (string) $atts['class'] : '';
		$atts['class'] = trim( $existing . ' qt-menu__cta' );
	}

	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'quiettruths_nav_item_attrs', 10, 2 );

/**
 * Hard cap the primary menu at seven items.
 *
 * The spec is explicit: never an eighth. Anything past seven is dropped from the
 * header rather than wrapped onto a second row on a phone. The editor still sees
 * the item in the dashboard — it simply does not render — so nothing is silently
 * deleted from their menu.
 *
 * Scoped to the primary location, and also applies the 2027 visibility rules so
 * a hand-built menu obeys the same time-based demotion as the spec.
 *
 * @since 1.2.0
 * @param array $items Menu items.
 * @param mixed $args  wp_nav_menu arguments (object or array).
 * @return array Capped items.
 */
function quiettruths_cap_primary_menu( $items, $args = array() ) {
	if ( ! is_array( $items ) ) {
		return $items;
	}

	$args     = (array) $args;
	$location = isset( $args['theme_location'] ) ? (string) $args['theme_location'] : '';

	if ( 'primary' !== $location ) {
		return $items;
	}

	$keep_2027 = (bool) get_theme_mod( 'qt_show_2027', true );

	$items = array_values(
		array_filter(
			$items,
			static function ( $item ) use ( $keep_2027 ) {
				if ( ! empty( $item->menu_item_parent ) ) {
					return false;
				}

				return $keep_2027 || ! quiettruths_is_election_url( $item->url );
			}
		)
	);

	if ( count( $items ) <= 7 ) {
		return $items;
	}

	return array_slice( $items, 0, 7 );
}
add_filter( 'wp_nav_menu_objects', 'quiettruths_cap_primary_menu', 10, 2 );

/**
 * Convenience wrapper used by the templates.
 *
 * @since 1.3.0
 * @param string $location Menu location.
 * @param array  $args     Optional. Extra wp_nav_menu arguments.
 * @return void
 */
function quiettruths_nav_menu( $location, $args = array() ) {
	$defaults = array(
		'theme_location' => $location,
		'container'      => false,
		'menu_class'     => 'qt-menu',
		'fallback_cb'    => 'quiettruths_menu_fallback',
		'depth'          => 1,
		'echo'           => true,
	);

	if ( 'primary' === $location ) {
		$defaults['items_wrap'] = '<ul id="%1$s" class="%2$s">%3$s</ul>';
	}

	wp_nav_menu( array_merge( $defaults, (array) $args ) );
}
