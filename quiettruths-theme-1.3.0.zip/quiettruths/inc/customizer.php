<?php
/**
 * Customizer panels and controls.
 *
 * Everything an editor needs to run the masthead — brand colours, the breaking
 * ticker, the tip line, social accounts — lives here rather than in code, so a
 * non-developer can maintain the site.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register Customizer settings and controls.
 *
 * @since 1.0.0
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function quiettruths_customize_register( $wp_customize ) {

	/* ------------------------------------------------------------------
	 * Section: Quiet Truths brand
	 * --------------------------------------------------------------- */
	$wp_customize->add_section( 'qt_brand', array(
		'title'    => __( 'Quiet Truths brand', 'quiettruths' ),
		'priority' => 25,
	) );

	$wp_customize->add_setting( 'qt_tagline', array(
		'default'           => __( 'Five counties, covered properly', 'quiettruths' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );

	$wp_customize->add_control( 'qt_tagline', array(
		'label'   => __( 'Masthead tagline', 'quiettruths' ),
		'section' => 'qt_brand',
		'type'    => 'text',
	) );

	$color_defaults = array(
		'qt_color_primary' => array( '#0B3B2E', __( 'Primary (masthead)', 'quiettruths' ) ),
		'qt_color_accent'  => array( '#C8A34B', __( 'Accent (rules, links on dark)', 'quiettruths' ) ),
		'qt_color_ink'     => array( '#16181C', __( 'Body text', 'quiettruths' ) ),
	);

	foreach ( $color_defaults as $key => $config ) {
		$wp_customize->add_setting( $key, array(
			'default'           => $config[0],
			'sanitize_callback' => 'quiettruths_sanitize_hex_cb',
			'transport'         => 'refresh',
		) );

		$wp_customize->add_control(
			new WP_Customize_Color_Control( $wp_customize, $key, array(
				'label'   => $config[1],
				'section' => 'qt_brand',
			) )
		);
	}

	$wp_customize->add_setting( 'qt_dark_default', array(
		'default'           => false,
		'sanitize_callback' => 'quiettruths_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'qt_dark_default', array(
		'label'       => __( 'Start readers in dark mode', 'quiettruths' ),
		'description' => __( 'Readers can still switch back. Respects prefers-color-scheme when off.', 'quiettruths' ),
		'section'     => 'qt_brand',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'qt_webfonts', array(
		'default'           => false,
		'sanitize_callback' => 'quiettruths_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'qt_webfonts', array(
		'label'       => __( 'Load Google Fonts', 'quiettruths' ),
		'description' => __( 'Off by default so the site works with no external requests. Turn on for Source Serif 4 + Inter.', 'quiettruths' ),
		'section'     => 'qt_brand',
		'type'        => 'checkbox',
	) );

	/* ------------------------------------------------------------------
	 * Section: Breaking news ticker
	 * --------------------------------------------------------------- */
	$wp_customize->add_section( 'qt_breaking', array(
		'title'    => __( 'Breaking news ticker', 'quiettruths' ),
		'priority' => 26,
	) );

	$wp_customize->add_setting( 'qt_breaking_enable', array(
		'default'           => false,
		'sanitize_callback' => 'quiettruths_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'qt_breaking_enable', array(
		'label'   => __( 'Show the breaking strip', 'quiettruths' ),
		'section' => 'qt_breaking',
		'type'    => 'checkbox',
	) );

	$wp_customize->add_setting( 'qt_breaking_label', array(
		'default'           => __( 'Breaking', 'quiettruths' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( 'qt_breaking_label', array(
		'label'   => __( 'Strip label', 'quiettruths' ),
		'section' => 'qt_breaking',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'qt_breaking_items', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( 'qt_breaking_items', array(
		'label'       => __( 'Headlines', 'quiettruths' ),
		'description' => __( 'Separate items with a pipe ( | ). To link one, write: Headline :: https://url', 'quiettruths' ),
		'section'     => 'qt_breaking',
		'type'        => 'textarea',
	) );

	/* ------------------------------------------------------------------
	 * Section: Contact and tip line
	 * --------------------------------------------------------------- */
	$wp_customize->add_section( 'qt_contact', array(
		'title'    => __( 'Contact & tip line', 'quiettruths' ),
		'priority' => 27,
	) );

	$contact_fields = array(
		'qt_tip_email'   => array( 'tips@quiettruths.co.ke', __( 'Tip contact email', 'quiettruths' ), 'email' ),
		'qt_news_email'  => array( 'news@quiettruths.co.ke', __( 'Newsroom email', 'quiettruths' ), 'email' ),
		'qt_corrections_email' => array( 'corrections@quiettruths.co.ke', __( 'Corrections email', 'quiettruths' ), 'email' ),
		'qt_phone'       => array( '', __( 'Newsroom phone', 'quiettruths' ), 'text' ),
		'qt_whatsapp'    => array( '', __( 'WhatsApp tip line (full URL)', 'quiettruths' ), 'url' ),
		'qt_address'     => array( '', __( 'Postal / street address', 'quiettruths' ), 'textarea' ),
	);

	foreach ( $contact_fields as $key => $config ) {
		$callback = 'sanitize_text_field';

		if ( 'email' === $config[2] ) {
			$callback = 'sanitize_email';
		} elseif ( 'url' === $config[2] ) {
			$callback = 'esc_url_raw';
		}

		$wp_customize->add_setting( $key, array(
			'default'           => $config[0],
			'sanitize_callback' => $callback,
		) );

		$wp_customize->add_control( $key, array(
			'label'   => $config[1],
			'section' => 'qt_contact',
			'type'    => $config[2],
		) );
	}

	/* ------------------------------------------------------------------
	 * Section: Social accounts
	 * --------------------------------------------------------------- */
	$wp_customize->add_section( 'qt_social', array(
		'title'    => __( 'Social accounts', 'quiettruths' ),
		'priority' => 28,
	) );

	$social_fields = array(
		'qt_x'        => __( 'X (Twitter) profile URL', 'quiettruths' ),
		'qt_facebook' => __( 'Facebook page URL', 'quiettruths' ),
		'qt_youtube'  => __( 'YouTube channel URL', 'quiettruths' ),
		'qt_tiktok'   => __( 'TikTok profile URL', 'quiettruths' ),
	);

	foreach ( $social_fields as $key => $label ) {
		$wp_customize->add_setting( $key, array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );

		$wp_customize->add_control( $key, array(
			'label'   => $label,
			'section' => 'qt_social',
			'type'    => 'url',
		) );
	}

	/* ------------------------------------------------------------------
	 * Section: Navigation
	 * --------------------------------------------------------------- */
	$wp_customize->add_section( 'qt_navigation', array(
		'title'       => __( 'Navigation', 'quiettruths' ),
		'description' => __( 'The top nav is fixed at seven items: five shelves, the 2027 hub, then About. Nothing else goes in it.', 'quiettruths' ),
		'priority'    => 26,
	) );

	$wp_customize->add_setting( 'qt_show_2027', array(
		'default'           => true,
		'sanitize_callback' => 'quiettruths_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'qt_show_2027', array(
		'label'       => __( 'Show the 2027 button in the nav', 'quiettruths' ),
		'description' => __( 'It demotes itself to a plain link after August 2027. Switch this off to drop it from the nav entirely once the election is settled.', 'quiettruths' ),
		'section'     => 'qt_navigation',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'qt_breadcrumbs', array(
		'default'           => true,
		'sanitize_callback' => 'quiettruths_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'qt_breadcrumbs', array(
		'label'       => __( 'Show breadcrumbs (Home > Section > Story)', 'quiettruths' ),
		'description' => __( 'Switch this off if Rank Math, Yoast or another plugin is already printing a trail, so the reader never sees two.', 'quiettruths' ),
		'section'     => 'qt_navigation',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'qt_footer_domain', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( 'qt_footer_domain', array(
		'label'       => __( 'Footer domain', 'quiettruths' ),
		'description' => __( 'Shown in the bottom bar. Leave blank to use this site\'s own domain.', 'quiettruths' ),
		'section'     => 'qt_navigation',
		'type'        => 'text',
	) );

	/* ------------------------------------------------------------------
	 * Section: Newsletter
	 *
	 * Deliberately off by default. Turning signups on is an editorial decision
	 * that depends on whether there is anything to send yet.
	 * --------------------------------------------------------------- */
	$wp_customize->add_section( 'qt_newsletter', array(
		'title'    => __( 'Newsletter', 'quiettruths' ),
		'priority' => 29,
	) );

	$wp_customize->add_setting( 'qt_newsletter_enable', array(
		'default'           => false,
		'sanitize_callback' => 'quiettruths_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'qt_newsletter_enable', array(
		'label'       => __( 'Open newsletter signups', 'quiettruths' ),
		'description' => __( 'Off until you switch it on. A newsletter is a second publication — do not collect addresses before you have two or three issues ready to send.', 'quiettruths' ),
		'section'     => 'qt_newsletter',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'qt_newsletter_pitch', array(
		'default'           => __( 'County budgets, tender notices, and what your leaders did — not what they said.', 'quiettruths' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( 'qt_newsletter_pitch', array(
		'label'       => __( 'Signup pitch', 'quiettruths' ),
		'description' => __( 'Do not promise a frequency until you can keep it.', 'quiettruths' ),
		'section'     => 'qt_newsletter',
		'type'        => 'textarea',
	) );

	/* ------------------------------------------------------------------
	 * Section: Layout
	 * --------------------------------------------------------------- */
	$wp_customize->add_section( 'qt_layout', array(
		'title'    => __( 'Quiet Truths layout', 'quiettruths' ),
		'priority' => 30,
	) );

	$wp_customize->add_setting( 'qt_posts_per_page', array(
		'default'           => 10,
		'sanitize_callback' => 'absint',
	) );

	$wp_customize->add_control( 'qt_posts_per_page', array(
		'label'       => __( 'Posts per archive page', 'quiettruths' ),
		'section'     => 'qt_layout',
		'type'        => 'number',
		'input_attrs' => array(
			'min'  => 4,
			'max'  => 40,
			'step' => 1,
		),
	) );

	$wp_customize->add_setting( 'qt_footer_note', array(
		'default'           => '',
		'sanitize_callback' => 'wp_kses_post',
	) );

	$wp_customize->add_control( 'qt_footer_note', array(
		'label'       => __( 'Footer note', 'quiettruths' ),
		'description' => __( 'Shown above the copyright line. Basic formatting allowed.', 'quiettruths' ),
		'section'     => 'qt_layout',
		'type'        => 'textarea',
	) );

	$wp_customize->add_setting( 'qt_corrections_url', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	) );

	$wp_customize->add_control( 'qt_corrections_url', array(
		'label'       => __( 'Corrections policy page URL', 'quiettruths' ),
		'description' => __( 'Linked in the footer. An accountability site should make its corrections policy one click away.', 'quiettruths' ),
		'section'     => 'qt_layout',
		'type'        => 'url',
	) );
}
add_action( 'customize_register', 'quiettruths_customize_register' );

/**
 * Sanitize callback for colour controls.
 *
 * @since 1.0.0
 * @param string $color Candidate colour.
 * @return string Valid hex colour.
 */
function quiettruths_sanitize_hex_cb( $color ) {
	return quiettruths_sanitize_hex( $color, '#000000' );
}

/**
 * Sanitize callback for checkbox controls.
 *
 * @since 1.0.0
 * @param mixed $value Candidate value.
 * @return bool Sanitized boolean.
 */
function quiettruths_sanitize_checkbox( $value ) {
	return (bool) $value;
}
