# Quiet Truths — WordPress theme

A custom, from-scratch WordPress theme for **quiettruths.co.ke**, an independent
politics, governance and accountability publication covering five counties:
Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.

Built for the hosting you actually have: LiteSpeed shared hosting on cPanel. No
build step, no Node on the server, no required plugins.

---

## What is in the box

### Scope: five counties

**Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.** Four counties of the former
Western Province, plus Trans Nzoia — which sat in the former Rift Valley Province
but is Western Kenya by economy, politics and electorate.

The six former Nyanza counties are deliberately out of scope. Five counties
covered properly beats ten covered thinly, particularly with an election eleven
months away.

### Coverage architecture

The county is the primary organising unit, not the category.

| Thing | Type | URL |
|---|---|---|
| Counties (5) | taxonomy `qt_county` | `/county/trans-nzoia/` |
| Topics | taxonomy `qt_topic` | `/topic/elections-2027/` |
| Investigations | CPT `qt_investigation` | `/investigations/` |
| Leaders directory | CPT `qt_leader` | `/leaders/` |
| Barazas & events | CPT `qt_event` | `/barazas/` |

County term slugs are the plain county slug, so the county name is in the URL.
A card whose archive does not exist yet renders unlinked rather than pointing
somewhere misleading.

Each county archive carries its own data panel: KNBS population, land area,
density, constituency count, capital, governor and party, plus the standing
issues the desk watches and the leaders profiled for that county.

### Navigation

Seven items, flat, no dropdowns. The order is load-bearing: shelves first ranked
by output share, then the election hub, then About — outlet info sits at the right
end by convention.

| # | Label | Goes to |
|---|---|---|
| 1 | Analysis | `/category/analysis/` |
| 2 | Profiles | `/category/profiles/` |
| 3 | Economy | `/category/economy/` |
| 4 | Explainers | `/category/explainers/` |
| 5 | Opinion | `/category/opinion/` |
| 6 | **2027** | `/2027/` — accent button |
| 7 | About | `/about/` |

The hamburger shows the same seven in the same order. The header carries a search
icon.

**Three rules the theme enforces:**

1. **2027 is the only button.** Applied by URL path, not by label, so renaming
   the item does not lose the styling. It demotes itself to a plain link after
   August 2027, and a Customizer switch drops it from the nav entirely.
2. **Never an eighth item.** `wp_nav_menu_objects` caps the primary location at
   seven. The extra item stays visible in the dashboard — it simply does not
   render — so nothing is silently deleted.
3. **Breadcrumbs on**, rendered `Home › Profiles › Name`.

Corrections and Contact are **footer only**. The footer is three fixed columns —
Brand, Sections, Outlet — plus a bottom bar. It is not widgetised, because the
outlet column is not something an editor should be able to delete by dragging.

### Seeded on activation

- **Pages:** About (with an `#standards` section), Contact, Corrections, Privacy,
  and the `/2027/` election hub — all with real, editable content.
- **Categories:** Analysis, Profiles, Economy, Explainers, Opinion, Election 2027.
- **Terms:** the five counties and eight subject topics.
- **Primary menu:** the seven items above. Only created when nothing is assigned
  to the primary location.

### Features

- **Investigations desk** — separate post type with its own dark masthead,
  a "how we reported this" method block and a tip line on every page.
- **Leaders directory** — searchable profiles with office, county, party,
  tenure and public contact, plus automatic "our coverage of this leader".
- **Barazas & events** — upcoming-first ordering, venue, host, map link.
- **Reader polls** — one live poll at a time, REST-backed voting, cookie plus
  IP rate limiting, admin UI under *Tools → Polls*. No plugin needed.
- **Newsletter capture** — custom table, double opt-in, honeypot, IP throttle,
  paginated admin list, CSV export and per-subscriber deletion under
  *Tools → Subscribers*. **Off by default**: a newsletter is a second
  publication, and collecting addresses before two or three issues exist means
  the first subscriber's first experience is silence.
- **Secure tip line** — nonce-stamped mailto links, WhatsApp channel, source
  safety guidance. Appears in the footer, sidebar and after every investigation.
- **Dark mode** — respects `prefers-color-scheme`, remembers an explicit choice,
  works before any JavaScript runs.
- **No-JavaScript fallbacks** — menus, newsletter signup and reading all work
  with JS disabled. Signups post to `admin-post.php` and redirect back.
- **SEO** — `NewsArticle` / `ReportageNewsArticle` JSON-LD, `AdministrativeArea`
  schema on county archives, Open Graph and Twitter cards, corrected canonicals
  on paginated archives.
- **Block patterns** — lead story, county spotlight, pull quote, tip line.
- **Widgets** — County Index, Investigations Desk, Reader Poll, plus four
  widget areas.
- **Customizer** — brand colours, tagline, breaking ticker, tip and newsroom
  contacts, social accounts, posts per page, footer note, corrections URL.

---

## Install

1. Zip the `quiettruths` folder (the folder itself, not its parent).
2. WordPress admin → *Appearance → Themes → Add New → Upload Theme*.
3. Activate. On activation the theme creates the subscriber table and seeds the
   ten county terms and the default topic terms.
4. Go to *Settings → Permalinks* and save once. This flushes rewrite rules so
   `/county/…`, `/investigations/`, `/leaders/` and `/barazas/` resolve.
5. Assign menus under *Appearance → Menus*. Until you do, the theme renders
   sensible fallbacks, so nothing looks broken.

**Requires:** WordPress 6.0+, PHP 7.4+. Tested against WordPress 7.1.1.

---

## File map

```
quiettruths/
├── style.css                     Theme manifest (header only)
├── functions.php                 Bootstrap: constants + module loader
├── inc/
│   ├── data.php                  The ten-county dataset + provenance notes
│   ├── helpers.php               Template helpers + menu fallbacks
│   ├── setup.php                 Theme support, assets, menus, image sizes
│   ├── content-types.php         CPTs, taxonomies, metaboxes, term seeding
│   ├── customizer.php            Brand, ticker, contacts, social, layout
│   ├── widgets.php               Sidebars + 3 theme widgets
│   ├── newsletter.php            Subscriber table, double opt-in, CSV export
│   ├── polls.php                 Poll store, REST endpoint, admin UI
│   ├── seo.php                   JSON-LD, Open Graph, canonicals
│   └── performance.php           LiteSpeed tuning, caching, query caps
├── assets/
│   ├── css/main.css              Full design system (no build step)
│   ├── css/editor.css            Block editor parity
│   ├── js/main.js                Menu, dark mode, newsletter AJAX
│   └── js/polls.js               Poll voting
├── patterns/                     4 block patterns
├── template-parts/               Cards, leader cards, archive head, tip CTA
└── tools/                        Lint harness (dev only, not needed in production)
```

---

## Maintaining the county data

Population, land area and density come from the **2019 KNBS census** and should
only change after the 2029 census or an official revision.

Governors, deputies and parties **change**. Do not edit templates. Either:

- update `inc/data.php` in a child theme, or
- filter at runtime:

```php
add_filter( 'quiettruths_counties', function ( $counties ) {
    $counties['bungoma']['governor'] = 'New Governor';
    $counties['bungoma']['party']    = 'New Party';
    return $counties;
} );
```

---

## Legal notes for the editor

- **Data Protection Act 2019.** The subscriber list records consent and a
  timestamp, uses double opt-in, and can export or delete a subscriber. Do not
  send to unconfirmed addresses.
- **Source protection.** The tip line never logs a sender's identity, and the
  only IP handling in the theme is a salted hash held in a short-lived transient
  for rate limiting.
- **Corrections.** Set the corrections policy URL in *Customize → Quiet Truths
  layout*. It appears in the footer and on every article.

---

## Development

The theme ships with its own lint harness under `tools/`. It needs any PHP 8.x
CLI and network access on first run:

```bash
php tools/build-symbols.php   # downloads WP core, indexes its real API
php tools/lint.php            # checks every theme file against it
```

`tools/lint.php` uses the tokenizer, not regex. It reports calls to functions
that do not exist in WordPress or PHP, wrong text domains in translation calls,
superglobal reads that skip `wp_unslash()`, and PHP 8-only syntax that would
break the declared PHP 7.4 floor.

`tools/` is not needed in production and can be deleted before uploading.
