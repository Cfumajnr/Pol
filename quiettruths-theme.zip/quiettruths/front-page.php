<?php
/**
 * The front page.
 *
 * Structure, top to bottom:
 *   1. Lead story with two supporting pieces
 *   2. The ten-county navigation grid (the site's signature block)
 *   3. Investigations desk
 *   4. Latest news with a right-hand rail
 *   5. Opinion
 *   6. Upcoming barazas
 *
 * Every secondary loop goes through quiettruths_cached_query() so a cache miss
 * still costs a handful of queries rather than dozens.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

$qt_lead = quiettruths_cached_query( 'lead', array(
	'post_type'           => 'post',
	'posts_per_page'      => 3,
	'ignore_sticky_posts' => false,
	'no_found_rows'       => true,
) );

$qt_investigations = quiettruths_cached_query( 'investigations', array(
	'post_type'      => 'qt_investigation',
	'posts_per_page' => 3,
	'no_found_rows'  => true,
) );

$qt_latest = quiettruths_cached_query( 'latest', array(
	'post_type'           => 'post',
	'posts_per_page'      => 8,
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
) );

$qt_opinion = quiettruths_cached_query( 'opinion', array(
	'post_type'      => 'post',
	'posts_per_page' => 4,
	'no_found_rows'  => true,
	'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		array(
			'taxonomy' => 'qt_topic',
			'field'    => 'slug',
			'terms'    => array( 'opinion' ),
		),
	),
) );

$qt_events = quiettruths_cached_query( 'events', array(
	'post_type'      => 'qt_event',
	'posts_per_page' => 3,
	'no_found_rows'  => true,
	'meta_key'       => '_qt_event_start', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
	'orderby'        => 'meta_value',
	'order'          => 'ASC',
) );
?>

<div class="qt-home">

	<?php if ( $qt_lead->have_posts() ) : ?>
		<?php
		$qt_lead->the_post();
		$qt_lead_class = has_post_thumbnail() ? 'qt-hero qt-hero--media' : 'qt-hero';
		?>
		<section class="<?php echo esc_attr( $qt_lead_class ); ?>" aria-label="<?php esc_attr_e( 'Lead story', 'quiettruths' ); ?>">
			<a class="qt-hero__link" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
				<?php if ( has_post_thumbnail() ) {
					the_post_thumbnail( 'qt-lead', array( 'class' => 'qt-hero__media' ) );
				} ?>
			</a>

			<div class="qt-hero__body">
				<?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 2 ); ?>
				<h1 class="qt-hero__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
				<p class="qt-hero__excerpt"><?php quiettruths_the_excerpt( 34 ); ?></p>
				<?php quiettruths_the_meta(); ?>
			</div>

			<?php
			$qt_support = 0;
			while ( $qt_lead->have_posts() && $qt_support < 2 ) :
				$qt_lead->the_post();
				$qt_support++;
				?>
				<article class="qt-hero__support">
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="qt-hero__support-media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
							<?php the_post_thumbnail( 'qt-thumb' ); ?>
						</a>
					<?php endif; ?>
					<div>
						<?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 1 ); ?>
						<h2 class="qt-hero__support-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<?php quiettruths_the_meta( get_the_ID(), false ); ?>
					</div>
				</article>
			<?php endwhile; ?>
		</section>
		<?php wp_reset_postdata(); ?>
	<?php else : ?>
		<section class="qt-hero qt-hero--empty">
			<div class="qt-hero__body">
				<h1 class="qt-hero__title"><?php bloginfo( 'name' ); ?></h1>
				<p class="qt-hero__excerpt"><?php esc_html_e( 'Independent reporting from Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.', 'quiettruths' ); ?></p>
			</div>
		</section>
	<?php endif; ?>

	<?php quiettruths_county_grid( true ); ?>

	<?php if ( $qt_investigations->have_posts() ) : ?>
		<section class="qt-desk" aria-labelledby="qt-desk-title">
			<header class="qt-section-head qt-section-head--dark">
				<h2 id="qt-desk-title"><?php esc_html_e( 'The Investigations Desk', 'quiettruths' ); ?></h2>
				<p><?php esc_html_e( 'Documents, data and the questions nobody in the county assembly wants asked.', 'quiettruths' ); ?></p>
				<a class="qt-section-head__more" href="<?php echo esc_url( get_post_type_archive_link( 'qt_investigation' ) ); ?>"><?php esc_html_e( 'All investigations', 'quiettruths' ); ?> &rarr;</a>
			</header>

			<div class="qt-desk__grid">
				<?php
				while ( $qt_investigations->have_posts() ) :
					$qt_investigations->the_post();
					get_template_part( 'template-parts/content/card', 'investigation' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<?php quiettruths_tip_cta(); ?>
		</section>
	<?php endif; ?>

	<div class="qt-home__split">
		<div class="qt-home__primary">
			<?php if ( $qt_latest->have_posts() ) : ?>
				<section class="qt-stream" aria-labelledby="qt-stream-title">
					<header class="qt-section-head">
						<h2 id="qt-stream-title"><?php esc_html_e( 'Latest', 'quiettruths' ); ?></h2>
					</header>

					<div class="qt-stream__list">
						<?php
						while ( $qt_latest->have_posts() ) :
							$qt_latest->the_post();
							get_template_part( 'template-parts/content/card', 'list' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
			<?php endif; ?>

			<?php if ( $qt_opinion->have_posts() ) : ?>
				<section class="qt-opinion" aria-labelledby="qt-opinion-title">
					<header class="qt-section-head">
						<h2 id="qt-opinion-title"><?php esc_html_e( 'Opinion', 'quiettruths' ); ?></h2>
						<p><?php esc_html_e( 'Argument from the region, not about it.', 'quiettruths' ); ?></p>
					</header>

					<div class="qt-opinion__grid">
						<?php
						while ( $qt_opinion->have_posts() ) :
							$qt_opinion->the_post();
							get_template_part( 'template-parts/content/card', 'compact' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
			<?php endif; ?>

			<?php if ( $qt_events->have_posts() ) : ?>
				<section class="qt-events" aria-labelledby="qt-events-title">
					<header class="qt-section-head">
						<h2 id="qt-events-title"><?php esc_html_e( 'Barazas &amp; events', 'quiettruths' ); ?></h2>
						<a class="qt-section-head__more" href="<?php echo esc_url( get_post_type_archive_link( 'qt_event' ) ); ?>"><?php esc_html_e( 'Full calendar', 'quiettruths' ); ?> &rarr;</a>
					</header>

					<ul class="qt-events__list">
						<?php
						while ( $qt_events->have_posts() ) :
							$qt_events->the_post();
							?>
							<li class="qt-event <?php echo quiettruths_event_is_upcoming() ? '' : 'qt-event--past'; ?>">
								<span class="qt-event__date"><?php quiettruths_the_event_date(); ?></span>
								<span class="qt-event__body">
									<a class="qt-event__title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									<?php
									$qt_venue = get_post_meta( get_the_ID(), '_qt_event_venue', true );
									$qt_host  = get_post_meta( get_the_ID(), '_qt_event_host', true );

									if ( $qt_venue || $qt_host ) :
										?>
										<span class="qt-event__where">
											<?php echo esc_html( trim( $qt_venue . ( $qt_venue && $qt_host ? ' · ' : '' ) . $qt_host ) ); ?>
										</span>
									<?php endif; ?>
								</span>
							</li>
						<?php
						endwhile;
						wp_reset_postdata();
						?>
					</ul>
				</section>
			<?php endif; ?>
		</div>

		<aside class="qt-home__rail" aria-label="<?php esc_attr_e( 'Sidebar', 'quiettruths' ); ?>">
			<?php
			$qt_active_poll = quiettruths_get_active_poll();

			if ( $qt_active_poll ) :
				?>
				<section class="qt-widget">
					<h2 class="qt-widget__title"><?php esc_html_e( 'Your view', 'quiettruths' ); ?></h2>
					<?php quiettruths_render_poll( $qt_active_poll ); ?>
				</section>
			<?php endif; ?>

			<?php if ( is_active_sidebar( 'sidebar-home' ) ) : ?>
				<?php dynamic_sidebar( 'sidebar-home' ); ?>
			<?php else : ?>
				<section class="qt-widget">
					<h2 class="qt-widget__title"><?php esc_html_e( 'The weekly briefing', 'quiettruths' ); ?></h2>
					<?php quiettruths_newsletter_form( 'home-rail' ); ?>
				</section>
			<?php endif; ?>

			<?php quiettruths_tip_cta(); ?>
		</aside>
	</div>

</div>

<?php
get_footer();
