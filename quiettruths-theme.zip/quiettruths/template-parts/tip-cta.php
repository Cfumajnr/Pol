<?php
/**
 * Secure tip line call to action.
 *
 * The single most important conversion on an accountability site. Placed at the
 * end of investigations, in the sidebar and in the footer.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

$qt_whatsapp = get_theme_mod( 'qt_whatsapp', '' );
$qt_tip_mail = get_theme_mod( 'qt_tip_email', 'tips@quiettruths.co.ke' );
?>
<section class="qt-tip" aria-labelledby="qt-tip-title">
	<h2 id="qt-tip-title"><?php esc_html_e( 'Have a document? Tell us.', 'quiettruths' ); ?></h2>

	<p><?php esc_html_e( 'Tender awards, audit queries, land titles, payroll lists, a memo someone hoped you would not read. Send it and we will treat your identity as the most important fact in the story.', 'quiettruths' ); ?></p>

	<ul class="qt-tip__channels">
		<li>
			<a class="qt-btn qt-btn--accent" href="<?php echo esc_url( quiettruths_tip_url() ); ?>">
				<?php echo esc_html( $qt_tip_mail ? $qt_tip_mail : __( 'Email the desk', 'quiettruths' ) ); ?>
			</a>
		</li>

		<?php if ( $qt_whatsapp ) : ?>
			<li>
				<a class="qt-btn qt-btn--ghost" href="<?php echo esc_url( $qt_whatsapp ); ?>" rel="noopener" target="_blank">
					<?php esc_html_e( 'WhatsApp the desk', 'quiettruths' ); ?>
				</a>
			</li>
		<?php endif; ?>
	</ul>

	<p class="qt-tip__note"><?php esc_html_e( 'Use a personal device and a personal email address, not one issued by your employer. Do not send documents from a work computer.', 'quiettruths' ); ?></p>
</section>
