/**
 * Quiet Truths — front-end behaviour.
 *
 * Plain ES5-compatible JavaScript, no framework and no build step. Three
 * responsibilities: the mobile menu, the colour-scheme switch, and progressive
 * enhancement of the newsletter form. Everything degrades to a working
 * no-JavaScript experience, which matters on the handsets and networks this
 * audience actually uses.
 *
 * @since 1.0.0
 */
( function () {
	'use strict';

	/* ----------------------------------------------------------------------
	 * Colour scheme.
	 *
	 * Read the stored preference before paint where possible; the attribute is
	 * set on <html> so the CSS custom properties swap without a flash.
	 * -------------------------------------------------------------------- */

	var THEME_KEY = 'qt-theme';

	function getStoredTheme() {
		try {
			return window.localStorage.getItem( THEME_KEY );
		} catch ( e ) {
			return null;
		}
	}

	function setStoredTheme( value ) {
		try {
			window.localStorage.setItem( THEME_KEY, value );
		} catch ( e ) {
			// Private browsing or a full quota. Not fatal.
		}
	}

	function systemPrefersDark() {
		return window.matchMedia && window.matchMedia( '(prefers-color-scheme: dark)' ).matches;
	}

	function currentTheme() {
		return document.documentElement.getAttribute( 'data-qt-theme' ) ||
			( systemPrefersDark() ? 'dark' : 'light' );
	}

	function applyTheme( theme ) {
		document.documentElement.setAttribute( 'data-qt-theme', theme );

		var buttons = document.querySelectorAll( '[data-qt-theme-toggle]' );

		for ( var i = 0; i < buttons.length; i++ ) {
			buttons[ i ].setAttribute( 'aria-pressed', theme === 'dark' ? 'true' : 'false' );
		}
	}

	// Apply immediately so the first paint is already correct.
	applyTheme( getStoredTheme() || ( document.body && document.body.classList.contains( 'qt-dark-default' ) ? 'dark' : ( systemPrefersDark() ? 'dark' : 'light' ) ) );

	// Follow the OS setting until the reader makes an explicit choice.
	if ( window.matchMedia ) {
		var media = window.matchMedia( '(prefers-color-scheme: dark)' );
		var onChange = function ( event ) {
			if ( ! getStoredTheme() ) {
				applyTheme( event.matches ? 'dark' : 'light' );
			}
		};

		if ( media.addEventListener ) {
			media.addEventListener( 'change', onChange );
		} else if ( media.addListener ) {
			media.addListener( onChange );
		}
	}

	/* ----------------------------------------------------------------------
	 * Boot: runs once the DOM is ready.
	 * -------------------------------------------------------------------- */

	function init() {
		/* --- Theme toggle ------------------------------------------------- */
		var toggles = document.querySelectorAll( '[data-qt-theme-toggle]' );

		for ( var t = 0; t < toggles.length; t++ ) {
			toggles[ t ].addEventListener( 'click', function () {
				var next = currentTheme() === 'dark' ? 'light' : 'dark';
				applyTheme( next );
				setStoredTheme( next );
			} );
		}

		/* --- Mobile navigation -------------------------------------------- */
		var navToggle = document.querySelector( '[data-qt-nav-toggle]' );
		var nav = document.querySelector( '[data-qt-nav]' );

		if ( navToggle && nav ) {
			navToggle.addEventListener( 'click', function () {
				var open = nav.getAttribute( 'data-qt-open' ) === 'true';
				nav.setAttribute( 'data-qt-open', open ? 'false' : 'true' );
				navToggle.setAttribute( 'aria-expanded', open ? 'false' : 'true' );
			} );

			// Close on Escape, and return focus to the toggle.
			document.addEventListener( 'keydown', function ( event ) {
				if ( event.key === 'Escape' && nav.getAttribute( 'data-qt-open' ) === 'true' ) {
					nav.setAttribute( 'data-qt-open', 'false' );
					navToggle.setAttribute( 'aria-expanded', 'false' );
					navToggle.focus();
				}
			} );

			// Close when a link inside is followed, so the reader is not left
			// with an overlay covering the page they navigated to.
			nav.addEventListener( 'click', function ( event ) {
				var target = event.target;

				while ( target && target !== nav ) {
					if ( target.tagName === 'A' ) {
						nav.setAttribute( 'data-qt-open', 'false' );
						navToggle.setAttribute( 'aria-expanded', 'false' );
						return;
					}
					target = target.parentNode;
				}
			} );
		}

		/* --- Newsletter forms: upgrade to AJAX ---------------------------- */
		var forms = document.querySelectorAll( '[data-qt-newsletter]' );

		for ( var f = 0; f < forms.length; f++ ) {
			enhanceNewsletter( forms[ f ] );
		}

		/* --- Smooth-scroll the county anchor ------------------------------ */
		var countyLinks = document.querySelectorAll( 'a[href*="#qt-counties"]' );

		for ( var c = 0; c < countyLinks.length; c++ ) {
			countyLinks[ c ].addEventListener( 'click', function ( event ) {
				var target = document.getElementById( 'qt-counties' );

				if ( ! target ) {
					return;
				}

				event.preventDefault();
				target.scrollIntoView( { behavior: 'smooth', block: 'start' } );

				// Keep the URL shareable and the history sane.
				if ( window.history && window.history.pushState ) {
					window.history.pushState( null, '', '#qt-counties' );
				}
			} );
		}
	}

	/**
	 * Submit a newsletter form over the WordPress admin-ajax endpoint and show
	 * the server's message inline. The form still works with JavaScript off,
	 * because it posts to admin-post.php and the server redirects back.
	 *
	 * @param {HTMLFormElement} form The signup form.
	 */
	function enhanceNewsletter( form ) {
		var message = form.querySelector( '.qt-newsletter__msg' );
		var submit = form.querySelector( '.qt-newsletter__submit' );
		var endpoint = ajaxUrl();

		if ( ! endpoint ) {
			// No usable endpoint: leave the form as a normal POST.
			return;
		}

		form.addEventListener( 'submit', function ( event ) {
			// Honeypot filled: let the server handle it, but do not send it.
			var honeypot = form.querySelector( '[name="qt_website"]' );

			if ( honeypot && honeypot.value !== '' ) {
				return;
			}

			event.preventDefault();

			var email = form.querySelector( '[name="qt_email"]' );

			if ( ! email || email.value === '' ) {
				setMessage( message, 'Enter an email address first.', 'error' );
				return;
			}

			var body = new URLSearchParams();
			body.append( 'action', 'qt_subscribe' );
			body.append( 'qt_newsletter_nonce', ( form.querySelector( '[name="qt_newsletter_nonce"]' ) || {} ).value || '' );
			body.append( 'qt_email', email.value );
			body.append( 'qt_county', ( form.querySelector( '[name="qt_county"]' ) || {} ).value || '' );
			body.append( 'qt_source', form.getAttribute( 'data-source' ) || 'ajax' );

			if ( submit ) {
				submit.disabled = true;
			}

			setMessage( message, 'Sending…', '' );

			window.fetch( endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: body.toString()
			} ).then( function ( response ) {
				return response.json();
			} ).then( function ( payload ) {
				if ( payload && payload.success ) {
					setMessage( message, ( payload.data && payload.data.message ) || 'Signed up.', 'success' );
					email.value = '';
				} else {
					setMessage( message, ( payload && payload.data && payload.data.message ) || 'That did not work. Please try again.', 'error' );
				}
			} ).catch( function () {
				setMessage( message, 'Network problem. Please try again.', 'error' );
			} ).then( function () {
				if ( submit ) {
					submit.disabled = false;
				}
			} );
		} );
	}

	/**
	 * Resolve the admin-ajax endpoint.
	 *
	 * Prefers the URL localised by inc/setup.php, which is correct even when
	 * WordPress is installed in a subdirectory. Falls back to a path derived
	 * from the document base, so a mis-set constant cannot break signups.
	 *
	 * @return {string} Absolute admin-ajax URL, or an empty string.
	 */
	function ajaxUrl() {
		if ( window.quietTruths && window.quietTruths.ajaxUrl ) {
			return window.quietTruths.ajaxUrl;
		}

		var base = document.baseURI || window.location.href;

		try {
			return new URL( 'wp-admin/admin-ajax.php', base ).toString();
		} catch ( e ) {
			return '';
		}
	}

	/**
	 * Write a status message into a live region.
	 *
	 * @param {HTMLElement} node  Target node.
	 * @param {string}      text  Message.
	 * @param {string}      state 'success', 'error' or ''.
	 */
	function setMessage( node, text, state ) {
		if ( ! node ) {
			return;
		}

		node.textContent = text;
		node.setAttribute( 'data-qt-state', state || '' );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
