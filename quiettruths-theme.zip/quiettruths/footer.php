<?php
/**
 * The footer.
 *
 * Three columns plus a bottom bar, per the site spec:
 *
 *   1. Brand    — wordmark, tagline, one-line descriptor, social icons.
 *   2. Sections — the five shelves plus the election hub.
 *   3. Outlet   — About, Standards, Corrections, Contact, Privacy.
 *
 * Corrections and Contact live here and only here. Corrections in the top nav
 * reads as amateur; omitting it hides accountability. Privacy sits in the footer
 * by legal convention.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?>
</main><!-- .qt-main -->

<footer class="qt-footer">
	<div class="qt-footer__inner">

		<?php /* ---------- Column 1: Brand ---------- */ ?>
		<div class="qt-footer__col qt-footer__col--brand">
			<?php quiettruths_branding(); ?>

			<p class="qt-footer__descriptor"><?php esc_html_e( 'Independent reporting on Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.', 'quiettruths' ); ?></p>

			<?php quiettruths_social_links(); ?>
		</div>

		<?php /* ---------- Column 2: Sections ---------- */ ?>
		<nav class="qt-footer__col" aria-label="<?php esc_attr_e( 'Sections', 'quiettruths' ); ?>">
			<h2 class="qt-footer__title"><?php esc_html_e( 'Sections', 'quiettruths' ); ?></h2>

			<ul class="qt-footer-menu">
				<?php
				$qt_footer_sections = array(
					__( 'Analysis', 'quiettruths' )       => home_url( '/category/analysis/' ),
					__( 'Profiles', 'quiettruths' )       => home_url( '/category/profiles/' ),
					__( 'Economy', 'quiettruths' )        => home_url( '/category/economy/' ),
					__( 'Explainers', 'quiettruths' )     => home_url( '/category/explainers/' ),
					__( 'Opinion', 'quiettruths' )        => home_url( '/category/opinion/' ),
					__( 'Election 2027', 'quiettruths' )  => home_url( '/2027/' ),
				);

				foreach ( $qt_footer_sections as $qt_label => $qt_url ) :
					?>
					<li><a href="<?php echo esc_url( $qt_url ); ?>"><?php echo esc_html( $qt_label ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>

		<?php /* ---------- Column 3: Outlet ---------- */ ?>
		<nav class="qt-footer__col" aria-label="<?php esc_attr_e( 'About this outlet', 'quiettruths' ); ?>">
			<h2 class="qt-footer__title"><?php esc_html_e( 'Quiet Truths', 'quiettruths' ); ?></h2>

			<ul class="qt-footer-menu">
				<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php esc_html_e( 'About', 'quiettruths' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/about/#standards' ) ); ?>"><?php esc_html_e( 'Standards', 'quiettruths' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/corrections/' ) ); ?>"><?php esc_html_e( 'Corrections', 'quiettruths' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact', 'quiettruths' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>"><?php esc_html_e( 'Privacy', 'quiettruths' ); ?></a></li>
			</ul>

			<?php
			$qt_tip_email = get_theme_mod( 'qt_tip_email', 'tips@quiettruths.co.ke' );

			if ( $qt_tip_email ) :
				?>
				<p class="qt-footer__tip">
					<span><?php esc_html_e( 'Have a document?', 'quiettruths' ); ?></span>
					<a href="<?php echo esc_url( 'mailto:' . $qt_tip_email ); ?>"><?php echo esc_html( $qt_tip_email ); ?></a>
				</p>
			<?php endif; ?>
		</nav>
	</div>

	<?php /* ---------- Bottom bar ---------- */ ?>
	<div class="qt-footer__base">
		<div class="qt-footer__base-inner">
			<p class="qt-footer__legal">
				<span class="qt-footer__copy">&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Quiet Truths</span>
				<span class="qt-footer__sep" aria-hidden="true">&middot;</span>
				<span class="qt-footer__domain">quiettruths.co.ke</span>
				<span class="qt-footer__sep" aria-hidden="true">&middot;</span>
				<span class="qt-footer__corrections">
					<?php esc_html_e( 'Corrections:', 'quiettruths' ); ?>
					<a href="<?php echo esc_url( 'mailto:' . get_theme_mod( 'qt_corrections_email', 'corrections@quiettruths.co.ke' ) ); ?>"><?php echo esc_html( get_theme_mod( 'qt_corrections_email', 'corrections@quiettruths.co.ke' ) ); ?></a>
				</span>
			</p>

			<?php
			$qt_footer_note = get_theme_mod( 'qt_footer_note', '' );

			if ( $qt_footer_note ) :
				?>
				<p class="qt-footer__note"><?php echo wp_kses_post( $qt_footer_note ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
