<?php
/**
 * Reader polls.
 *
 * Polls are stored as a single option rather than a custom table: a news site
 * runs one poll at a time, the payload is a few hundred bytes, and this keeps
 * the theme install-clean with no schema to migrate.
 *
 * Structure of the `quiettruths_polls` option:
 *   array(
 *     'active' => 'string poll id',
 *     'polls'  => array(
 *       'id' => array(
 *         'id'      => string,
 *         'question'=> string,
 *         'options' => array( array( 'label' => string, 'votes' => int ) ),
 *         'active'  => bool,
 *         'created' => int timestamp,
 *       ),
 *     ),
 *   )
 *
 * Vote counting is deliberately simple and best-effort: one vote per browser
 * via a cookie, plus a per-IP rate limit held in a transient. It is a
 * straw-poll for reader engagement, not a scientific instrument, and the theme
 * says so on the page. If a campaign needs a defensible poll, that needs a
 * proper survey tool — not this.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Option name holding all polls.
 */
if ( ! defined( 'QUIETTRUTHS_POLLS_OPTION' ) ) {
	define( 'QUIETTRUTHS_POLLS_OPTION', 'quiettruths_polls' );
}

/**
 * Read the whole poll store.
 *
 * @since 1.0.0
 * @return array Normalised store.
 */
function quiettruths_get_poll_store() {
	$store = get_option( QUIETTRUTHS_POLLS_OPTION, array() );

	if ( ! is_array( $store ) ) {
		$store = array();
	}

	$store = wp_parse_args( $store, array(
		'active' => '',
		'polls'  => array(),
	) );

	if ( ! is_array( $store['polls'] ) ) {
		$store['polls'] = array();
	}

	return $store;
}

/**
 * Persist the poll store.
 *
 * @since 1.0.0
 * @param array $store Store to save.
 * @return bool True on success.
 */
function quiettruths_save_poll_store( $store ) {
	return update_option( QUIETTRUTHS_POLLS_OPTION, $store, false );
}

/**
 * Get the currently active poll, or null.
 *
 * @since 1.0.0
 * @return array|null Poll array, or null when nothing is active.
 */
function quiettruths_get_active_poll() {
	$store = quiettruths_get_poll_store();

	if ( '' === $store['active'] || ! isset( $store['polls'][ $store['active'] ] ) ) {
		return null;
	}

	return $store['polls'][ $store['active'] ];
}

/**
 * Generate a poll identifier.
 *
 * @since 1.0.0
 * @return string Short unique id.
 */
function quiettruths_new_poll_id() {
	return 'p' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 8 );
}

/**
 * Create a poll.
 *
 * @since 1.0.0
 * @param string $question Question text.
 * @param array  $options  Option labels.
 * @param bool   $activate Whether to make it the active poll.
 * @return string|WP_Error Poll id, or an error.
 */
function quiettruths_create_poll( $question, $options, $activate = true ) {
	$question = sanitize_text_field( (string) $question );

	if ( '' === $question ) {
		return new WP_Error( 'qt_poll_no_question', __( 'A poll needs a question.', 'quiettruths' ) );
	}

	$clean = array();

	foreach ( (array) $options as $option ) {
		$option = sanitize_text_field( (string) $option );

		if ( '' !== $option ) {
			$clean[] = $option;
		}
	}

	$clean = array_values( array_unique( $clean ) );

	if ( count( $clean ) < 2 ) {
		return new WP_Error( 'qt_poll_too_few', __( 'A poll needs at least two different options.', 'quiettruths' ) );
	}

	if ( count( $clean ) > 6 ) {
		$clean = array_slice( $clean, 0, 6 );
	}

	$id = quiettruths_new_poll_id();

	$poll = array(
		'id'       => $id,
		'question' => $question,
		'options'  => array(),
		'active'   => (bool) $activate,
		'created'  => time(),
	);

	foreach ( $clean as $label ) {
		$poll['options'][] = array(
			'label' => $label,
			'votes' => 0,
		);
	}

	$store                = quiettruths_get_poll_store();
	$store['polls'][ $id ] = $poll;

	if ( $activate ) {
		// Only one poll can be active at a time.
		foreach ( $store['polls'] as $key => $existing ) {
			$store['polls'][ $key ]['active'] = ( $key === $id );
		}

		$store['active'] = $id;
	}

	quiettruths_save_poll_store( $store );

	return $id;
}

/**
 * Record a vote.
 *
 * @since 1.0.0
 * @param string $poll_id   Poll id.
 * @param int    $option    Zero-based option index.
 * @return WP_Error|true True on success, WP_Error otherwise.
 */
function quiettruths_record_vote( $poll_id, $option ) {
	$store = quiettruths_get_poll_store();

	if ( ! isset( $store['polls'][ $poll_id ] ) ) {
		return new WP_Error( 'qt_poll_missing', __( 'That poll no longer exists.', 'quiettruths' ), array( 'status' => 404 ) );
	}

	if ( empty( $store['polls'][ $poll_id ]['active'] ) ) {
		return new WP_Error( 'qt_poll_closed', __( 'This poll is closed.', 'quiettruths' ), array( 'status' => 403 ) );
	}

	$option = (int) $option;

	if ( ! isset( $store['polls'][ $poll_id ]['options'][ $option ] ) ) {
		return new WP_Error( 'qt_poll_bad_option', __( 'Choose one of the listed options.', 'quiettruths' ), array( 'status' => 400 ) );
	}

	// One vote per browser.
	if ( isset( $_COOKIE['qt_voted'] ) ) {
		$voted = array_filter( explode( ',', sanitize_text_field( wp_unslash( $_COOKIE['qt_voted'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.

		if ( in_array( $poll_id, $voted, true ) ) {
			return new WP_Error( 'qt_poll_dup', __( 'You have already voted in this poll.', 'quiettruths' ), array( 'status' => 409 ) );
		}
	}

	// Rate limit by IP so a script cannot pad the result.
	$ip        = quiettruths_client_ip();
	$transient = 'qt_poll_ip_' . md5( $ip . $poll_id );

	if ( get_transient( $transient ) ) {
		return new WP_Error( 'qt_poll_rate', __( 'Please wait before voting again.', 'quiettruths' ), array( 'status' => 429 ) );
	}

	$store['polls'][ $poll_id ]['options'][ $option ]['votes']++;
	quiettruths_save_poll_store( $store );

	set_transient( $transient, 1, HOUR_IN_SECONDS );
	quiettruths_mark_voted( $poll_id );

	return true;
}

/**
 * Flag this browser as having voted, via a long-lived cookie.
 *
 * @since 1.0.0
 * @param string $poll_id Poll id.
 */
function quiettruths_mark_voted( $poll_id ) {
	$voted = array();

	if ( isset( $_COOKIE['qt_voted'] ) ) {
		$voted = array_filter( explode( ',', sanitize_text_field( wp_unslash( $_COOKIE['qt_voted'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.
	}

	$voted[] = $poll_id;

	// Cap the list so the cookie cannot grow without bound.
	$voted = array_slice( array_values( array_unique( $voted ) ), -40 );

	if ( ! headers_sent() ) {
		setcookie( 'qt_voted', implode( ',', $voted ), time() + YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
	}
}

/**
 * Best-effort client IP for rate limiting.
 *
 * Never used for identity, and never stored — only hashed into a transient key.
 *
 * @since 1.0.0
 * @return string IP address or a placeholder.
 */
function quiettruths_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.

	return '' !== $ip ? $ip : '0.0.0.0';
}

/**
 * Render a poll: the form for non-voters, the result bars for voters.
 *
 * @since 1.0.0
 * @param array $poll Poll array.
 */
function quiettruths_render_poll( $poll ) {
	if ( empty( $poll ) || empty( $poll['options'] ) ) {
		return;
	}

	$voted    = quiettruths_has_voted( $poll['id'] );
	$show_bar = $voted || ! empty( $poll['active'] ) && get_theme_mod( 'qt_poll_show_results', false );

	echo '<div class="qt-poll" data-poll-id="' . esc_attr( $poll['id'] ) . '" data-voted="' . ( $voted ? '1' : '0' ) . '">';
	echo '<p class="qt-poll__question">' . esc_html( $poll['question'] ) . '</p>';

	if ( $voted ) {
		echo '<div class="qt-poll__results">';

		$total = 0;
		foreach ( $poll['options'] as $option ) {
			$total += (int) $option['votes'];
		}

		foreach ( $poll['options'] as $index => $option ) {
			$votes   = (int) $option['votes'];
			$percent = $total > 0 ? round( ( $votes / $total ) * 100 ) : 0;

			echo '<div class="qt-poll__row">';
			echo '<span class="qt-poll__label">' . esc_html( $option['label'] ) . '</span>';
			echo '<span class="qt-poll__bar"><span style="width:' . esc_attr( $percent ) . '%"></span></span>';
			echo '<span class="qt-poll__pct">' . esc_html( $percent ) . '%</span>';
			echo '<span class="qt-poll__count">' . esc_html( sprintf(
				/* translators: %s: number of votes. */
				_n( '%s vote', '%s votes', $votes, 'quiettruths' ),
				quiettruths_number( $votes )
			) ) . '</span>';
			echo '</div>';

			unset( $index );
		}

		printf(
			'<p class="qt-poll__total">%s</p>',
			esc_html( sprintf(
				/* translators: %s: total number of votes. */
				_n( '%s reader has weighed in', '%s readers have weighed in', $total, 'quiettruths' ),
				quiettruths_number( $total )
			) )
		);

		echo '</div>';
	} else {
		echo '<form class="qt-poll__form" method="post" action="">';

		foreach ( $poll['options'] as $index => $option ) {
			printf(
				'<label class="qt-poll__option"><input type="radio" name="qt_poll_option" value="%1$d" required /> <span>%2$s</span></label>',
				(int) $index,
				esc_html( $option['label'] )
			);
		}

		wp_nonce_field( 'qt_poll_' . $poll['id'], 'qt_poll_nonce' );

		echo '<button type="submit" class="qt-btn qt-btn--accent">' . esc_html__( 'Vote', 'quiettruths' ) . '</button>';
		echo '<p class="qt-poll__note">' . esc_html__( 'A straw poll for readers — one vote per device, not a scientific survey.', 'quiettruths' ) . '</p>';
		echo '</form>';
	}

	echo '</div>';

	unset( $show_bar );
}

/**
 * Whether this browser has voted in a poll.
 *
 * @since 1.0.0
 * @param string $poll_id Poll id.
 * @return bool True when a vote cookie is present for this poll.
 */
function quiettruths_has_voted( $poll_id ) {
	if ( ! isset( $_COOKIE['qt_voted'] ) ) {
		return false;
	}

	$voted = array_filter( explode( ',', sanitize_text_field( wp_unslash( $_COOKIE['qt_voted'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.

	return in_array( (string) $poll_id, $voted, true );
}

/* ---------------------------------------------------------------------------
 * REST endpoint
 * ------------------------------------------------------------------------ */

/**
 * Register the vote endpoint.
 *
 * @since 1.0.0
 */
function quiettruths_register_poll_routes() {
	register_rest_route(
		'quiettruths/v1',
		'/poll/(?P<id>[a-zA-Z0-9]+)/vote',
		array(
			'methods'             => 'POST',
			'callback'            => 'quiettruths_rest_vote',
			'permission_callback' => '__return_true',
			'args'                => array(
				'id'     => array(
					'required'          => true,
					'sanitize_callback' => 'sanitize_key',
				),
				'option' => array(
					'required'          => true,
					'sanitize_callback' => 'absint',
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'quiettruths_register_poll_routes' );

/**
 * Handle a vote over the REST API.
 *
 * Public by design — a poll is open to any reader — but nonce-protected via the
 * `wp_rest` nonce and rate-limited per IP in quiettruths_record_vote().
 *
 * @since 1.0.0
 * @param WP_REST_Request $request Incoming request.
 * @return WP_REST_Response|WP_Error Response payload.
 */
function quiettruths_rest_vote( $request ) {
	$poll_id = (string) $request->get_param( 'id' );
	$option  = (int) $request->get_param( 'option' );

	$result = quiettruths_record_vote( $poll_id, $option );

	if ( is_wp_error( $result ) ) {
		$status = isset( $result->error_data['status'] ) ? (int) $result->error_data['status'] : 400;

		return new WP_REST_Response(
			array(
				'ok'      => false,
				'message' => $result->get_error_message(),
			),
			$status
		);
	}

	$store = quiettruths_get_poll_store();
	$poll  = $store['polls'][ $poll_id ];

	$options = array();
	$total   = 0;

	foreach ( $poll['options'] as $item ) {
		$total     += (int) $item['votes'];
		$options[] = array(
			'label' => $item['label'],
			'votes' => (int) $item['votes'],
		);
	}

	return new WP_REST_Response(
		array(
			'ok'      => true,
			'message' => __( 'Vote counted.', 'quiettruths' ),
			'total'   => $total,
			'options' => $options,
		),
		200
	);
}

/* ---------------------------------------------------------------------------
 * Admin UI
 * ------------------------------------------------------------------------ */

/**
 * Add the polls admin page under Tools.
 *
 * @since 1.0.0
 */
function quiettruths_poll_admin_menu() {
	add_management_page(
		__( 'Quiet Truths Polls', 'quiettruths' ),
		__( 'Polls', 'quiettruths' ),
		'manage_options',
		'quiettruths-polls',
		'quiettruths_poll_admin_page'
	);
}
add_action( 'admin_menu', 'quiettruths_poll_admin_menu' );

/**
 * Handle create / activate / delete actions, then render the page.
 *
 * @since 1.0.0
 */
function quiettruths_poll_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to manage polls.', 'quiettruths' ) );
	}

	$notice = '';

	// Create.
	if ( isset( $_POST['qt_poll_action'] ) && 'create' === $_POST['qt_poll_action'] ) {
		check_admin_referer( 'qt_poll_create' );

		$question = isset( $_POST['qt_poll_question'] ) ? sanitize_text_field( wp_unslash( $_POST['qt_poll_question'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.
		$raw      = isset( $_POST['qt_poll_options'] ) ? sanitize_textarea_field( wp_unslash( $_POST['qt_poll_options'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.
		$options  = preg_split( '/\r\n|\r|\n/', (string) $raw );

		$id = quiettruths_create_poll( $question, (array) $options, true );

		$notice = is_wp_error( $id )
			? $id->get_error_message()
			: __( 'Poll created and set live.', 'quiettruths' );
	}

	// Activate an existing poll.
	if ( isset( $_POST['qt_poll_action'] ) && 'activate' === $_POST['qt_poll_action'] ) {
		check_admin_referer( 'qt_poll_manage' );

		$id    = isset( $_POST['qt_poll_id'] ) ? sanitize_key( wp_unslash( $_POST['qt_poll_id'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.
		$store = quiettruths_get_poll_store();

		if ( isset( $store['polls'][ $id ] ) ) {
			foreach ( $store['polls'] as $key => $poll ) {
				$store['polls'][ $key ]['active'] = ( $key === $id );
			}

			$store['active'] = $id;
			quiettruths_save_poll_store( $store );
			$notice = __( 'That poll is now live.', 'quiettruths' );
		}
	}

	// Delete.
	if ( isset( $_POST['qt_poll_action'] ) && 'delete' === $_POST['qt_poll_action'] ) {
		check_admin_referer( 'qt_poll_manage' );

		$id    = isset( $_POST['qt_poll_id'] ) ? sanitize_key( wp_unslash( $_POST['qt_poll_id'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.
		$store = quiettruths_get_poll_store();

		if ( isset( $store['polls'][ $id ] ) ) {
			unset( $store['polls'][ $id ] );

			if ( $store['active'] === $id ) {
				$store['active'] = '';
			}

			quiettruths_save_poll_store( $store );
			$notice = __( 'Poll deleted.', 'quiettruths' );
		}
	}

	$store = quiettruths_get_poll_store();

	echo '<div class="wrap">';
	echo '<h1>' . esc_html__( 'Quiet Truths Polls', 'quiettruths' ) . '</h1>';

	if ( $notice ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $notice ) . '</p></div>';
	}

	echo '<h2>' . esc_html__( 'Create a poll', 'quiettruths' ) . '</h2>';
	echo '<form method="post">';
	wp_nonce_field( 'qt_poll_create' );
	echo '<input type="hidden" name="qt_poll_action" value="create" />';
	echo '<p><label for="qt_poll_question">' . esc_html__( 'Question', 'quiettruths' ) . '</label><br />';
	echo '<input type="text" id="qt_poll_question" name="qt_poll_question" class="large-text" required /></p>';
	echo '<p><label for="qt_poll_options">' . esc_html__( 'Options, one per line (2 to 6)', 'quiettruths' ) . '</label><br />';
	echo '<textarea id="qt_poll_options" name="qt_poll_options" rows="6" class="large-text" required></textarea></p>';
	submit_button( __( 'Create and go live', 'quiettruths' ) );
	echo '</form>';

	echo '<h2>' . esc_html__( 'Existing polls', 'quiettruths' ) . '</h2>';

	if ( empty( $store['polls'] ) ) {
		echo '<p>' . esc_html__( 'No polls yet.', 'quiettruths' ) . '</p>';
	} else {
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'Question', 'quiettruths' ) . '</th>';
		echo '<th>' . esc_html__( 'Votes', 'quiettruths' ) . '</th>';
		echo '<th>' . esc_html__( 'Status', 'quiettruths' ) . '</th>';
		echo '<th>' . esc_html__( 'Actions', 'quiettruths' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( array_reverse( $store['polls'], true ) as $poll ) {
			$total = 0;
			foreach ( $poll['options'] as $option ) {
				$total += (int) $option['votes'];
			}

			echo '<tr>';
			echo '<td><strong>' . esc_html( $poll['question'] ) . '</strong><br /><small>' . esc_html( implode( ' · ', wp_list_pluck( $poll['options'], 'label' ) ) ) . '</small></td>';
			echo '<td>' . esc_html( quiettruths_number( $total ) ) . '</td>';
			echo '<td>' . ( ! empty( $poll['active'] ) ? esc_html__( 'Live', 'quiettruths' ) : esc_html__( 'Closed', 'quiettruths' ) ) . '</td>';
			echo '<td>';

			if ( empty( $poll['active'] ) ) {
				echo '<form method="post" style="display:inline">';
				wp_nonce_field( 'qt_poll_manage' );
				echo '<input type="hidden" name="qt_poll_action" value="activate" />';
				echo '<input type="hidden" name="qt_poll_id" value="' . esc_attr( $poll['id'] ) . '" />';
				echo '<button class="button">' . esc_html__( 'Make live', 'quiettruths' ) . '</button>';
				echo '</form> ';
			}

			echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Delete this poll and its results?\');">';
			wp_nonce_field( 'qt_poll_manage' );
			echo '<input type="hidden" name="qt_poll_action" value="delete" />';
			echo '<input type="hidden" name="qt_poll_id" value="' . esc_attr( $poll['id'] ) . '" />';
			echo '<button class="button button-link-delete">' . esc_html__( 'Delete', 'quiettruths' ) . '</button>';
			echo '</form>';

			echo '</td></tr>';
		}

		echo '</tbody></table>';
	}

	echo '</div>';
}
