<?php
/**
 * Structured data, Open Graph and metadata hygiene.
 *
 * No SEO plugin is required. A news site in this space competes for Google News
 * and Discover placement, which means correct NewsArticle markup, a dated
 * byline, and a canonical on every archive — all of which are cheap to emit
 * directly and painful to retrofit.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Emit Organization and WebSite schema site-wide.
 *
 * @since 1.0.0
 */
function quiettruths_schema_site() {
	if ( is_singular() || is_archive() || is_search() ) {
		return; // Handled by quiettruths_schema_content().
	}

	$org = array(
		'@context' => 'https://schema.org',
		'@type'    => 'NewsMediaOrganization',
		'name'     => get_bloginfo( 'name' ),
		'url'      => home_url( '/' ),
		'slogan'   => get_theme_mod( 'qt_tagline', '' ),
		'email'    => get_theme_mod( 'qt_news_email', '' ),
		'areaServed' => array(
			'@type' => 'AdministrativeArea',
			'name'  => __( 'Western Kenya', 'quiettruths' ),
		),
	);

	$address = get_theme_mod( 'qt_address', '' );

	if ( $address ) {
		$org['address'] = array(
			'@type'         => 'PostalAddress',
			'streetAddress' => $address,
			'addressCountry' => 'KE',
		);
	}

	echo quiettruths_jsonld( $org ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- quiettruths_jsonld() returns a safe, encoded script tag.
}
add_action( 'wp_head', 'quiettruths_schema_site', 5 );

/**
 * Emit Article / NewsArticle schema on singles and archives.
 *
 * @since 1.0.0
 */
function quiettruths_schema_content() {
	if ( is_singular( array( 'post', 'qt_investigation' ) ) ) {
		$post_id = get_the_ID();

		$article = array(
			'@context'      => 'https://schema.org',
			'@type'         => 'qt_investigation' === get_post_type( $post_id ) ? 'ReportageNewsArticle' : 'NewsArticle',
			'headline'      => get_the_title( $post_id ),
			'datePublished' => get_the_date( 'c', $post_id ),
			'dateModified'  => get_the_modified_date( 'c', $post_id ),
			'mainEntityOfPage' => array(
				'@type' => 'WebPage',
				'@id'   => get_permalink( $post_id ),
			),
			'author'        => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ),
			),
			'publisher'     => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
			),
		);

		$excerpt = get_the_excerpt( $post_id );

		if ( $excerpt ) {
			$article['description'] = wp_strip_all_tags( $excerpt );
		}

		if ( has_post_thumbnail( $post_id ) ) {
			$article['image'] = array( get_the_post_thumbnail_url( $post_id, 'qt-lead' ) );
		}

		$counties = get_the_terms( $post_id, 'qt_county' );

		if ( ! is_wp_error( $counties ) && $counties ) {
			$article['about'] = array();

			foreach ( $counties as $county ) {
				$article['about'][] = array(
					'@type' => 'Place',
					'name'  => $county->name . ' County, Kenya',
				);
			}
		}

		echo quiettruths_jsonld( $article ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- safe by construction.
	}

	if ( is_tax( 'qt_county' ) ) {
		$term = get_queried_object();

		if ( $term instanceof WP_Term ) {
			$county = quiettruths_get_county( str_replace( 'qt-', '', $term->slug ) );

			$place = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'AdministrativeArea',
				'name'        => $term->name . ' County',
				'containedInPlace' => array(
					'@type' => 'Country',
					'name'  => 'Kenya',
				),
			);

			if ( $county ) {
				$place['identifier'] = $county['code'];

				if ( $county['governor'] ) {
					$place['employee'] = array(
						'@type'    => 'Person',
						'name'     => $county['governor'],
						'jobTitle' => __( 'Governor', 'quiettruths' ),
					);
				}
			}

			echo quiettruths_jsonld( $place ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- safe by construction.
		}
	}
}
add_action( 'wp_head', 'quiettruths_schema_content', 6 );

/**
 * Open Graph and Twitter card tags.
 *
 * WhatsApp and X drive most political link sharing in Kenya, and both read
 * these tags to build the preview card. Without them a shared investigation
 * shows up as a bare URL and gets far less traction.
 *
 * @since 1.0.0
 */
function quiettruths_open_graph() {
	$site_name = get_bloginfo( 'name' );

	$tags = array(
		'og:site_name' => $site_name,
		'og:locale'    => 'en_KE',
	);

	if ( is_singular() ) {
		$tags['og:type']  = 'article';
		$tags['og:title'] = get_the_title();
		$tags['og:url']   = get_permalink();

		$excerpt = get_the_excerpt();

		if ( $excerpt ) {
			$tags['og:description'] = wp_strip_all_tags( $excerpt );
		}

		if ( has_post_thumbnail() ) {
			$tags['og:image']       = get_the_post_thumbnail_url( null, 'qt-lead' );
			$tags['twitter:card']   = 'summary_large_image';
		}

		$tags['article:published_time'] = get_the_date( 'c' );
		$tags['article:modified_time']  = get_the_modified_date( 'c' );
	} else {
		$tags['og:type']        = 'website';
		$tags['og:title']       = wp_get_document_title();
		$tags['og:url']         = quiettruths_current_url();
		$tags['og:description'] = get_bloginfo( 'description' );
	}

	foreach ( $tags as $property => $content ) {
		if ( '' === $content || null === $content ) {
			continue;
		}

		$prefix = 0 === strpos( $property, 'twitter:' ) ? 'name' : 'property';

		printf(
			'<meta %1$s="%2$s" content="%3$s">' . "\n",
			esc_attr( $prefix ),
			esc_attr( $property ),
			esc_attr( $content )
		);
	}
}
add_action( 'wp_head', 'quiettruths_open_graph', 7 );

/**
 * Return the URL of the current request, built from the parsed request path.
 *
 * Deliberately derived from `home_url()` plus the request rather than from
 * `$_SERVER['HTTP_HOST']`, so a spoofed Host header can never end up in an
 * og:url tag that readers then share.
 *
 * @since 1.0.0
 * @return string Absolute URL.
 */
function quiettruths_current_url() {
	$request = isset( $GLOBALS['wp']->request ) ? (string) $GLOBALS['wp']->request : '';

	// Keep only path-safe characters; discard anything that looks injected.
	$request = preg_replace( '/[^A-Za-z0-9\/_\-]/', '', $request );

	return home_url( '/' . ltrim( (string) $request, '/' ) );
}

/**
 * Canonical URL for every view, including paginated archives.
 *
 * WordPress emits a canonical by default, but archive pagination and taxonomy
 * views are where duplicates creep in — and duplicate county archives would
 * split the authority the site is trying to build.
 *
 * @since 1.0.0
 * @param string $canonical The canonical URL WordPress chose.
 * @return string Corrected canonical.
 */
function quiettruths_canonical( $canonical ) {
	if ( is_paged() && is_archive() ) {
		$canonical = get_pagenum_link( (int) get_query_var( 'paged' ) );
	}

	if ( is_tax( 'qt_county' ) ) {
		$term = get_queried_object();

		if ( $term instanceof WP_Term ) {
			$canonical = get_term_link( $term );

			if ( is_wp_error( $canonical ) ) {
				$canonical = home_url( '/' );
			}
		}
	}

	return $canonical;
}
add_filter( 'get_canonical_url', 'quiettruths_canonical' );

/**
 * Add a `humans.txt` style editorial note to the feed.
 *
 * @since 1.0.0
 * @param string $content Feed item content.
 * @return string Content with a source line appended.
 */
function quiettruths_feed_source_line( $content ) {
	return $content . '<p><em>' . esc_html( sprintf(
		/* translators: %s: site name. */
		__( 'Originally reported by %s.', 'quiettruths' ),
		get_bloginfo( 'name' )
	) ) . '</em></p>';
}
add_filter( 'the_excerpt_rss', 'quiettruths_feed_source_line' );

/**
 * Declare the archive date format used across the theme.
 *
 * @since 1.0.0
 * @param string $format Date format.
 * @return string Theme date format.
 */
function quiettruths_date_format( $format ) {
	return 'j M Y';
}
add_filter( 'get_the_date', 'quiettruths_date_format' );
