<?php
/**
 * Newsletter capture.
 *
 * A custom table rather than an option, because a subscriber list grows without
 * bound and must be exportable, deduplicated and paginated. Creation is
 * guarded by dbDelta so it is safe to run repeatedly, and the whole feature
 * degrades to "no signup" rather than a fatal error if the table is missing.
 *
 * Compliance note for the editor: Kenya's Data Protection Act 2019 requires
 * consent, a stated purpose, and a way to withdraw. The signup form records a
 * timestamp and the consent text, and this file documents where the export and
 * deletion controls live. Do not send to this list without a double opt-in
 * flow — see quiettruths_send_confirmation().
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return the subscribers table name.
 *
 * @since 1.0.0
 * @return string Prefixed table name.
 */
function quiettruths_subscribers_table() {
	global $wpdb;

	return $wpdb->prefix . 'qt_subscribers';
}

/**
 * Create or update the subscribers table.
 *
 * @since 1.0.0
 */
function quiettruths_create_subscribers_table() {
	global $wpdb;

	$table   = quiettruths_subscribers_table();
	$charset = $wpdb->get_charset_collate();

	// email_hash is the dedupe key: a UNIQUE index on the address alone would
	// also work, but hashing keeps the raw address out of every index.
	$sql = "CREATE TABLE {$table} (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		email VARCHAR(191) NOT NULL,
		email_hash CHAR(32) NOT NULL,
		county VARCHAR(64) NOT NULL DEFAULT '',
		source VARCHAR(64) NOT NULL DEFAULT '',
		status VARCHAR(16) NOT NULL DEFAULT 'pending',
		consented TINYINT(1) NOT NULL DEFAULT 0,
		confirm_key CHAR(32) NOT NULL DEFAULT '',
		ip_hash CHAR(64) NOT NULL DEFAULT '',
		created DATETIME NOT NULL,
		confirmed DATETIME NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY email_hash (email_hash),
		KEY status (status),
		KEY county (county)
	) {$charset};";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
}
add_action( 'after_switch_theme', 'quiettruths_create_subscribers_table' );

/**
 * Store a subscription request.
 *
 * @since 1.0.0
 * @param string $email  Email address.
 * @param string $county Optional county slug.
 * @param string $source Optional signup source, e.g. 'footer', 'sidebar'.
 * @return string|WP_Error 'added', 'already', or a WP_Error.
 */
function quiettruths_subscribe( $email, $county = '', $source = '' ) {
	global $wpdb;

	$email = sanitize_email( (string) $email );

	if ( ! is_email( $email ) ) {
		return new WP_Error( 'qt_bad_email', __( 'That does not look like a valid email address.', 'quiettruths' ) );
	}

	$county = sanitize_title( (string) $county );
	$source = sanitize_key( (string) $source );

	if ( ! array_key_exists( $county, quiettruths_counties() ) ) {
		$county = '';
	}

	$table = quiettruths_subscribers_table();

	// If the table is missing (e.g. the theme was activated before a required
	// upgrade), create it now rather than failing silently.
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name from our own function.
		quiettruths_create_subscribers_table();
	}

	$hash = md5( strtolower( $email ) );

	$existing = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare( "SELECT id, status FROM {$table} WHERE email_hash = %s", $hash ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is ours.
	);

	if ( $existing ) {
		return 'already';
	}

	$ip_hash = hash( 'sha256', quiettruths_client_ip() . wp_salt( 'auth' ) );

	$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$table,
		array(
			'email'      => $email,
			'email_hash' => $hash,
			'county'     => $county,
			'source'     => $source,
			'status'     => 'pending',
			'consented'  => 1,
			'confirm_key' => wp_generate_password( 20, false ),
			'ip_hash'    => $ip_hash,
			'created'    => current_time( 'mysql' ),
		),
		array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
	);

	if ( false === $inserted ) {
		return new WP_Error( 'qt_insert_failed', __( 'We could not save that just now. Please try again.', 'quiettruths' ) );
	}

	quiettruths_send_confirmation( $email, $county );

	return 'added';
}

/**
 * Email the double opt-in confirmation.
 *
 * Double opt-in is the only defensible way to build this list under the Data
 * Protection Act: it proves the address belongs to the person who signed up and
 * keeps harvested addresses out of the database.
 *
 * @since 1.0.0
 * @param string $email  Subscriber email.
 * @param string $county Optional county slug.
 * @return bool Whether wp_mail accepted the message.
 */
function quiettruths_send_confirmation( $email, $county = '' ) {
	global $wpdb;

	$table = quiettruths_subscribers_table();

	$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare( "SELECT confirm_key FROM {$table} WHERE email_hash = %s", md5( strtolower( $email ) ) ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is ours.
	);

	if ( ! $row || empty( $row->confirm_key ) ) {
		return false;
	}

	$link = add_query_arg(
		array(
			'qt_confirm' => $row->confirm_key,
			'qt_email'   => md5( strtolower( $email ) ),
		),
		home_url( '/' )
	);

	$county_name = $county ? quiettruths_county_name( $county ) : __( 'Western Kenya', 'quiettruths' );

	$subject = sprintf(
		/* translators: %s: site name. */
		__( 'Confirm your %s subscription', 'quiettruths' ),
		get_bloginfo( 'name' )
	);

	$message  = sprintf( __( 'Hello,', 'quiettruths' ) ) . "\n\n";
	$message .= sprintf(
		/* translators: %s: county or region name. */
		__( 'Someone asked us to send the %1$s briefing on %2$s.', 'quiettruths' ),
		get_bloginfo( 'name' ),
		$county_name
	) . "\n\n";
	$message .= __( 'Confirm here:', 'quiettruths' ) . "\n" . $link . "\n\n";
	$message .= __( 'If this was not you, ignore this email and nothing further will be sent.', 'quiettruths' ) . "\n";

	$headers = array( 'Content-Type: text/plain; charset=UTF-8' );

	return wp_mail( $email, $subject, $message, $headers );
}

/**
 * Confirm a subscription from the emailed link.
 *
 * Hooked to `init` so it runs before any output. Both the confirm key and the
 * email hash must match, so a leaked link cannot be replayed against a
 * different address.
 *
 * @since 1.0.0
 */
function quiettruths_handle_confirmation() {
	if ( ! isset( $_GET['qt_confirm'], $_GET['qt_email'] ) ) {
		return;
	}

	global $wpdb;

	$key   = sanitize_key( wp_unslash( $_GET['qt_confirm'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_key applied.
	$hash  = preg_replace( '/[^a-f0-9]/', '', strtolower( sanitize_text_field( wp_unslash( $_GET['qt_email'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.
	$table = quiettruths_subscribers_table();

	if ( '' === $key || 32 !== strlen( (string) $hash ) ) {
		return;
	}

	$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$table,
		array(
			'status'    => 'confirmed',
			'confirmed' => current_time( 'mysql' ),
		),
		array(
			'email_hash'  => $hash,
			'confirm_key' => $key,
			'status'      => 'pending',
		),
		array( '%s', '%s' ),
		array( '%s', '%s', '%s' )
	);

	// Strip the tokens from the URL so a refreshed page does not re-confirm.
	wp_safe_redirect( add_query_arg( 'qt_subscribed', '1', remove_query_arg( array( 'qt_confirm', 'qt_email' ) ) ) );
	exit;
}
add_action( 'init', 'quiettruths_handle_confirmation' );

/**
 * Print a confirmation banner after a successful opt-in.
 *
 * @since 1.0.0
 */
function quiettruths_confirmation_notice() {
	$subscribed = isset( $_GET['qt_subscribed'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag, no state change.
	$already    = isset( $_GET['qt_already'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag, no state change.

	if ( ! $subscribed && ! $already ) {
		return;
	}

	echo '<div class="qt-notice qt-notice--success" role="status"><p>';

	if ( $subscribed ) {
		echo esc_html__( 'Check your inbox — click the confirmation link and you are on the list.', 'quiettruths' );
	} else {
		echo esc_html__( 'That address is already signed up. Look for the confirmation email if you have not confirmed yet.', 'quiettruths' );
	}

	echo '</p></div>';
}
add_action( 'wp_body_open', 'quiettruths_confirmation_notice' );

/* ---------------------------------------------------------------------------
 * Front-end form + AJAX
 * ------------------------------------------------------------------------ */

/**
 * Render the newsletter signup form.
 *
 * @since 1.0.0
 * @param string $source Signup source label, recorded for analytics.
 */
function quiettruths_newsletter_form( $source = 'inline' ) {
	$source = sanitize_key( (string) $source );

	/*
	 * Off until the editor switches it on. A newsletter is a second
	 * publication: opening signups before two or three issues exist means the
	 * first subscriber's first experience of the brand is silence. The form
	 * renders nothing until then, so nothing on the site promises a briefing
	 * that has not been written.
	 */
	if ( ! get_theme_mod( 'qt_newsletter_enable', false ) ) {
		return;
	}

	// Posts to admin-post.php so a reader with JavaScript disabled still gets
	// through the same validation path; main.js upgrades this to AJAX when it can.
	$action = esc_url( admin_url( 'admin-post.php' ) );

	echo '<form class="qt-newsletter" method="post" action="' . $action . '" data-qt-newsletter data-source="' . esc_attr( $source ) . '">';

	echo '<p class="qt-newsletter__pitch">' . esc_html( get_theme_mod( 'qt_newsletter_pitch', __( 'County budgets, tender notices, and what your leaders did — not what they said.', 'quiettruths' ) ) ) . '</p>';

	echo '<div class="qt-newsletter__row">';
	echo '<label class="screen-reader-text" for="qt-newsletter-email-' . esc_attr( $source ) . '">' . esc_html__( 'Email address', 'quiettruths' ) . '</label>';
	echo '<input id="qt-newsletter-email-' . esc_attr( $source ) . '" class="qt-newsletter__email" type="email" name="qt_email" required autocomplete="email" placeholder="' . esc_attr__( 'you@example.com', 'quiettruths' ) . '" />';

	echo '<label class="screen-reader-text" for="qt-newsletter-county-' . esc_attr( $source ) . '">' . esc_html__( 'County', 'quiettruths' ) . '</label>';
	echo '<select id="qt-newsletter-county-' . esc_attr( $source ) . '" class="qt-newsletter__county" name="qt_county">';
	echo '<option value="">' . esc_html__( 'Whole region', 'quiettruths' ) . '</option>';

	foreach ( quiettruths_counties() as $county ) {
		printf(
			'<option value="%1$s">%2$s</option>',
			esc_attr( $county['slug'] ),
			esc_html( $county['name'] )
		);
	}

	echo '</select>';
	echo '</div>';

	// Honeypot: a field no human fills in, but most bots do.
	echo '<p class="qt-newsletter__hp" aria-hidden="true"><label>Leave this empty<input type="text" name="qt_website" tabindex="-1" autocomplete="off" /></label></p>';

	wp_nonce_field( 'qt_newsletter', 'qt_newsletter_nonce' );
	// `action` drives admin-post.php routing; `qt_action` carries the AJAX name
	// so main.js can reuse it without the two colliding.
	echo '<input type="hidden" name="action" value="qt_subscribe_post" />';
	echo '<input type="hidden" name="qt_action" value="qt_subscribe" />';
	echo '<input type="hidden" name="qt_source" value="' . esc_attr( $source ) . '" />';

	echo '<button type="submit" class="qt-btn qt-btn--accent qt-newsletter__submit">' . esc_html__( 'Sign up', 'quiettruths' ) . '</button>';

	echo '<p class="qt-newsletter__legal">' . esc_html__( 'We confirm by email before sending anything. One click to leave, and we never share the list.', 'quiettruths' ) . '</p>';
	echo '<p class="qt-newsletter__msg" role="status" aria-live="polite"></p>';

	echo '</form>';
}

/**
 * Register the AJAX endpoint.
 *
 * @since 1.0.0
 */
function quiettruths_register_newsletter_ajax() {
	add_action( 'wp_ajax_qt_subscribe', 'quiettruths_ajax_subscribe' );
	add_action( 'wp_ajax_nopriv_qt_subscribe', 'quiettruths_ajax_subscribe' );
}
add_action( 'init', 'quiettruths_register_newsletter_ajax' );

/**
 * Handle an AJAX signup.
 *
 * @since 1.0.0
 */
function quiettruths_ajax_subscribe() {
	check_ajax_referer( 'qt_newsletter', 'qt_newsletter_nonce' );

	// Honeypot: a filled field means a bot. Answer success anyway so the bot
	// learns nothing from the response.
	if ( ! empty( $_POST['qt_website'] ) ) {
		wp_send_json_success( array( 'message' => __( 'Thanks — check your inbox to confirm.', 'quiettruths' ) ) );
	}

	$email  = isset( $_POST['qt_email'] ) ? sanitize_email( wp_unslash( $_POST['qt_email'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_email applied.
	$county = isset( $_POST['qt_county'] ) ? sanitize_title( wp_unslash( $_POST['qt_county'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_title applied.
	$source = isset( $_POST['qt_source'] ) ? sanitize_key( wp_unslash( $_POST['qt_source'] ) ) : 'ajax'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_key applied.

	// Basic throttle: no more than a few signups an hour per IP.
	$ip_hash = hash( 'sha256', quiettruths_client_ip() );
	$hits    = (int) get_transient( 'qt_sub_' . $ip_hash );

	if ( $hits >= 5 ) {
		wp_send_json_error( array( 'message' => __( 'Too many attempts. Please come back in an hour.', 'quiettruths' ) ), 429 );
	}

	set_transient( 'qt_sub_' . $ip_hash, $hits + 1, HOUR_IN_SECONDS );

	$result = quiettruths_subscribe( $email, $county, $source );

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
	}

	if ( 'already' === $result ) {
		wp_send_json_success( array(
			'message' => __( 'That address is already on the list. Check your inbox for the confirmation link.', 'quiettruths' ),
		) );
	}

	wp_send_json_success( array(
		'message' => __( 'Almost there — we have sent a confirmation email. Click the link and you are in.', 'quiettruths' ),
	) );
}

/**
 * Non-JS fallback: handle a posted signup when JavaScript is unavailable.
 *
 * Shared hosting users on slow connections and older handsets regularly have JS
 * blocked or failing, and a political site in this market must not depend on it.
 *
 * @since 1.0.0
 */
function quiettruths_handle_posted_signup() {
	if ( ! isset( $_POST['qt_newsletter_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qt_newsletter_nonce'] ) ), 'qt_newsletter' ) ) {
		return;
	}

	if ( ! empty( $_POST['qt_website'] ) ) {
		return;
	}

	$email  = isset( $_POST['qt_email'] ) ? sanitize_email( wp_unslash( $_POST['qt_email'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_email applied.
	$county = isset( $_POST['qt_county'] ) ? sanitize_title( wp_unslash( $_POST['qt_county'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_title applied.
	$source = isset( $_POST['qt_source'] ) ? sanitize_key( wp_unslash( $_POST['qt_source'] ) ) : 'post'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_key applied.

	$result = quiettruths_subscribe( $email, $county, $source );

	// Redirect back to the referring page (Post/Redirect/Get) so a refresh
	// cannot submit the form a second time. Falls back to the home page when
	// the referrer is missing or off-site.
	$back = wp_get_referer();

	if ( ! $back || false === strpos( (string) $back, wp_parse_url( home_url(), PHP_URL_HOST ) ) ) {
		$back = home_url( '/' );
	}

	$flag = 'already' === $result ? 'qt_already' : 'qt_subscribed';

	wp_safe_redirect( add_query_arg( $flag, '1', remove_query_arg( $flag, $back ) ) );
	exit;
}
add_action( 'admin_post_nopriv_qt_subscribe_post', 'quiettruths_handle_posted_signup' );
add_action( 'admin_post_qt_subscribe_post', 'quiettruths_handle_posted_signup' );

/* ---------------------------------------------------------------------------
 * Admin: list and CSV export
 * ------------------------------------------------------------------------ */

/**
 * Add the subscribers admin page.
 *
 * @since 1.0.0
 */
function quiettruths_subscriber_admin_menu() {
	add_management_page(
		__( 'Quiet Truths Subscribers', 'quiettruths' ),
		__( 'Subscribers', 'quiettruths' ),
		'manage_options',
		'quiettruths-subscribers',
		'quiettruths_subscriber_admin_page'
	);
}
add_action( 'admin_menu', 'quiettruths_subscriber_admin_menu' );

/**
 * Stream a CSV export of confirmed subscribers, or render the list screen.
 *
 * The export is a direct download rather than a generated file on disk, so a
 * shared host never holds a plaintext list of subscriber addresses in the web
 * root. Capability is re-checked immediately before any row is written.
 *
 * @since 1.0.0
 */
function quiettruths_subscriber_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to view subscribers.', 'quiettruths' ) );
	}

	global $wpdb;

	$table = quiettruths_subscribers_table();

	// --- CSV export -------------------------------------------------------
	if ( isset( $_GET['qt_export'] ) ) {
		check_admin_referer( 'qt_export_subscribers' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not permitted.', 'quiettruths' ) );
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=quiettruths-subscribers-' . gmdate( 'Y-m-d' ) . '.csv' );

		$handle = fopen( 'php://output', 'w' );

		if ( false !== $handle ) {
			fputcsv( $handle, array( 'email', 'county', 'status', 'source', 'created', 'confirmed' ) );

			$rows = $wpdb->get_results( "SELECT email, county, status, source, created, confirmed FROM {$table} ORDER BY created DESC" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- table name is ours; admin-only export.

			foreach ( (array) $rows as $row ) {
				fputcsv( $handle, array( $row->email, $row->county, $row->status, $row->source, $row->created, $row->confirmed ) );
			}

			fclose( $handle );
		}

		exit;
	}

	// --- Delete a subscriber ---------------------------------------------
	if ( isset( $_GET['qt_delete'] ) ) {
		check_admin_referer( 'qt_delete_subscriber_' . sanitize_key( wp_unslash( $_GET['qt_delete'] ) ) );

		$hash = preg_replace( '/[^a-f0-9]/', '', strtolower( sanitize_text_field( wp_unslash( $_GET['qt_delete'] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized before use.

		if ( 32 === strlen( (string) $hash ) ) {
			$wpdb->delete( $table, array( 'email_hash' => $hash ), array( '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}

		wp_safe_redirect( admin_url( 'tools.php?page=quiettruths-subscribers&qt_deleted=1' ) );
		exit;
	}

	// --- Render -----------------------------------------------------------
	$page    = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.
	$per     = 30;
	$offset  = ( $page - 1 ) * $per;

	$total  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$counts = $wpdb->get_results( "SELECT status, COUNT(*) AS total FROM {$table} GROUP BY status" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare( "SELECT email, email_hash, county, status, source, created FROM {$table} ORDER BY created DESC LIMIT %d OFFSET %d", $per, $offset ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is ours.
	);

	echo '<div class="wrap">';
	echo '<h1>' . esc_html__( 'Quiet Truths Subscribers', 'quiettruths' ) . '</h1>';

	if ( isset( $_GET['qt_deleted'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Subscriber removed.', 'quiettruths' ) . '</p></div>';
	}

	echo '<p><strong>' . esc_html( quiettruths_number( $total ) ) . '</strong> ' . esc_html__( 'total', 'quiettruths' );

	foreach ( (array) $counts as $count ) {
		echo ' &middot; ' . esc_html( $count->status ) . ': ' . esc_html( quiettruths_number( (int) $count->total ) );
	}

	echo '</p>';

	printf(
		'<p><a class="button button-primary" href="%s">%s</a></p>',
		esc_url( wp_nonce_url( admin_url( 'tools.php?page=quiettruths-subscribers&qt_export=1' ), 'qt_export_subscribers' ) ),
		esc_html__( 'Export CSV', 'quiettruths' )
	);

	echo '<p class="description">' . esc_html__( 'Exporting downloads the list and never writes it to the server. Under the Data Protection Act 2019 you must be able to delete a subscriber on request — use the remove link.', 'quiettruths' ) . '</p>';

	echo '<table class="widefat striped"><thead><tr>';
	echo '<th>' . esc_html__( 'Email', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'County', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'Status', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'Source', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'Signed up', 'quiettruths' ) . '</th>';
	echo '<th></th>';
	echo '</tr></thead><tbody>';

	if ( empty( $rows ) ) {
		echo '<tr><td colspan="6">' . esc_html__( 'No subscribers yet.', 'quiettruths' ) . '</td></tr>';
	}

	foreach ( (array) $rows as $row ) {
		echo '<tr>';
		echo '<td>' . esc_html( $row->email ) . '</td>';
		echo '<td>' . esc_html( $row->county ? quiettruths_county_name( $row->county ) : '—' ) . '</td>';
		echo '<td>' . esc_html( $row->status ) . '</td>';
		echo '<td>' . esc_html( $row->source ) . '</td>';
		echo '<td>' . esc_html( mysql2date( 'j M Y', $row->created ) ) . '</td>';
		echo '<td><a href="' . esc_url( wp_nonce_url( admin_url( 'tools.php?page=quiettruths-subscribers&qt_delete=' . $row->email_hash ), 'qt_delete_subscriber_' . $row->email_hash ) ) . '">' . esc_html__( 'Remove', 'quiettruths' ) . '</a></td>';
		echo '</tr>';
	}

	echo '</tbody></table>';

	$pages = (int) ceil( $total / $per );

	if ( $pages > 1 ) {
		echo '<p class="tablenav-pages">';
		echo wp_kses_post( paginate_links( array(
			'base'    => add_query_arg( 'paged', '%#%' ),
			'format'  => '',
			'current' => $page,
			'total'   => $pages,
		) ) );
		echo '</p>';
	}

	echo '</div>';
}
