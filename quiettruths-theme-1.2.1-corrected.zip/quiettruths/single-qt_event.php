<?php
/**
 * Single event.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

while ( have_posts() ) :
	the_post();

	$qt_start = get_post_meta( get_the_ID(), '_qt_event_start', true );
	$qt_end   = get_post_meta( get_the_ID(), '_qt_event_end', true );
	$qt_venue = get_post_meta( get_the_ID(), '_qt_event_venue', true );
	$qt_host  = get_post_meta( get_the_ID(), '_qt_event_host', true );
	?>

	<article <?php post_class( 'qt-article qt-article--event' ); ?>>
		<?php quiettruths_breadcrumbs(); ?>

		<header class="qt-article__head">
			<?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 2 ); ?>

			<h1 class="qt-article__title"><?php the_title(); ?></h1>

			<dl class="qt-event-facts">
				<div>
					<dt><?php esc_html_e( 'When', 'quiettruths' ); ?></dt>
					<dd>
						<?php if ( $qt_start ) : ?>
							<time datetime="<?php echo esc_attr( $qt_start ); ?>"><?php quiettruths_the_event_date(); ?></time>
						<?php else : ?>
							<?php echo esc_html( get_the_date() ); ?>
						<?php endif; ?>

						<?php if ( $qt_end ) : ?>
							<span class="qt-event-facts__end"><?php esc_html_e( 'until', 'quiettruths' ); ?> <?php echo esc_html( gmdate( 'j M Y, H:i', (int) strtotime( $qt_end ) ) ); ?></span>
						<?php endif; ?>
					</dd>
				</div>

				<?php if ( $qt_venue ) : ?>
					<div>
						<dt><?php esc_html_e( 'Where', 'quiettruths' ); ?></dt>
						<dd><?php echo esc_html( $qt_venue ); ?></dd>
					</div>
				<?php endif; ?>

				<?php if ( $qt_host ) : ?>
					<div>
						<dt><?php esc_html_e( 'Hosted by', 'quiettruths' ); ?></dt>
						<dd><?php echo esc_html( $qt_host ); ?></dd>
					</div>
				<?php endif; ?>
			</dl>

			<?php if ( ! quiettruths_event_is_upcoming() ) : ?>
				<p class="qt-event-past"><?php esc_html_e( 'This event has already taken place.', 'quiettruths' ); ?></p>
			<?php endif; ?>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="qt-article__hero"><?php the_post_thumbnail( 'qt-lead' ); ?></figure>
		<?php endif; ?>

		<div class="qt-layout">
			<div class="qt-article__body">
				<?php the_content(); ?>

				<?php if ( $qt_venue ) : ?>
					<p class="qt-event-map">
						<a class="qt-btn qt-btn--ghost" href="<?php echo esc_url( add_query_arg(
							array( 'q' => rawurlencode( $qt_venue . ', Kenya' ) ),
							'https://www.openstreetmap.org/search'
						) ); ?>" rel="noopener" target="_blank"><?php esc_html_e( 'Open in maps', 'quiettruths' ); ?></a>
					</p>
				<?php endif; ?>
			</div>

			<?php get_sidebar(); ?>
		</div>
	</article>

<?php endwhile; ?>

<?php
get_footer();
