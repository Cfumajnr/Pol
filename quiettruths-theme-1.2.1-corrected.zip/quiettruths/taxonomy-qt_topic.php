<?php
/**
 * Topic archive.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

get_template_part( 'template-parts/archive/header' );
?>

<div class="qt-layout">
	<div class="qt-layout__main">
		<?php if ( have_posts() ) : ?>
			<div class="qt-stream__list">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content/card', 'list' );
				endwhile;
				?>
			</div>

			<?php quiettruths_pagination(); ?>
		<?php else : ?>
			<?php quiettruths_no_results(); ?>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
