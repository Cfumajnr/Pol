# Quiet Truths 1.2.1 — test results

Executed locally on 21 September 2026 against the corrected theme.

## Environment

- WordPress 7.1.1 (actual downloaded core and installed database, not API stubs)
- PHP 8.4.24
- MariaDB 11.8.6
- Headless Chromium through Playwright
- PHP development HTTP server; WordPress debug logging enabled
- Test-only interception of outgoing mail for successful-submission flows; separate failed-mail simulation

No test installation, development credentials, fixtures or email-interception plugin is included in this ZIP.

## Results

| Check | Result |
|---|---|
| PHP syntax | 48 files passed |
| JavaScript syntax | 2 files passed |
| WordPress/PHP integration assertions | 40 passed, 0 failed |
| Core browser/HTTP assertions | 39 passed, 0 failed |
| Extended browser/HTTP assertions | 15 passed, 0 failed |
| Original subscriber-schema migration assertions | 2 passed |
| Concurrent vote test | 24 independent requests, 24 successful increments; total rose from 1 to 25 |
| Final WordPress debug log during test run | No recorded PHP warnings/fatal errors |

## Tested behaviors

- Corrected theme activation and additive subscriber migration.
- Original-schema confirmed record retained and given an unsubscribe token when needed.
- Human/ISO date handling without the destructive global date filter.
- Strict poll index checks, missing/valid nonce checks, missing/closed/duplicate/rate-limited poll responses, Close/reopen behavior.
- Real browser REST/AJAX voting and native no-JavaScript POST voting both persist counts.
- Archive sidebar poll script loads and binds.
- Serialized concurrent voting across independent PHP processes.
- Newsletter shared service: enabled/disabled, valid/invalid nonce, email validation, resend limit, pending state, consent version, failed mail submission.
- Confirmation: wrong, valid, replayed and expired tokens.
- Unsubscribe: wrong token rejected; browser GET shows confirmation; POST deletes record.
- CSV streamed as a real download, beginning with CSV headers rather than dashboard HTML; only confirmed records; private unsubscribe URL per exported record.
- Spreadsheet-formula neutralization and unchanged normal email cells.
- Unauthenticated CSV access denied.
- Mobile navigation with JS on/off, opening/closing, Escape behavior.
- Main/header/footer sibling landmarks and no homepage horizontal overflow at 360px, 768px and 1440px.
- Homepage, article, page, search, county, leader, investigation, event, past-event and election views render.
- Leader page-2 link and response; county page-2 canonical preserved.
- Upcoming/ongoing versus past-event query behavior including missing/empty end dates.
- Cache namespace invalidation and private/no-store headers on interactive pages.

## Not certified by these tests

- Real email inbox delivery, SPF/DKIM/DMARC, campaign sending, or external subscriber-list synchronization.
- Production LiteSpeed, CDN, Redis, load balancer, database proxy, or multisite behavior.
- WordPress 6.0/PHP 7.4 minimum-version execution; this run used the versions above.
- All plugins, all browsers, complete WCAG conformance, security penetration testing, or legal compliance.
- A secure anonymous source-submission service (not part of the implementation).

Use a staging copy and the README's deployment checklist before updating the production site.
