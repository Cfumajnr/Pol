<?php
/**
 * Performance tuning for LiteSpeed shared hosting.
 *
 * The hosting reality this theme targets: LiteSpeed with LSCache, a modest CPU
 * quota, MySQL on the same box, and readers largely on mobile networks with
 * patchy 3G. The wins that matter here are fewer SQL queries, fewer HTTP
 * requests, and not asking the database for anything a transient can hold.
 *
 * Nothing here requires a caching plugin, but everything here makes LSCache
 * more effective because it shortens the uncached path.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Defer non-critical scripts.
 *
 * WordPress loads theme scripts in the footer already, but `defer` lets the
 * parser finish the document before the file is fetched — which on a slow
 * connection is the difference between a readable page and a blank one.
 *
 * @since 1.0.0
 * @param string $tag    Script tag HTML.
 * @param string $handle Script handle.
 * @param string $src    Source URL.
 * @return string Filtered tag.
 */
function quiettruths_defer_scripts( $tag, $handle, $src ) {
	$defer = array( 'quiettruths-main', 'quiettruths-polls' );

	if ( ! in_array( $handle, $defer, true ) ) {
		return $tag;
	}

	if ( false !== strpos( $tag, ' defer' ) ) {
		return $tag;
	}

	return str_replace( ' src=', ' defer src=', $tag );
}
add_filter( 'script_loader_tag', 'quiettruths_defer_scripts', 10, 3 );

/**
 * Add preconnect hints only when webfonts are actually enabled.
 *
 * @since 1.0.0
 */
function quiettruths_resource_hints() {
	if ( ! get_theme_mod( 'qt_webfonts', false ) ) {
		return;
	}

	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}
add_action( 'wp_head', 'quiettruths_resource_hints', 2 );

/**
 * Remove emoji scripts and the oEmbed discovery links.
 *
 * wp-emoji adds two requests and an inline script to every page for a feature
 * this theme does not use. oEmbed discovery adds a query per page view.
 *
 * @since 1.0.0
 */
function quiettruths_trim_head() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
}
add_action( 'init', 'quiettruths_trim_head' );

/**
 * Cap the revision count.
 *
 * Investigations get rewritten many times, and on shared MySQL an unbounded
 * revisions table is the usual cause of a bloated database and a slow editor.
 *
 * @since 1.0.0
 * @param int $revisions Current cap.
 * @return int New cap.
 */
function quiettruths_revision_limit( $revisions ) {
	return 10;
}
add_filter( 'wp_revisions_to_keep', 'quiettruths_revision_limit' );

/**
 * Transient cache for the front page's secondary loops.
 *
 * The homepage runs four extra queries (investigations, opinion, events,
 * most-read). Caching them for a short window keeps the uncached response fast
 * while still picking up new posts within minutes.
 *
 * @since 1.0.0
 * @param string $key   Cache key.
 * @param array  $args  WP_Query arguments.
 * @param int    $ttl   Optional. Seconds to cache. Default 300.
 * @return WP_Query Query object.
 */
function quiettruths_cached_query( $key, $args, $ttl = 300 ) {
	$cache_key = 'qt_q_' . md5( get_option( 'qt_query_generation', '1' ) . $key . wp_json_encode( $args ) );
	$cached    = get_transient( $cache_key );

	if ( is_array( $cached ) ) {
		$args['post__in']      = $cached;
		$args['orderby']      = 'post__in';
		$args['no_found_rows'] = true;

		return new WP_Query( $args );
	}

	$query = new WP_Query( $args );

	if ( $query->have_posts() ) {
		set_transient( $cache_key, wp_list_pluck( $query->posts, 'ID' ), $ttl );
	}

	return $query;
}

/**
 * Flush the front page caches when anything is published.
 *
 * @since 1.0.0
 * @param int $post_id Post ID.
 */
function quiettruths_flush_query_cache( $post_id ) {
	update_option( 'qt_query_generation', wp_generate_uuid4(), false );
}
add_action( 'save_post', 'quiettruths_flush_query_cache' );
add_action( 'deleted_post', 'quiettruths_flush_query_cache' );
add_action( 'transition_post_status', 'quiettruths_flush_query_cache_on_status', 10, 3 );

/**
 * Flush caches when a post changes status.
 *
 * @since 1.0.0
 * @param string  $new_status New status.
 * @param string  $old_status Old status.
 * @param WP_Post $post       Post object.
 */
function quiettruths_flush_query_cache_on_status( $new_status, $old_status, $post ) {
	if ( $new_status === $old_status ) {
		return;
	}

	quiettruths_flush_query_cache( $post->ID );
}

/**
 * Conservative policy: do not page-cache interactive pages. Disable newsletter
 * and close polls to restore normal caching. Purge upstream caches on upgrades.
 */
function quiettruths_interactive_cache_policy() {
	$tokens = array( 'qt_confirm', 'qt_email', 'qt_notice', 'qt_unsubscribe', 'qt_poll_notice', 'qt_subscribed', 'qt_already' );
	foreach ( $tokens as $key ) {
		if ( isset( $_GET[ $key ] ) ) { quiettruths_private_response(); return; }
	}
	if ( ! is_admin() && ( get_theme_mod( 'qt_newsletter_enable', false ) || quiettruths_get_active_poll() ) ) {
		quiettruths_private_response();
	}
}
add_action( 'init', 'quiettruths_interactive_cache_policy', 1 );
