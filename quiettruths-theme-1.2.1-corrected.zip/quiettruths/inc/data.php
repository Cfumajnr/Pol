<?php
/**
 * Reference data for the coverage area.
 *
 * SCOPE — FIVE COUNTIES
 *
 * Quiet Truths covers the four counties of the former Western Province
 * (Kakamega, Vihiga, Bungoma, Busia) plus Trans Nzoia. That is the editorial
 * bet: five counties covered properly beats ten covered thinly, especially with
 * an election eleven months away.
 *
 * Trans Nzoia is included deliberately even though it sits in the former Rift
 * Valley Province. It is Western Kenya in every sense that matters to this
 * publication — economy, politics, electorate — and excluding it on the basis
 * of a provincial boundary abolished in 2013 would be administrative nostalgia
 * rather than editorial strategy.
 *
 * Deliberately OUT of scope: the six former Nyanza counties (Siaya, Kisumu,
 * Homa Bay, Migori, Kisii, Nyamira). Post-Raila Nyanza is a separate political
 * universe and covering it would dilute the region this site exists to serve.
 *
 * DATA PROVENANCE — read this before editing:
 *  - population, area_km2 and density come from the 2019 Kenya Population and
 *    Housing Census (KNBS, Volume I). They are the last official figures and
 *    should only change after the 2029 census or an official KNBS revision.
 *  - capital means the county headquarters, which is not always the town the
 *    county is named after. Vihiga's headquarters is Mbale, not Vihiga Town.
 *    Verify against the county's own site before changing one.
 *  - governor / deputy / party are current-officeholder facts that CHANGE.
 *    Override them via the `quiettruths_counties` filter from a child theme
 *    rather than editing this file, so a theme update cannot revert a correction.
 *  - `key_issues` are standing editorial themes for the desk, not allegations.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return the full county dataset.
 *
 * @since 1.0.0
 * @return array<int, array<string, mixed>> Keyed by lowercase county slug.
 */
function quiettruths_counties() {
	static $cached = null;

	if ( null !== $cached ) {
		return $cached;
	}

	$counties = array(
		'kakamega'    => array(
			'slug'           => 'kakamega',
			'code'           => '037',
			'name'           => 'Kakamega',
			'capital'        => 'Kakamega Town',
			'governor'       => 'Fernandes Barasa',
			'deputy'         => 'Ayub Savula',
			'party'          => 'ODM',
			'population'     => 1867579,
			'area_km2'       => 3020.0,
			'density'        => 618,
			'constituencies' => 12,
			'region'         => 'Western',
			'communities'    => array( 'Luhya (Bukusu, Isukha, Idakho, Kabras, Marachi, Wanga)' ),
			'economy'        => 'Sugarcane, maize, dairy, small-scale gold mining at Kakamega Forest and Shinyalu',
			'key_issues'     => array( 'Sugar sector & miller debt', 'Kakamega Forest conservation', 'Mumias revival', 'Youth unemployment' ),
			'blurb'          => 'The most populous county in the region and the heart of the Luhya vote. Sugar has shaped its politics for a century.',
		),
		'vihiga'      => array(
			'slug'           => 'vihiga',
			'code'           => '038',
			'name'           => 'Vihiga',
			// County headquarters is Mbale, not Vihiga Town. Source: vihiga.go.ke.
			'capital'        => 'Mbale',
			'governor'       => 'Wilber Ottichilo',
			'deputy'         => 'Patrick Saisi',
			'party'          => 'ODM',
			'population'     => 590013,
			'area_km2'       => 563.8,
			'density'        => 1047,
			'constituencies' => 5,
			'region'         => 'Western',
			'communities'    => array( 'Luhya (Maragoli, Tiriki, Mbale)' ),
			'economy'        => 'Intensive smallholder farming, quarrying, tea, remittances',
			'key_issues'     => array( 'Land fragmentation & food security', 'Quarry revenue', 'Devolved health financing' ),
			'blurb'          => 'The smallest county by land area and the most densely populated in Kenya — over a thousand people per square kilometre.',
		),
		'bungoma'     => array(
			'slug'           => 'bungoma',
			'code'           => '039',
			'name'           => 'Bungoma',
			'capital'        => 'Bungoma Town',
			'governor'       => 'Kenneth Lusaka',
			'deputy'         => '',
			'party'          => 'FORD Kenya',
			'population'     => 1670570,
			'area_km2'       => 3023.9,
			'density'        => 552,
			'constituencies' => 9,
			'region'         => 'Western',
			'communities'    => array( 'Luhya (Bukusu, Sabiny)' ),
			'economy'        => 'Sugarcane, maize, dairy, Mount Elgon tourism, cross-border trade with Uganda',
			'key_issues'     => array( 'Sugar outgrower payments', 'Mount Elgon land & conservation', 'Cross-border trade with Uganda' ),
			'blurb'          => 'Home to Mount Elgon and the Bukusu community. The only county in the region whose governor sits outside ODM.',
		),
		'busia'       => array(
			'slug'           => 'busia',
			'code'           => '040',
			'name'           => 'Busia',
			'capital'        => 'Busia Town',
			'governor'       => 'Paul Otuoma',
			'deputy'         => '',
			'party'          => 'ODM',
			'population'     => 893681,
			'area_km2'       => 1696.3,
			'density'        => 527,
			'constituencies' => 7,
			'region'         => 'Western',
			'communities'    => array( 'Luhya (Samia, Marachi, Abanyala, Tachoni)' ),
			'economy'        => 'Border trade at Busia and Malaba, fishing on Lake Victoria, cotton revival',
			'key_issues'     => array( 'Border trade & revenue', 'Lake Victoria fishing rights', 'Cotton ginnery revival' ),
			'blurb'          => 'Kenya\'s western gateway. Two of the busiest land borders into Uganda decide much of its economic fate.',
		),
		'trans-nzoia' => array(
			'slug'           => 'trans-nzoia',
			'code'           => '026',
			'name'           => 'Trans Nzoia',
			'capital'        => 'Kitale',
			'governor'       => 'George Natembeya',
			'deputy'         => '',
			'party'          => 'DAP-K',
			'population'     => 1054848,
			'area_km2'       => 2495.2,
			'density'        => 423,
			'constituencies' => 5,
			'region'         => 'Rift Valley (former province) — covered as Western Kenya',
			'communities'    => array( 'Bukusu, Sabiny, Sabaot, Luhya, Kalenjin' ),
			'economy'        => 'Maize and wheat basket, dairy, Cherangani Hills forestry, cross-border trade',
			'key_issues'     => array( 'Maize prices & storage', 'Cherangani Hills land and forests', 'Sabaot land grievances', 'Farm input costs' ),
			'blurb'          => 'Kenya\'s maize and wheat basket, and the swing county that decides whether Western Kenya speaks with one voice.',
		),
	);

	/**
	 * Filter the county dataset.
	 *
	 * Lets a child theme, a plugin or a Customizer override refresh officeholders
	 * without editing theme files. Always run officeholder facts through this
	 * filter rather than duplicating the array in templates.
	 *
	 * @since 1.0.0
	 * @param array $counties County dataset keyed by slug.
	 */
	$cached = apply_filters( 'quiettruths_counties', $counties );

	return $cached;
}

/**
 * Get one county by slug.
 *
 * @since 1.0.0
 * @param string $slug County slug, e.g. 'trans-nzoia'.
 * @return array|null County row, or null when the slug is unknown.
 */
function quiettruths_get_county( $slug ) {
	$counties = quiettruths_counties();
	$slug     = sanitize_title( (string) $slug );

	return isset( $counties[ $slug ] ) ? $counties[ $slug ] : null;
}

/**
 * The taxonomy term slug used for a county.
 *
 * County terms use the plain county slug, which is what puts the county name in
 * the URL: /county/trans-nzoia/ rather than /county/qt-trans-nzoia/. For a site
 * whose brand is being the record, the canonical URL is part of the product.
 *
 * @since 1.0.0
 * @param string $slug County slug.
 * @return string Term slug.
 */
function quiettruths_county_term_slug( $slug ) {
	return sanitize_title( (string) $slug );
}

/**
 * The public archive URL for a county.
 *
 * Every county link in the theme goes through here, so the URL shape is decided
 * in exactly one place. Returns an empty string when the term does not exist
 * yet, which lets callers de-link a card instead of printing a dead href.
 *
 * @since 1.0.0
 * @param string $slug County slug.
 * @return string Archive URL, or '' when the term is missing.
 */
function quiettruths_county_link( $slug ) {
	$link = get_term_link( quiettruths_county_term_slug( $slug ), 'qt_county' );

	if ( is_wp_error( $link ) ) {
		return '';
	}

	return (string) $link;
}

/**
 * Map a slug back to its human-readable county name.
 *
 * @since 1.0.0
 * @param string $slug County slug.
 * @return string County name, or the slug prettified when unknown.
 */
function quiettruths_county_name( $slug ) {
	$county = quiettruths_get_county( $slug );

	if ( $county ) {
		return $county['name'];
	}

	return ucwords( str_replace( '-', ' ', (string) $slug ) );
}

/**
 * Format an integer with thousands separators.
 *
 * @since 1.0.0
 * @param int|float $number Number to format.
 * @return string Formatted number.
 */
function quiettruths_number( $number ) {
	return number_format( (float) $number, 0, '.', ',' );
}

/**
 * Aggregate stats across the covered counties.
 *
 * @since 1.0.0
 * @return array{counties:int,population:int,area_km2:float,constituencies:int}
 */
function quiettruths_region_totals() {
	$totals = array(
		'counties'       => 0,
		'population'     => 0,
		'area_km2'       => 0.0,
		'constituencies' => 0,
	);

	foreach ( quiettruths_counties() as $county ) {
		$totals['counties']++;
		$totals['population']     += (int) $county['population'];
		$totals['area_km2']       += (float) $county['area_km2'];
		$totals['constituencies'] += (int) $county['constituencies'];
	}

	return $totals;
}
