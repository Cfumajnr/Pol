<?php
/**
 * Sidebars and theme widgets.
 *
 * Four widget areas plus three purpose-built widgets: the county index, the
 * investigations desk and the current poll. All three render server-side and
 * work with the classic Widgets screen and the block editor's widget areas.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register widget areas.
 *
 * @since 1.0.0
 */
function quiettruths_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Article sidebar', 'quiettruths' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Appears beside articles, county archives and the leaders directory.', 'quiettruths' ),
		'before_widget' => '<section id="%1$s" class="qt-widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="qt-widget__title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Home — lower rail', 'quiettruths' ),
		'id'            => 'sidebar-home',
		'description'   => __( 'Appears in the right column of the front page.', 'quiettruths' ),
		'before_widget' => '<section id="%1$s" class="qt-widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="qt-widget__title">',
		'after_title'   => '</h2>',
	) );

	/*
	 * The footer has no widget areas by design. It is three fixed columns
	 * defined in footer.php, because the outlet column (About, Standards,
	 * Corrections, Contact, Privacy) is not something an editor should be able
	 * to delete by dragging.
	 */
}
add_action( 'widgets_init', 'quiettruths_widgets_init' );

/**
 * Widget: county index.
 *
 * @since 1.0.0
 */
class QuietTruths_County_Widget extends WP_Widget {

	/**
	 * Set up the widget.
	 */
	public function __construct() {
		parent::__construct(
			'qt_county_widget',
			__( 'Quiet Truths: County Index', 'quiettruths' ),
			array( 'description' => __( 'Lists the five covered counties with populations.', 'quiettruths' ) )
		);
	}

	/**
	 * Front-end output.
	 *
	 * @param array $args     Widget area arguments.
	 * @param array $instance Saved settings.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- registered markup.

		$title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Counties', 'quiettruths' );

		echo $args['before_title'] . esc_html( apply_filters( 'widget_title', $title ) ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		echo '<ul class="qt-widget-list">';

		foreach ( quiettruths_counties() as $county ) {
			$link = quiettruths_county_link( $county['slug'] );

			if ( '' === $link ) {
				continue;
			}

			printf(
				'<li><a href="%1$s"><span>%2$s</span><small>%3$s</small></a></li>',
				esc_url( $link ),
				esc_html( $county['name'] ),
				esc_html( quiettruths_number( $county['population'] ) )
			);
		}

		echo '</ul>';
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- registered markup.
	}

	/**
	 * Settings form.
	 *
	 * @param array $instance Saved settings.
	 * @return string Always 'form'.
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : __( 'Counties', 'quiettruths' );

		printf(
			'<p><label for="%1$s">%2$s</label><input class="widefat" id="%1$s" name="%3$s" type="text" value="%4$s" /></p>',
			esc_attr( $this->get_field_id( 'title' ) ),
			esc_html__( 'Title', 'quiettruths' ),
			esc_attr( $this->get_field_name( 'title' ) ),
			esc_attr( $title )
		);

		return 'form';
	}

	/**
	 * Save settings.
	 *
	 * @param array $new_instance New settings.
	 * @param array $old_instance Old settings.
	 * @return array Sanitized settings.
	 */
	public function update( $new_instance, $old_instance ) {
		unset( $old_instance );

		$instance          = array();
		$instance['title'] = sanitize_text_field( $new_instance['title'] ?? '' );

		return $instance;
	}
}

/**
 * Widget: investigations desk.
 *
 * @since 1.0.0
 */
class QuietTruths_Investigations_Widget extends WP_Widget {

	/**
	 * Set up the widget.
	 */
	public function __construct() {
		parent::__construct(
			'qt_investigations_widget',
			__( 'Quiet Truths: Investigations Desk', 'quiettruths' ),
			array( 'description' => __( 'Latest investigations, with a tip-line call to action.', 'quiettruths' ) )
		);
	}

	/**
	 * Front-end output.
	 *
	 * @param array $args     Widget area arguments.
	 * @param array $instance Saved settings.
	 */
	public function widget( $args, $instance ) {
		$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 4;
		$number = $number > 0 ? min( $number, 10 ) : 4;

		$query = new WP_Query( array(
			'post_type'      => 'qt_investigation',
			'posts_per_page' => $number,
			'no_found_rows'  => true,
		) );

		if ( ! $query->have_posts() ) {
			wp_reset_postdata();
			return;
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- registered markup.
		echo $args['before_title'] . esc_html( isset( $instance['title'] ) && $instance['title'] ? $instance['title'] : __( 'Investigations', 'quiettruths' ) ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		echo '<ul class="qt-widget-list qt-widget-list--investigations">';

		while ( $query->have_posts() ) {
			$query->the_post();

			printf(
				'<li><a href="%1$s">%2$s</a><small>%3$s</small></li>',
				esc_url( get_permalink() ),
				esc_html( get_the_title() ),
				esc_html( get_the_date() )
			);
		}

		echo '</ul>';

		wp_reset_postdata();

		printf(
			'<p class="qt-widget__tip"><a href="%1$s">%2$s</a></p>',
			esc_url( get_post_type_archive_link( 'qt_investigation' ) ),
			esc_html__( 'See the full desk &rarr;', 'quiettruths' )
		);

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- registered markup.
	}

	/**
	 * Settings form.
	 *
	 * @param array $instance Saved settings.
	 * @return string Always 'form'.
	 */
	public function form( $instance ) {
		$title  = isset( $instance['title'] ) ? $instance['title'] : __( 'Investigations', 'quiettruths' );
		$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 4;

		printf(
			'<p><label for="%1$s">%2$s</label><input class="widefat" id="%1$s" name="%3$s" type="text" value="%4$s" /></p>',
			esc_attr( $this->get_field_id( 'title' ) ),
			esc_html__( 'Title', 'quiettruths' ),
			esc_attr( $this->get_field_name( 'title' ) ),
			esc_attr( $title )
		);

		printf(
			'<p><label for="%1$s">%2$s</label><input class="tiny-text" id="%1$s" name="%3$s" type="number" min="1" max="10" value="%4$s" /></p>',
			esc_attr( $this->get_field_id( 'number' ) ),
			esc_html__( 'How many to show', 'quiettruths' ),
			esc_attr( $this->get_field_name( 'number' ) ),
			esc_attr( $number )
		);

		return 'form';
	}

	/**
	 * Save settings.
	 *
	 * @param array $new_instance New settings.
	 * @param array $old_instance Old settings.
	 * @return array Sanitized settings.
	 */
	public function update( $new_instance, $old_instance ) {
		unset( $old_instance );

		$instance           = array();
		$instance['title']  = sanitize_text_field( $new_instance['title'] ?? '' );
		$instance['number'] = absint( $new_instance['number'] ?? 4 );

		return $instance;
	}
}

/**
 * Widget: active poll.
 *
 * @since 1.0.0
 */
class QuietTruths_Poll_Widget extends WP_Widget {

	/**
	 * Set up the widget.
	 */
	public function __construct() {
		parent::__construct(
			'qt_poll_widget',
			__( 'Quiet Truths: Reader Poll', 'quiettruths' ),
			array( 'description' => __( 'Shows the poll marked active in the Polls admin screen.', 'quiettruths' ) )
		);
	}

	/**
	 * Front-end output.
	 *
	 * @param array $args     Widget area arguments.
	 * @param array $instance Saved settings.
	 */
	public function widget( $args, $instance ) {
		$poll = quiettruths_get_active_poll();

		if ( empty( $poll ) ) {
			return;
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- registered markup.
		echo $args['before_title'] . esc_html( isset( $instance['title'] ) && $instance['title'] ? $instance['title'] : __( 'Your view', 'quiettruths' ) ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		quiettruths_render_poll( $poll );

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- registered markup.
	}

	/**
	 * Settings form.
	 *
	 * @param array $instance Saved settings.
	 * @return string Always 'form'.
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? $instance['title'] : __( 'Your view', 'quiettruths' );

		printf(
			'<p><label for="%1$s">%2$s</label><input class="widefat" id="%1$s" name="%3$s" type="text" value="%4$s" /></p>',
			esc_attr( $this->get_field_id( 'title' ) ),
			esc_html__( 'Title', 'quiettruths' ),
			esc_attr( $this->get_field_name( 'title' ) ),
			esc_attr( $title )
		);

		echo '<p class="description">' . esc_html__( 'The poll itself is managed under Tools → Quiet Truths Polls.', 'quiettruths' ) . '</p>';

		return 'form';
	}

	/**
	 * Save settings.
	 *
	 * @param array $new_instance New settings.
	 * @param array $old_instance Old settings.
	 * @return array Sanitized settings.
	 */
	public function update( $new_instance, $old_instance ) {
		unset( $old_instance );

		$instance          = array();
		$instance['title'] = sanitize_text_field( $new_instance['title'] ?? '' );

		return $instance;
	}
}

/**
 * Register the theme widgets.
 *
 * @since 1.0.0
 */
function quiettruths_register_widgets() {
	register_widget( 'QuietTruths_County_Widget' );
	register_widget( 'QuietTruths_Investigations_Widget' );
	register_widget( 'QuietTruths_Poll_Widget' );
}
add_action( 'widgets_init', 'quiettruths_register_widgets' );
