<?php
/** Shared request, locking and rate-limit utilities. @package QuietTruths */
defined( 'ABSPATH' ) || exit;

/** Only scalar request values are accepted. */
function quiettruths_input( $source, $key, $default = '' ) {
	return isset( $source[ $key ] ) && is_scalar( $source[ $key ] ) ? wp_unslash( (string) $source[ $key ] ) : $default;
}

/**
 * Serialize read/modify/write operations across PHP workers on MySQL/MariaDB.
 * A failed/unsupported lock fails closed; finally releases on every return path.
 * Reentrant within this request. Do not call exit/die inside the callback.
 */
function quiettruths_with_lock( $resource, $callback ) {
	global $wpdb;
	static $held = array();
	$name = 'qt_' . md5( DB_NAME . $wpdb->prefix . $resource );
	if ( isset( $held[ $name ] ) ) {
		return call_user_func( $callback );
	}
	if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $name ) ) ) {
		return new WP_Error( 'qt_busy', __( 'This service is busy. Please try again shortly.', 'quiettruths' ), array( 'status' => 503 ) );
	}
	$held[ $name ] = true;
	try {
		return call_user_func( $callback );
	} finally {
		unset( $held[ $name ] );
		$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $name ) );
	}
}

/** Fixed-window, serialized best-effort IP/address throttle; not identity proof. */
function quiettruths_rate_limit( $key, $limit, $seconds ) {
	$key = 'qt_rate_' . hash_hmac( 'sha256', $key, wp_salt( 'auth' ) );
	return quiettruths_with_lock( $key, function () use ( $key, $limit, $seconds ) {
		$state = get_transient( $key );
		if ( ! is_array( $state ) || $state['until'] <= time() ) {
			$state = array( 'hits' => 0, 'until' => time() + $seconds );
		}
		if ( $state['hits'] >= $limit ) {
			return new WP_Error( 'qt_rate', __( 'Too many attempts. Please try again later.', 'quiettruths' ), array( 'status' => 429 ) );
		}
		$state['hits']++;
		set_transient( $key, $state, max( 1, $state['until'] - time() ) );
		return true;
	} );
}

/** Prevent personalized/token/form responses entering supported page caches. */
function quiettruths_private_response() {
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	if ( ! headers_sent() ) {
		nocache_headers();
		header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
		header( 'Referrer-Policy: no-referrer' );
	}
	do_action( 'litespeed_control_set_nocache', 'quiettruths-interactive' );
}
