<?php
/** Newsletter capture and subscriber administration. @package QuietTruths */
defined( 'ABSPATH' ) || exit;

function quiettruths_subscribers_table() {
	global $wpdb;
	return $wpdb->prefix . 'qt_subscribers';
}

/** Additive migration: preserves existing subscribers and their statuses. */
function quiettruths_create_subscribers_table() {
	global $wpdb;
	$table = quiettruths_subscribers_table();
	$charset = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE {$table} (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		email VARCHAR(191) NOT NULL,
		email_hash CHAR(32) NOT NULL,
		county VARCHAR(64) NOT NULL DEFAULT '',
		source VARCHAR(64) NOT NULL DEFAULT '',
		status VARCHAR(16) NOT NULL DEFAULT 'pending',
		consented TINYINT(1) NOT NULL DEFAULT 0,
		consent_version VARCHAR(32) NOT NULL DEFAULT '',
		confirm_key CHAR(32) NOT NULL DEFAULT '',
		confirm_expires BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
		unsubscribe_key CHAR(64) NOT NULL DEFAULT '',
		ip_hash CHAR(64) NOT NULL DEFAULT '',
		created DATETIME NOT NULL,
		confirmed DATETIME NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY email_hash (email_hash),
		KEY status (status),
		KEY county (county)
	) {$charset};";
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
	$column = $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE 'unsubscribe_key'" );
	if ( $column ) { update_option( 'qt_subscriber_schema', '1.2.1', false ); }
}
add_action( 'after_switch_theme', 'quiettruths_create_subscribers_table' );

function quiettruths_newsletter_upgrade() {
	if ( '1.2.1' !== get_option( 'qt_subscriber_schema' ) && current_user_can( 'manage_options' ) ) {
		quiettruths_create_subscribers_table();
	}
}
add_action( 'admin_init', 'quiettruths_newsletter_upgrade' );

/** Store/resend one pending request. Serialization protects concurrent resends. */
function quiettruths_subscribe( $email, $county = '', $source = '' ) {
	return quiettruths_with_lock( 'subscriber-' . strtolower( $email ), function () use ( $email, $county, $source ) {
		return quiettruths_subscribe_locked( $email, $county, $source );
	} );
}

function quiettruths_subscribe_locked( $email, $county, $source ) {
	global $wpdb;
	if ( ! is_email( $email ) || strlen( $email ) > 191 ) {
		return new WP_Error( 'qt_bad_email', __( 'Enter a valid email address.', 'quiettruths' ), array( 'status' => 400 ) );
	}
	if ( '1.2.1' !== get_option( 'qt_subscriber_schema' ) ) {
		return new WP_Error( 'qt_setup', __( 'Signups are temporarily unavailable. Please contact the desk.', 'quiettruths' ), array( 'status' => 503 ) );
	}
	$county = array_key_exists( $county, quiettruths_counties() ) ? $county : '';
	$source = substr( sanitize_key( $source ), 0, 64 );
	$table = quiettruths_subscribers_table();
	$hash = md5( strtolower( $email ) );
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE email_hash = %s", $hash ) );
	if ( $row && 'confirmed' === $row->status ) {
		return 'received'; // Same public message avoids exposing list membership.
	}
	$limited = quiettruths_rate_limit( 'newsletter-address-' . $hash, 1, 300 );
	if ( is_wp_error( $limited ) ) { return $limited; }
	$data = array(
		'email' => $email, 'email_hash' => $hash, 'county' => $county,
		'source' => $source, 'status' => 'pending', 'consented' => 1,
		'consent_version' => 'newsletter-1.2.1',
		'confirm_key' => bin2hex( random_bytes( 16 ) ),
		'confirm_expires' => time() + DAY_IN_SECONDS,
		'ip_hash' => hash_hmac( 'sha256', quiettruths_client_ip(), wp_salt( 'auth' ) ),
		'created' => current_time( 'mysql' ), 'confirmed' => null,
	);
	// Keep a previously issued unsubscribe token valid during re-subscription.
	$data['unsubscribe_key'] = $row && $row->unsubscribe_key ? $row->unsubscribe_key : bin2hex( random_bytes( 32 ) );
	$saved = $row ? $wpdb->update( $table, $data, array( 'id' => $row->id ) ) : $wpdb->insert( $table, $data );
	if ( false === $saved ) {
		return new WP_Error( 'qt_insert_failed', __( 'We could not save your request. Please try again.', 'quiettruths' ), array( 'status' => 503 ) );
	}
	if ( ! quiettruths_send_confirmation( $email, $county ) ) {
		return new WP_Error( 'qt_mail_failed', __( 'We saved your request but could not submit the confirmation email. Please retry after five minutes or contact the desk.', 'quiettruths' ), array( 'status' => 503 ) );
	}
	return 'received';
}

function quiettruths_send_confirmation( $email, $county = '' ) {
	global $wpdb;
	$table = quiettruths_subscribers_table();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT confirm_key FROM {$table} WHERE email_hash = %s AND status = 'pending'", md5( strtolower( $email ) ) ) );
	if ( ! $row || ! $row->confirm_key ) { return false; }
	$link = add_query_arg( array( 'qt_confirm' => $row->confirm_key, 'qt_email' => md5( strtolower( $email ) ) ), home_url( '/' ) );
	$subject = sprintf( __( 'Confirm your %s subscription', 'quiettruths' ), get_bloginfo( 'name' ) );
	$message = __( 'You requested the Quiet Truths newsletter. Confirm within 24 hours:', 'quiettruths' ) . "\n\n" . $link . "\n\n";
	$message .= __( 'If you did not request this, ignore this email. To request a new link, sign up again after five minutes. Ordinary email delivery is not guaranteed.', 'quiettruths' );
	return wp_mail( $email, $subject, $message, array( 'Content-Type: text/plain; charset=UTF-8' ) );
}

/** Pure result helper so invalid/expired/database outcomes can be tested. */
function quiettruths_confirm_subscriber( $hash, $key ) {
	global $wpdb;
	if ( ! preg_match( '/^[a-f0-9]{32}$/D', $hash ) || ! preg_match( '/^[a-f0-9]{32}$/D', $key ) ) {
		return 'invalid';
	}
	$table = quiettruths_subscribers_table();
	$n = $wpdb->query( $wpdb->prepare(
		"UPDATE {$table} SET status = 'confirmed', confirmed = %s, confirm_key = '', confirm_expires = 0 WHERE email_hash = %s AND BINARY confirm_key = %s AND status = 'pending' AND confirm_expires >= %d",
		current_time( 'mysql' ), $hash, $key, time()
	) );
	return false === $n ? 'error' : ( 1 === $n ? 'confirmed' : 'invalid' );
}

function quiettruths_handle_confirmation() {
	if ( ! isset( $_GET['qt_confirm'] ) ) { return; }
	quiettruths_private_response();
	$state = quiettruths_confirm_subscriber( quiettruths_input( $_GET, 'qt_email' ), quiettruths_input( $_GET, 'qt_confirm' ) );
	wp_safe_redirect( add_query_arg( 'qt_notice', $state, home_url( '/' ) ), 303 );
	exit;
}
add_action( 'init', 'quiettruths_handle_confirmation', 5 );

function quiettruths_newsletter_messages() {
	return array(
		'received' => __( 'Request received. If confirmation is needed, check your inbox and spam folder. You can request another link after five minutes.', 'quiettruths' ),
		'confirmed' => __( 'Your subscription is confirmed. Thank you.', 'quiettruths' ),
		'invalid' => __( 'This confirmation link is invalid, expired, or already used. Sign up again if you still need a link.', 'quiettruths' ),
		'error' => __( 'We could not complete that request. Please try again or contact the desk.', 'quiettruths' ),
		'unsubscribed' => __( 'You have been removed from this newsletter list.', 'quiettruths' ),
	);
}

function quiettruths_confirmation_notice() {
	$state = quiettruths_input( $_GET, 'qt_notice' );
	$messages = quiettruths_newsletter_messages();
	if ( isset( $messages[ $state ] ) ) {
		echo '<div class="qt-notice" role="status"><p>' . esc_html( $messages[ $state ] ) . '</p></div>';
	}
}
add_action( 'wp_body_open', 'quiettruths_confirmation_notice' );

/** One shared gate for AJAX and native POST. No public request bypasses limits. */
function quiettruths_process_signup() {
	if ( ! get_theme_mod( 'qt_newsletter_enable', false ) ) {
		return new WP_Error( 'qt_disabled', __( 'Newsletter signup is currently closed.', 'quiettruths' ), array( 'status' => 403 ) );
	}
	if ( ! wp_verify_nonce( quiettruths_input( $_POST, 'qt_newsletter_nonce' ), 'qt_newsletter' ) ) {
		return new WP_Error( 'qt_nonce', __( 'This form has expired. Reload the page and try again.', 'quiettruths' ), array( 'status' => 403 ) );
	}
	if ( quiettruths_input( $_POST, 'qt_website' ) ) { return 'received'; }
	$limit = quiettruths_rate_limit( 'newsletter-ip-' . quiettruths_client_ip(), 5, HOUR_IN_SECONDS );
	if ( is_wp_error( $limit ) ) { return $limit; }
	return quiettruths_subscribe(
		trim( quiettruths_input( $_POST, 'qt_email' ) ),
		sanitize_title( quiettruths_input( $_POST, 'qt_county' ) ),
		sanitize_key( quiettruths_input( $_POST, 'qt_source' ) )
	);
}

function quiettruths_ajax_subscribe() {
	quiettruths_private_response();
	$result = quiettruths_process_signup();
	if ( is_wp_error( $result ) ) {
		$data = $result->get_error_data();
		wp_send_json_error( array( 'message' => $result->get_error_message() ), isset( $data['status'] ) ? $data['status'] : 400 );
	}
	$messages = quiettruths_newsletter_messages();
	wp_send_json_success( array( 'message' => $messages['received'] ) );
}
add_action( 'wp_ajax_qt_subscribe', 'quiettruths_ajax_subscribe' );
add_action( 'wp_ajax_nopriv_qt_subscribe', 'quiettruths_ajax_subscribe' );

function quiettruths_handle_posted_signup() {
	quiettruths_private_response();
	$result = quiettruths_process_signup();
	if ( is_wp_error( $result ) ) {
		$data = $result->get_error_data();
		wp_die( esc_html( $result->get_error_message() ), esc_html__( 'Signup not completed', 'quiettruths' ), array( 'response' => isset( $data['status'] ) ? $data['status'] : 400, 'back_link' => true ) );
	}
	$referer = wp_get_referer();
	$back = $referer ? wp_validate_redirect( $referer, home_url( '/' ) ) : home_url( '/' );
	if ( ! $back ) { $back = home_url( '/' ); }
	wp_safe_redirect( add_query_arg( 'qt_notice', 'received', remove_query_arg( array( 'qt_notice', 'qt_subscribed', 'qt_already' ), $back ) ), 303 );
	exit;
}
add_action( 'admin_post_nopriv_qt_subscribe_post', 'quiettruths_handle_posted_signup' );
add_action( 'admin_post_qt_subscribe_post', 'quiettruths_handle_posted_signup' );

/** Bearer-token unsubscribe URLs; tokens must be kept private like addresses. */
function quiettruths_unsubscribe_url( $row ) {
	global $wpdb;
	if ( ! $row->unsubscribe_key ) {
		$key = bin2hex( random_bytes( 32 ) );
		$table = quiettruths_subscribers_table();
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET unsubscribe_key = %s WHERE id = %d AND unsubscribe_key = ''", $key, $row->id ) );
		$row->unsubscribe_key = $wpdb->get_var( $wpdb->prepare( "SELECT unsubscribe_key FROM {$table} WHERE id = %d", $row->id ) );
	}
	if ( ! $row->unsubscribe_key ) { return ''; }
	return add_query_arg( array( 'qt_unsubscribe' => $row->unsubscribe_key, 'qt_email' => $row->email_hash ), home_url( '/' ) );
}

function quiettruths_unsubscribe_subscriber( $hash, $key ) {
	global $wpdb;
	if ( ! preg_match( '/^[a-f0-9]{32}$/D', $hash ) || ! preg_match( '/^[a-f0-9]{64}$/D', $key ) ) { return false; }
	$table = quiettruths_subscribers_table();
	return 1 === $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE email_hash = %s AND BINARY unsubscribe_key = %s", $hash, $key ) );
}

/** GET shows a confirmation; POST removes the row. Link scanners cannot delete. */
function quiettruths_handle_unsubscribe() {
	if ( ! isset( $_GET['qt_unsubscribe'] ) ) { return; }
	quiettruths_private_response();
	$hash = quiettruths_input( $_GET, 'qt_email' );
	$key = quiettruths_input( $_GET, 'qt_unsubscribe' );
	if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) {
		if ( ! wp_verify_nonce( quiettruths_input( $_POST, '_wpnonce' ), 'qt_unsubscribe_' . $hash ) ) {
			wp_die( esc_html__( 'This form expired. Reload the link from your email.', 'quiettruths' ), '', array( 'response' => 403 ) );
		}
		$ok = quiettruths_unsubscribe_subscriber( $hash, $key );
		wp_safe_redirect( add_query_arg( 'qt_notice', $ok ? 'unsubscribed' : 'error', home_url( '/' ) ), 303 );
		exit;
	}
	global $wpdb;
	$table = quiettruths_subscribers_table();
	$row = preg_match( '/^[a-f0-9]{32}$/D', $hash ) && preg_match( '/^[a-f0-9]{64}$/D', $key ) ? $wpdb->get_row( $wpdb->prepare( "SELECT unsubscribe_key FROM {$table} WHERE email_hash = %s", $hash ) ) : null;
	if ( ! $row || ! hash_equals( $row->unsubscribe_key, $key ) ) {
		wp_die( esc_html__( 'This unsubscribe link is invalid or has already been used.', 'quiettruths' ), '', array( 'response' => 400 ) );
	}
	$form = '<form method="post"><p>' . esc_html__( 'Remove your address from the Quiet Truths newsletter?', 'quiettruths' ) . '</p>';
	$form .= wp_nonce_field( 'qt_unsubscribe_' . $hash, '_wpnonce', false, false );
	$form .= '<button type="submit">' . esc_html__( 'Unsubscribe', 'quiettruths' ) . '</button></form>';
	wp_die( $form, esc_html__( 'Unsubscribe', 'quiettruths' ), array( 'response' => 200 ) );
}
add_action( 'init', 'quiettruths_handle_unsubscribe', 5 );

/** Spreadsheet-safe cells: quoting alone does not neutralize formulas. */
function quiettruths_csv_cell( $value ) {
	$value = (string) $value;
	return preg_match( '/^[\s\x00-\x20]*[=+@\-]/u', $value ) ? "'" . $value : $value;
}

function quiettruths_export_subscribers() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not permitted.', '', array( 'response' => 403 ) ); }
	check_admin_referer( 'qt_export_subscribers' );
	quiettruths_private_response();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=quiettruths-confirmed-subscribers-' . gmdate( 'Y-m-d' ) . '.csv' );
	global $wpdb;
	$table = quiettruths_subscribers_table();
	$handle = fopen( 'php://output', 'w' );
	if ( false === $handle ) { wp_die( 'Could not open export.', '', array( 'response' => 500 ) ); }
	fputcsv( $handle, array( 'email', 'county', 'status', 'source', 'created', 'confirmed', 'unsubscribe_url' ), ',', '"', '' );
	$last = 0;
	do {
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = 'confirmed' AND id > %d ORDER BY id ASC LIMIT 200", $last ) );
		foreach ( $rows as $row ) {
			$url = quiettruths_unsubscribe_url( $row );
			// Do not export a mailing row without a working withdrawal token.
			if ( $url ) {
				fputcsv( $handle, array_map( 'quiettruths_csv_cell', array( $row->email, $row->county, $row->status, $row->source, $row->created, $row->confirmed, $url ) ), ',', '"', '' );
			}
			$last = (int) $row->id;
		}
	} while ( count( $rows ) === 200 );
	fclose( $handle );
	exit;
}
add_action( 'admin_post_qt_export_subscribers', 'quiettruths_export_subscribers' );

function quiettruths_delete_subscriber() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not permitted.', '', array( 'response' => 403 ) ); }
	if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) { wp_die( 'POST required.', '', array( 'response' => 405 ) ); }
	$hash = quiettruths_input( $_POST, 'qt_delete' );
	check_admin_referer( 'qt_delete_subscriber_' . $hash );
	if ( ! preg_match( '/^[a-f0-9]{32}$/D', $hash ) ) { wp_die( 'Invalid record.', '', array( 'response' => 400 ) ); }
	global $wpdb;
	$ok = $wpdb->delete( quiettruths_subscribers_table(), array( 'email_hash' => $hash ) );
	if ( 1 !== $ok ) { wp_die( 'The record was not removed. Reload and try again.', '', array( 'response' => 400 ) ); }
	wp_safe_redirect( admin_url( 'tools.php?page=quiettruths-subscribers&qt_deleted=1' ), 303 );
	exit;
}
add_action( 'admin_post_qt_delete_subscriber', 'quiettruths_delete_subscriber' );

/** Unconfirmed requests are retained for no more than about 30 days. */
function quiettruths_cleanup_pending_subscribers() {
	global $wpdb;
	$table = quiettruths_subscribers_table();
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE status = 'pending' AND created < %s", wp_date( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) );
}
add_action( 'qt_cleanup_pending_subscribers', 'quiettruths_cleanup_pending_subscribers' );
function quiettruths_schedule_subscriber_cleanup() {
	if ( '1.2.1' === get_option( 'qt_subscriber_schema' ) && ! wp_next_scheduled( 'qt_cleanup_pending_subscribers' ) ) {
		wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', 'qt_cleanup_pending_subscribers' );
	}
}
add_action( 'init', 'quiettruths_schedule_subscriber_cleanup' );
function quiettruths_unschedule_subscriber_cleanup() { wp_clear_scheduled_hook( 'qt_cleanup_pending_subscribers' ); }
add_action( 'switch_theme', 'quiettruths_unschedule_subscriber_cleanup' );

function quiettruths_newsletter_form( $source = 'inline' ) {
	$source = sanitize_key( (string) $source );
	$form_id = wp_unique_id( 'qt-newsletter-' );

	/*
	 * Off until the editor switches it on. A newsletter is a second
	 * publication: opening signups before two or three issues exist means the
	 * first subscriber's first experience of the brand is silence. The form
	 * renders nothing until then, so nothing on the site promises a briefing
	 * that has not been written.
	 */
	if ( ! get_theme_mod( 'qt_newsletter_enable', false ) ) {
		return;
	}

	// Posts to admin-post.php so a reader with JavaScript disabled still gets
	// through the same validation path; main.js upgrades this to AJAX when it can.
	$action = esc_url( admin_url( 'admin-post.php' ) );

	echo '<form class="qt-newsletter" method="post" action="' . $action . '" data-qt-newsletter data-source="' . esc_attr( $form_id ) . '">';

	echo '<p class="qt-newsletter__pitch">' . esc_html( get_theme_mod( 'qt_newsletter_pitch', __( 'County budgets, tender notices, and what your leaders did — not what they said.', 'quiettruths' ) ) ) . '</p>';

	echo '<div class="qt-newsletter__row">';
	echo '<label class="screen-reader-text" for="qt-newsletter-email-' . esc_attr( $form_id ) . '">' . esc_html__( 'Email address', 'quiettruths' ) . '</label>';
	echo '<input id="qt-newsletter-email-' . esc_attr( $form_id ) . '" class="qt-newsletter__email" type="email" name="qt_email" required autocomplete="email" placeholder="' . esc_attr__( 'you@example.com', 'quiettruths' ) . '" />';

	echo '<label class="screen-reader-text" for="qt-newsletter-county-' . esc_attr( $form_id ) . '">' . esc_html__( 'County', 'quiettruths' ) . '</label>';
	echo '<select id="qt-newsletter-county-' . esc_attr( $form_id ) . '" class="qt-newsletter__county" name="qt_county">';
	echo '<option value="">' . esc_html__( 'Whole region', 'quiettruths' ) . '</option>';

	foreach ( quiettruths_counties() as $county ) {
		printf(
			'<option value="%1$s">%2$s</option>',
			esc_attr( $county['slug'] ),
			esc_html( $county['name'] )
		);
	}

	echo '</select>';
	echo '</div>';

	// Honeypot: a field no human fills in, but most bots do.
	echo '<p class="qt-newsletter__hp" aria-hidden="true"><label>Leave this empty<input type="text" name="qt_website" tabindex="-1" autocomplete="off" /></label></p>';

	echo '<input type="hidden" name="qt_newsletter_nonce" value="' . esc_attr( wp_create_nonce( 'qt_newsletter' ) ) . '">';
	wp_referer_field();
	// `action` drives admin-post.php routing; `qt_action` carries the AJAX name
	// so main.js can reuse it without the two colliding.
	echo '<input type="hidden" name="action" value="qt_subscribe_post" />';
	echo '<input type="hidden" name="qt_action" value="qt_subscribe" />';
	echo '<input type="hidden" name="qt_source" value="' . esc_attr( $source ) . '" />';

	echo '<button type="submit" class="qt-btn qt-btn--accent qt-newsletter__submit">' . esc_html__( 'Sign up', 'quiettruths' ) . '</button>';

	echo '<p class="qt-newsletter__legal">' . esc_html__( 'By signing up, you request the Quiet Truths newsletter. Confirm by email before receiving it. Every newsletter must include an unsubscribe link. We never share the list.', 'quiettruths' ) . '</p>';
	echo '<p><a href="' . esc_url( get_privacy_policy_url() ? get_privacy_policy_url() : home_url( '/privacy/' ) ) . '">' . esc_html__( 'Privacy and withdrawal', 'quiettruths' ) . '</a></p>';
	echo '<p class="qt-newsletter__msg" role="status" aria-live="polite"></p>';

	echo '</form>';
}


function quiettruths_subscriber_admin_menu() {
	add_management_page(
		__( 'Quiet Truths Subscribers', 'quiettruths' ),
		__( 'Subscribers', 'quiettruths' ),
		'manage_options',
		'quiettruths-subscribers',
		'quiettruths_subscriber_admin_page'
	);
}
add_action( 'admin_menu', 'quiettruths_subscriber_admin_menu' );

/**
 * Stream a CSV export of confirmed subscribers, or render the list screen.
 *
 * The export is a direct download rather than a generated file on disk, so a
 * shared host never holds a plaintext list of subscriber addresses in the web
 * root. Capability is re-checked immediately before any row is written.
 *
 * @since 1.0.0
 */
function quiettruths_subscriber_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to view subscribers.', 'quiettruths' ) );
	}

	global $wpdb;

	$table = quiettruths_subscribers_table();

	// --- Render -----------------------------------------------------------
	$page    = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.
	$per     = 30;
	$offset  = ( $page - 1 ) * $per;

	$total  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$counts = $wpdb->get_results( "SELECT status, COUNT(*) AS total FROM {$table} GROUP BY status" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

	$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare( "SELECT email, email_hash, county, status, source, created FROM {$table} ORDER BY created DESC LIMIT %d OFFSET %d", $per, $offset ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is ours.
	);

	echo '<div class="wrap">';
	echo '<h1>' . esc_html__( 'Quiet Truths Subscribers', 'quiettruths' ) . '</h1>';

	if ( isset( $_GET['qt_deleted'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Subscriber removed.', 'quiettruths' ) . '</p></div>';
	}

	echo '<p><strong>' . esc_html( quiettruths_number( $total ) ) . '</strong> ' . esc_html__( 'total', 'quiettruths' );

	foreach ( (array) $counts as $count ) {
		echo ' &middot; ' . esc_html( $count->status ) . ': ' . esc_html( quiettruths_number( (int) $count->total ) );
	}

	echo '</p>';

	printf(
		'<p><a class="button button-primary" href="%s">%s</a></p>',
		esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qt_export_subscribers' ), 'qt_export_subscribers' ) ),
		esc_html__( 'Export confirmed subscribers CSV', 'quiettruths' )
	);

	echo '<p class="description">' . esc_html__( 'Exporting downloads the list and never writes it to the server. Under the Data Protection Act 2019 you must be able to delete a subscriber on request — use the Remove button. Include each exported unsubscribe_url in every email and use a fresh export before every send. External mailing platforms need their own synchronized suppression handling.', 'quiettruths' ) . '</p>';

	echo '<table class="widefat striped"><thead><tr>';
	echo '<th>' . esc_html__( 'Email', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'County', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'Status', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'Source', 'quiettruths' ) . '</th>';
	echo '<th>' . esc_html__( 'Signed up', 'quiettruths' ) . '</th>';
	echo '<th></th>';
	echo '</tr></thead><tbody>';

	if ( empty( $rows ) ) {
		echo '<tr><td colspan="6">' . esc_html__( 'No subscribers yet.', 'quiettruths' ) . '</td></tr>';
	}

	foreach ( (array) $rows as $row ) {
		echo '<tr>';
		echo '<td>' . esc_html( $row->email ) . '</td>';
		echo '<td>' . esc_html( $row->county ? quiettruths_county_name( $row->county ) : '—' ) . '</td>';
		echo '<td>' . esc_html( $row->status ) . '</td>';
		echo '<td>' . esc_html( $row->source ) . '</td>';
		echo '<td>' . esc_html( mysql2date( 'j M Y', $row->created ) ) . '</td>';
		echo '<td><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'qt_delete_subscriber_' . $row->email_hash );
		echo '<input type="hidden" name="action" value="qt_delete_subscriber"><input type="hidden" name="qt_delete" value="' . esc_attr( $row->email_hash ) . '">';
		echo '<button type="submit" class="button-link-delete">' . esc_html__( 'Remove', 'quiettruths' ) . '</button></form></td>';
		echo '</tr>';
	}

	echo '</tbody></table>';

	$pages = (int) ceil( $total / $per );

	if ( $pages > 1 ) {
		echo '<p class="tablenav-pages">';
		echo wp_kses_post( paginate_links( array(
			'base'    => add_query_arg( 'paged', '%#%' ),
			'format'  => '',
			'current' => $page,
			'total'   => $pages,
		) ) );
		echo '</p>';
	}

	echo '</div>';
}
