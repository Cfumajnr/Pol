<?php
/**
 * Single investigation.
 *
 * Gets a distinct treatment from a news post: a dark masthead, a standing
 * documents/sources block, and a prominent tip line, because the point of an
 * investigation page is to make the next one possible.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<article <?php post_class( 'qt-article qt-article--investigation' ); ?>>
		<div class="qt-investigation__masthead">
			<div class="qt-investigation__masthead-inner">
				<?php quiettruths_breadcrumbs(); ?>

				<p class="qt-investigation__kicker"><?php esc_html_e( 'Investigation', 'quiettruths' ); ?></p>

				<h1 class="qt-investigation__title"><?php the_title(); ?></h1>

				<?php if ( has_excerpt() ) : ?>
					<p class="qt-investigation__standfirst"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>

				<?php quiettruths_the_meta(); ?>
				<?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 3 ); ?>
			</div>
		</div>

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="qt-article__hero">
				<?php the_post_thumbnail( 'qt-lead' ); ?>

				<?php
				$qt_caption = get_the_post_thumbnail_caption();

				if ( $qt_caption ) :
					?>
					<figcaption><?php echo esc_html( $qt_caption ); ?></figcaption>
				<?php endif; ?>
			</figure>
		<?php endif; ?>

		<div class="qt-layout">
			<div class="qt-article__body">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<nav class="qt-page-links" aria-label="' . esc_attr__( 'Pages', 'quiettruths' ) . '">',
					'after'  => '</nav>',
				) );
				?>

				<aside class="qt-investigation__method" aria-labelledby="qt-method-title">
					<h2 id="qt-method-title"><?php esc_html_e( 'How we reported this', 'quiettruths' ); ?></h2>
					<p><?php esc_html_e( 'Every Quiet Truths investigation names its sources where it can, publishes the documents it relies on, and corrects itself openly. If you believe we have made an error, tell us — the desk answers every correction request.', 'quiettruths' ); ?></p>
					<p><a class="qt-btn qt-btn--ghost" href="<?php echo esc_url( quiettruths_tip_url( sprintf( /* translators: %s: investigation title. */ __( 'Query about: %s', 'quiettruths' ), get_the_title() ) ) ); ?>"><?php esc_html_e( 'Contact the investigations desk', 'quiettruths' ); ?></a></p>
				</aside>

				<footer class="qt-article__foot">
					<?php quiettruths_the_terms_chips( 'qt_topic', get_the_ID(), 5 ); ?>
				</footer>

				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>

			<?php get_sidebar(); ?>
		</div>
	</article>

	<?php
	get_template_part( 'template-parts/content/related' );

endwhile;

get_footer();
