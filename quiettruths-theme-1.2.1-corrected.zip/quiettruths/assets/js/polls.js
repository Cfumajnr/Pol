/**
 * Quiet Truths — poll interaction.
 *
 * Enqueued whenever a poll renders. Native POST remains available if JS or
 * modern browser APIs are unavailable. Public tokens are not anti-bot proof.
 *
 * @since 1.0.0
 */
( function () {
	'use strict';

	function init() {
		if ( ! window.fetch || ! window.URLSearchParams ) { return; }
		var polls = document.querySelectorAll( '[data-qt-poll], .qt-poll' );

		for ( var i = 0; i < polls.length; i++ ) {
			bind( polls[ i ] );
		}
	}

	/**
	 * Attach a submit handler to one poll form.
	 *
	 * @param {HTMLElement} poll The .qt-poll container.
	 */
	function bind( poll ) {
		var form = poll.querySelector( '.qt-poll__form' );

		if ( ! form || form.getAttribute( 'data-qt-bound' ) === 'true' ) {
			return;
		}

		form.setAttribute( 'data-qt-bound', 'true' );

		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();

			var pollId = poll.getAttribute( 'data-poll-id' );
			var chosen = form.querySelector( 'input[name="qt_poll_option"]:checked' );

			if ( ! pollId || ! chosen ) {
				return;
			}

			var button = form.querySelector( 'button[type="submit"]' );

			if ( button ) {
				button.disabled = true;
			}

			if ( ! window.quietTruthsPolls || ! window.quietTruthsPolls.restUrl ) {
				// No localised endpoint: fall back to a plain POST.
				form.submit();
				return;
			}

			var url = window.quietTruthsPolls.restUrl.replace( /\/$/, '' ) +
				'/poll/' + encodeURIComponent( pollId ) + '/vote';

			var body = new URLSearchParams();
			body.append( 'id', pollId );
			body.append( 'option', chosen.value );
			body.append( 'qt_poll_nonce', ( form.querySelector('[name="qt_poll_nonce"]') || {} ).value || '' );

			window.fetch( url, {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'X-WP-Nonce': window.quietTruthsPolls.nonce || ''
				},
				body: body.toString()
			} ).then( function ( response ) {
				return response.json().then( function ( payload ) {
					return { status: response.status, payload: payload };
				} );
			} ).then( function ( result ) {
				if ( result.status === 200 && result.payload && result.payload.ok ) {
					renderResults( poll, result.payload );
				} else {
					showNotice( poll, ( result.payload && result.payload.message ) || 'Could not record that vote.' );

					if ( button ) {
						button.disabled = false;
					}
				}
			} ).catch( function () {
				showNotice( poll, 'Network problem. Please try again.' );

				if ( button ) {
					button.disabled = false;
				}
			} );
		} );
	}

	/**
	 * Replace the form with result bars.
	 *
	 * @param {HTMLElement} poll    The .qt-poll container.
	 * @param {Object}      payload Server response: { total, options[] }.
	 */
	function renderResults( poll, payload ) {
		var options = payload.options || [];
		var total = payload.total || 0;

		var wrap = document.createElement( 'div' );
		wrap.className = 'qt-poll__results';

		for ( var i = 0; i < options.length; i++ ) {
			var votes = parseInt( options[ i ].votes, 10 ) || 0;
			var percent = total > 0 ? Math.round( ( votes / total ) * 100 ) : 0;

			var row = document.createElement( 'div' );
			row.className = 'qt-poll__row';

			var label = document.createElement( 'span' );
			label.className = 'qt-poll__label';
			label.textContent = options[ i ].label;

			var pct = document.createElement( 'span' );
			pct.className = 'qt-poll__pct';
			pct.textContent = percent + '%';

			var bar = document.createElement( 'span' );
			bar.className = 'qt-poll__bar';

			var fill = document.createElement( 'span' );
			fill.style.width = '0%';

			bar.appendChild( fill );

			var count = document.createElement( 'span' );
			count.className = 'qt-poll__count';
			count.textContent = votes + ( votes === 1 ? ' vote' : ' votes' );

			row.appendChild( label );
			row.appendChild( pct );
			row.appendChild( bar );
			row.appendChild( count );
			wrap.appendChild( row );

			// Animate on the next frame so the transition is visible.
			( function ( fillEl, target ) {
				window.requestAnimationFrame( function () {
					fillEl.style.width = target + '%';
				} );
			} )( fill, percent );
		}

		var totalLine = document.createElement( 'p' );
		totalLine.className = 'qt-poll__total';
		totalLine.textContent = total + ( total === 1 ? ' reader has weighed in' : ' readers have weighed in' );
		wrap.appendChild( totalLine );

		var form = poll.querySelector( '.qt-poll__form' );

		if ( form && form.parentNode ) {
			form.parentNode.replaceChild( wrap, form );
		} else {
			poll.appendChild( wrap );
		}

		poll.setAttribute( 'data-voted', '1' );
	}

	/**
	 * Show an inline error inside a poll.
	 *
	 * @param {HTMLElement} poll The .qt-poll container.
	 * @param {string}      text Message.
	 */
	function showNotice( poll, text ) {
		var existing = poll.querySelector( '.qt-poll__error' );

		if ( ! existing ) {
			existing = document.createElement( 'p' );
			existing.className = 'qt-poll__error qt-poll__note';
			existing.setAttribute( 'role', 'alert' );
			poll.appendChild( existing );
		}

		existing.textContent = text;
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
