<?php
/**
 * Leaders directory.
 *
 * A searchable, filterable index of everyone the region elected or appointed —
 * the page a voter opens before polling day, and the page a journalist opens
 * before writing about a county.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

get_template_part( 'template-parts/archive/header' );
?>

<div class="qt-layout">
	<div class="qt-layout__main">
		<?php quiettruths_county_chips(); ?>

		<?php if ( have_posts() ) : ?>
			<div class="qt-leaders-grid">
				<?php quiettruths_leaders_grid( 60 ); ?>
			</div>
			<?php quiettruths_pagination(); ?>
		<?php else : ?>
			<div class="qt-empty-state">
				<h2><?php esc_html_e( 'The directory is being built', 'quiettruths' ); ?></h2>
				<p><?php esc_html_e( 'Add leaders under Leaders Directory in the dashboard. Each profile takes a county, an office, a party and a public contact detail.', 'quiettruths' ); ?></p>
			</div>
		<?php endif; ?>
	</div>

	<aside class="qt-layout__aside" aria-label="<?php esc_attr_e( 'Directory tools', 'quiettruths' ); ?>">
		<section class="qt-widget">
			<h2 class="qt-widget__title"><?php esc_html_e( 'Find a leader', 'quiettruths' ); ?></h2>
			<?php get_search_form(); ?>
		</section>

		<section class="qt-widget">
			<h2 class="qt-widget__title"><?php esc_html_e( 'The five counties', 'quiettruths' ); ?></h2>
			<ul class="qt-widget-list">
				<?php
				foreach ( quiettruths_counties() as $qt_county ) :
					$qt_link = quiettruths_county_link( $qt_county['slug'] );

					if ( '' === $qt_link ) {
						continue;
					}
					?>
					<li>
						<a href="<?php echo esc_url( $qt_link ); ?>">
							<span><?php echo esc_html( $qt_county['name'] ); ?></span>
							<small><?php echo esc_html( $qt_county['governor'] ); ?></small>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>

		<?php quiettruths_tip_cta(); ?>
	</aside>
</div>

<?php
get_footer();
