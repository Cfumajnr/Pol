<?php
/**
 * The article/archive sidebar.
 *
 * Falls back to a useful default stack when nothing has been assigned, so the
 * column is never an empty gap on a fresh install.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) :
	?>
	<aside class="qt-layout__aside" aria-label="<?php esc_attr_e( 'Sidebar', 'quiettruths' ); ?>">
		<section class="qt-widget">
			<h2 class="qt-widget__title"><?php esc_html_e( 'The five counties', 'quiettruths' ); ?></h2>
			<ul class="qt-widget-list">
				<?php
				foreach ( quiettruths_counties() as $qt_county ) :
					$qt_link = quiettruths_county_link( $qt_county['slug'] );

					if ( '' === $qt_link ) {
						continue;
					}
					?>
					<li>
						<a href="<?php echo esc_url( $qt_link ); ?>">
							<span><?php echo esc_html( $qt_county['name'] ); ?></span>
							<small><?php echo esc_html( quiettruths_number( $qt_county['population'] ) ); ?></small>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>

		<section class="qt-widget">
			<h2 class="qt-widget__title"><?php esc_html_e( 'The weekly briefing', 'quiettruths' ); ?></h2>
			<?php quiettruths_newsletter_form( 'sidebar' ); ?>
		</section>

		<?php quiettruths_tip_cta(); ?>
	</aside>
	<?php
else :
	?>
	<aside class="qt-layout__aside" aria-label="<?php esc_attr_e( 'Sidebar', 'quiettruths' ); ?>">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</aside>
	<?php
endif;
