<?php
/**
 * Single leader profile.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

while ( have_posts() ) :
	the_post();

	$qt_office  = get_post_meta( get_the_ID(), '_qt_leader_office', true );
	$qt_lcounty = get_post_meta( get_the_ID(), '_qt_leader_county', true );
	$qt_party   = get_post_meta( get_the_ID(), '_qt_leader_party', true );
	$qt_since   = get_post_meta( get_the_ID(), '_qt_leader_since', true );
	$qt_contact = get_post_meta( get_the_ID(), '_qt_leader_contact', true );
	?>

	<article <?php post_class( 'qt-leader' ); ?>>
		<?php quiettruths_breadcrumbs(); ?>

		<header class="qt-leader__head">
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="qt-leader__portrait">
					<?php the_post_thumbnail( 'qt-portrait' ); ?>
				</div>
			<?php else : ?>
				<div class="qt-leader__portrait qt-leader__portrait--empty" aria-hidden="true">
					<?php quiettruths_logo_mark(); ?>
				</div>
			<?php endif; ?>

			<div class="qt-leader__intro">
				<h1 class="qt-leader__name"><?php the_title(); ?></h1>

				<?php if ( $qt_office ) : ?>
					<p class="qt-leader__office"><?php echo esc_html( $qt_office ); ?></p>
				<?php endif; ?>

				<dl class="qt-leader__facts">
					<?php if ( $qt_lcounty ) : ?>
						<div>
							<dt><?php esc_html_e( 'County', 'quiettruths' ); ?></dt>
							<dd>
								<?php
								$qt_lslug = sanitize_title( $qt_lcounty );

								if ( quiettruths_get_county( $qt_lslug ) ) :
									$qt_llink = quiettruths_county_link( $qt_lslug );

									if ( '' !== $qt_llink ) :
										?>
										<a href="<?php echo esc_url( $qt_llink ); ?>"><?php echo esc_html( $qt_lcounty ); ?></a>
										<?php
									else :
										echo esc_html( $qt_lcounty );
									endif;
								else :
									echo esc_html( $qt_lcounty );
								endif;
								?>
							</dd>
						</div>
					<?php endif; ?>

					<?php if ( $qt_party ) : ?>
						<div>
							<dt><?php esc_html_e( 'Party', 'quiettruths' ); ?></dt>
							<dd><?php echo esc_html( $qt_party ); ?></dd>
						</div>
					<?php endif; ?>

					<?php if ( $qt_since ) : ?>
						<div>
							<dt><?php esc_html_e( 'In office since', 'quiettruths' ); ?></dt>
							<dd><?php echo esc_html( $qt_since ); ?></dd>
						</div>
					<?php endif; ?>

					<?php if ( $qt_contact ) : ?>
						<div>
							<dt><?php esc_html_e( 'Public contact', 'quiettruths' ); ?></dt>
							<dd>
								<?php if ( is_email( $qt_contact ) ) : ?>
									<a href="<?php echo esc_url( 'mailto:' . $qt_contact ); ?>"><?php echo esc_html( $qt_contact ); ?></a>
								<?php else : ?>
									<?php echo esc_html( $qt_contact ); ?>
								<?php endif; ?>
							</dd>
						</div>
					<?php endif; ?>
				</dl>

				<?php
				$qt_roles = get_the_terms( get_the_ID(), 'qt_role' );

				if ( ! is_wp_error( $qt_roles ) && $qt_roles ) :
					?>
					<ul class="qt-chips">
						<?php foreach ( $qt_roles as $qt_role ) : ?>
							<li class="qt-chip"><a href="<?php echo esc_url( get_term_link( $qt_role ) ); ?>"><?php echo esc_html( $qt_role->name ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		</header>

		<div class="qt-layout">
			<div class="qt-article__body">
				<?php the_content(); ?>

				<aside class="qt-leader__coverage" aria-labelledby="qt-coverage-title">
					<h2 id="qt-coverage-title"><?php esc_html_e( 'Our coverage of this leader', 'quiettruths' ); ?></h2>

					<?php
					$qt_coverage = quiettruths_cached_query( 'leader-coverage', array(
						'post_type'      => array( 'post', 'qt_investigation' ),
						'posts_per_page' => 5,
						'no_found_rows'  => true,
						's'              => get_the_title(),
					) );

					if ( $qt_coverage->have_posts() ) :
						echo '<ul class="qt-widget-list">';

						while ( $qt_coverage->have_posts() ) :
							$qt_coverage->the_post();
							?>
							<li>
								<a href="<?php the_permalink(); ?>">
									<span><?php the_title(); ?></span>
									<small><?php echo esc_html( get_the_date() ); ?></small>
								</a>
							</li>
						<?php
						endwhile;

						echo '</ul>';
						wp_reset_postdata();
					else :
						?>
						<p><?php esc_html_e( 'No stories filed against this name yet.', 'quiettruths' ); ?></p>
					<?php endif; ?>
				</aside>
			</div>

			<?php get_sidebar(); ?>
		</div>
	</article>

<?php endwhile; ?>

<?php
get_footer();
