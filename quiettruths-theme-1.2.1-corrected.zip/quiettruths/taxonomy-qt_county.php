<?php
/**
 * County archive — the spine of the site.
 *
 * Each of the five counties gets a data-rich landing page: the KNBS figures, the
 * officeholders, the standing issues for the desk, then everything published
 * about that county across news and investigations.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

$qt_term   = get_queried_object();
$qt_slug   = ( $qt_term instanceof WP_Term ) ? str_replace( 'qt-', '', $qt_term->slug ) : '';
$qt_county = quiettruths_get_county( $qt_slug );
?>

<div class="qt-county-page">

	<?php quiettruths_breadcrumbs(); ?>

	<header class="qt-county-hero">
		<div class="qt-county-hero__intro">
			<p class="qt-county-hero__code"><?php echo esc_html( $qt_county ? $qt_county['code'] : '' ); ?></p>
			<h1 class="qt-county-hero__name"><?php single_term_title(); ?> <?php esc_html_e( 'County', 'quiettruths' ); ?></h1>

			<?php if ( $qt_county ) : ?>
				<p class="qt-county-hero__blurb"><?php echo esc_html( $qt_county['blurb'] ); ?></p>
			<?php elseif ( term_description() ) : ?>
				<div class="qt-county-hero__blurb"><?php echo wp_kses_post( term_description() ); ?></div>
			<?php endif; ?>
		</div>

		<?php if ( $qt_county ) : ?>
			<dl class="qt-county-facts">
				<div class="qt-county-facts__item">
					<dt><?php esc_html_e( 'Capital', 'quiettruths' ); ?></dt>
					<dd><?php echo esc_html( $qt_county['capital'] ); ?></dd>
				</div>
				<div class="qt-county-facts__item">
					<dt><?php esc_html_e( 'Population', 'quiettruths' ); ?></dt>
					<dd><?php echo esc_html( quiettruths_number( $qt_county['population'] ) ); ?></dd>
				</div>
				<div class="qt-county-facts__item">
					<dt><?php esc_html_e( 'Land area', 'quiettruths' ); ?></dt>
					<dd><?php echo esc_html( number_format( (float) $qt_county['area_km2'], 1 ) . ' km²' ); ?></dd>
				</div>
				<div class="qt-county-facts__item">
					<dt><?php esc_html_e( 'Density', 'quiettruths' ); ?></dt>
					<dd><?php echo esc_html( quiettruths_number( $qt_county['density'] ) ); ?> <small><?php esc_html_e( 'per km²', 'quiettruths' ); ?></small></dd>
				</div>
				<div class="qt-county-facts__item">
					<dt><?php esc_html_e( 'Constituencies', 'quiettruths' ); ?></dt>
					<dd><?php echo esc_html( quiettruths_number( $qt_county['constituencies'] ) ); ?></dd>
				</div>
				<div class="qt-county-facts__item">
					<dt><?php esc_html_e( 'Governor', 'quiettruths' ); ?></dt>
					<dd>
						<?php echo esc_html( $qt_county['governor'] ); ?>
						<?php if ( ! empty( $qt_county['party'] ) ) : ?>
							<em><?php echo esc_html( $qt_county['party'] ); ?></em>
						<?php endif; ?>
					</dd>
				</div>
			</dl>

			<?php if ( ! empty( $qt_county['key_issues'] ) ) : ?>
				<div class="qt-county-issues">
					<h2><?php esc_html_e( 'What we watch here', 'quiettruths' ); ?></h2>
					<ul>
						<?php foreach ( $qt_county['key_issues'] as $qt_issue ) : ?>
							<li><?php echo esc_html( $qt_issue ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $qt_county['economy'] ) ) : ?>
				<p class="qt-county-economy"><strong><?php esc_html_e( 'Economy:', 'quiettruths' ); ?></strong> <?php echo esc_html( $qt_county['economy'] ); ?></p>
			<?php endif; ?>

			<?php if ( ! empty( $qt_county['communities'] ) ) : ?>
				<p class="qt-county-communities"><strong><?php esc_html_e( 'Communities:', 'quiettruths' ); ?></strong> <?php echo esc_html( implode( ', ', $qt_county['communities'] ) ); ?></p>
			<?php endif; ?>
		<?php endif; ?>
	</header>

	<div class="qt-layout">
		<div class="qt-layout__main">
			<?php if ( have_posts() ) : ?>
				<header class="qt-section-head">
					<h2><?php esc_html_e( 'Latest from this county', 'quiettruths' ); ?></h2>
					<p><?php echo esc_html( sprintf(
						/* translators: %s: number of published items. */
						_n( '%s story published', '%s stories published', (int) $GLOBALS['wp_query']->found_posts, 'quiettruths' ),
						quiettruths_number( (int) $GLOBALS['wp_query']->found_posts )
					) ); ?></p>
				</header>

				<div class="qt-stream__list">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content/card', 'list' );
					endwhile;
					?>
				</div>

				<?php quiettruths_pagination(); ?>
			<?php else : ?>
				<div class="qt-empty-state">
					<h2><?php esc_html_e( 'Nothing published for this county yet', 'quiettruths' ); ?></h2>
					<p><?php esc_html_e( 'Tag a post or investigation with this county and it will appear here.', 'quiettruths' ); ?></p>
					<?php quiettruths_newsletter_form( 'county' ); ?>
				</div>
			<?php endif; ?>
		</div>

		<aside class="qt-layout__aside" aria-label="<?php esc_attr_e( 'More counties', 'quiettruths' ); ?>">
			<section class="qt-widget">
				<h2 class="qt-widget__title"><?php esc_html_e( 'Other counties', 'quiettruths' ); ?></h2>
				<ul class="qt-widget-list">
					<?php
					foreach ( quiettruths_counties() as $qt_other ) :
						if ( $qt_other['slug'] === $qt_slug ) {
							continue;
						}

						$qt_link = quiettruths_county_link( $qt_other['slug'] );

						if ( '' === $qt_link ) {
							continue;
						}
						?>
						<li>
							<a href="<?php echo esc_url( $qt_link ); ?>">
								<span><?php echo esc_html( $qt_other['name'] ); ?></span>
								<small><?php echo esc_html( quiettruths_number( $qt_other['population'] ) ); ?></small>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>

			<section class="qt-widget">
				<h2 class="qt-widget__title"><?php esc_html_e( 'Leaders here', 'quiettruths' ); ?></h2>
				<?php
				$qt_leaders = quiettruths_cached_query( 'county-leaders', array(
					'post_type'      => 'qt_leader',
					'posts_per_page' => 6,
					'no_found_rows'  => true,
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						array(
							'key'     => '_qt_leader_county',
							'value'   => $qt_county ? $qt_county['name'] : '',
							'compare' => 'LIKE',
						),
					),
				) );

				if ( $qt_leaders->have_posts() ) :
					echo '<ul class="qt-widget-list">';

					while ( $qt_leaders->have_posts() ) :
						$qt_leaders->the_post();
						?>
						<li>
							<a href="<?php the_permalink(); ?>">
								<span><?php the_title(); ?></span>
								<small><?php echo esc_html( get_post_meta( get_the_ID(), '_qt_leader_office', true ) ); ?></small>
							</a>
						</li>
					<?php
					endwhile;

					echo '</ul>';
					wp_reset_postdata();
				else :
					?>
					<p class="qt-widget__empty"><?php esc_html_e( 'Profiles are being added county by county.', 'quiettruths' ); ?></p>
				<?php endif; ?>
			</section>

			<?php quiettruths_tip_cta(); ?>
		</aside>
	</div>
</div>

<?php
get_footer();
