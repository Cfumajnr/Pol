<?php
/**
 * Archive page header — works for taxonomies, post type archives, dates and search.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?>
<header class="qt-archive-head">
	<?php quiettruths_breadcrumbs(); ?>

	<?php if ( is_post_type_archive( 'qt_investigation' ) ) : ?>
		<p class="qt-archive-head__kicker"><?php esc_html_e( 'The desk', 'quiettruths' ); ?></p>
		<h1 class="qt-archive-head__title"><?php esc_html_e( 'Investigations', 'quiettruths' ); ?></h1>
		<p class="qt-archive-head__desc"><?php esc_html_e( 'Long-form reporting built on documents, data and named sources. Where we cannot name a source, we say why.', 'quiettruths' ); ?></p>

	<?php elseif ( is_post_type_archive( 'qt_leader' ) ) : ?>
		<p class="qt-archive-head__kicker"><?php esc_html_e( 'Reference', 'quiettruths' ); ?></p>
		<h1 class="qt-archive-head__title"><?php esc_html_e( 'Leaders Directory', 'quiettruths' ); ?></h1>
		<p class="qt-archive-head__desc"><?php esc_html_e( 'Who represents the five counties, which party sent them, and how to reach their office.', 'quiettruths' ); ?></p>

	<?php elseif ( is_post_type_archive( 'qt_event' ) ) : ?>
		<p class="qt-archive-head__kicker"><?php esc_html_e( 'Calendar', 'quiettruths' ); ?></p>
		<h1 class="qt-archive-head__title"><?php esc_html_e( 'Barazas &amp; Events', 'quiettruths' ); ?></h1>
		<p class="qt-archive-head__desc"><?php esc_html_e( 'Public barazas, county assembly sittings, town halls and campaign stops across the region.', 'quiettruths' ); ?></p>

	<?php elseif ( is_tax( 'qt_topic' ) || is_category() || is_tag() ) : ?>
		<p class="qt-archive-head__kicker"><?php esc_html_e( 'Topic', 'quiettruths' ); ?></p>
		<h1 class="qt-archive-head__title"><?php single_term_title(); ?></h1>

		<?php if ( term_description() ) : ?>
			<div class="qt-archive-head__desc"><?php echo wp_kses_post( term_description() ); ?></div>
		<?php endif; ?>

	<?php elseif ( is_author() ) : ?>
		<p class="qt-archive-head__kicker"><?php esc_html_e( 'Reporter', 'quiettruths' ); ?></p>
		<h1 class="qt-archive-head__title"><?php the_author(); ?></h1>

		<?php if ( get_the_author_meta( 'description' ) ) : ?>
			<div class="qt-archive-head__desc"><?php echo wp_kses_post( get_the_author_meta( 'description' ) ); ?></div>
		<?php endif; ?>

	<?php elseif ( is_day() || is_month() || is_year() ) : ?>
		<p class="qt-archive-head__kicker"><?php esc_html_e( 'Archive', 'quiettruths' ); ?></p>
		<h1 class="qt-archive-head__title"><?php echo esc_html( get_the_archive_title() ); ?></h1>

	<?php elseif ( is_home() && ! is_front_page() ) : ?>
		<h1 class="qt-archive-head__title"><?php esc_html_e( 'Latest reporting', 'quiettruths' ); ?></h1>

	<?php else : ?>
		<h1 class="qt-archive-head__title"><?php echo esc_html( wp_get_document_title() ); ?></h1>
	<?php endif; ?>

	<p class="qt-archive-head__count">
		<?php
		echo esc_html( sprintf(
			/* translators: %s: number of published items. */
			_n( '%s story', '%s stories', (int) $GLOBALS['wp_query']->found_posts, 'quiettruths' ),
			quiettruths_number( (int) $GLOBALS['wp_query']->found_posts )
		) );
		?>
	</p>
</header>
