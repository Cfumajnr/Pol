<?php
/**
 * Leader directory card.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

$qt_office  = get_post_meta( get_the_ID(), '_qt_leader_office', true );
$qt_lcounty = get_post_meta( get_the_ID(), '_qt_leader_county', true );
$qt_party   = get_post_meta( get_the_ID(), '_qt_leader_party', true );
?>
<article <?php post_class( 'qt-leader-card' ); ?>>
	<a class="qt-leader-card__link" href="<?php the_permalink(); ?>">
		<?php if ( has_post_thumbnail() ) : ?>
			<span class="qt-leader-card__portrait"><?php the_post_thumbnail( 'qt-thumb' ); ?></span>
		<?php else : ?>
			<span class="qt-leader-card__portrait qt-leader-card__portrait--empty" aria-hidden="true"><?php quiettruths_logo_mark(); ?></span>
		<?php endif; ?>

		<span class="qt-leader-card__body">
			<span class="qt-leader-card__name"><?php the_title(); ?></span>

			<?php if ( $qt_office ) : ?>
				<span class="qt-leader-card__office"><?php echo esc_html( $qt_office ); ?></span>
			<?php endif; ?>

			<span class="qt-leader-card__meta">
				<?php if ( $qt_lcounty ) : ?>
					<span><?php echo esc_html( $qt_lcounty ); ?></span>
				<?php endif; ?>

				<?php if ( $qt_party ) : ?>
					<span class="qt-leader-card__party"><?php echo esc_html( $qt_party ); ?></span>
				<?php endif; ?>
			</span>
		</span>
	</a>
</article>
