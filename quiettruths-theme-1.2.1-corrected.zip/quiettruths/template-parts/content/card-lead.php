<?php
/**
 * Card variant: lead.
 *
 * The large-format treatment used when a story opens a page on its own — full
 * media, standfirst-length excerpt, and the complete meta line.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?>
<article <?php post_class( 'qt-card qt-card--lead' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="qt-card__media qt-card__media--wide" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php the_post_thumbnail( 'qt-lead' ); ?>
		</a>
	<?php endif; ?>

	<div class="qt-card__body">
		<div class="qt-card__tags">
			<?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 2 ); ?>

			<?php if ( 'qt_investigation' === get_post_type() ) : ?>
				<span class="qt-flag qt-flag--investigation"><?php esc_html_e( 'Investigation', 'quiettruths' ); ?></span>
			<?php endif; ?>
		</div>

		<h2 class="qt-card__title qt-card__title--lead">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<p class="qt-card__excerpt qt-card__excerpt--lead"><?php quiettruths_the_excerpt( 34 ); ?></p>

		<?php quiettruths_the_meta(); ?>
	</div>
</article>
