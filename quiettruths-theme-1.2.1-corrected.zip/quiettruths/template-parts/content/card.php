<?php
/**
 * Card variant: grid tile.
 *
 * This is the default variant, so it doubles as the fallback that
 * get_template_part( 'template-parts/content/card' ) resolves to.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?>
<article <?php post_class( 'qt-card qt-card--grid' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="qt-card__media qt-card__media--wide" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php the_post_thumbnail( 'qt-card' ); ?>
		</a>
	<?php endif; ?>

	<div class="qt-card__body">
		<div class="qt-card__tags"><?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 2 ); ?></div>

		<h2 class="qt-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<p class="qt-card__excerpt"><?php quiettruths_the_excerpt( 20 ); ?></p>

		<?php quiettruths_the_meta( get_the_ID(), false ); ?>
	</div>
</article>
