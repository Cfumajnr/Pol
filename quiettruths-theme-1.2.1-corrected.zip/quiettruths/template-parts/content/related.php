<?php
/**
 * Related stories, matched by county first then by topic.
 *
 * County is the strongest relevance signal on this site: a reader in Migori
 * wants more Migori, not more of whatever the national conversation is.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

$qt_related_counties = get_the_terms( get_the_ID(), 'qt_county' );

if ( is_wp_error( $qt_related_counties ) || empty( $qt_related_counties ) ) {
	return;
}

$qt_related = quiettruths_cached_query(
	'related',
	array(
		'post_type'      => array( 'post', 'qt_investigation' ),
		'posts_per_page' => 4,
		'no_found_rows'  => true,
		'post__not_in'   => array( get_the_ID() ), // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- small, explicit exclusion.
		'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			array(
				'taxonomy' => 'qt_county',
				'field'    => 'term_id',
				'terms'    => wp_list_pluck( $qt_related_counties, 'term_id' ),
			),
		),
	)
);

if ( ! $qt_related->have_posts() ) {
	wp_reset_postdata();
	return;
}
?>

<section class="qt-related" aria-labelledby="qt-related-title">
	<header class="qt-section-head">
		<h2 id="qt-related-title"><?php esc_html_e( 'More from this county', 'quiettruths' ); ?></h2>
	</header>

	<div class="qt-related__grid">
		<?php
		while ( $qt_related->have_posts() ) :
			$qt_related->the_post();
			get_template_part( 'template-parts/content/card', 'grid' );
		endwhile;
		wp_reset_postdata();
		?>
	</div>
</section>
