<?php
/**
 * Card variant: investigation tile.
 *
 * Visually distinct from news: darker, with a document-count line, because the
 * desk is the part of the site that earns trust.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

$qt_counties = get_the_terms( get_the_ID(), 'qt_county' );
?>
<article <?php post_class( 'qt-card qt-card--investigation' ); ?>>
	<a class="qt-card__media qt-card__media--investigation" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'qt-card' ); ?>
		<?php else : ?>
			<span class="qt-card__placeholder" aria-hidden="true"><?php quiettruths_logo_mark(); ?></span>
		<?php endif; ?>
	</a>

	<div class="qt-card__body">
		<span class="qt-flag qt-flag--investigation"><?php esc_html_e( 'Investigation', 'quiettruths' ); ?></span>

		<h3 class="qt-card__title qt-card__title--investigation">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h3>

		<p class="qt-card__excerpt"><?php quiettruths_the_excerpt( 22 ); ?></p>

		<p class="qt-card__foot">
			<?php if ( ! is_wp_error( $qt_counties ) && $qt_counties ) : ?>
				<span class="qt-card__where"><?php echo esc_html( implode( ' · ', wp_list_pluck( $qt_counties, 'name' ) ) ); ?></span>
			<?php endif; ?>

			<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
		</p>
	</div>
</article>
