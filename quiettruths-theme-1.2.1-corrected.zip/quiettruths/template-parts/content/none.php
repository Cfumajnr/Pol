<?php
/**
 * "Nothing found" block.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?>
<div class="qt-empty-state">
	<h2><?php esc_html_e( 'Nothing here yet', 'quiettruths' ); ?></h2>
	<p><?php esc_html_e( 'This section fills up as the desk publishes. In the meantime, browse by county or sign up for the weekly briefing.', 'quiettruths' ); ?></p>

	<?php quiettruths_county_chips(); ?>
</div>
