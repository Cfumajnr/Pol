<?php
/**
 * Card variant: compact (opinion rail, dense grids).
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?>
<article <?php post_class( 'qt-card qt-card--compact' ); ?>>
	<div class="qt-card__body">
		<?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 1 ); ?>

		<h3 class="qt-card__title qt-card__title--small">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h3>

		<p class="qt-card__byline">
			<?php echo esc_html( get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', get_the_ID() ) ) ); ?>
			<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
		</p>
	</div>
</article>
