<?php
/**
 * Barazas & events calendar.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

get_template_part( 'template-parts/archive/header' );
?>

<div class="qt-layout">
	<div class="qt-layout__main">
		<nav aria-label="<?php esc_attr_e( 'Event dates', 'quiettruths' ); ?>"><p>
		<a href="<?php echo esc_url( get_post_type_archive_link( 'qt_event' ) ); ?>"><?php esc_html_e( 'Upcoming and ongoing', 'quiettruths' ); ?></a> ·
		<a href="<?php echo esc_url( add_query_arg( 'qt_events', 'past', get_post_type_archive_link( 'qt_event' ) ) ); ?>"><?php esc_html_e( 'Past events', 'quiettruths' ); ?></a>
		</p></nav>
		<?php if ( have_posts() ) : ?>
			<ul class="qt-events__list qt-events__list--archive">
				<?php
				while ( have_posts() ) :
					the_post();
					$qt_venue = get_post_meta( get_the_ID(), '_qt_event_venue', true );
					$qt_host  = get_post_meta( get_the_ID(), '_qt_event_host', true );
					?>
					<li class="qt-event <?php echo quiettruths_event_is_upcoming() ? '' : 'qt-event--past'; ?>">
						<span class="qt-event__date"><?php quiettruths_the_event_date(); ?></span>
						<span class="qt-event__body">
							<a class="qt-event__title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>

							<?php if ( $qt_venue || $qt_host ) : ?>
								<span class="qt-event__where"><?php echo esc_html( trim( $qt_venue . ( $qt_venue && $qt_host ? ' · ' : '' ) . $qt_host ) ); ?></span>
							<?php endif; ?>

							<?php if ( has_excerpt() ) : ?>
								<span class="qt-event__excerpt"><?php quiettruths_the_excerpt( 22 ); ?></span>
							<?php endif; ?>
						</span>
					</li>
				<?php endwhile; ?>
			</ul>

			<?php quiettruths_pagination(); ?>
		<?php else : ?>
			<div class="qt-empty-state">
				<h2><?php esc_html_e( 'Nothing on the calendar yet', 'quiettruths' ); ?></h2>
				<p><?php esc_html_e( 'Add barazas, town halls and county assembly sittings under Barazas &amp; Events in the dashboard.', 'quiettruths' ); ?></p>
			</div>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
