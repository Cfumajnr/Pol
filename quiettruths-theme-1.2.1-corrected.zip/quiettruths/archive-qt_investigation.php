<?php
/**
 * Investigations archive.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

get_template_part( 'template-parts/archive/header' );
?>

<div class="qt-layout">
	<div class="qt-layout__main">
		<?php if ( have_posts() ) : ?>
			<div class="qt-desk__grid qt-desk__grid--archive">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content/card', 'investigation' );
				endwhile;
				?>
			</div>

			<?php quiettruths_pagination(); ?>
		<?php else : ?>
			<div class="qt-empty-state">
				<h2><?php esc_html_e( 'The desk has not published yet', 'quiettruths' ); ?></h2>
				<p><?php esc_html_e( 'Investigations take time. While you wait, here is how to get a document to us safely.', 'quiettruths' ); ?></p>
				<?php quiettruths_tip_cta(); ?>
			</div>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
