<?php
/**
 * Search results.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();
?>

<header class="qt-archive-head">
	<h1 class="qt-archive-head__title">
		<?php
		echo esc_html( sprintf(
			/* translators: %s: search query. */
			__( 'Search results for “%s”', 'quiettruths' ),
			get_search_query()
		) );
		?>
	</h1>

	<p class="qt-archive-head__count">
		<?php
		echo esc_html( sprintf(
			/* translators: %s: number of results. */
			_n( '%s result', '%s results', (int) $GLOBALS['wp_query']->found_posts, 'quiettruths' ),
			quiettruths_number( (int) $GLOBALS['wp_query']->found_posts )
		) );
		?>
	</p>
</header>

<div class="qt-layout">
	<div class="qt-layout__main">
		<?php if ( have_posts() ) : ?>
			<div class="qt-stream__list">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content/card', 'list' );
				endwhile;
				?>
			</div>

			<?php quiettruths_pagination(); ?>
		<?php else : ?>
			<div class="qt-empty-state">
				<h2><?php esc_html_e( 'Nothing matched', 'quiettruths' ); ?></h2>
				<p><?php esc_html_e( 'Try a county name, a leader, or a shorter phrase.', 'quiettruths' ); ?></p>
				<?php get_search_form(); ?>
				<?php quiettruths_county_chips(); ?>
			</div>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
