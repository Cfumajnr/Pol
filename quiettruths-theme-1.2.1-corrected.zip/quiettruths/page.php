<?php
/**
 * Static pages: About, corrections policy, ethics, contact.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<article <?php post_class( 'qt-page' ); ?>>
		<?php quiettruths_breadcrumbs(); ?>

		<header class="qt-page__head">
			<h1 class="qt-page__title"><?php the_title(); ?></h1>

			<?php if ( has_excerpt() ) : ?>
				<p class="qt-page__standfirst"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="qt-article__hero"><?php the_post_thumbnail( 'qt-lead' ); ?></figure>
		<?php endif; ?>

		<div class="qt-layout">
			<div class="qt-article__body">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<nav class="qt-page-links" aria-label="' . esc_attr__( 'Pages', 'quiettruths' ) . '">',
					'after'  => '</nav>',
				) );
				?>
			</div>

			<?php get_sidebar(); ?>
		</div>
	</article>

	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}

endwhile;

get_footer();
