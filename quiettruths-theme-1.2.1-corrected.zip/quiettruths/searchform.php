<?php
/**
 * Search form.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

$qt_search_id = 'qt-search-' . wp_rand( 1000, 9999 );
?>

<form role="search" method="get" class="qt-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $qt_search_id ); ?>"><?php esc_html_e( 'Search Quiet Truths', 'quiettruths' ); ?></label>

	<input
		type="search"
		id="<?php echo esc_attr( $qt_search_id ); ?>"
		class="qt-search__input"
		name="s"
		value="<?php echo esc_attr( get_search_query() ); ?>"
		placeholder="<?php esc_attr_e( 'Search a county, leader or story', 'quiettruths' ); ?>"
	/>

	<button type="submit" class="qt-btn qt-btn--accent qt-search__submit"><?php esc_html_e( 'Search', 'quiettruths' ); ?></button>
</form>
