<?php
/**
 * Single post.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<article <?php post_class( 'qt-article' ); ?> id="post-<?php the_ID(); ?>">
		<?php quiettruths_breadcrumbs(); ?>

		<header class="qt-article__head">
			<?php quiettruths_the_terms_chips( 'qt_county', get_the_ID(), 3 ); ?>

			<h1 class="qt-article__title"><?php the_title(); ?></h1>

			<?php if ( has_excerpt() ) : ?>
				<p class="qt-article__standfirst"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>

			<?php quiettruths_the_meta(); ?>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="qt-article__hero">
				<?php the_post_thumbnail( 'qt-lead' ); ?>

				<?php
				$qt_caption = get_the_post_thumbnail_caption();

				if ( $qt_caption ) :
					?>
					<figcaption><?php echo esc_html( $qt_caption ); ?></figcaption>
				<?php endif; ?>
			</figure>
		<?php endif; ?>

		<div class="qt-layout">
			<div class="qt-article__body">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<nav class="qt-page-links" aria-label="' . esc_attr__( 'Pages', 'quiettruths' ) . '">',
					'after'  => '</nav>',
				) );
				?>

				<footer class="qt-article__foot">
					<?php quiettruths_the_terms_chips( 'qt_topic', get_the_ID(), 5 ); ?>

					<div class="qt-article__share">
						<span><?php esc_html_e( 'Share', 'quiettruths' ); ?></span>
						<a href="<?php echo esc_url( add_query_arg(
							array(
								'text' => rawurlencode( get_the_title() ),
								'url'  => rawurlencode( get_permalink() ),
							),
							'https://twitter.com/intent/tweet'
						) ); ?>" rel="noopener" target="_blank">X</a>
						<a href="<?php echo esc_url( add_query_arg(
							array( 'u' => rawurlencode( get_permalink() ) ),
							'https://www.facebook.com/sharer/sharer.php'
						) ); ?>" rel="noopener" target="_blank">Facebook</a>
						<a href="<?php echo esc_url( add_query_arg(
							array(
								'text' => rawurlencode( get_the_title() . ' ' . get_permalink() ),
							),
							'https://wa.me/'
						) ); ?>" rel="noopener" target="_blank">WhatsApp</a>
					</div>

					<div class="qt-article__correction">
						<p><?php esc_html_e( 'Spotted an error, or something we got wrong? Tell us and we will correct it on the record.', 'quiettruths' ); ?></p>
						<p><a class="qt-btn qt-btn--ghost" href="<?php echo esc_url( quiettruths_tip_url( sprintf( /* translators: %s: post title. */ __( 'Correction: %s', 'quiettruths' ), get_the_title() ) ) ); ?>"><?php esc_html_e( 'Report a correction', 'quiettruths' ); ?></a></p>
					</div>
				</footer>

				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>

			<?php get_sidebar(); ?>
		</div>
	</article>

	<?php
	get_template_part( 'template-parts/content/related' );

endwhile;

get_footer();
