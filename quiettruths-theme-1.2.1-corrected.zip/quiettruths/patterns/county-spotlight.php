<?php
/**
 * Block pattern: county spotlight.
 *
 * A data callout for the KNBS figures an editor wants to put in front of a
 * reader before the prose starts.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

return '<!-- wp:group {"className":"qt-data-callout","align":"wide"} -->
<div class="wp-block-group qt-data-callout alignwide"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">County at a glance</h3>
<!-- /wp:heading -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>1,867,579</strong>people (2019 census)</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>3,020 km²</strong>land area</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p><strong>12</strong>constituencies</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Source: 2019 Kenya Population and Housing Census, KNBS.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->';
