<?php
/**
 * Comments.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

if ( post_password_required() ) {
	return;
}
?>

<section id="comments" class="qt-comments" aria-labelledby="qt-comments-title">
	<?php if ( have_comments() ) : ?>
		<h2 id="qt-comments-title" class="qt-comments__title">
			<?php
			$qt_comment_count = get_comments_number();

			echo esc_html( sprintf(
				/* translators: %s: number of comments. */
				_n( '%s response', '%s responses', $qt_comment_count, 'quiettruths' ),
				quiettruths_number( $qt_comment_count )
			) );
			?>
		</h2>

		<ol class="qt-comment-list">
			<?php
			wp_list_comments( array(
				'style'       => 'ol',
				'short_ping'  => true,
				'avatar_size' => 48,
			) );
			?>
		</ol>

		<?php
		the_comments_navigation( array(
			'prev_text' => __( '&larr; Older comments', 'quiettruths' ),
			'next_text' => __( 'Newer comments &rarr;', 'quiettruths' ),
		) );
		?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="qt-comments__closed"><?php esc_html_e( 'Comments are closed on this story.', 'quiettruths' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form( array(
		'title_reply'         => __( 'Join the conversation', 'quiettruths' ),
		'title_reply_before'  => '<h3 class="qt-comments__reply-title">',
		'title_reply_after'   => '</h3>',
		'comment_notes_before' => '<p class="qt-comments__note">' . esc_html__( 'Comment under your real name. We remove abuse, and we do not publish threats against sources.', 'quiettruths' ) . '</p>',
		'class_submit'        => 'qt-btn qt-btn--accent',
	) );
	?>
</section>
