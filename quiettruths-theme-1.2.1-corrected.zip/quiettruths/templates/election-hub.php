<?php
/**
 * Template Name: Election 2027 hub
 *
 * The /2027/ hub. A page rather than a category archive because the URL is
 * fixed by the site spec and because a hub should do more than list posts: it
 * frames the contest, then shows the reporting underneath.
 *
 * Everything below the editor's intro is generated from the Election 2027
 * category, so the page keeps itself current without anyone touching it.
 *
 * @package QuietTruths
 * @since   1.2.0
 */

get_header();

while ( have_posts() ) :
	the_post();

	$qt_election_cat = get_category_by_slug( 'election-2027' );
	$qt_cat_id       = ( $qt_election_cat && ! is_wp_error( $qt_election_cat ) ) ? (int) $qt_election_cat->term_id : 0;
	?>

	<article <?php post_class( 'qt-page qt-page--hub' ); ?>>
		<?php quiettruths_breadcrumbs(); ?>

		<header class="qt-hub__head">
			<p class="qt-hub__kicker"><?php esc_html_e( 'Election hub', 'quiettruths' ); ?></p>
			<h1 class="qt-hub__title"><?php the_title(); ?></h1>
			<p class="qt-hub__counties"><?php esc_html_e( 'Kakamega · Vihiga · Bungoma · Busia · Trans Nzoia', 'quiettruths' ); ?></p>
		</header>

		<div class="qt-article__body qt-article__body--intro">
			<?php the_content(); ?>
		</div>

		<div class="qt-layout">
			<div class="qt-layout__main">
				<?php if ( $qt_cat_id ) : ?>
					<?php
					$qt_profiles = quiettruths_cached_query( 'hub-profiles', array(
						'post_type'      => array( 'post' ),
						'posts_per_page' => 6,
						'no_found_rows'  => true,
						'category__in'   => array( $qt_cat_id ),
						'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
							array(
								'taxonomy' => 'category',
								'field'    => 'slug',
								'terms'    => array( 'profiles' ),
							),
						),
					) );
					?>

					<?php if ( $qt_profiles->have_posts() ) : ?>
						<section class="qt-hub__section" aria-labelledby="qt-hub-profiles">
							<header class="qt-section-head">
								<h2 id="qt-hub-profiles"><?php esc_html_e( 'Candidate profiles', 'quiettruths' ); ?></h2>
							</header>

							<div class="qt-related__grid">
								<?php
								while ( $qt_profiles->have_posts() ) :
									$qt_profiles->the_post();
									get_template_part( 'template-parts/content/card', 'grid' );
								endwhile;
								wp_reset_postdata();
								?>
							</div>
						</section>
					<?php endif; ?>

					<?php
					$qt_election_posts = quiettruths_cached_query( 'hub-latest', array(
						'post_type'      => array( 'post', 'qt_investigation' ),
						'posts_per_page' => 10,
						'no_found_rows'  => true,
						'category__in'   => array( $qt_cat_id ),
					) );
					?>

					<section class="qt-hub__section" aria-labelledby="qt-hub-latest">
						<header class="qt-section-head">
							<h2 id="qt-hub-latest"><?php esc_html_e( 'Latest election reporting', 'quiettruths' ); ?></h2>
						</header>

						<?php if ( $qt_election_posts->have_posts() ) : ?>
							<div class="qt-stream__list">
								<?php
								while ( $qt_election_posts->have_posts() ) :
									$qt_election_posts->the_post();
									get_template_part( 'template-parts/content/card', 'list' );
								endwhile;
								wp_reset_postdata();
								?>
							</div>
						<?php else : ?>
							<div class="qt-empty-state">
								<h2><?php esc_html_e( 'No election coverage filed yet', 'quiettruths' ); ?></h2>
								<p><?php esc_html_e( 'Assign a post to the Election 2027 category and it appears here automatically.', 'quiettruths' ); ?></p>
							</div>
						<?php endif; ?>
					</section>
				<?php else : ?>
					<div class="qt-empty-state">
						<h2><?php esc_html_e( 'The Election 2027 category is missing', 'quiettruths' ); ?></h2>
						<p><?php esc_html_e( 'Re-save your permalinks, or create a category with the slug election-2027.', 'quiettruths' ); ?></p>
					</div>
				<?php endif; ?>

				<section class="qt-hub__section" aria-labelledby="qt-hub-counties">
					<header class="qt-section-head">
						<h2 id="qt-hub-counties"><?php esc_html_e( 'County by county', 'quiettruths' ); ?></h2>
						<p><?php esc_html_e( 'The five contests that decide the region.', 'quiettruths' ); ?></p>
					</header>

					<?php quiettruths_county_grid( true ); ?>
				</section>
			</div>

			<?php get_sidebar(); ?>
		</div>
	</article>

<?php endwhile; ?>

<?php
get_footer();
