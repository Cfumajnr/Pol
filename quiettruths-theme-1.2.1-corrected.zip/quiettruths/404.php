<?php
/**
 * 404.
 *
 * Sends the reader somewhere useful rather than a dead end — on a news site the
 * best recovery is the county index and the search box.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

get_header();
?>

<section class="qt-error">
	<h1 class="qt-error__code">404</h1>
	<h2 class="qt-error__title"><?php esc_html_e( 'That page is not here', 'quiettruths' ); ?></h2>
	<p class="qt-error__text"><?php esc_html_e( 'The story may have been moved, renamed, or withdrawn after a correction. Try a search, or go straight to a county.', 'quiettruths' ); ?></p>

	<?php get_search_form(); ?>

	<?php quiettruths_county_chips(); ?>

	<p class="qt-error__links">
		<a class="qt-btn qt-btn--accent" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Front page', 'quiettruths' ); ?></a>
		<a class="qt-btn qt-btn--ghost" href="<?php echo esc_url( get_post_type_archive_link( 'qt_investigation' ) ); ?>"><?php esc_html_e( 'Investigations', 'quiettruths' ); ?></a>
	</p>
</section>

<?php
get_footer();
