<?php
/** Kenya's 47 counties in official county-code order. */
defined( 'ABSPATH' ) || exit;
function kenya47_counties() {
 return array(
 'Mombasa','Kwale','Kilifi','Tana River','Lamu','Taita-Taveta','Garissa','Wajir','Mandera','Marsabit','Isiolo','Meru','Tharaka-Nithi','Embu','Kitui','Machakos','Makueni','Nyandarua','Nyeri','Kirinyaga','Murang’a','Kiambu','Turkana','West Pokot','Samburu','Trans Nzoia','Uasin Gishu','Elgeyo-Marakwet','Nandi','Baringo','Laikipia','Nakuru','Narok','Kajiado','Kericho','Bomet','Kakamega','Vihiga','Bungoma','Busia','Siaya','Kisumu','Homa Bay','Migori','Kisii','Nyamira','Nairobi' );
}
function kenya47_county_slug( $name ) {
 $special = array( 'Murang’a' => 'muranga', 'Taita-Taveta' => 'taita-taveta', 'Elgeyo-Marakwet' => 'elgeyo-marakwet', 'Tharaka-Nithi' => 'tharaka-nithi' );
 return isset( $special[$name] ) ? $special[$name] : sanitize_title( $name );
}
