(function(){
 document.documentElement.classList.add('js');
 var btn=document.querySelector('.menu-toggle'), nav=document.getElementById('primary-menu');
 if(btn&&nav){btn.addEventListener('click',function(){var open=btn.getAttribute('aria-expanded')==='true';btn.setAttribute('aria-expanded',String(!open));nav.classList.toggle('is-open',!open);});}
 var input=document.getElementById('county-search'), items=document.querySelectorAll('.county-item'), no=document.getElementById('county-no-results');
 if(input){input.addEventListener('input',function(){var q=input.value.toLocaleLowerCase().trim().replace(/[’']/g,'');var n=0;items.forEach(function(el){var ok=(el.getAttribute('data-county')||'').toLocaleLowerCase().replace(/[’']/g,'').indexOf(q)!==-1;el.hidden=!ok;if(ok)n++;});if(no)no.hidden=n!==0;});}
})();
