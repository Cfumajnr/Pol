<?php
defined( 'ABSPATH' ) || exit;
define( 'KENYA47_VERSION', '1.1.0' );
require_once get_template_directory() . '/inc/counties.php';
function kenya47_setup() {
 add_theme_support( 'title-tag' );
 add_theme_support( 'post-thumbnails' );
 add_theme_support( 'automatic-feed-links' );
 add_theme_support( 'responsive-embeds' );
 add_theme_support( 'html5', array( 'search-form','comment-form','comment-list','gallery','caption','style','script' ) );
 register_nav_menus( array( 'primary' => __( 'Primary navigation', 'kenya47' ), 'footer' => __( 'Footer navigation', 'kenya47' ) ) );
 add_image_size( 'kenya47-card', 800, 560, true );
}
add_action( 'after_setup_theme', 'kenya47_setup' );
function kenya47_assets() {
 wp_enqueue_style( 'kenya47-style', get_template_directory_uri() . '/assets/css/main.css', array(), KENYA47_VERSION );
 wp_enqueue_script( 'kenya47-main', get_template_directory_uri() . '/assets/js/main.js', array(), KENYA47_VERSION, true );
 if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' );
}
add_action( 'wp_enqueue_scripts', 'kenya47_assets' );
/** Preserve Quiet Truths content registrations and their established URLs. */
function kenya47_register_content() {
 $types = array(
  'qt_investigation' => array( 'Investigations', 'Investigation', 'investigations', 'dashicons-visibility', array('title','editor','excerpt','thumbnail','author','revisions','custom-fields') ),
  'qt_leader' => array( 'Leaders', 'Leader', 'leaders', 'dashicons-groups', array('title','editor','excerpt','thumbnail','revisions') ),
  'qt_event' => array( 'Barazas & Events', 'Event', 'barazas', 'dashicons-calendar-alt', array('title','editor','excerpt','thumbnail') ),
 );
 foreach ( $types as $id => $v ) register_post_type( $id, array( 'labels' => array( 'name' => $v[0], 'singular_name' => $v[1] ), 'public' => true, 'show_in_rest' => true, 'menu_icon' => $v[3], 'rewrite' => array( 'slug' => $v[2], 'with_front' => false ), 'has_archive' => $v[2], 'supports' => $v[4] ) );
 register_taxonomy( 'qt_county', array( 'post','qt_investigation','qt_event' ), array( 'labels' => array( 'name' => 'Counties', 'singular_name' => 'County' ), 'public' => true, 'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true, 'rewrite' => array( 'slug' => 'county', 'with_front' => false ) ) );
 register_taxonomy( 'qt_topic', array( 'post','qt_investigation' ), array( 'labels' => array( 'name' => 'Topics', 'singular_name' => 'Topic' ), 'public' => true, 'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true, 'rewrite' => array( 'slug' => 'topic', 'with_front' => false ) ) );
 register_taxonomy( 'qt_role', array( 'qt_leader' ), array( 'labels' => array( 'name' => 'Roles', 'singular_name' => 'Role' ), 'public' => true, 'show_in_rest' => true, 'show_admin_column' => true, 'rewrite' => array( 'slug' => 'role', 'with_front' => false ) ) );
}
add_action( 'init', 'kenya47_register_content', 0 );
/** Setup is additive: do not overwrite existing terms, posts, menus or pages. */
function kenya47_activate() {
 kenya47_register_content();
 foreach ( kenya47_counties() as $name ) {
  $slug = kenya47_county_slug( $name );
  if ( ! get_term_by( 'slug', $slug, 'qt_county' ) && ! term_exists( $name, 'qt_county' ) ) wp_insert_term( $name, 'qt_county', array( 'slug' => $slug ) );
 }
 foreach ( array( 'Profiles' => 'profiles', 'Economy' => 'economy', 'Opinion' => 'opinion', 'Explainers' => 'explainers', 'Analysis' => 'analysis', 'Election 2027' => 'election-2027' ) as $name => $slug ) {
  if ( ! get_category_by_slug( $slug ) && ! term_exists( $name, 'category' ) ) wp_insert_term( $name, 'category', array( 'slug' => $slug ) );
 }
 if ( ! get_page_by_path( 'counties' ) ) wp_insert_post( array( 'post_title' => 'Counties', 'post_name' => 'counties', 'post_status' => 'publish', 'post_type' => 'page' ) );
 if ( ! kenya47_election_page() ) {
  $id = wp_insert_post( array( 'post_title' => 'Election 2027', 'post_name' => 'election-2027', 'post_status' => 'publish', 'post_type' => 'page' ), true );
  if ( ! is_wp_error( $id ) && $id ) update_post_meta( $id, '_wp_page_template', 'templates/election-hub.php' );
 }
 // Add useful starter pages only on installations where they do not already exist.
 $pages = array(
  'about' => array( 'About Kenya 47', '<p>Kenya 47 is a national publication bringing together reporting and perspectives from across Kenya’s 47 counties.</p><p>Our focus is on people, public decisions and the issues that shape everyday life.</p>' ),
  'contact' => array( 'Contact', '<p>Our newsroom contact details will be published here once confirmed. Please do not send sensitive information until a suitable contact channel has been established.</p>' ),
  'corrections' => array( 'Corrections', '<p>Our corrections process and contact details will be published here before launch.</p>' ),
  'privacy' => array( 'Privacy', '<p>Our privacy information will be published here before launch.</p>' ),
 );
 foreach ( $pages as $slug => $details ) if ( ! get_page_by_path( $slug ) ) wp_insert_post( array( 'post_title' => $details[0], 'post_name' => $slug, 'post_content' => $details[1], 'post_status' => 'publish', 'post_type' => 'page' ) );
 flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'kenya47_activate' );
function kenya47_category_url( $slug ) {
 $term = get_category_by_slug( $slug );
 if ( $term ) { $url = get_term_link( $term ); if ( ! is_wp_error( $url ) ) return $url; }
 return home_url( '/' );
}
function kenya47_page_url( $slug ) {
 $page = get_page_by_path( $slug );
 return $page && 'publish' === $page->post_status ? get_permalink( $page ) : home_url( '/' );
}
/** Find an existing Quiet Truths election hub before creating a new one. */
function kenya47_election_page() {
 $matches = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 1, 'meta_key' => '_wp_page_template', 'meta_value' => 'templates/election-hub.php', 'suppress_filters' => true ) );
 if ( $matches ) return $matches[0];
 foreach ( array('election-2027', '2027-2', '2027') as $slug ) { $p = get_page_by_path($slug); if ( $p && 'publish' === $p->post_status ) return $p; }
 return null;
}
function kenya47_election_url() { $page = kenya47_election_page(); return $page ? get_permalink($page) : home_url('/'); }
/** Route an existing hub to the new design without changing its content or URL. */
function kenya47_election_template( $template ) {
 if ( is_page() ) { $hub = kenya47_election_page(); if ( $hub && get_queried_object_id() === (int) $hub->ID ) return get_template_directory() . '/templates/election-hub.php'; }
 return $template;
}
add_filter( 'template_include', 'kenya47_election_template' );
function kenya47_menu_fallback() {
 $links = array( 'Profiles' => kenya47_category_url('profiles'), 'Counties' => kenya47_page_url('counties'), 'Economy' => kenya47_category_url('economy'), 'Opinions' => kenya47_category_url('opinion'), 'Explainers' => kenya47_category_url('explainers'), 'Analysis' => kenya47_category_url('analysis'), '2027' => kenya47_election_url() );
 echo '<ul class="nav-list">'; foreach ( $links as $label => $url ) echo '<li><a href="' . esc_url($url) . '">' . esc_html($label) . '</a></li>'; echo '</ul>';
}
function kenya47_county_url( $name ) {
 $term = get_term_by( 'slug', kenya47_county_slug($name), 'qt_county' );
 if ( ! $term ) $term = get_term_by( 'name', $name, 'qt_county' );
 if ( $term && ! is_wp_error($term) ) { $url = get_term_link($term); if ( ! is_wp_error($url) ) return $url; }
 return '';
}
/** A county archive should include legacy investigations and events as well as posts. */
function kenya47_county_query( $query ) {
 if ( ! is_admin() && $query->is_main_query() && $query->is_tax('qt_county') ) $query->set( 'post_type', array('post','qt_investigation','qt_event') );
}
add_action( 'pre_get_posts', 'kenya47_county_query' );
