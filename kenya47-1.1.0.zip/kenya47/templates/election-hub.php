<?php
/** Template Name: Kenya 47 Election 2027 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="wrap">
<header class="page-heading election-heading"><span class="eyebrow"><span class="signal"></span> THE KENYA 47 ELECTION DESK</span><h1>Kenya decides.<br><em>2027.</em></h1><p>The decisions, people and issues shaping Kenya’s 2027 general election, with a view from across all 47 counties.</p><a class="text-link" href="<?php echo esc_url(kenya47_page_url('counties')); ?>">Explore the counties →</a></header>
<section class="section"><div class="section-head"><div><span class="eyebrow"><span class="signal"></span> ELECTION COVERAGE</span><h2>The 2027 record<span class="heading-dot">.</span></h2><p>Reporting and context from across the country.</p></div></div>
<?php $category = get_category_by_slug('election-2027'); $paged = max(1, get_query_var('paged'), get_query_var('page')); $coverage = $category ? new WP_Query(array('post_type'=>'post','post_status'=>'publish','cat'=>$category->term_id,'posts_per_page'=>9,'paged'=>$paged,'ignore_sticky_posts'=>true)) : null;
if($coverage && $coverage->have_posts()): ?><div class="story-grid"><?php while($coverage->have_posts()): $coverage->the_post(); get_template_part('template-parts/card'); endwhile; ?></div><div class="pagination"><?php echo wp_kses_post(paginate_links(array('total'=>$coverage->max_num_pages,'current'=>$paged,'prev_text'=>'← Previous','next_text'=>'Next →'))); ?></div><?php wp_reset_postdata(); else: ?><div class="empty-message"><strong>Coverage is on its way.</strong><p>Election reporting will appear here as it is published.</p></div><?php endif; ?></section>
<?php while(have_posts()): the_post(); if(trim(get_the_content())): ?><section class="article-content entry-content"><?php the_content(); ?></section><?php endif; endwhile; ?>
<section class="county-feature election-cta"><div class="county-feature-copy"><span class="eyebrow"><span class="signal"></span> THE LOCAL PICTURE</span><h2>Every county.<br><em>Every voice.</em></h2><p>The national picture is built from the stories and decisions that matter locally.</p><a class="button button-light" href="<?php echo esc_url(kenya47_page_url('counties')); ?>">Explore all 47 counties ↗</a></div></section></div>
<?php get_footer(); ?>
