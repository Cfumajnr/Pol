<?php defined('ABSPATH') || exit; ?><!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>
<div class="topline"><div class="wrap topline-inner"><span>Independent journalism. A national perspective.</span><span>Kenya &nbsp; / &nbsp; All 47 counties</span></div></div>
<header class="site-header"><div class="wrap header-row">
<a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Kenya 47, home"><span>KENYA<span class="brand-number">47<span class="brand-dot">.</span></span></span><small>THE WHOLE STORY</small></a>
<div class="header-side"><span class="header-motto">The country, in context.</span><details class="header-search"><summary>⌕ <span>Search</span></summary><?php get_search_form(); ?></details><button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-menu">Menu <span aria-hidden="true">☰</span></button></div>
</div><div class="nav-wrap"><nav class="wrap main-nav" id="primary-menu" aria-label="Main navigation"><?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'menu_class'=>'nav-list','fallback_cb'=>'kenya47_menu_fallback')); ?><a class="nav-discover" href="<?php echo esc_url(kenya47_page_url('counties')); ?>">Explore the counties <span aria-hidden="true">↗</span></a></nav></div></header>
<main id="main">
