# Kenya 47 — WordPress theme 1.1.0

A fresh, national public-interest theme. It includes an indexed directory for all 47 counties, responsive templates, search, article and archive layouts, and a dynamic homepage populated from real published WordPress content. It makes no claim that all counties already have coverage.

## Safe installation

1. Back up your WordPress database, uploads and existing theme. Install and test on a staging copy first. The ZIP is a theme, **not** a database, media or complete-site backup.
2. Upload `kenya47-1.1.0.zip` via Appearance → Themes → Add New → Upload Theme and activate it **on staging**.
3. Activation adds missing county taxonomy terms, the Profiles, Economy, Opinion, Explainers, Analysis and Election 2027 categories, a Counties page, an Election 2027 hub and basic informational pages if missing. It does not overwrite existing terms, pages or articles. Check Posts → Counties to confirm all 47 exist. Save Settings → Permalinks once, and purge page/CDN caches.
4. Assign articles to relevant counties and categories. The home page shows real published posts and investigations; empty sections stay empty. You can assign a custom primary or footer menu in Appearance → Menus. Existing Quiet Truths menu assignments do not automatically transfer to this separate theme. The default menu is Profiles, Counties, Economy, Opinions, Explainers, Analysis and 2027. An assigned primary menu overrides it.
5. Review every existing About, Contact, Privacy, Corrections, election, and other page for old branding, five-county claims, and promises that no longer match operations. Update WordPress Settings → General site title and tagline. This theme does not overwrite them or alter your domain.
6. Test home, mobile navigation, all county links, old article URLs, media, search, pagination, comments, menus and any SEO, caching or other plugins on the actual host. Confirm accessibility, email and security measures before launch.

## Compatibility and important limitations

- The theme registers existing `qt_county`, `qt_topic` and `qt_role` taxonomies and `qt_investigation`, `qt_leader`, `qt_event` post types with the legacy rewrite slugs so existing records and county assignments can remain available. Existing pages, posts, images and meta are not deleted. Generic templates are used for legacy types: the old theme's specialist leader and event displays are not reproduced. Their metadata remains in the database but may not be displayed.
- The old theme's newsletter, polls, subscribers admin, custom widgets, original election hub features, schema, source-tip tooling and automatic menu seeding are **not** included. Activating Kenya 47 disables those old theme features; it does not intentionally delete their stored data. Do not switch on production until you have assessed any live dependencies, subscriber privacy and data export/migration. No newsletters or poll functionality are claimed here.
- If another plugin registers the same post types or taxonomies, test for conflicts on staging. The new election hub displays posts assigned to the Election 2027 category. Legacy election pages using the original template are reused; check the resolved URL and page content. Legacy theme menu locations and customizer settings do not automatically migrate.
- Existing county terms are matched by slug/name; unusual renamed or legacy `qt-` slugs should be checked manually. Activation creates terms only when the standard slug or name is absent; it does not rename or delete anything. If creation fails, investigate WordPress logs/database and re-activate on staging.
- County directory includes names and official code order, not governors, population, or unverified officeholder facts. Editors are responsible for maintaining accuracy.
- This theme does not enforce HTTPS, provide a secure or anonymous tip line, provide a legal/privacy policy, verify articles, or guarantee email deliverability. Enforce HTTPS at hosting level and use reviewed source-safety procedures.
- Name and branding are working choices; check trademarks and domain availability. The bundled illustration is AI-generated. A WordPress Playground demonstration was checked for the homepage, directory, sample county and category archives, election hub, article, search, and informational pages. This is not a production compatibility, security, accessibility, mail or migration certification; test with your own WordPress/PHP/plugin/host versions before public deployment. No production site has been modified.

## Files
`style.css` is the WordPress theme manifest; `functions.php` defines setup and content registration; `inc/counties.php` lists counties; `front-page.php` and `page-counties.php` render the homepage and directory; `assets/` contains bundled styles, scripts and editorial illustration. The theme has no CDN or build-step dependency.

The seeded Contact, Corrections and Privacy pages contain launch placeholders, not final policies or contact channels. Replace them with accurate, reviewed information before opening to the public. On existing sites, old pages are not changed and must be manually reviewed.
