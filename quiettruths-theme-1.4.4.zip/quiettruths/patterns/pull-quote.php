<?php
/**
 * Title: Pull quote
 * Slug: quiettruths/pull-quote
 * Categories: quiettruths
 * Description: A wide pull quote for a line that carries the story.
 *
 * Block pattern: pull quote.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

return '<!-- wp:group {"className":"qt-pull-quote","align":"wide"} -->
<div class="wp-block-group qt-pull-quote alignwide"><!-- wp:quote -->
<blockquote class="wp-block-quote"><!-- wp:paragraph -->
<p>Western Kenya must be at the table where decisions are made, not knocking from the outside.</p>
<!-- /wp:paragraph --><cite>Attribute the speaker and the occasion</cite></blockquote>
<!-- /wp:quote --></div>
<!-- /wp:group -->';
