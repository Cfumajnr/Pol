<?php
/**
 * Title: Email tip contact call to action
 * Slug: quiettruths/tip-line
 * Categories: quiettruths
 * Description: A closing call to action pointing readers at the newsroom tip contact.
 *
 * Block pattern: email tip contact call to action.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

return '<!-- wp:group {"align":"wide","style":{"color":{"background":"#F3F0E9"},"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}},"border":{"left":{"color":"#A32020","width":"4px"}}}} -->
<div class="wp-block-group alignwide has-background" style="border-left-color:#A32020;border-left-width:4px;background-color:#F3F0E9;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:heading {"level":2,"fontSize":"large"} -->
<h2 class="wp-block-heading has-large-font-size">Have a document? Tell us.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Tender awards, audit queries, land titles, payroll lists, a memo someone hoped you would not read. Send it and we will treat your identity as the most important fact in the story.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"vivid-cyan-blue"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="mailto:info@quiettruths.co.ke">Email the desk</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><em>Use a personal device and a personal email address, not one issued by your employer. Do not send documents from a work computer.</em></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->';
