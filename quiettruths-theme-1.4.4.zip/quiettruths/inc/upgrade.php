<?php
/**
 * One-time upgrades for installs that already run this theme.
 *
 * Two classes of change cannot ship by editing the theme's own code alone.
 *
 * Core pages are seeded once and skipped thereafter, so an address written into
 * a page body stays there no matter what the seeder says now. Menu sync only
 * ever adds spec items — it never deletes an editor's work — so an item this
 * theme added and has since retired stays in the menu until someone notices.
 *
 * Both need an explicit pass, recorded so it runs once and never again.
 *
 * @package QuietTruths
 * @since   1.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Contact addresses retired in 1.4.0, mapped to their replacement.
 *
 * The newsroom consolidated four inboxes into three. Only exact matches of a
 * retired address are replaced anywhere, so an address an editor typed
 * deliberately is never touched. The retired masthead tagline is listed here for
 * the same reason.
 *
 * @since 1.4.0
 * @return array<string, string> Retired address => current address.
 */
function quiettruths_retired_emails() {
	return array(
		'tips@quiettruths.co.ke'        => 'info@quiettruths.co.ke',
		'news@quiettruths.co.ke'        => 'editor@quiettruths.co.ke',
		'corrections@quiettruths.co.ke' => 'admin@quiettruths.co.ke',
		'privacy@quiettruths.co.ke'     => 'info@quiettruths.co.ke',
	);
}

/**
 * Replace retired addresses in seeded pages and in stored Customizer settings.
 *
 * Pages first: the seeder skips pages that already exist, so its new copy never
 * reaches them. Then the theme mods — saving any control in the Customizer's
 * contact section writes every control in it, so a stored old default would
 * keep serving the retired address even after this release.
 *
 * @since 1.4.0
 * @return int Number of records updated.
 */
function quiettruths_retire_old_emails() {
	$map     = quiettruths_retired_emails();
	$updated = 0;

	foreach ( array_keys( quiettruths_core_pages() ) as $slug ) {
		if ( '2027' === (string) $slug ) {
			$page = quiettruths_election_page();
		} else {
			$page = get_page_by_path( (string) $slug );
		}

		if ( ! $page ) {
			continue;
		}

		$content = str_replace( array_keys( $map ), array_values( $map ), (string) $page->post_content );

		if ( $content === $page->post_content ) {
			continue;
		}

		$result = wp_update_post(
			array(
				'ID'           => (int) $page->ID,
				'post_content' => $content,
			)
		);

		if ( ! is_wp_error( $result ) ) {
			++$updated;
		}
	}

	/* The masthead tagline changed in 1.4.1. Retire the stored copy of the old
	 * default; a tagline an editor rewrote is left alone. */
	if ( 'Five counties, covered properly' === (string) get_theme_mod( 'qt_tagline', '' ) ) {
		set_theme_mod( 'qt_tagline', "The record behind Western Kenya's politics" );
		++$updated;
	}

	foreach ( array( 'qt_tip_email', 'qt_news_email', 'qt_corrections_email' ) as $mod ) {
		$stored = (string) get_theme_mod( $mod, '' );

		if ( isset( $map[ $stored ] ) ) {
			set_theme_mod( $mod, $map[ $stored ] );
			++$updated;
		}
	}

	return $updated;
}

/**
 * Remove menu items that fell out of the theme's specs in 1.4.0.
 *
 * About left the top nav for the footer; the 2027 hub left the footer because it
 * is already the nav's button. Both are matched by destination, and only inside
 * menus this theme created, so a hand-built menu is left alone.
 *
 * The same pass de-duplicates every theme-owned menu and re-syncs it, which is
 * what repairs installations whose menus doubled before 1.4.1.
 *
 * @since 1.4.0
 * @return int Number of menu items removed.
 */
function quiettruths_prune_retired_menu_items() {
	$about    = get_page_by_path( 'about' );
	$election = quiettruths_election_page();
	$targets  = array();

	if ( $about ) {
		$targets['primary'] = (int) $about->ID;
	}

	if ( $election ) {
		$targets['footer_sections'] = (int) $election->ID;
	}

	$removed = 0;

	foreach ( $targets as $location => $page_id ) {
		$menu_id = (int) get_option( 'qt_owned_menu_' . $location, 0 );

		if ( ! $menu_id ) {
			continue;
		}

		$items = wp_get_nav_menu_items( $menu_id );
		$items = is_array( $items ) ? $items : array();

		/*
		 * Match the destination, not just the object reference. On an install
		 * whose menus were seeded while the About page was missing, the item is a
		 * plain link to /about/ and would survive an object-id comparison.
		 */
		$identity = quiettruths_menu_item_identity( (string) get_permalink( $page_id ) );

		foreach ( $items as $item ) {
			$is_object = ( 'post_type' === $item->type && 'page' === $item->object && (int) $item->object_id === $page_id );
			$is_link   = ( 'custom' === $item->type && quiettruths_menu_item_identity( $item->url ) === $identity );

			if ( $is_object || $is_link ) {
				wp_delete_post( (int) $item->ID, true );
				++$removed;
			}
		}
	}

	/*
	 * De-duplicate every menu the theme owns, then re-sync. Installations that
	 * duplicated their menus before 1.4.1 — the seeder added a second copy beside
	 * each plain link it failed to recognise — are repaired here; the ones that
	 * did not are unaffected, because a menu with no repeats loses nothing.
	 */
	foreach ( array_keys( quiettruths_menu_locations() ) as $location ) {
		$menu_id = (int) get_option( 'qt_owned_menu_' . $location, 0 );

		if ( ! $menu_id ) {
			continue;
		}

		$removed += quiettruths_dedupe_menu_items( $menu_id );

		// Re-number positions so the remaining items stay in spec order.
		quiettruths_sync_menu_items( $menu_id, $location );
	}

	return $removed;
}

/**
 * Run the upgrade pass once per theme version.
 *
 * Priority 97: just before quiettruths_maybe_seed_content(), so pages are
 * rewritten before anything else reads them and the menus are pruned before
 * they are synced.
 *
 * @since 1.4.0
 */
function quiettruths_maybe_upgrade() {
	if ( wp_installing() ) {
		return;
	}

	if ( QUIETTRUTHS_VERSION === get_option( 'qt_upgrade_version' ) ) {
		return;
	}

	// One attempt per ten minutes: on a read-only database this must not run on
	// every single page view.
	if ( get_transient( 'qt_upgrade_lock' ) ) {
		return;
	}

	set_transient( 'qt_upgrade_lock', 1, 10 * MINUTE_IN_SECONDS );

	quiettruths_retire_old_emails();
	quiettruths_prune_retired_menu_items();

	update_option( 'qt_upgrade_version', QUIETTRUTHS_VERSION, false );
}
add_action( 'init', 'quiettruths_maybe_upgrade', 97 );
