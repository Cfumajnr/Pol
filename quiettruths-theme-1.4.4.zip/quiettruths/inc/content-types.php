<?php
/**
 * Custom post types, taxonomies and seeded reference terms.
 *
 * Everything here is prefix-namespaced (`qt_`) and registered with
 * `show_in_rest` so the block editor, REST API and any future headless client
 * all work without extra configuration.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register post types: investigations, leaders, barazas/events.
 *
 * @since 1.0.0
 */
function quiettruths_register_post_types() {

	register_post_type(
		'qt_investigation',
		array(
			'labels'        => array(
				'name'               => __( 'Investigations', 'quiettruths' ),
				'singular_name'      => __( 'Investigation', 'quiettruths' ),
				'add_new_item'       => __( 'Add new investigation', 'quiettruths' ),
				'edit_item'          => __( 'Edit investigation', 'quiettruths' ),
				'new_item'           => __( 'New investigation', 'quiettruths' ),
				'view_item'          => __( 'View investigation', 'quiettruths' ),
				'search_items'       => __( 'Search investigations', 'quiettruths' ),
				'not_found'          => __( 'No investigations found', 'quiettruths' ),
				'not_found_in_trash' => __( 'No investigations in Trash', 'quiettruths' ),
				'menu_name'          => __( 'Investigations', 'quiettruths' ),
			),
			'public'        => true,
			'show_in_rest'  => true,
			'menu_position' => 21,
			'menu_icon'     => 'dashicons-visibility',
			'rewrite'       => array( 'slug' => 'investigations', 'with_front' => false ),
			'has_archive'   => 'investigations',
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'author', 'revisions', 'custom-fields' ),
		)
	);

	register_post_type(
		'qt_leader',
		array(
			'labels'        => array(
				'name'               => __( 'Leaders', 'quiettruths' ),
				'singular_name'      => __( 'Leader', 'quiettruths' ),
				'add_new_item'       => __( 'Add new leader', 'quiettruths' ),
				'edit_item'          => __( 'Edit leader profile', 'quiettruths' ),
				'view_item'          => __( 'View leader', 'quiettruths' ),
				'search_items'       => __( 'Search leaders', 'quiettruths' ),
				'not_found'          => __( 'No leaders found', 'quiettruths' ),
				'menu_name'          => __( 'Leaders Directory', 'quiettruths' ),
			),
			'public'        => true,
			'show_in_rest'  => true,
			'menu_position' => 22,
			'menu_icon'     => 'dashicons-groups',
			'rewrite'       => array( 'slug' => 'leaders', 'with_front' => false ),
			'has_archive'   => 'leaders',
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ),
		)
	);

	register_post_type(
		'qt_event',
		array(
			'labels'        => array(
				'name'               => __( 'Barazas & Events', 'quiettruths' ),
				'singular_name'      => __( 'Event', 'quiettruths' ),
				'add_new_item'       => __( 'Add new event', 'quiettruths' ),
				'edit_item'          => __( 'Edit event', 'quiettruths' ),
				'view_item'          => __( 'View event', 'quiettruths' ),
				'search_items'       => __( 'Search events', 'quiettruths' ),
				'not_found'          => __( 'No events found', 'quiettruths' ),
				'menu_name'          => __( 'Barazas & Events', 'quiettruths' ),
			),
			'public'        => true,
			'show_in_rest'  => true,
			'menu_position' => 23,
			'menu_icon'     => 'dashicons-calendar-alt',
			'rewrite'       => array( 'slug' => 'barazas', 'with_front' => false ),
			'has_archive'   => 'barazas',
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		)
	);
}
add_action( 'init', 'quiettruths_register_post_types' );

/**
 * Register taxonomies: counties, topics and leader roles.
 *
 * `qt_county` is the spine of the site. It is attached to posts and to
 * investigations so a single county archive answers "what has happened in
 * Homa Bay?" across both.
 *
 * @since 1.0.0
 */
function quiettruths_register_taxonomies() {

	register_taxonomy(
		'qt_county',
		array( 'post', 'qt_investigation', 'qt_event' ),
		array(
			'labels'            => array(
				'name'              => __( 'Counties', 'quiettruths' ),
				'singular_name'     => __( 'County', 'quiettruths' ),
				'search_items'      => __( 'Search counties', 'quiettruths' ),
				'all_items'         => __( 'All counties', 'quiettruths' ),
				'edit_item'         => __( 'Edit county', 'quiettruths' ),
				'update_item'       => __( 'Update county', 'quiettruths' ),
				'add_new_item'      => __( 'Add new county', 'quiettruths' ),
				'new_item_name'     => __( 'New county name', 'quiettruths' ),
				'menu_name'         => __( 'Counties', 'quiettruths' ),
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'county', 'with_front' => false ),
		)
	);

	register_taxonomy(
		'qt_topic',
		array( 'post', 'qt_investigation' ),
		array(
			'labels'            => array(
				'name'          => __( 'Topics', 'quiettruths' ),
				'singular_name' => __( 'Topic', 'quiettruths' ),
				'search_items'  => __( 'Search topics', 'quiettruths' ),
				'all_items'     => __( 'All topics', 'quiettruths' ),
				'edit_item'     => __( 'Edit topic', 'quiettruths' ),
				'add_new_item'  => __( 'Add new topic', 'quiettruths' ),
				'menu_name'     => __( 'Topics', 'quiettruths' ),
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'topic', 'with_front' => false ),
		)
	);

	register_taxonomy(
		'qt_role',
		array( 'qt_leader' ),
		array(
			'labels'            => array(
				'name'          => __( 'Roles', 'quiettruths' ),
				'singular_name' => __( 'Role', 'quiettruths' ),
				'search_items'  => __( 'Search roles', 'quiettruths' ),
				'all_items'     => __( 'All roles', 'quiettruths' ),
				'edit_item'     => __( 'Edit role', 'quiettruths' ),
				'add_new_item'  => __( 'Add new role', 'quiettruths' ),
				'menu_name'     => __( 'Roles', 'quiettruths' ),
			),
			'public'            => true,
			'hierarchical'      => false,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'role', 'with_front' => false ),
		)
	);
}
add_action( 'init', 'quiettruths_register_taxonomies' );

/**
 * Seed county and topic terms, and migrate slug changes across versions.
 *
 * Keyed on a version string rather than a boolean flag so that a deliberate
 * change to the term slugs or the county scope re-runs exactly once. Migration
 * renames an existing term's slug in place, which preserves its term_id and
 * therefore every post already tagged to it — nothing is orphaned.
 *
 * Terms an editor has renamed are left alone; only the slug is migrated.
 *
 * @since 1.0.0
 */
function quiettruths_seed_terms() {
	/*
	 * The marker is a speed optimisation, not proof. Tied to a fixed '1.1.0' it
	 * stayed true forever, so a site whose terms went missing — a database
	 * import without term rows, a bulk delete, a seeding run that died halfway —
	 * never got them back, and every county and shelf URL 404'd with no way to
	 * recover short of re-activating the theme. Keying it to the theme version
	 * means each release re-checks once; the per-term checks below make the run
	 * itself idempotent, so nothing an editor renamed is touched.
	 */
	$version = QUIETTRUTHS_VERSION;

	if ( get_option( 'quiettruths_terms_seeded' ) === $version ) {
		return;
	}

	foreach ( quiettruths_counties() as $county ) {
		$slug     = quiettruths_county_term_slug( $county['slug'] );
		$old_slug = 'qt-' . $county['slug'];
		$term     = get_term_by( 'slug', $slug, 'qt_county' );

		if ( ! $term ) {
			$legacy = get_term_by( 'slug', $old_slug, 'qt_county' );

			if ( $legacy && ! is_wp_error( $legacy ) ) {
				// Migrate the pre-1.1 slug. Renaming keeps the term_id, so every
				// post tagged to it stays tagged and no URL history is invented.
				$updated = wp_update_term( (int) $legacy->term_id, 'qt_county', array(
					'slug' => $slug,
				) );

				$term = is_wp_error( $updated ) ? false : get_term( (int) $legacy->term_id, 'qt_county' );
			}
		}

		if ( ! $term ) {
			$result = wp_insert_term( $county['name'], 'qt_county', array(
				'slug'        => $slug,
				'description' => $county['blurb'],
			) );

			if ( ! is_wp_error( $result ) ) {
				$term = get_term( (int) $result['term_id'], 'qt_county' );
			}
		}

		if ( $term && ! is_wp_error( $term ) ) {
			update_term_meta( (int) $term->term_id, 'qt_county_code', $county['code'] );
			update_term_meta( (int) $term->term_id, 'qt_county_population', (int) $county['population'] );
		}
	}

	// Retire the counties this publication stopped covering. The terms are
	// trashed rather than deleted so any reporting already tagged to them can
	// be recovered and re-tagged by hand.
	$in_scope = array();

	foreach ( quiettruths_counties() as $county ) {
		$in_scope[] = quiettruths_county_term_slug( $county['slug'] );
		$in_scope[] = 'qt-' . $county['slug'];
	}

	$existing = get_terms( array(
		'taxonomy'   => 'qt_county',
		'hide_empty' => false,
		'fields'     => 'ids',
	) );

	// get_terms() can return null on some failure paths, which is not a
	// WP_Error — guard for it explicitly or the foreach warns.
	if ( ! is_wp_error( $existing ) && ! empty( $existing ) ) {
		foreach ( $existing as $term_id ) {
			$term = get_term( (int) $term_id, 'qt_county' );

			if ( $term && ! is_wp_error( $term ) && ! in_array( $term->slug, $in_scope, true ) ) {
				wp_delete_term( (int) $term_id, 'qt_county' );
			}
		}
	}

	/*
	 * Categories are the site's shelves and they own the primary navigation
	 * URLs (/category/analysis/ and siblings). The five below are the launch
	 * set, ordered by expected output share. Adding a sixth is an editorial
	 * decision, not a code change — but note the top nav is capped at seven
	 * items, so a new shelf means an old one drops to the footer.
	 */
	$categories = array(
		'Analysis',
		'Profiles',
		'Economy',
		'Explainers',
		'Opinion',
	);

	foreach ( $categories as $category ) {
		$slug = sanitize_title( $category );

		if ( ! get_category_by_slug( $slug ) ) {
			wp_insert_term( $category, 'category', array( 'slug' => $slug ) );
		}
	}

	/*
	 * Election coverage gets its own category so the /2027/ hub has a query to
	 * draw from, and so election reporting is separable from the general
	 * analysis it often overlaps.
	 */
	if ( ! get_category_by_slug( 'election-2027' ) ) {
		wp_insert_term( 'Election 2027', 'category', array( 'slug' => 'election-2027' ) );
	}

	$topics = array(
		'Governance & Audit',
		'Land & Environment',
		'Agriculture & Cooperatives',
		'Devolution & Finance',
		'Health',
		'Education',
		'Security',
		'Business & Trade',
	);

	foreach ( $topics as $topic ) {
		$slug = sanitize_title( $topic );

		if ( ! get_term_by( 'slug', $slug, 'qt_topic' ) ) {
			wp_insert_term( $topic, 'qt_topic', array( 'slug' => $slug ) );
		}
	}

	update_option( 'quiettruths_terms_seeded', $version, false );
}
add_action( 'after_switch_theme', 'quiettruths_seed_terms' );
add_action( 'init', 'quiettruths_seed_terms', 20 );

/**
 * Add leader profile fields to the editor.
 *
 * Stored as post meta on `qt_leader` so the directory can be sorted and
 * filtered by county, office and party without a custom table.
 *
 * @since 1.0.0
 */
function quiettruths_leader_metabox() {
	add_meta_box(
		'qt_leader_details',
		__( 'Leader details', 'quiettruths' ),
		'quiettruths_render_leader_metabox',
		'qt_leader',
		'normal',
		'high'
	);

	add_meta_box(
		'qt_event_details',
		__( 'Event details', 'quiettruths' ),
		'quiettruths_render_event_metabox',
		'qt_event',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'quiettruths_leader_metabox' );

/**
 * Render the leader details metabox.
 *
 * @since 1.0.0
 * @param WP_Post $post Current post.
 */
function quiettruths_render_leader_metabox( $post ) {
	wp_nonce_field( 'qt_leader_details', 'qt_leader_details_nonce' );

	$fields = array(
		'_qt_leader_office'  => __( 'Office held (e.g. Governor, Senator)', 'quiettruths' ),
		'_qt_leader_county'  => __( 'County', 'quiettruths' ),
		'_qt_leader_party'   => __( 'Party', 'quiettruths' ),
		'_qt_leader_since'   => __( 'In office since (e.g. 2022)', 'quiettruths' ),
		'_qt_leader_contact' => __( 'Public contact (email or phone)', 'quiettruths' ),
	);

	echo '<table class="form-table" role="presentation">';

	foreach ( $fields as $key => $label ) {
		$value = get_post_meta( $post->ID, $key, true );

		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
		echo '<td><input type="text" class="widefat" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" /></td></tr>';
	}

	echo '</table>';

	printf(
		'<p class="description">%s</p>',
		esc_html__( 'Only publish contact details a leader has made public. Quiet Truths does not doxx.', 'quiettruths' )
	);
}

/**
 * Render the event details metabox.
 *
 * @since 1.0.0
 * @param WP_Post $post Current post.
 */
function quiettruths_render_event_metabox( $post ) {
	wp_nonce_field( 'qt_event_details', 'qt_event_details_nonce' );

	$start   = get_post_meta( $post->ID, '_qt_event_start', true );
	$end     = get_post_meta( $post->ID, '_qt_event_end', true );
	$venue   = get_post_meta( $post->ID, '_qt_event_venue', true );
	$host    = get_post_meta( $post->ID, '_qt_event_host', true );

	echo '<table class="form-table" role="presentation">';

	echo '<tr><th scope="row"><label for="_qt_event_start">' . esc_html__( 'Start (date &amp; time)', 'quiettruths' ) . '</label></th>';
	echo '<td><input type="datetime-local" class="regular-text" id="_qt_event_start" name="_qt_event_start" value="' . esc_attr( $start ) . '" /></td></tr>';

	echo '<tr><th scope="row"><label for="_qt_event_end">' . esc_html__( 'End (date &amp; time)', 'quiettruths' ) . '</label></th>';
	echo '<td><input type="datetime-local" class="regular-text" id="_qt_event_end" name="_qt_event_end" value="' . esc_attr( $end ) . '" /></td></tr>';

	echo '<tr><th scope="row"><label for="_qt_event_venue">' . esc_html__( 'Venue', 'quiettruths' ) . '</label></th>';
	echo '<td><input type="text" class="widefat" id="_qt_event_venue" name="_qt_event_venue" value="' . esc_attr( $venue ) . '" /></td></tr>';

	echo '<tr><th scope="row"><label for="_qt_event_host">' . esc_html__( 'Hosted by', 'quiettruths' ) . '</label></th>';
	echo '<td><input type="text" class="widefat" id="_qt_event_host" name="_qt_event_host" value="' . esc_attr( $host ) . '" /></td></tr>';

	echo '</table>';
}

/**
 * Save leader and event metabox data.
 *
 * @since 1.0.0
 * @param int $post_id Post ID being saved.
 */
function quiettruths_save_metaboxes( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( wp_is_post_revision( $post_id ) ) {
		return;
	}

	// Leaders.
	if ( isset( $_POST['qt_leader_details_nonce'] ) ) {
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qt_leader_details_nonce'] ) ), 'qt_leader_details' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$leader_fields = array(
			'_qt_leader_office',
			'_qt_leader_county',
			'_qt_leader_party',
			'_qt_leader_since',
			'_qt_leader_contact',
		);

		foreach ( $leader_fields as $field ) {
			if ( ! isset( $_POST[ $field ] ) ) {
				continue;
			}

			update_post_meta(
				$post_id,
				$field,
				sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_text_field applied.
			);
		}
	}

	// Events.
	if ( isset( $_POST['qt_event_details_nonce'] ) ) {
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qt_event_details_nonce'] ) ), 'qt_event_details' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( array( '_qt_event_venue', '_qt_event_host' ) as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				update_post_meta(
					$post_id,
					$field,
					sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_text_field applied.
				);
			}
		}

		foreach ( array( '_qt_event_start', '_qt_event_end' ) as $field ) {
			if ( ! isset( $_POST[ $field ] ) ) {
				continue;
			}

			$raw = sanitize_text_field( wp_unslash( $_POST[ $field ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitize_text_field applied.

			if ( '' === $raw ) { delete_post_meta( $post_id, $field ); continue; }
			$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $raw, wp_timezone() );
			if ( $date && $date->format( 'Y-m-d\TH:i' ) === $raw ) {
				update_post_meta( $post_id, $field, $raw );
			}
		}
	}
}
add_action( 'save_post', 'quiettruths_save_metaboxes' );

/**
 * Order the leaders archive by county then office.
 *
 * @since 1.0.0
 * @param WP_Query $query Current query.
 */
function quiettruths_leader_archive_order( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}

	if ( ! is_post_type_archive( 'qt_leader' ) ) {
		return;
	}

	$query->set( 'orderby', array( 'title' => 'ASC' ) );
	$query->set( 'posts_per_page', 60 );
}
add_action( 'pre_get_posts', 'quiettruths_leader_archive_order' );

/**
 * Order the events archive so upcoming barazas come first.
 *
 * @since 1.0.0
 * @param WP_Query $query Current query.
 */
function quiettruths_event_archive_order( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}

	if ( ! is_post_type_archive( 'qt_event' ) ) {
		return;
	}

	$past = 'past' === quiettruths_input( $_GET, 'qt_events' );
	$now = current_time( 'Y-m-d\TH:i' );
	$query->set( 'meta_key', '_qt_event_start' );
	$query->set( 'orderby', 'meta_value' );
	$query->set( 'order', $past ? 'DESC' : 'ASC' );
	$query->set( 'meta_query', array(
		'relation' => 'OR',
		array( 'relation' => 'AND', array( 'key' => '_qt_event_end', 'value' => '', 'compare' => '!=' ), array( 'key' => '_qt_event_end', 'value' => $now, 'compare' => $past ? '<' : '>=' ) ),
		array(
			'relation' => 'AND',
			array( 'key' => '_qt_event_end', 'compare' => 'NOT EXISTS' ),
			array( 'key' => '_qt_event_start', 'value' => $now, 'compare' => $past ? '<' : '>=' ),
		),
		array(
			'relation' => 'AND',
			array( 'key' => '_qt_event_end', 'value' => '', 'compare' => '=' ),
			array( 'key' => '_qt_event_start', 'value' => $now, 'compare' => $past ? '<' : '>=' ),
		),
	) );
}
add_action( 'pre_get_posts', 'quiettruths_event_archive_order' );

/**
 * Keep the front page query lean: the homepage builds its own secondary loops.
 *
 * @since 1.0.0
 * @param WP_Query $query Current query.
 */
function quiettruths_front_page_query( $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! is_home() ) {
		return;
	}

	$query->set( 'posts_per_page', (int) get_theme_mod( 'qt_posts_per_page', 10 ) );
}
add_action( 'pre_get_posts', 'quiettruths_front_page_query' );
