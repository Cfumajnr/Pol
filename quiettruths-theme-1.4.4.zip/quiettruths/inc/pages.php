<?php
/**
 * Core pages and the navigation that points to them.
 *
 * A site that links to /corrections/ and /contact/ must actually have those
 * pages, and a footer that says "we publish our corrections" is a promise the
 * site has to be able to keep on day one. These pages are seeded with real,
 * editable content on activation — not lorem ipsum, and not dead links.
 *
 * Seeding is idempotent and matched by slug, so re-activation never duplicates
 * a page and never overwrites an editor's changes.
 *
 * @package QuietTruths
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * The core pages this theme creates, keyed by slug.
 *
 * @since 1.1.0
 * @return array<string, array<string, string>> Page definitions.
 */
function quiettruths_core_pages() {
	$tip_email   = get_theme_mod( 'qt_tip_email', 'info@quiettruths.co.ke' );
	$news_email  = get_theme_mod( 'qt_news_email', 'editor@quiettruths.co.ke' );
	$collections = get_theme_mod( 'qt_corrections_email', 'admin@quiettruths.co.ke' );

	$pages = array(
		'about' => array(
			'title'   => __( 'About Quiet Truths', 'quiettruths' ),
			'content' => '<!-- wp:paragraph -->
<p><strong>Quiet Truths reports on five counties: Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We are deliberately narrow. Five counties covered properly will tell you more about how power works in Western Kenya than forty-seven covered thinly. Every budget line, tender award, land transaction and promise made in those five counties is our beat, and we intend to be the record of it.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Investigations.</strong> Long-form reporting built on documents and data. Where we cannot name a source, we say why.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Analysis.</strong> What a decision in Nairobi or a county assembly actually changes on the ground.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Opinion.</strong> Argument from the region, not about it. Contributors keep their disagreements with us.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>The Leaders Directory.</strong> Who represents the five counties, which party sent them, and how to reach their office.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Barazas &amp; events.</strong> Public meetings, county assembly sittings and campaign stops, published before they happen.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Why Trans Nzoia</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Trans Nzoia sat in the former Rift Valley Province, which was abolished in 2013. By economy, politics and electorate it is Western Kenya, and leaving it out on the strength of a provincial line that no longer exists would be administrative nostalgia rather than journalism. It is in scope, and it is covered to the same standard.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="standards">Our standards</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This is the part worth reading before you cite us.</p>
<!-- /wp:paragraph -->

<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Name the source.</strong> Where we can name a source, we do. Where we cannot, we say why in the piece itself rather than leaving the reader to guess.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Publish the document.</strong> If a story rests on a tender award, an audit query or a land title, the document goes up alongside it.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Put it to the subject.</strong> Before we publish criticism of a person or an office, we seek their response and give them a fair window to give one.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Separate reporting from opinion.</strong> Opinion is labelled Opinion and lives on its own shelf. It does not borrow the authority of our reporting.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Correct in the open.</strong> A correction states what was wrong, what it now says, and when it changed. We never silently edit, and we do not rewrite the record. See our <a href="/corrections/">corrections policy</a>.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Protect sources absolutely.</strong> A source\'s identity is the most important fact in most of our stories. We do not log it unless asked to.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Get the small facts right.</strong> Names, figures, dates and county headquarters. Our readers use these pages as a reference, so a wrong population figure is a correction, not a typo.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>If you think we have fallen short of any of this, write to the newsroom. We would rather hear it from you than discover it later.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sources are the most important fact in most of our stories. How to reach the desk safely is on the <a href="/contact/">contact page</a>.</p>
<!-- /wp:paragraph -->',
		),

		'contact' => array(
			'title'   => __( 'Contact', 'quiettruths' ),
			'content' => '<!-- wp:paragraph -->
<p>Three mailboxes, one desk. Use the one that fits.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"className":"qt-data-callout"} -->
<div class="wp-block-group qt-data-callout"><!-- wp:paragraph -->
<p><strong>Tips and documents</strong><br><a href="mailto:' . esc_attr( $tip_email ) . '">' . esc_html( $tip_email ) . '</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p class="has-small-font-size">For anything sensitive. Use a personal email address on a personal device, never one issued by your employer. See the source safety guidance below.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"qt-data-callout"} -->
<div class="wp-block-group qt-data-callout"><!-- wp:paragraph -->
<p><strong>Newsroom</strong><br><a href="mailto:' . esc_attr( $news_email ) . '">' . esc_html( $news_email ) . '</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p class="has-small-font-size">Story leads, press releases, right of reply, interview requests.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"qt-data-callout"} -->
<div class="wp-block-group qt-data-callout"><!-- wp:paragraph -->
<p><strong>Corrections</strong><br><a href="mailto:' . esc_attr( $collections ) . '">' . esc_html( $collections ) . '</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p class="has-small-font-size">If we got something wrong, tell us here. How we handle it is set out in our <a href="/corrections/">corrections policy</a>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Source safety</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item">Use a personal email address, not one issued by your employer. Work email is routinely monitored.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">Do not send documents from a work computer or a work network.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">Tell us if you want to speak on background. We will agree terms before you say anything substantive.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">We do not log or store the identity of a source unless you ask us to.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Right of reply</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If we are about to publish something that criticises you or your office, we will try to put it to you first and give you a fair window to respond. If you believe you have been treated unfairly, write to the newsroom and we will consider it seriously.</p>
<!-- /wp:paragraph -->',
		),

		'corrections' => array(
			'title'   => __( 'Corrections policy', 'quiettruths' ),
			'content' => '<!-- wp:paragraph -->
<p>Quiet Truths aims to be the record of what happened in Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia. A record that quietly rewrites itself is worthless, so our corrections are made in the open.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">How to tell us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Email <a href="mailto:' . esc_attr( $collections ) . '">' . esc_html( $collections ) . '</a>, or use the "Report a correction" link at the foot of any article. Every correction request is read by an editor, not filtered by a form.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we do</h2>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We acknowledge.</strong> You get a reply, even if we conclude we were right.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We check against the primary source.</strong> The document, the transcript, the statute — not against what we remember writing.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We correct on the record.</strong> The correction appears at the top of the article, states what was wrong and what it has been changed to, and carries the date it was made.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We never silently edit.</strong> The text may change, but the fact that it changed does not disappear.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>We withdraw what cannot stand.</strong> If a central claim fails, the story comes down and a notice explains why.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Mistakes we treat as serious</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Getting a name, a figure, a date or a county headquarters wrong matters more here than it would elsewhere, because our readers use these pages as a reference. A wrong population figure or a wrong officeholder is a correction, not a typo.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Corrections log</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><em>Editors: list material corrections here, newest first, as "Date — Article — What changed and why". An empty log is fine at launch; a hidden one is not.</em></p>
<!-- /wp:paragraph -->',
		),
	);

	/*
	 * The election hub sits at /2027/ — a page slug, not a category, because
	 * the spec calls for that exact URL and the hub is more than a listing.
	 * It uses the election template, which queries the Election 2027 category.
	 */
	$pages['2027'] = array(
		'title'    => __( 'Election 2027', 'quiettruths' ),
		'template' => 'templates/election-hub.php',
		'content'  => '<!-- wp:paragraph -->
<p>Everything Quiet Truths publishes about the 2027 general election across Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia: the contests, the money, the machinery and the count.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This page updates itself as election coverage is published. Below it you will find the latest reporting, the candidate profiles we have filed, and the county-by-county picture.</p>
<!-- /wp:paragraph -->',
	);

	// Privacy, in the footer by legal convention.
	$pages['privacy'] = array(
		'title'   => __( 'Privacy', 'quiettruths' ),
		'content' => '<!-- wp:paragraph -->
<p>This page explains what Quiet Truths collects, why, and what you can ask us to do about it. It is written for readers in Kenya and reflects the Data Protection Act, 2019.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we collect</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Email address</strong>, if you sign up to the newsletter. Only once you have confirmed it by email.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Comments</strong> you choose to leave, along with the name you give and your IP address, which WordPress stores for spam filtering.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Poll votes.</strong> A cookie on your device records that you voted so the tally is not padded. It contains no personal information.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item"><strong>Standard server logs</strong>, such as your IP address and browser, kept by our hosting provider for security.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we do not do</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li class="wp-block-list-item">We do not sell or share the subscriber list. Not with parties, not with candidates, not with advertisers.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">We do not run third-party advertising trackers.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li class="wp-block-list-item">We do not record the identity of a source unless you explicitly ask us to.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Sources</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If you send us a document or speak to us on background, protecting you matters more than the story. Use a personal email address on a personal device, not one issued by your employer. Practical guidance is on the <a href="/contact/">contact page</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Your rights</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You can ask us what we hold about you, ask us to correct it, or ask us to delete it. Write to <a href="mailto:info@quiettruths.co.ke">info@quiettruths.co.ke</a> and we will respond within thirty days. Newsletter subscribers can follow the unsubscribe link in each newsletter and confirm removal.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Retention</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Confirmed subscriber records are kept until you unsubscribe or ask us to delete them. Unconfirmed signup requests are removed after approximately thirty days by a scheduled task. Poll vote cookies expire after a year. Comments remain published unless you ask us to remove them.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Cookies</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We use two kinds: a colour-scheme preference, so the site stays in the mode you chose, and a poll-vote marker. Neither identifies you and neither is shared with anyone.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Contact</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Data protection questions go to <a href="mailto:info@quiettruths.co.ke">info@quiettruths.co.ke</a>. If you are not satisfied with our response you can complain to the Office of the Data Protection Commissioner in Kenya.</p>
<!-- /wp:paragraph -->',
	);

	/**
	 * Filter the core pages before they are seeded.
	 *
	 * @since 1.1.0
	 * @param array $pages Page definitions keyed by slug.
	 */
	return apply_filters( 'quiettruths_core_pages', $pages );
}

/**
 * Create the core pages if they are missing.
 *
 * Matched by slug, so an editor who renames a page's title keeps their work and
 * re-activation does not create a second copy.
 *
 * @since 1.1.0
 */
function quiettruths_seed_core_pages() {
	foreach ( quiettruths_core_pages() as $slug => $page ) {
		if ( ( '2027' === (string) $slug && quiettruths_election_page() ) || get_page_by_path( $slug ) ) {
			continue;
		}

		$post_id = wp_insert_post( array(
			'post_title'   => $page['title'],
			'post_name'    => '2027' === (string) $slug ? 'election-2027' : $slug,
			'post_content' => isset( $page['content'] ) ? $page['content'] : '',
			'post_status'  => 'publish',
			'post_type'    => 'page',
		) );

		// A page can declare its own template, which is how the /2027/ hub gets
		// a self-updating listing instead of static content.
		if ( ! is_wp_error( $post_id ) && $post_id && ! empty( $page['template'] ) ) {
			update_post_meta( (int) $post_id, '_wp_page_template', $page['template'] );
		}
	}

}
add_action( 'after_switch_theme', 'quiettruths_seed_core_pages' );

/**
 * Seed the theme's content on any request, not only on activation.
 *
 * WordPress fires `after_switch_theme` when a theme is *activated*. It does not
 * fire when an already-active theme is replaced — by FTP, by a file manager, or
 * by "replace current with uploaded" in the theme uploader, which is how most
 * updates actually happen. On those installs the core pages are never created
 * and the menus are never assigned, so /about/, /contact/, /corrections/,
 * /privacy/ and the election hub all 404 even though the theme is running.
 *
 * Runs once per theme version. Everything it calls is idempotent: terms are
 * matched by slug, pages by path, menus by assigned location.
 *
 * Priority 98 puts it after the post types and taxonomies are registered and
 * just before quiettruths_maybe_flush_rewrites(), so the rules are rebuilt for
 * content that now exists.
 *
 * @since 1.3.2
 */
function quiettruths_maybe_seed_content() {
	if ( wp_installing() ) {
		return;
	}

	if ( QUIETTRUTHS_VERSION === get_option( 'qt_content_version' ) ) {
		return;
	}

	// One attempt per ten minutes: if something blocks insertion (a read-only
	// database, a missing capability) this must not run on every page view.
	if ( get_transient( 'qt_content_seed' ) ) {
		return;
	}

	set_transient( 'qt_content_seed', 1, 10 * MINUTE_IN_SECONDS );

	quiettruths_seed_terms();
	quiettruths_seed_core_pages();
	quiettruths_seed_menus();

	update_option( 'qt_content_version', QUIETTRUTHS_VERSION, false );
}
add_action( 'init', 'quiettruths_maybe_seed_content', 98 );

/** Legacy numeric URL resolves to the saved page, without renaming editor data. */
function quiettruths_election_rewrite() {
	$page = quiettruths_election_page();
	if ( $page ) { add_rewrite_rule( '^2027/?$', 'index.php?page_id=' . (int) $page->ID, 'top' ); }
}
add_action( 'init', 'quiettruths_election_rewrite', 20 );
/**
 * The rewrite rules this theme's URLs depend on.
 *
 * @since 1.3.1
 * @return array<int, string> Rule patterns that must exist in the stored rules.
 */
function quiettruths_required_rewrite_rules() {
	$rules = array(
		'county/([^/]+)/?$',        // County taxonomy archives.
		'leaders/?$',               // Leaders directory.
		'barazas/?$',               // Events archive.
		'investigations/?$',        // Investigations archive.
	);

	/*
	 * The legacy numeric hub URL, which the nav's own button points at.
	 *
	 * Unlike the four above it is not generated by a registered post type:
	 * quiettruths_election_rewrite() adds it at init 20, and core merges
	 * init-time rules into the stored set only when it rebuilds that set — while
	 * a populated `rewrite_rules` option is served verbatim. So an install whose
	 * rules were last flushed before the election page existed keeps 404ing at
	 * /2027/ indefinitely, because nothing about the other four looks wrong.
	 *
	 * Required only while the page exists; otherwise the check would demand a
	 * rule that cannot be generated and re-flush on every attempt.
	 *
	 * @since 1.4.1
	 */
	if ( quiettruths_election_page() ) {
		$rules[] = '^2027/?$';
	}

	return $rules;
}

/**
 * Whether the stored rewrite rules can resolve this theme's URLs.
 *
 * @since 1.3.1
 * @return bool True when every required rule is present.
 */
function quiettruths_rewrite_rules_are_current() {
	$rules = get_option( 'rewrite_rules' );

	if ( ! is_array( $rules ) || empty( $rules ) ) {
		return false;
	}

	foreach ( quiettruths_required_rewrite_rules() as $rule ) {
		if ( ! isset( $rules[ $rule ] ) ) {
			return false;
		}
	}

	return true;
}

/**
 * Rebuild rewrite rules when they cannot serve this theme's URLs.
 *
 * WordPress only flushes rules when a theme is *activated*. Replacing an active
 * theme by uploading a ZIP — the normal update path — fires no such hook, so the
 * old rules stay in place and every county, leader, event and investigation URL
 * returns 404 until an administrator happens to re-save permalinks. That is a
 * support ticket, not a reader-facing outage, so the theme fixes it itself.
 *
 * Cost on the normal path is one autoloaded option read and four isset() checks.
 * A flush is attempted at most once per five minutes, so a server whose
 * .htaccess is not writable cannot turn this into a flush on every request.
 *
 * @since 1.3.1
 */
function quiettruths_maybe_flush_rewrites() {
	if ( wp_installing() ) {
		return;
	}

	$rules_ok   = quiettruths_rewrite_rules_are_current();
	$version_ok = QUIETTRUTHS_VERSION === get_option( 'qt_rewrite_version' );

	if ( $rules_ok && $version_ok ) {
		return;
	}

	if ( get_transient( 'qt_rewrite_flush' ) ) {
		return;
	}

	set_transient( 'qt_rewrite_flush', 1, 5 * MINUTE_IN_SECONDS );

	/*
	 * Re-register the election hub rule before rebuilding.
	 *
	 * quiettruths_election_rewrite() runs at init 20 and bails when the hub page
	 * does not exist yet. On a request that also has to create that page —
	 * quiettruths_maybe_seed_content() at priority 98 — the rule would be missing
	 * from this rebuild. Re-adding it here makes one request enough; the rule is
	 * keyed by its regex, so registering it twice overwrites rather than
	 * duplicates.
	 *
	 * @since 1.4.1
	 */
	quiettruths_election_rewrite();

	// Hard flush: regenerates the rules and rewrites .htaccess when the server
	// needs it, which a soft flush deliberately skips.
	flush_rewrite_rules();

	/*
	 * Record success only once the rules actually pass.
	 *
	 * flush_rewrite_rules() called during `init` does not flush: WP_Rewrite defers
	 * it to `wp_loaded` so that everyone has registered their rewrites first
	 * (class-wp-rewrite.php, flush_rules()). Checking here would therefore read
	 * the old rule set and always fail, so the confirmation runs after the
	 * deferred flush instead. Where `wp_loaded` has already fired — WP-CLI, a
	 * later hook — the flush was synchronous and the check can run immediately.
	 *
	 * Recording success only on a passing check also covers the case where this
	 * request had to create the election hub page itself: rather than claim
	 * success with the hub rule still missing, the marker stays stale and the next
	 * request finishes the job, with the transient above throttling the attempts.
	 *
	 * @since 1.4.1
	 */
	if ( did_action( 'wp_loaded' ) ) {
		quiettruths_confirm_rewrite_flush();
	} else {
		add_action( 'wp_loaded', 'quiettruths_confirm_rewrite_flush', 20 );
	}
}

/**
 * Record the rewrite version once the stored rules pass the theme's check.
 *
 * @since 1.4.1
 */
function quiettruths_confirm_rewrite_flush() {
	if ( quiettruths_rewrite_rules_are_current() ) {
		update_option( 'qt_rewrite_version', QUIETTRUTHS_VERSION, false );
	}
}
add_action( 'init', 'quiettruths_maybe_flush_rewrites', 99 );
