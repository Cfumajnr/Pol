<?php
/**
 * Structured data, Open Graph and metadata hygiene.
 *
 * No SEO plugin is required. A news site in this space competes for Google News
 * and Discover placement, which means correct NewsArticle markup, a dated
 * byline, and a canonical on every archive — all of which are cheap to emit
 * directly and painful to retrofit.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Emit Organization and WebSite schema site-wide.
 *
 * @since 1.0.0
 */
function quiettruths_schema_site() {
	if ( ! quiettruths_owns_metadata() ) { return; }
	if ( is_singular() || is_archive() || is_search() ) {
		return; // Handled by quiettruths_schema_content().
	}

	$org = array(
		'@context' => 'https://schema.org',
		'@type'    => 'NewsMediaOrganization',
		'name'     => get_bloginfo( 'name' ),
		'url'      => home_url( '/' ),
		'slogan'   => get_theme_mod( 'qt_tagline', '' ),
		'email'    => get_theme_mod( 'qt_news_email', '' ),
		'areaServed' => array(
			'@type' => 'AdministrativeArea',
			'name'  => __( 'Western Kenya', 'quiettruths' ),
		),
	);

	$address = get_theme_mod( 'qt_address', '' );

	if ( $address ) {
		$org['address'] = array(
			'@type'         => 'PostalAddress',
			'streetAddress' => $address,
			'addressCountry' => 'KE',
		);
	}

	echo quiettruths_jsonld( $org ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- quiettruths_jsonld() returns a safe, encoded script tag.
}
add_action( 'wp_head', 'quiettruths_schema_site', 5 );

/**
 * Emit Article / NewsArticle schema on singles and archives.
 *
 * @since 1.0.0
 */
function quiettruths_schema_content() {
	if ( ! quiettruths_owns_metadata() ) { return; }
	if ( is_singular( array( 'post', 'qt_investigation' ) ) ) {
		$post_id = get_the_ID();

		$article = array(
			'@context'      => 'https://schema.org',
			'@type'         => 'qt_investigation' === get_post_type( $post_id ) ? 'ReportageNewsArticle' : 'NewsArticle',
			'headline'      => get_the_title( $post_id ),
			'datePublished' => get_the_date( 'c', $post_id ),
			'dateModified'  => get_the_modified_date( 'c', $post_id ),
			'mainEntityOfPage' => array(
				'@type' => 'WebPage',
				'@id'   => get_permalink( $post_id ),
			),
			'author'        => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ),
			),
			'publisher'     => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
			),
		);

		$excerpt = get_the_excerpt( $post_id );

		if ( $excerpt ) {
			$article['description'] = wp_strip_all_tags( $excerpt );
		}

		if ( has_post_thumbnail( $post_id ) ) {
			$article['image'] = array( get_the_post_thumbnail_url( $post_id, 'qt-lead' ) );
		}

		$counties = get_the_terms( $post_id, 'qt_county' );

		if ( ! is_wp_error( $counties ) && $counties ) {
			$article['about'] = array();

			foreach ( $counties as $county ) {
				$article['about'][] = array(
					'@type' => 'Place',
					'name'  => $county->name . ' County, Kenya',
				);
			}
		}

		echo quiettruths_jsonld( $article ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- safe by construction.
	}

	if ( is_tax( 'qt_county' ) ) {
		$term = get_queried_object();

		if ( $term instanceof WP_Term ) {
			$county = quiettruths_get_county( str_replace( 'qt-', '', $term->slug ) );

			$place = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'AdministrativeArea',
				'name'        => $term->name . ' County',
				'containedInPlace' => array(
					'@type' => 'Country',
					'name'  => 'Kenya',
				),
			);

			if ( $county ) {
				$place['identifier'] = $county['code'];

				if ( $county['governor'] ) {
					$place['employee'] = array(
						'@type'    => 'Person',
						'name'     => $county['governor'],
						'jobTitle' => __( 'Governor', 'quiettruths' ),
					);
				}
			}

			echo quiettruths_jsonld( $place ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- safe by construction.
		}
	}
}
add_action( 'wp_head', 'quiettruths_schema_content', 6 );

/**
 * Open Graph and Twitter card tags.
 *
 * WhatsApp and X drive most political link sharing in Kenya, and both read
 * these tags to build the preview card. Without them a shared investigation
 * shows up as a bare URL and gets far less traction.
 *
 * @since 1.0.0
 */
function quiettruths_open_graph() {
	if ( ! quiettruths_owns_metadata() ) { return; }
	$site_name = get_bloginfo( 'name' );

	$tags = array(
		'og:site_name' => $site_name,
		'og:locale'    => 'en_KE',
	);

	if ( is_singular() ) {
		$tags['og:type']  = 'article';
		$tags['og:title'] = get_the_title();
		$tags['og:url']   = get_permalink();

		$excerpt = get_the_excerpt();

		if ( $excerpt ) {
			$tags['og:description'] = wp_strip_all_tags( $excerpt );
		}

		if ( has_post_thumbnail() ) {
			$tags['og:image']       = get_the_post_thumbnail_url( null, 'qt-lead' );
			$tags['twitter:card']   = 'summary_large_image';
		}

		$tags['article:published_time'] = get_the_date( 'c' );
		$tags['article:modified_time']  = get_the_modified_date( 'c' );
	} else {
		$tags['og:type']        = 'website';
		$tags['og:title']       = wp_get_document_title();
		$tags['og:url']         = quiettruths_current_url();
		$tags['og:description'] = get_bloginfo( 'description' );
	}

	foreach ( $tags as $property => $content ) {
		if ( '' === $content || null === $content ) {
			continue;
		}

		$prefix = 0 === strpos( $property, 'twitter:' ) ? 'name' : 'property';

		printf(
			'<meta %1$s="%2$s" content="%3$s">' . "\n",
			esc_attr( $prefix ),
			esc_attr( $property ),
			esc_attr( $content )
		);
	}
}
add_action( 'wp_head', 'quiettruths_open_graph', 7 );

/**
 * Return the URL of the current request, built from the parsed request path.
 *
 * Deliberately derived from `home_url()` plus the request rather than from
 * `$_SERVER['HTTP_HOST']`, so a spoofed Host header can never end up in an
 * og:url tag that readers then share.
 *
 * @since 1.0.0
 * @return string Absolute URL.
 */
function quiettruths_current_url() {
	if ( is_search() ) { return get_search_link(); }
	return get_pagenum_link( max( 1, (int) get_query_var( 'paged' ) ), false );
}

/** Let an installed SEO plugin own metadata, or disable via this filter. */
function quiettruths_owns_metadata() {
	return apply_filters( 'quiettruths_output_metadata', ! ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) ) );
}

/** Core supplies singular canonicals; explicitly supply index/archive URLs. */
function quiettruths_archive_canonical() {
	if ( ! quiettruths_owns_metadata() || is_singular() || is_search() || is_404() || is_feed() ) {
		return;
	}
	if ( ! ( is_archive() || is_home() || is_front_page() ) ) {
		return;
	}
	$url = get_pagenum_link( max( 1, (int) get_query_var( 'paged' ) ), false );
	if ( is_post_type_archive( 'qt_event' ) && 'past' === quiettruths_input( $_GET, 'qt_events' ) ) {
		$url = add_query_arg( 'qt_events', 'past', $url );
	}
	// Strip tracking and interaction arguments from otherwise canonical paths.
	$parts = wp_parse_url( $url );
	$query = array();
	if ( isset( $parts['query'] ) ) { parse_str( $parts['query'], $query ); }
	$keep = array( 'paged', 'cat', 'tag', 'author', 'm', 'year', 'monthnum', 'day', 'post_type', 'taxonomy', 'term', 'qt_county', 'qt_topic', 'qt_events' );
	foreach ( array_keys( $query ) as $key ) {
		if ( ! in_array( $key, $keep, true ) ) { $url = remove_query_arg( $key, $url ); }
	}
	echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
}
add_action( 'wp_head', 'quiettruths_archive_canonical', 9 );

/**
 * Add a `humans.txt` style editorial note to the feed.
 *
 * @since 1.0.0
 * @param string $content Feed item content.
 * @return string Content with a source line appended.
 */
/**
 * BreadcrumbList JSON-LD for the visible trail.
 *
 * Emitted only when the theme owns metadata and is actually printing
 * breadcrumbs, so a site running Rank Math or Yoast breadcrumbs does not end up
 * with two competing trails in the same page.
 *
 * @since 1.3.0
 * @return void
 */
function quiettruths_schema_breadcrumb() {
	if ( ! quiettruths_owns_metadata() || ! quiettruths_breadcrumbs_enabled() ) {
		return;
	}

	$items = quiettruths_breadcrumb_trail();

	if ( count( $items ) < 2 ) {
		return;
	}

	$list = array();

	foreach ( $items as $index => $item ) {
		$entry = array(
			'@type'    => 'ListItem',
			'position' => $index + 1,
			'name'     => $item['label'],
		);

		// The current page is not a link; schema.org allows omitting "item".
		if ( '' !== $item['url'] ) {
			$entry['item'] = $item['url'];
		}

		$list[] = $entry;
	}

	echo '<script type="application/ld+json">' . wp_json_encode(
		array(
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $list,
		)
	) . '</script>' . "\n";
}
add_action( 'wp_head', 'quiettruths_schema_breadcrumb', 6 );

function quiettruths_feed_source_line( $content ) {
	return $content . '<p><em>' . esc_html( sprintf(
		/* translators: %s: site name. */
		__( 'Originally reported by %s.', 'quiettruths' ),
		get_bloginfo( 'name' )
	) ) . '</em></p>';
}
add_filter( 'the_excerpt_rss', 'quiettruths_feed_source_line' );

