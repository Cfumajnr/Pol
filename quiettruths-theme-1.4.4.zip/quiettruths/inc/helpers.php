<?php
/**
 * Template helpers.
 *
 * Every function here is prefixed `quiettruths_` so the theme can coexist with
 * plugins without collisions, and so a child theme can override behaviour with
 * `remove_action`/`add_filter` rather than copying templates.
 *
 * Conventions used throughout:
 *  - Functions that PRINT are named `the_*` (matching core's vocabulary).
 *  - Functions that RETURN are named `get_*`.
 *  - All output is escaped at the point of echo. No exceptions.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/* ---------------------------------------------------------------------------
 * Reading time & excerpts
 * ------------------------------------------------------------------------ */

/**
 * Estimate reading time in minutes for a post.
 *
 * @since 1.0.0
 * @param int $post_id Optional. Post ID. Defaults to the current post.
 * @return int Minutes, minimum 1.
 */
function quiettruths_reading_minutes( $post_id = 0 ) {
	$post = get_post( $post_id );

	if ( ! $post ) {
		return 1;
	}

	// strip_shortcodes + wp_strip_all_tags keeps embeds out of the count.
	$words = str_word_count( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) );

	return max( 1, (int) ceil( $words / 220 ) );
}

/**
 * Return a clean excerpt of a given word length.
 *
 * Falls back to a content-derived excerpt when the author left it blank.
 *
 * @since 1.0.0
 * @param int $words  Optional. Word count. Default 24.
 * @param int $post_id Optional. Post ID. Defaults to the current post.
 * @return string Excerpt text, unescaped.
 */
function quiettruths_get_excerpt( $words = 24, $post_id = 0 ) {
	$post = get_post( $post_id );

	if ( ! $post ) {
		return '';
	}

	$source = has_excerpt( $post ) ? $post->post_excerpt : $post->post_content;
	$source = wp_strip_all_tags( strip_shortcodes( $source ) );
	$source = str_replace( array( "\r", "\n" ), ' ', $source );
	$source = preg_replace( '/\s+/', ' ', $source );

	$parts = array_filter( explode( ' ', $source ) );

	if ( count( $parts ) <= $words ) {
		return implode( ' ', $parts );
	}

	return implode( ' ', array_slice( $parts, 0, $words ) ) . '&hellip;';
}

/**
 * Print an excerpt.
 *
 * @since 1.0.0
 * @param int $words   Optional. Word count.
 * @param int $post_id Optional. Post ID.
 */
function quiettruths_the_excerpt( $words = 24, $post_id = 0 ) {
	echo esc_html( quiettruths_get_excerpt( $words, $post_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_html applied to full string.
}

/* ---------------------------------------------------------------------------
 * Taxonomy chips
 * ------------------------------------------------------------------------ */

/**
 * Print linked chips for a taxonomy on a post.
 *
 * @since 1.0.0
 * @param string $taxonomy Taxonomy slug.
 * @param int    $post_id  Optional. Post ID.
 * @param int    $limit    Optional. Max chips. Default 3.
 */
function quiettruths_the_terms_chips( $taxonomy, $post_id = 0, $limit = 3 ) {
	$terms = get_the_terms( $post_id ? $post_id : get_the_ID(), $taxonomy );

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return;
	}

	$terms = array_slice( $terms, 0, max( 1, (int) $limit ) );

	echo '<ul class="qt-chips">';
	foreach ( $terms as $term ) {
		printf(
			'<li class="qt-chip"><a href="%1$s" rel="tag">%2$s</a></li>',
			esc_url( get_term_link( $term ) ),
			esc_html( $term->name )
		);
	}
	echo '</ul>';
}

/* ---------------------------------------------------------------------------
 * Byline / meta
 * ------------------------------------------------------------------------ */

/**
 * Print the byline and dateline for a post.
 *
 * @since 1.0.0
 * @param int  $post_id   Optional. Post ID.
 * @param bool $show_time Optional. Show updated time. Default true.
 */
function quiettruths_the_meta( $post_id = 0, $show_time = true ) {
	$post_id = $post_id ? $post_id : get_the_ID();

	if ( ! $post_id ) {
		return;
	}

	$time = sprintf(
		'<time class="qt-meta__time" datetime="%1$s">%2$s</time>',
		esc_attr( get_the_date( 'c', $post_id ) ),
		esc_html( get_the_date( 'j M Y', $post_id ) )
	);

	printf( '<div class="qt-meta"><span class="qt-meta__by">%1$s</span>%2$s',
		esc_html( sprintf(
			/* translators: %s: author name. */
			__( 'By %s', 'quiettruths' ),
			get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) )
		) ),
		$time // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_attr/esc_html above.
	);

	if ( $show_time ) {
		printf(
			'<span class="qt-meta__read">%s</span>',
			esc_html( sprintf(
				/* translators: %d: reading time in minutes. */
				_n( '%d min read', '%d min read', quiettruths_reading_minutes( $post_id ), 'quiettruths' ),
				quiettruths_reading_minutes( $post_id )
			) )
		);
	}

	echo '</div>';
}

/* ---------------------------------------------------------------------------
 * Post cards
 * ------------------------------------------------------------------------ */

/**
 * Print a post card.
 *
 * @since 1.0.0
 * @param string $variant One of 'lead', 'grid', 'list', 'compact'.
 * @param int    $post_id Optional. Post ID.
 */
function quiettruths_card( $variant = 'grid', $post_id = 0 ) {
	$allowed = array( 'lead', 'grid', 'list', 'compact' );
	$variant = in_array( $variant, $allowed, true ) ? $variant : 'grid';

	get_template_part( 'template-parts/content/card', $variant );
}

/**
 * Print a grid of post cards from the current query.
 *
 * @since 1.0.0
 * @param string $variant Card variant.
 * @param int    $count   Max cards to print.
 */
function quiettruths_card_loop( $variant = 'grid', $count = 6 ) {
	$printed = 0;

	while ( have_posts() && $printed < $count ) {
		the_post();
		quiettruths_card( $variant );
		$printed++;
	}

	if ( 0 === $printed ) {
		quiettruths_no_results();
	}

	// Reset so the page can run other queries afterwards.
	rewind_posts();
}

/**
 * Print a friendly "nothing here yet" block.
 *
 * @since 1.0.0
 */
function quiettruths_no_results() {
	get_template_part( 'template-parts/content/none' );
}

/* ---------------------------------------------------------------------------
 * Breadcrumbs
 * ------------------------------------------------------------------------ */

/**
 * Whether the theme prints its own breadcrumb trail.
 *
 * On by default. Turn it off in the Customizer, or with
 * `add_filter( 'quiettruths_breadcrumbs_enabled', '__return_false' );` when
 * another plugin already prints a trail, so the reader never sees two. Yoast is
 * detected automatically when its breadcrumbs are switched on; for Rank Math or
 * anything else use the filter.
 *
 * @since 1.3.0
 * @return bool True when the theme should render breadcrumbs.
 */
function quiettruths_breadcrumbs_enabled() {
	$enabled = (bool) get_theme_mod( 'qt_breadcrumbs', true );

	if ( $enabled && class_exists( 'WPSEO_Options' ) && method_exists( 'WPSEO_Options', 'get' ) ) {
		$yoast = WPSEO_Options::get( 'breadcrumbs-enable', false );

		if ( $yoast ) {
			$enabled = false;
		}
	}

	return (bool) apply_filters( 'quiettruths_breadcrumbs_enabled', $enabled );
}

/**
 * The shelf category a post should be filed under in the breadcrumb trail.
 *
 * Prefers one of the five launch shelves over any other category, so "Home >
 * Profiles > Name" stays true even when a story also sits in a topical category.
 *
 * @since 1.3.0
 * @param int $post_id Post ID.
 * @return WP_Term|null Category term.
 */
function quiettruths_primary_shelf_category( $post_id ) {
	$terms = get_the_category( $post_id );

	if ( empty( $terms ) || is_wp_error( $terms ) ) {
		return null;
	}

	foreach ( array( 'analysis', 'profiles', 'economy', 'explainers', 'opinion' ) as $shelf ) {
		foreach ( $terms as $term ) {
			if ( $shelf === $term->slug ) {
				return $term;
			}
		}
	}

	return isset( $terms[0] ) ? $terms[0] : null;
}

/**
 * Build the breadcrumb trail.
 *
 * Returns an ordered list of `label`/`url` pairs; the last entry is the current
 * page and carries an empty URL. Shared by the visible trail and the
 * BreadcrumbList JSON-LD in inc/seo.php so the two cannot disagree.
 *
 * @since 1.3.0
 * @return array<int, array<string, string>> Trail items.
 */
function quiettruths_breadcrumb_trail() {
	if ( is_front_page() ) {
		return array();
	}

	$items   = array(
		array(
			'label' => __( 'Home', 'quiettruths' ),
			'url'   => home_url( '/' ),
		),
	);
	$term    = is_category() || is_tag() || is_tax() ? get_queried_object() : null;

	// Middle crumbs: the shelf, archive or section this page belongs to.
	if ( is_singular( 'qt_investigation' ) ) {
		$items[] = array( 'label' => __( 'Investigations', 'quiettruths' ), 'url' => (string) get_post_type_archive_link( 'qt_investigation' ) );
	} elseif ( is_singular( 'qt_leader' ) ) {
		$items[] = array( 'label' => __( 'Leaders Directory', 'quiettruths' ), 'url' => (string) get_post_type_archive_link( 'qt_leader' ) );
	} elseif ( is_singular( 'qt_event' ) ) {
		$items[] = array( 'label' => __( 'Barazas & Events', 'quiettruths' ), 'url' => (string) get_post_type_archive_link( 'qt_event' ) );
	} elseif ( is_singular( 'post' ) ) {
		$category = quiettruths_primary_shelf_category( get_the_ID() );

		if ( $category ) {
			$link = get_term_link( $category );
			$items[] = array( 'label' => $category->name, 'url' => is_wp_error( $link ) ? '' : $link );
		}
	} elseif ( is_page() ) {
		foreach ( array_reverse( get_post_ancestors( get_the_ID() ) ) as $ancestor_id ) {
			$items[] = array( 'label' => get_the_title( $ancestor_id ), 'url' => (string) get_permalink( $ancestor_id ) );
		}
	} elseif ( $term instanceof WP_Term ) {
		if ( 'qt_county' === $term->taxonomy ) {
			$items[] = array( 'label' => __( 'Counties', 'quiettruths' ), 'url' => home_url( '/#qt-counties' ) );
		} elseif ( 'qt_topic' === $term->taxonomy ) {
			$items[] = array( 'label' => __( 'Topics', 'quiettruths' ), 'url' => get_post_type_archive_link( 'post' ) );
		}

		// Parent terms first, so a nested category reads Home > Parent > Child.
		foreach ( array_reverse( get_ancestors( $term->term_id, $term->taxonomy, 'taxonomy' ) ) as $ancestor_id ) {
			$ancestor = get_term( $ancestor_id, $term->taxonomy );

			if ( ! $ancestor || is_wp_error( $ancestor ) ) {
				continue;
			}

			$link    = get_term_link( $ancestor );
			$items[] = array( 'label' => $ancestor->name, 'url' => is_wp_error( $link ) ? '' : $link );
		}
	} elseif ( is_post_type_archive() ) {
		$items[] = array( 'label' => (string) post_type_archive_title( '', false ), 'url' => '' );
	}

	// Terminal crumb: always the current page, never a link.
	if ( is_singular() ) {
		$items[] = array( 'label' => (string) get_the_title(), 'url' => '' );
	} elseif ( is_search() ) {
		$items[] = array( 'label' => sprintf( __( 'Search: %s', 'quiettruths' ), (string) get_search_query() ), 'url' => '' );
	} elseif ( $term instanceof WP_Term ) {
		$items[] = array( 'label' => $term->name, 'url' => '' );
	} elseif ( is_post_type_archive() ) {
		// Already added above; nothing further to append.
		$items[] = array( 'label' => '', 'url' => '' );
		$items   = array_filter(
			$items,
			static function ( $item ) {
				return '' !== $item['label'];
			}
		);
	} elseif ( is_author() ) {
		$items[] = array( 'label' => (string) get_the_author_meta( 'display_name', (int) get_queried_object_id() ), 'url' => '' );
	} elseif ( is_day() ) {
		$items[] = array( 'label' => (string) get_the_date(), 'url' => '' );
	} elseif ( is_month() ) {
		$items[] = array( 'label' => (string) get_the_date( 'F Y' ), 'url' => '' );
	} elseif ( is_year() ) {
		$items[] = array( 'label' => (string) get_the_date( 'Y' ), 'url' => '' );
	} elseif ( is_archive() ) {
		$items[] = array( 'label' => wp_strip_all_tags( (string) get_the_archive_title() ), 'url' => '' );
	} elseif ( is_404() ) {
		$items[] = array( 'label' => __( 'Page not found', 'quiettruths' ), 'url' => '' );
	}

	return apply_filters( 'quiettruths_breadcrumb_trail', array_values( $items ) );
}

/**
 * Print breadcrumbs for archives, singles and search.
 *
 * Deliberately lightweight: no plugin dependency, and the JSON-LD twin lives in
 * inc/seo.php so structured data is not duplicated here.
 *
 * @since 1.0.0
 * @return void
 */
function quiettruths_breadcrumbs() {
	if ( ! quiettruths_breadcrumbs_enabled() ) {
		return;
	}

	$items = quiettruths_breadcrumb_trail();

	if ( count( $items ) < 2 ) {
		return;
	}

	// Rendered as "Home > Profiles > Name". The chevron is markup, not a CSS
	// pseudo-element, so it survives a stripped stylesheet and reads correctly
	// to a screen reader as a separator rather than as content.
	echo '<nav class="qt-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'quiettruths' ) . '"><ol>';
	$last = count( $items ) - 1;

	foreach ( $items as $index => $item ) {
		if ( $index > 0 ) {
			echo '<li class="qt-breadcrumbs__sep" aria-hidden="true">&rsaquo;</li>';
		}

		if ( $index === $last || '' === $item['url'] ) {
			printf( '<li aria-current="page">%s</li>', esc_html( $item['label'] ) );
		} else {
			printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( $item['url'] ), esc_html( $item['label'] ) );
		}
	}

	echo '</ol></nav>';
}

/* ---------------------------------------------------------------------------
 * Pagination
 * ------------------------------------------------------------------------ */

/**
 * Print accessible archive pagination.
 *
 * @since 1.0.0
 * @param string $query Optional. Query var to paginate. Default 'paged'.
 */
function quiettruths_pagination( $query = 'paged' ) {
	$big = 999999999;

	$links = paginate_links(
		array(
			'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format'    => '?paged=%#%',
			'current'   => max( 1, (int) get_query_var( $query ) ),
			'total'     => $GLOBALS['wp_query']->max_num_pages,
			'prev_text' => __( '&larr; Newer', 'quiettruths' ),
			'next_text' => __( 'Older &rarr;', 'quiettruths' ),
			'type'      => 'list',
		)
	);

	if ( empty( $links ) ) {
		return;
	}

	echo '<nav class="qt-pagination" aria-label="' . esc_attr__( 'Posts navigation', 'quiettruths' ) . '">';
	echo wp_kses_post( $links );
	echo '</nav>';
}

/* ---------------------------------------------------------------------------
 * County navigation
 * ------------------------------------------------------------------------ */

/**
 * Print the county navigation grid.
 *
 * @since 1.0.0
 * @param bool $with_stats Optional. Show population and governor. Default true.
 */
function quiettruths_county_grid( $with_stats = true ) {
	$counties = quiettruths_counties();
	$totals   = quiettruths_region_totals();

	echo '<section id="qt-counties" class="qt-counties">';

	printf(
		'<header class="qt-section-head"><h2>%1$s</h2><p>%2$s</p></header>',
		esc_html__( 'The five counties we cover', 'quiettruths' ),
		esc_html( sprintf(
			/* translators: 1: number of people, 2: number of constituencies. */
			__( '%1$s people across %2$s constituencies, covered properly rather than thinly.', 'quiettruths' ),
			quiettruths_number( $totals['population'] ),
			quiettruths_number( $totals['constituencies'] )
		) )
	);

	echo '<div class="qt-county-grid">';

	foreach ( $counties as $county ) {
		$link = quiettruths_county_link( $county['slug'] );

		/*
		 * When the county archive does not exist yet, render the card without a
		 * link rather than pointing it somewhere misleading. A dead or bait-and-
		 * switch link on a site whose brand is being the record costs more than
		 * a card that is not clickable for one release.
		 */
		if ( '' !== $link ) {
			echo '<a class="qt-county-card" href="' . esc_url( $link ) . '">';
		} else {
			echo '<span class="qt-county-card qt-county-card--static">';
		}

		echo '<span class="qt-county-card__code">' . esc_html( $county['code'] ) . '</span>';
		echo '<span class="qt-county-card__name">' . esc_html( $county['name'] ) . '</span>';
		echo '<span class="qt-county-card__capital">' . esc_html( $county['capital'] ) . '</span>';

		if ( $with_stats ) {
			echo '<span class="qt-county-card__stats">';
			echo '<span>' . esc_html( quiettruths_number( $county['population'] ) ) . '</span>';
			echo '<small>' . esc_html__( 'people', 'quiettruths' ) . '</small>';
			echo '</span>';
			echo '<span class="qt-county-card__gov">' . esc_html( $county['governor'] );

			if ( ! empty( $county['party'] ) ) {
				echo ' <em>' . esc_html( $county['party'] ) . '</em>';
			}

			echo '</span>';
		}

		echo '' !== $link ? '</a>' : '</span>';
	}

	echo '</div>';
	echo '<p class="qt-county-note">' . esc_html( sprintf(
		/* translators: %s: census year. */
		__( 'Population, land area and density: %s Kenya Population and Housing Census (KNBS). Officeholders are updated by our editors.', 'quiettruths' ),
		'2019'
	) ) . '</p>';
	echo '</section>';
}

/**
 * Print compact county filter chips, used on archives and the leaders directory.
 *
 * @since 1.0.0
 */
function quiettruths_county_chips() {
	echo '<ul class="qt-county-chips" aria-label="' . esc_attr__( 'Filter by county', 'quiettruths' ) . '">';
	printf(
		'<li><a class="qt-county-chip" href="%s">%s</a></li>',
		esc_url( home_url( '/#qt-counties' ) ),
		esc_html__( 'All counties', 'quiettruths' )
	);

	foreach ( quiettruths_counties() as $county ) {
		$link = quiettruths_county_link( $county['slug'] );

		if ( '' === $link ) {
			continue;
		}

		printf(
			'<li><a class="qt-county-chip" href="%1$s">%2$s</a></li>',
			esc_url( $link ),
			esc_html( $county['name'] )
		);
	}

	echo '</ul>';
}

/* ---------------------------------------------------------------------------
 * Email tip contact
 * ------------------------------------------------------------------------ */

/**
 * Build the "send us a document" mailto link.
 *
 * Ordinary email contact: no encryption, anonymity or expiry is provided.
 *
 * @since 1.0.0
 * @param string $subject Optional. Prefilled subject.
 * @return string Escaped URL.
 */
function quiettruths_tip_url( $subject = '' ) {
	$to = get_theme_mod( 'qt_tip_email', 'info@quiettruths.co.ke' );

	$args = array(
		'subject' => $subject ? $subject : __( 'Tip for Quiet Truths', 'quiettruths' ),
		'body' => sprintf(
			__( "Sent: %1\$s\n\nYour message:\n\n---\n%2\$s email tip contact. Ordinary email is not anonymous or end-to-end encrypted.", 'quiettruths' ),
			gmdate( 'Y-m-d H:i' ), get_bloginfo( 'name' )
		),
	);

	return esc_url( add_query_arg( array_map( 'rawurlencode', $args ), 'mailto:' . $to ) );
}

/**
 * Print the tip-line call to action.
 *
 * @since 1.0.0
 */
function quiettruths_tip_cta() {
	get_template_part( 'template-parts/tip-cta' );
}

/* ---------------------------------------------------------------------------
 * JSON-LD
 * ------------------------------------------------------------------------ */

/**
 * Return a JSON-LD payload as a script tag.
 *
 * @since 1.0.0
 * @param array $data Schema.org array.
 * @return string Safe script tag, or an empty string for invalid input.
 */
function quiettruths_jsonld( array $data ) {
	if ( empty( $data ) ) {
		return '';
	}

	// JSON_UNESCAPED_SLASHES keeps URLs readable; UNESCAPED_UNICODE is safe for
	// the UTF-8 output we declare in the <meta charset>.
	$json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

	if ( ! $json ) {
		return '';
	}

	// Escape any closing script sequence so content cannot break out of the tag.
	$json = str_replace( '</', '<\/', $json );

	return '<script type="application/ld+json">' . $json . '</script>';
}

/* ---------------------------------------------------------------------------
 * Leaders directory
 * ------------------------------------------------------------------------ */

/**
 * Print a grid of leader profiles from the current query.
 *
 * @since 1.0.0
 * @param int $count Optional. Max cards. Default 12.
 */
function quiettruths_leaders_grid( $count = 12 ) {
	$printed = 0;

	while ( have_posts() && $printed < $count ) {
		the_post();
		get_template_part( 'template-parts/leader/card' );
		$printed++;
	}

	if ( 0 === $printed ) {
		printf(
			'<p class="qt-empty">%s</p>',
			esc_html__( 'No profiles match that filter yet. Our editors are adding leaders county by county.', 'quiettruths' )
		);
	}

	rewind_posts();
}

/* ---------------------------------------------------------------------------
 * Events / barazas
 * ------------------------------------------------------------------------ */

/**
 * Print a human-friendly event date, e.g. "Sat 4 Oct 2027 · 10:00".
 *
 * @since 1.0.0
 * @param int $post_id Optional. Post ID.
 */
function quiettruths_the_event_date( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$start   = get_post_meta( $post_id, '_qt_event_start', true );

	if ( ! $start ) {
		echo esc_html( get_the_date( 'j M Y', $post_id ) );
		return;
	}

	$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $start, wp_timezone() );
	$timestamp = $date ? $date->getTimestamp() : false;

	if ( false === $timestamp ) {
		echo esc_html( get_the_date( 'j M Y', $post_id ) );
		return;
	}

	/* translators: 1: day name, 2: date, 3: time. */
	echo esc_html( sprintf(
		__( '%1$s %2$s · %3$s', 'quiettruths' ),
		wp_date( 'D', $timestamp ),
		wp_date( 'j M Y', $timestamp ),
		wp_date( 'H:i', $timestamp )
	) );
}

/**
 * Whether an event is still upcoming.
 *
 * @since 1.0.0
 * @param int $post_id Optional. Post ID.
 * @return bool True when the start date is in the future, or unset.
 */
function quiettruths_event_is_upcoming( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$end = get_post_meta( $post_id, '_qt_event_end', true );
	$start = $end ? $end : get_post_meta( $post_id, '_qt_event_start', true );
	if ( ! $start ) { return true; }
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $start, wp_timezone() );
	return $date ? $date->getTimestamp() >= time() : true;
}

/* ---------------------------------------------------------------------------
 * Misc UI atoms
 * ------------------------------------------------------------------------ */

/**
 * Print the theme's inline SVG logo mark.
 *
 * Embedded rather than referenced as a file so it inherits currentColor, works
 * offline in the previewer, and costs no extra request on LiteSpeed.
 *
 * @since 1.0.0
 */
function quiettruths_logo_mark() {
	echo '<svg class="qt-mark" viewBox="0 0 32 32" role="img" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">';
	echo '<circle cx="16" cy="16" r="15" fill="none" stroke="currentColor" stroke-width="1.5"/>';
	echo '<path d="M9 20.5c2.4-3 4.2-9.2 7-9.2s4.6 6.2 7 9.2" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>';
	echo '<circle cx="16" cy="10.4" r="1.6" fill="currentColor"/>';
	echo '</svg>';
}

/**
 * Print the site brand block (mark + name + tagline).
 *
 * @since 1.0.0
 */
function quiettruths_branding() {
	$tagline = get_theme_mod( 'qt_tagline', __( 'The record behind Western Kenya\'s politics', 'quiettruths' ) );

	echo '<a class="qt-brand" href="' . esc_url( home_url( '/' ) ) . '" rel="home">';
	quiettruths_logo_mark();
	echo '<span class="qt-brand__text">';
	echo '<span class="qt-brand__name">' . esc_html( get_bloginfo( 'name' ) ) . '</span>';

	if ( $tagline ) {
		echo '<span class="qt-brand__tag">' . esc_html( $tagline ) . '</span>';
	}

	echo '</span></a>';
}

/**
 * Print the breaking-news ticker strip.
 *
 * Reads comma-separated headlines from the Customizer. Renders nothing when the
 * control is empty or the feature is switched off, so there is no empty strip
 * on a fresh install.
 *
 * @since 1.0.0
 */
function quiettruths_breaking_news() {
	if ( ! get_theme_mod( 'qt_breaking_enable', false ) ) {
		return;
	}

	$raw = (string) get_theme_mod( 'qt_breaking_items', '' );

	if ( '' === trim( $raw ) ) {
		return;
	}

	$items = array_filter( array_map( 'trim', explode( '|', $raw ) ) );

	if ( empty( $items ) ) {
		return;
	}

	echo '<div class="qt-ticker" role="region" aria-label="' . esc_attr__( 'Breaking news', 'quiettruths' ) . '">';
	echo '<span class="qt-ticker__label">' . esc_html( get_theme_mod( 'qt_breaking_label', __( 'Breaking', 'quiettruths' ) ) ) . '</span>';
	echo '<div class="qt-ticker__track">';

	foreach ( $items as $item ) {
		// Each item is "Headline :: URL"; the URL half is optional.
		$parts = array_map( 'trim', explode( '::', $item, 2 ) );
		$label = isset( $parts[0] ) ? $parts[0] : '';
		$url   = isset( $parts[1] ) ? $parts[1] : '';

		if ( '' === $label ) {
			continue;
		}

		if ( $url ) {
			printf(
				'<a class="qt-ticker__item" href="%1$s">%2$s</a>',
				esc_url( $url ),
				esc_html( $label )
			);
		} else {
			printf( '<span class="qt-ticker__item">%s</span>', esc_html( $label ) );
		}
	}

	echo '</div></div>';
}

/**
 * Print social links from Customizer controls.
 *
 * @since 1.0.0
 */
function quiettruths_social_links() {
	$networks = array(
		'qt_x'        => __( 'X (Twitter)', 'quiettruths' ),
		'qt_facebook' => __( 'Facebook', 'quiettruths' ),
		'qt_youtube'  => __( 'YouTube', 'quiettruths' ),
		'qt_tiktok'   => __( 'TikTok', 'quiettruths' ),
		'qt_whatsapp' => __( 'WhatsApp', 'quiettruths' ),
	);

	$rendered = array();

	foreach ( $networks as $key => $label ) {
		$url = (string) get_theme_mod( $key, '' );

		if ( '' === trim( $url ) ) {
			continue;
		}

		$rendered[] = sprintf(
			'<li><a href="%1$s" rel="me noopener" target="_blank">%2$s</a></li>',
			esc_url( $url ),
			esc_html( $label )
		);
	}

	if ( empty( $rendered ) ) {
		return;
	}

	echo '<ul class="qt-social">' . implode( '', $rendered ) . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- each item escaped above.
}

/** Resolve an existing hub without changing its content or permalink. */
function quiettruths_election_page() {
	$page = get_page_by_path( '2027' );
	if ( $page && 'publish' === $page->post_status ) { return $page; }
	$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 1, 'meta_key' => '_wp_page_template', 'meta_value' => 'templates/election-hub.php', 'orderby' => 'ID', 'order' => 'ASC' ) );
	return $pages ? $pages[0] : null;
}
function quiettruths_election_url() {
	$page = quiettruths_election_page();
	return $page ? get_permalink( $page ) : home_url( '/election-2027/' );
}
function quiettruths_is_election_url( $url ) {
	$legacy = untrailingslashit( home_url( '/2027/' ) );
	return untrailingslashit( $url ) === $legacy || untrailingslashit( $url ) === untrailingslashit( quiettruths_election_url() );
}

/**
 * Domain shown in the footer bottom bar.
 *
 * Defaults to the host this install actually serves, so a staging copy does not
 * advertise the production domain, and can be overridden in the Customizer.
 *
 * @since 1.3.0
 * @return string Domain without scheme or trailing slash.
 */
function quiettruths_footer_domain() {
	$default = (string) wp_parse_url( home_url(), PHP_URL_HOST );

	if ( '' === $default ) {
		$default = 'quiettruths.co.ke';
	}

	$domain = (string) get_theme_mod( 'qt_footer_domain', '' );

	return '' !== trim( $domain ) ? $domain : $default;
}

/**
 * The homepage launch panel, shown when there is no reporting to list yet.
 *
 * A new newsroom's front page would otherwise render a tall blank column beside
 * the rail while the first stories are being reported. This panel fills that
 * space with the site's promise and a bundled illustration, so the homepage
 * reads as deliberate rather than broken. It is only ever called when the
 * Latest, Opinion and Barazas loops all came back empty.
 *
 * @since 1.4.3
 */
function quiettruths_home_empty_state() {
	$qt_image = get_template_directory_uri() . '/assets/images/launch.jpg';
	?>
	<section class="qt-launch" aria-labelledby="qt-launch-title">
		<img
			class="qt-launch__media"
			src="<?php echo esc_url( $qt_image ); ?>"
			alt="<?php esc_attr_e( 'Illustration of a western Kenya hillside at sunset: tea pickers at work and a reader at a stall where newspapers are pinned up.', 'quiettruths' ); ?>"
			width="1200"
			height="675"
			loading="lazy"
		/>
		<div class="qt-launch__body">
			<span class="qt-flag"><?php esc_html_e( 'Quiet Truths is reporting', 'quiettruths' ); ?></span>
			<h2 id="qt-launch-title" class="qt-launch__title"><?php esc_html_e( 'The first stories are being reported now.', 'quiettruths' ); ?></h2>
			<p class="qt-launch__text"><?php esc_html_e( 'We are working sources and documents across Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia. The first investigations and county briefings land here soon — and readers who send us documents shape what we publish first.', 'quiettruths' ); ?></p>
			<div class="qt-launch__actions">
				<?php
				/*
				 * One call to action only. The rail already carries the
				 * "have a document" prompt, so the launch panel points readers to
				 * the About page instead of asking for documents a second time.
				 */
				?>
				<a class="qt-btn qt-btn--accent" href="<?php echo esc_url( quiettruths_page_url( 'about' ) ); ?>"><?php esc_html_e( 'Who we are', 'quiettruths' ); ?></a>
			</div>
		</div>
	</section>
	<?php
}
