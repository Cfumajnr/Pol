<?php
/**
 * Theme setup, assets, menus, image sizes and block patterns.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Declare theme support and register menus.
 *
 * @since 1.0.0
 */
function quiettruths_setup() {
	load_theme_textdomain( 'quiettruths', QUIETTRUTHS_DIR . 'languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'wp-block-styles' );

	// A custom logo lets editors swap the masthead without a designer.
	add_theme_support( 'custom-logo', array(
		'height'      => 96,
		'width'       => 480,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	/*
	 * Image sizes are deliberately few. Every extra size multiplies disk usage
	 * on shared hosting, and LiteSpeed serves these straight off disk.
	 */
	add_image_size( 'qt-lead', 1440, 810, true );
	add_image_size( 'qt-card', 720, 480, true );
	add_image_size( 'qt-thumb', 360, 270, true );
	add_image_size( 'qt-portrait', 480, 600, true );

	/*
	 * One location, deliberately. The top nav is a fixed seven-item spec and the
	 * footer is fixed markup, so extra locations would only invite an editor to
	 * build a menu that never renders.
	 */
	register_nav_menus( quiettruths_menu_locations() );
}
add_action( 'after_setup_theme', 'quiettruths_setup' );

/**
 * Set the content width so embeds and the editor do not overflow.
 *
 * Declared as a global before 'after_setup_theme' per the theme check rule.
 *
 * @since 1.0.0
 */
function quiettruths_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'quiettruths_content_width', 820 );
}
add_action( 'after_setup_theme', 'quiettruths_content_width', 0 );

/**
 * Enqueue front-end assets.
 *
 * @since 1.0.0
 */
function quiettruths_scripts() {
	// Optional webfonts. Off by default so the theme works fully offline and on
	// hosts that block outbound requests; editors can switch it on.
	if ( get_theme_mod( 'qt_webfonts', false ) ) {
		wp_enqueue_style(
			'quiettruths-fonts',
			'https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=Inter:wght@400;500;600;700&display=swap',
			array(),
			null // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Google serves a versioned URL itself.
		);
	}

	wp_enqueue_style(
		'quiettruths-style',
		QUIETTRUTHS_URI . 'assets/css/main.css',
		array(),
		QUIETTRUTHS_VERSION
	);

	wp_enqueue_script(
		'quiettruths-main',
		QUIETTRUTHS_URI . 'assets/js/main.js',
		array(),
		QUIETTRUTHS_VERSION,
		true
	);

	// admin_url() resolves correctly even when WordPress lives in a
	// subdirectory, which a hard-coded '/wp-admin/' path in JS would not.
	wp_localize_script( 'quiettruths-main', 'quietTruths', array(
		'ajaxUrl' => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
	) );

	wp_register_script( 'quiettruths-polls', QUIETTRUTHS_URI . 'assets/js/polls.js', array(), QUIETTRUTHS_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'quiettruths_scripts' );

/**
 * Enqueue the editor stylesheet so the block editor matches the front end.
 *
 * @since 1.0.0
 */
function quiettruths_editor_assets() {
	wp_enqueue_style(
		'quiettruths-editor',
		QUIETTRUTHS_URI . 'assets/css/editor.css',
		array(),
		QUIETTRUTHS_VERSION
	);
}
add_action( 'enqueue_block_editor_assets', 'quiettruths_editor_assets' );

/**
 * Apply Customizer brand colours as CSS custom properties.
 *
 * Keeps the whole design system in one place (main.css) while still letting
 * editors recolour the masthead from Appearance > Customize.
 *
 * @since 1.0.0
 */
function quiettruths_brand_css() {
	$primary  = get_theme_mod( 'qt_color_primary', '#0B3B2E' );
	$accent   = get_theme_mod( 'qt_color_accent', '#C8A34B' );
	$ink      = get_theme_mod( 'qt_color_ink', '#16181C' );

	// Re-validate: a malformed value would break every rule that uses the var.
	$primary = quiettruths_sanitize_hex( $primary );
	$accent  = quiettruths_sanitize_hex( $accent );
	$ink     = quiettruths_sanitize_hex( $ink );

	$css = sprintf(
		':root{--qt-primary:%1$s;--qt-accent:%2$s;--qt-ink:%3$s}',
		esc_attr( $primary ),
		esc_attr( $accent ),
		esc_attr( $ink )
	);

	wp_add_inline_style( 'quiettruths-style', $css );
}
add_action( 'wp_enqueue_scripts', 'quiettruths_brand_css', 20 );

/**
 * Validate a hex colour, falling back to the supplied default.
 *
 * @since 1.0.0
 * @param string $color   Candidate colour.
 * @param string $default Fallback colour.
 * @return string A valid #rrggbb string.
 */
function quiettruths_sanitize_hex( $color, $default = '#000000' ) {
	$color = trim( (string) $color );

	if ( preg_match( '/^#([a-f0-9]{3}|[a-f0-9]{6})$/i', $color ) ) {
		return $color;
	}

	return $default;
}

/**
 * Body classes that drive layout and dark-mode state without JavaScript.
 *
 * @since 1.0.0
 * @param array $classes Existing classes.
 * @return array Filtered classes.
 */
function quiettruths_body_classes( $classes ) {
	$classes[] = 'qt-theme';

	if ( is_singular( 'qt_investigation' ) ) {
		$classes[] = 'qt-is-investigation';
	}

	if ( is_tax( 'qt_county' ) || is_post_type_archive( 'qt_leader' ) ) {
		$classes[] = 'qt-has-sidebar';
	}

	if ( get_theme_mod( 'qt_dark_default', false ) ) {
		$classes[] = 'qt-dark-default';
	}

	return $classes;
}
add_filter( 'body_class', 'quiettruths_body_classes' );

/**
 * Add the theme colour to the browser chrome on mobile.
 *
 * @since 1.0.0
 */
function quiettruths_theme_color_meta() {
	printf(
		'<meta name="theme-color" content="%s">' . "\n",
		esc_attr( quiettruths_sanitize_hex( get_theme_mod( 'qt_color_primary', '#0B3B2E' ) ) )
	);
}
add_action( 'wp_head', 'quiettruths_theme_color_meta', 1 );

/**
 * Register the theme's block pattern category.
 *
 * The pattern files themselves live in /patterns and are registered by
 * WordPress from their Title/Slug headers. Registering them here as well would
 * raise an "already registered" notice, so this only creates the shelf they are
 * filed under. Hooked before init so the category exists when core reads the
 * pattern files.
 *
 * @since 1.0.0
 */
function quiettruths_register_patterns() {
	register_block_pattern_category(
		'quiettruths',
		array( 'label' => __( 'Quiet Truths', 'quiettruths' ) )
	);
}
add_action( 'after_setup_theme', 'quiettruths_register_patterns' );

/**
 * Read a pattern file's contents.
 *
 * Pattern files return their block markup rather than echoing it, so the
 * pattern API receives a string it can re-render on demand.
 *
 * @since 1.0.0
 * @param string $file Absolute path to the pattern file.
 * @return string Block markup.
 */
function quiettruths_read_pattern( $file ) {
	$content = require $file;

	return is_string( $content ) ? $content : '';
}
