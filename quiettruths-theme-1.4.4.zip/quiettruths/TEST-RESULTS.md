# Quiet Truths 1.4.4 — test results

Executed locally on 21 September 2026 against the corrected theme.

## 1.4.4 verification (latest run)

| Check | Result |
|---|---|
| PHP syntax (`php -l`) | 50 files, 0 errors |
| Front-page launch panel + single document CTA + hero copy (Playwright) | 10 passed, 0 failed |
| Navigation / footer / search / breadcrumb browser assertions | 41 passed, 0 failed |
| Core browser/HTTP assertions | 39 passed, 0 failed |
| Extended browser/HTTP assertions | 15 passed, 0 failed |
| Rewrite self-heal assertions | 11 passed, 0 failed |
| Menu / footer integration assertions | 59 passed, 0 failed |
| Missing-term restoration (break + self-heal verify) | 13 passed, 0 failed |
| Newsletter / poll / date / event integration assertions | 40 passed, 0 failed |

The empty-state front page now shows exactly **one** "have a document" CTA (the
rail), the launch panel carries a single "Who we are" action, the hero renders the
new masthead band, and the footer bottom bar shows © + tagline + a corrections
link with no bare domain and no raw email.

Earlier per-release reports follow; where numbers differ they reflect the release
named in that section.

## 1.3.3 results (historical)

## Environment

- WordPress 7.1.1 (actual downloaded core and installed database, not API stubs)
- PHP 8.4.24
- MariaDB 11.8.6
- Headless Chromium through Playwright
- PHP development HTTP server; WordPress debug logging enabled
- Test-only interception of outgoing mail for successful-submission flows; separate failed-mail simulation

No test installation, development credentials, fixtures or email-interception plugin is included in this ZIP.

## Results

| Check | Result |
|---|---|
| PHP syntax | 49 files passed |
| Rewrite self-heal assertions (1.3.1) | 9 passed, 0 failed |
| File-level-update repair assertions (1.3.2) | 6 broken-state + 11 repaired-state assertions, 0 failed |
| Missing-term restoration assertions (new in 1.3.3) | 5 broken-state + 13 restored-state assertions, 0 failed |
| URL sweep of 21 URLs after a simulated file-level update | all 200 |
| HTTP status sweep of 17 URLs after a simulated stale-rules upgrade | all 200 |
| JavaScript syntax | 2 files passed |
| Menu / breadcrumb / footer integration assertions (new in 1.3.0) | 54 passed, 0 failed |
| Newsletter / poll / date / event integration assertions | 40 passed, 0 failed |
| Navigation, footer, search and breadcrumb browser assertions (new in 1.3.0) | 39 passed, 0 failed |
| Core browser/HTTP assertions | 39 passed, 0 failed |
| Extended browser/HTTP assertions | 15 passed, 0 failed |
| Original subscriber-schema migration assertions | 2 passed |
| Concurrent vote test | 24 independent requests, 24 successful increments; total rose from 1 to 25 |
| Final WordPress debug log during test run | Only one WordPress core deprecation (`the_block_template_skip_link`) raised by calling `wp_footer()` inside WP-CLI; no theme warnings or fatals |

## 404 regression reproduced and fixed (1.3.1)

The failure was reproduced locally before the fix: with the rewrite rules a theme *replace* leaves behind (theme bases stripped, as WordPress does not flush on replace), `/county/trans-nzoia/`, `/leaders/` and `/barazas/` all returned **404** while core category archives still returned 200.

After the fix, a single front-end request rebuilt the rules (95 → 179) with no dashboard visit, and every URL in the sweep returned 200: home, four county archives, leaders (and page 2), events (and past view), investigations, two categories, About, Corrections, Contact, Privacy, the election hub, search, and an article.

Also asserted: stale rules are detected; the four required bases are restored; the five-minute throttle prevents a flush on every request when a fix cannot complete; and there is no rewrite churn when rules and version already match.

## File-level theme update reproduced and fixed (1.3.2)

Simulated the update path that WordPress does not hook: theme files replaced with no re-activation, so `after_switch_theme` never fires. With `init` hooks disabled (so the theme could not repair itself mid-test) the install was put into the broken state — core pages deleted, menus unassigned, rewrite rules stripped (178 → 94), version markers cleared — and that state was asserted directly.

One plain HTTP request to the homepage then repaired everything: About, Contact, Corrections, Privacy and the election hub recreated; all three menu locations assigned with the seven spec items; every theme rewrite base restored; the Trans Nzoia term present; version markers recorded so the work does not repeat. A 21-URL sweep afterwards returned 200 for every URL, including all five county archives, leaders and page 2, both event views, investigations, all five categories, the four outlet pages, and search.

Note on test method: an earlier attempt at this test passed `-- break` to WP-CLI, which arrives as `$args[0] === '--'` and silently ran the verify branch. The assertions above were re-run with positional arguments and the broken state confirmed before repair.

## Empty versus missing archives (1.3.3)

WordPress core (`WP::handle_404()`) deliberately keeps **200** for `is_category() || is_tag() || is_tax() || is_post_type_archive()` when the queried object exists. Measured against WordPress 7.1.1:

| URL | state | status |
|---|---|---|
| `/category/economy/` | term exists, 0 posts | **200** |
| `/category/empty-test-shelf/` | term exists, 0 posts | **200** |
| `/investigations/` | archive, 0 posts | **200** |
| `/category/analysis/` | term deleted | **404** |
| `/this-does-not-exist/` | no object | **404** |

So an empty section is not the cause of a 404; a *missing term* is. That is what 1.3.3 restores: with the shelf categories and all five counties deleted and the old `quiettruths_terms_seeded = 1.1.0` marker in place (the state that trapped earlier releases), one plain HTTP request recreated all six categories, all five counties and the topic terms, and advanced the marker to the theme version.

Test-method note: an early version of this test compared `get_term_by()` against `null`; that function returns `false` when nothing matches, so the strict comparison failed on a healthy state. The assertions were corrected to `false ===` / `(bool)` and re-run.

## Navigation behaviours verified (1.3.0)

- Seeding creates the three locations with exactly the spec items in spec order; re-running the seeder does not duplicate items.
- Header renders one list of seven items; 2027 is the only button; no dropdown markup.
- An editor can add an eighth item in the dashboard, and the rendered header still shows seven.
- The Customizer control removes 2027 from the nav entirely.
- With no menu assigned, the fallback renders the seven items exactly once (no duplication), in both header and footer.
- Deleting a spec item from a theme-owned menu and running the upgrade pass restores it in the correct position and records the spec version.
- Footer columns match the spec, Standards points at `/about/#standards`, and Corrections/Contact/Privacy appear only in the footer.
- Hamburger at 360px shows the same seven in the same order, opens/closes with Escape, no horizontal overflow.
- Search icon opens the panel, moves focus into the field, submits to a results page, closes on Escape; with JavaScript disabled the search box is visible and works.
- Breadcrumbs read `Home › Profiles › Story` on an article, `Home › Analysis` on a category, `Home › About` on a page; the front page has none; BreadcrumbList JSON-LD matches the visible trail; the filter suppresses the theme trail.
- All four block patterns register from their file headers, and the theme pattern category exists.

## Tested behaviours (1.2.1 scope, re-run against 1.3.0)

- Corrected theme activation and additive subscriber migration.
- Original-schema confirmed record retained and given an unsubscribe token when needed.
- Human/ISO date handling without the destructive global date filter.
- Strict poll index checks, missing/valid nonce checks, missing/closed/duplicate/rate-limited poll responses, Close/reopen behavior.
- Real browser REST/AJAX voting and native no-JavaScript POST voting both persist counts.
- Archive sidebar poll script loads and binds.
- Serialized concurrent voting across independent PHP processes.
- Newsletter shared service: enabled/disabled, valid/invalid nonce, email validation, resend limit, pending state, consent version, failed mail submission.
- Confirmation: wrong, valid, replayed and expired tokens.
- Unsubscribe: wrong token rejected; browser GET shows confirmation; POST deletes record.
- CSV streamed as a real download, beginning with CSV headers rather than dashboard HTML; only confirmed records; private unsubscribe URL per exported record.
- Spreadsheet-formula neutralization and unchanged normal email cells.
- Unauthenticated CSV access denied.
- Mobile navigation with JS on/off, opening/closing, Escape behavior.
- Main/header/footer sibling landmarks and no homepage horizontal overflow at 360px, 768px and 1440px.
- Homepage, article, page, search, county, leader, investigation, event, past-event and election views render.
- Leader page-2 link and response; county page-2 canonical preserved.
- Upcoming/ongoing versus past-event query behavior including missing/empty end dates.
- Cache namespace invalidation and private/no-store headers on interactive pages.

### 1.4.0 — contact addresses, nav and footer specs

Environment: WordPress 7.1.1, PHP 8.4.24, MariaDB, Chromium via Playwright.

| Suite | Result |
|---|---|
| `test-upgrade-140.php break` | 8 passed; 0 failed |
| `test-upgrade-140.php verify` (after one plain HTTP request) | 19 passed; 0 failed |
| `test-menus.php` | 57 passed; 0 failed |
| `test-terms.php verify` | 13 passed; 0 failed |
| `test-selfseed.php` | break 6 / verify 11; 0 failed |
| `test-rewrites.php` | 9 passed; 0 failed |
| `test-theme.php` | 40 passed; 0 failed |
| `nav-browser-tests.py` | 39 passed; 0 failed |
| `browser-tests.py` | 39 passed; 0 failed |
| `extended-browser-tests.py` | 15 passed; 0 failed |
| `php -l` across 50 theme files | 0 errors |
| `node --check` main.js, polls.js | clean |
| 18-URL sweep | all 200; `/this-does-not-exist/` 404 as expected |

The upgrade pass is tested by rebuilding a pre-1.4.0 install and then making one
plain HTTP request, because `init` has already fired by the time a `wp eval-file`
body runs — probing the repair from WP-CLI would let the pass run inside the
probe. Verified: retired addresses replaced in the About, Contact, Corrections
and Privacy page bodies (including both the `href` and the visible link text);
stored Customizer values equal to an old default retired; an address an editor
typed themselves left untouched; About removed from the top nav and still
present in the footer Outlet column; Election 2027 removed from the footer
Sections column; a second run changes nothing.

### 1.4.1 — menu duplication, election hub rule, tagline

Environment: WordPress 7.1.1, PHP 8.4.24, MariaDB, Chromium via Playwright.

| Suite | Result |
|---|---|
| `test-dedup.php` break / verify | 5 / 0, then **12 / 0** |
| `test-upgrade-140.php` break / verify | 8 / 0, then **19 / 0** |
| `test-selfseed.php` break / verify | 6 / 0, then **11 / 0** |
| `test-rewrites.php` | 11 passed; 0 failed |
| `test-menus.php` | 57 passed; 0 failed |
| `test-terms.php verify` | 13 passed; 0 failed |
| `test-theme.php` | 40 passed; 0 failed |
| `nav-browser-tests.py` | 39 passed; 0 failed |
| `browser-tests.py` | 39 passed; 0 failed |
| `extended-browser-tests.py` | 15 passed; 0 failed |
| `php -l` across 50 theme files | 0 errors |
| 17-URL sweep | all 200; `/this-does-not-exist/` 404 as expected |

The duplication case is reproduced, not assumed: a primary menu is rebuilt as a
1.3.x install leaves it — every spec item a plain link, with a correctly-typed
twin beside each one (14 items) — and the footer Sections menu the same way (11
items). After one plain HTTP request the pass returns six and five items
respectively, each surviving item the correct type, `About` and `Standards` still
distinct in the Outlet column, and a second pass removing nothing further.

The election hub rule is checked the same way: with every required rule present
*except* `^2027/?$` — the state an install is left in when its rules were last
saved before the hub page existed — the rules are now reported as not current and
one request restores them (178 to 179 stored rules). Note that
`flush_rewrite_rules()` called during `init` defers to `wp_loaded`, so the
version marker is written from a `wp_loaded` callback rather than inline.

### 1.4.2 — homepage hero dead space

| Suite | Result |
|---|---|
| `nav-browser-tests.py` (lead without a featured image) | 41 passed; 0 failed |
| `nav-browser-tests.py` (lead with a featured image) | 40 passed; 0 failed |
| `browser-tests.py` | 39 passed; 0 failed |
| `extended-browser-tests.py` | 15 passed; 0 failed |
| `test-dedup` / `test-upgrade-140` / `test-selfseed` break→verify | 5→12, 8→19, 6→11; 0 failed |
| `test-rewrites` · `test-menus` · `test-terms` · `test-theme` | 11 · 57 · 13 · 40; 0 failed |
| `php -l` across 50 theme files | 0 errors |

Measured with Chromium at 1440px, before and after:

| Element | Before | After |
|---|---|---|
| `.qt-hero__link` (empty anchor) | present, 755 x 0 at y=86 | not rendered |
| `.qt-hero__body` top edge | y=234 (148px below the hero) | y=86 (gap 0.0px) |
| `.qt-hero` height | 390px | 319px |

With a featured image the overlay layout is unchanged: `qt-hero--media`, one
anchor containing one `<img class="qt-hero__media">`, image 755 x 424.

A scan of every element on the rendered homepage at 1440px and 390px for boxes
larger than 40 x 24 with no text, no media and no painted background returns only
the newsletter email input, which is correctly empty.

### 1.4.3 — homepage launch panel and weekly briefing box

| Suite | Result |
|---|---|
| `test-launch-panel.py` (draft all, then restore) | 6 passed; 0 failed |
| `nav-browser-tests.py` | 41 passed; 0 failed |
| `browser-tests.py` | 39 passed; 0 failed |
| `extended-browser-tests.py` | 15 passed; 0 failed |
| `test-rewrites` · `test-menus` · `test-terms` · `test-theme` | 11 · 57 · 13 · 40; 0 failed |
| `php -l` across 50 theme files | 0 errors |

Verified by drafting every post, event and investigation, then loading the front
page at 1440px: `.qt-launch` renders once with one `<img src=…/launch.jpg>`, the
primary column measures ~1135px tall (previously a blank band), and the weekly
briefing box is no longer empty. After restoring the posts and reloading,
`.qt-launch` is absent and the Latest stream returns.

A full-page screenshot of the empty state was captured and inspected: hero
fallback, five-county grid, launch panel with illustration and two actions, and a
filled rail.

## Not certified by these tests

- Real email inbox delivery, SPF/DKIM/DMARC, campaign sending, or external subscriber-list synchronization.
- Production LiteSpeed, CDN, Redis, load balancer, database proxy, or multisite behavior.
- WordPress 6.0/PHP 7.4 minimum-version execution; this run used the versions above.
- All plugins, all browsers, complete WCAG conformance, security penetration testing, or legal compliance.
- A secure anonymous source-submission service (not part of the implementation).

Use a staging copy and the README's deployment checklist before updating the production site.
