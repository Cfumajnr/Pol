# Changelog

## 1.4.4 — 21 September 2026

### Changed
- **One document prompt per screen.** The front page previously asked for
  documents up to three times on a single view (the launch-panel button, the
  investigations-desk CTA and the rail CTA, plus a "Have a document?" line in the
  footer). It now asks exactly once — the rail's "Have a document? Tell us."
  section. The launch panel's second button was dropped (it keeps a single "Who
  we are" action), the investigations-desk CTA was removed, and the footer tip
  line was retired. The tip inboxes remain reachable from the Contact and
  Corrections pages.
- **Empty-state hero is a real masthead, not a name + descriptor.** When there
  is no lead story, the hero previously repeated the site name and the
  "Independent reporting from…" line. It now renders a branded dark-green band in
  the site palette with a gold kicker ("Quiet Truths · Western Kenya"), the
  headline "Follow the money across *five counties*." and a one-sentence mission
  line.
- **Footer bottom bar rewritten.** Kept `© {year} Quiet Truths`; replaced the bare
  domain and the raw `Corrections: admin@…` mailto with the tagline
  ("The record behind Western Kenya's politics") and a "We correct the record"
  link to the Corrections page.

### Added
- `.qt-hero__kicker`, `.qt-hero--empty` band and `.qt-footer__tag` styles in
  `assets/css/main.css`.

## 1.4.3 — 21 September 2026

### Added
- **Homepage launch panel.** When the Latest, Opinion and Barazas loops all come
  back empty, the front page's primary column previously rendered as a tall blank
  band beside the rail. It now fills with a launch panel: a bundled western-Kenya
  illustration (`assets/images/launch.jpg`), the line "The first stories are being
  reported now.", a sentence about the five counties, and two actions (Who we are,
  Send us a document). It disappears automatically as soon as any of the three
  loops has a post, so a live front page is never changed.
- **Weekly briefing box no longer renders empty.** The newsletter form returns
  nothing until the editor enables it, which left a titled box with a blank body.
  The rail now shows the signup form when enabled, and a short "launches with our
  first issue" line otherwise. Added `quiettruths_newsletter_enabled()` so other
  templates can make the same decision.

### Changed
- New helper `quiettruths_home_empty_state()` and `.qt-launch` styles.

## 1.4.2 — 21 September 2026

### Fixed
- **Dead space at the top of the homepage when the lead story has no featured
  image.** `front-page.php` rendered the hero's image anchor unconditionally and
  put the `<img>` inside an `if`. With no featured image that produced an empty
  `<a class="qt-hero__link">` — and because the hero is a CSS grid, the empty
  element still claimed the first cell of the lead column, pushing the headline
  down and leaving a gap the full width of that column. Measured at 1440px: the
  headline sat 148px below the top of the hero. The anchor is now inside the
  condition, and `.qt-hero:not(.qt-hero--media) .qt-hero__body` claims the lead
  grid area, so the headline starts at the top either way.
  Measured after the fix: gap 0.0px, hero 390px to 319px tall.

### Added
- Two browser assertions covering both hero states, so this cannot silently
  return: with a featured image the anchor must carry the `<img>`; without one
  there must be no anchor at all and the headline must sit within 4px of the
  hero's top edge.

## 1.4.1 — 21 September 2026

### Fixed
- **Menus no longer duplicate themselves.** `quiettruths_find_menu_item()` matched
  on item type alone, so a plain link to `/category/analysis/` was never
  recognised as the Analysis spec item once the category existed — the seeder
  added a second copy beside it. On an installation whose menus were seeded while
  the shelves and counties were still missing (the 404 period), that turned seven
  nav items into thirteen, with every shelf listed twice and About pushed to the
  end. Matching now falls back to the destination, so the existing item is
  upgraded in place.
- **Already-duplicated menus are repaired.** The upgrade pass de-duplicates every
  theme-owned menu before re-syncing it: the first item at a destination is kept,
  later ones are removed. The legacy `/2027/` URL and the election page count as
  one destination; `About` and `Standards` (`/about/#standards`) count as two.
- The retired About item is now removed whether it is a page reference or a plain
  link, so installs seeded before the About page existed are cleaned up too.
- **`/2027/` no longer 404s on installs whose rules predate the election page.**
  `quiettruths_required_rewrite_rules()` checked only the four rules that
  registered post types generate, so an installation whose `rewrite_rules` were
  last saved before the election hub existed looked healthy and was never
  re-flushed — while WordPress serves a populated rules option verbatim and only
  merges init-time rules when it rebuilds. The nav's own button therefore 404ed
  permanently. The hub rule is now part of what the self-heal verifies.

### Changed
- Masthead tagline is now "The record behind Western Kenya's politics". A stored
  copy of the old default is retired on upgrade; a tagline an editor rewrote is
  left alone.

## 1.4.0 — 21 September 2026

### Changed
- Contact addresses consolidated to three inboxes: `tips@` becomes `info@`,
  `news@` becomes `editor@`, `corrections@` becomes `admin@`. Data protection
  queries on the Privacy page now go to `info@` rather than a dedicated
  `privacy@` address. The Customizer defaults, the footer, the tip-line pattern,
  the tip CTA and the seeded page copy all follow.
- Top navigation drops About and ships six items: the five shelves, then the
  2027 hub. About was already in the footer's Outlet column, so it is not lost —
  it is just no longer duplicated into the header.
- Footer "Sections" column drops Election 2027. It is already the one button in
  the top nav, and the footer now lists the five shelves only.

### Added
- `inc/upgrade.php`: a one-time, recorded pass for installs already running the
  theme. It rewrites retired addresses inside pages that were seeded by an
  earlier release (the seeder skips pages that already exist), retires stored
  Customizer values that equal an old default, and removes the two menu items
  that left the specs. Menu sync only ever adds, so without this pass the old
  About link and the footer's Election 2027 would have survived the update.

## 1.3.3 — 21 September 2026

### Fixed
- **Missing categories and counties are now restored automatically.** `quiettruths_seed_terms()` short-circuited on a hard-coded `quiettruths_terms_seeded === '1.1.0'` marker, so once that option was set the theme never re-created a term again. On a site where the terms are absent — a database import without term rows, a bulk delete, or a seeding run that stopped halfway — `/category/analysis/`, `/county/trans-nzoia/` and friends return 404 permanently, because WordPress 404s an archive whose *term* does not exist. The marker is now keyed to the theme version, so each release re-checks once; the existing per-term guards keep the run idempotent and leave renamed terms alone.

### Clarified
- An archive with **no posts** does not 404: WordPress core explicitly keeps 200 for `is_category() || is_tag() || is_tax() || is_post_type_archive()` when the queried object exists. Verified against WordPress 7.1.1 — `/category/economy/` and `/investigations/` with zero posts both return 200, while the same URL with the term deleted returns 404. Empty sections render the theme's empty state; they are not the cause of a 404.

## 1.3.2 — 21 September 2026

### Fixed
- **Missing pages and menus after a file-level theme update.** The core pages (About, Standards anchor, Contact, Corrections, Privacy, election hub) and the three spec menus were created only on `after_switch_theme` — a hook WordPress fires on *activation* and never when an active theme's files are replaced (FTP, file manager, or "replace current with uploaded"). Those installs 404 on `/about/`, `/contact/`, `/corrections/`, `/privacy/` and the hub, and their rewrite rules are stale as well. A version-gated pass on `init` (priority 98, once per ten minutes) now seeds terms, core pages and menus on any request; every seeder is idempotent, so nothing is duplicated and no editor content is overwritten.
- Runs immediately before the rewrite self-heal added in 1.3.1, so rules are rebuilt for content that now exists.

## 1.3.1 — 21 September 2026

### Fixed
- **Custom URLs returning 404 after a theme update.** WordPress flushes rewrite rules only on theme *activation*; replacing an active theme by uploading a ZIP fires no such hook, so county, leader, event and investigation URLs kept 404-ing until an administrator re-saved permalinks. The theme now verifies its own rewrite bases (`county/`, `leaders/`, `barazas/`, `investigations/`) on `init` and rebuilds the rules when they are missing or after a version change — at most once per five minutes, so an unwritable `.htaccess` cannot cause a flush per request.
- Replaced the previous dashboard-only rewrite refresh (`admin_init`) with the front-end check above, so a site recovers without anyone logging in.

## 1.3.0 — 21 September 2026

### Navigation and footer menus
- Register three menu locations: **Primary**, **Footer — Sections**, **Footer — Outlet**.
- Add `inc/menus.php`: one spec per location drives the dashboard menu, the no-menu fallback and the footer columns, so they cannot drift apart.
- Seed the three spec menus on activation and assign them to any unassigned location. An editor-assigned menu always wins.
- Add a non-destructive upgrade pass (`admin_init`) that creates the footer locations on existing installs and restores missing spec items, without deleting items an editor added.
- Footer Sections and Outlet columns now render from real menu locations with spec fallbacks; the brand column, tip contact and bottom bar are unchanged.
- Footer bottom bar derives the domain from the site (Customizer override available) instead of a hard-coded string.
- Enforce the two nav rules at render time as well as in the spec: never more than seven top-level items, and 2027 remains the only button (demoted after August 2027, removable via the Customizer).

### Header search
- The header search icon now opens a real search panel (focus, Escape, outside-click close) instead of linking to `/?s=`, which loaded the homepage on a static-front-page install.
- Without JavaScript the panel stays in flow, so search remains reachable.

### Block patterns
- Add the required `Title:`/`Slug:` headers to the four files in `/patterns`. WordPress scans that directory on every load; without headers each request logged a "Slug field missing" notice and the patterns were never registered.
- Stop registering the same patterns a second time from `inc/setup.php` (which would raise "already registered"); the theme now registers only the pattern category, on `after_setup_theme` so it exists before core reads the files.

### Breadcrumbs
- Corrected the trail: posts now read **Home › Profiles › Name** using the shelf category, category/tag/term archives show the term name (not the document title with the site name appended), pages include ancestor chains, and date/author archives use proper labels.
- Trail logic is shared with new BreadcrumbList JSON-LD, emitted only when the theme owns metadata.
- Customizer toggle plus `quiettruths_breadcrumbs_enabled` filter; Yoast breadcrumbs are detected automatically so a trail is never printed twice.

## 1.2.1 — 21 September 2026

### Layout, navigation and dates
- Close the site header before the main landmark.
- Remove the filter that replaced every post date with the literal `j M Y`.
- Fix a runtime fatal error discovered in staging: `wp_nav_menu_objects` supplies an argument object, not an array.
- Make the fallback menu actually output markup, and make the saved-menu election setting/demotion consistent with the fallback.
- Keep mobile navigation available without JavaScript; enhanced menu still supports Escape.
- Apply saved color preference early and respect reduced-motion scrolling.
- Guard form enhancements when Fetch/URLSearchParams are unavailable.
- Use unique tip/newsletter label IDs.
- Resolve election links from the saved page instead of assuming a numeric slug survived WordPress slug validation. Preserve existing page data.

### Newsletter
- Shared validation, feature-enable checks and rate limiting for AJAX/native POST.
- Correct error propagation for database and mail-submission failures.
- Rate-limited confirmation resend, 24-hour expiry and single-use confirmation tokens.
- Honest pending/confirmed/invalid/error notices; no false success on failed updates.
- Additive schema migration on activation and authenticated administrator visits.
- Consent-version recording and scheduled pending-record cleanup.
- Confirmed-only, batched, formula-safe CSV export via authenticated admin-post handler.
- POST-only, capability- and nonce-checked admin deletion before rendering.
- Private unsubscribe URLs in exports; confirmation POST removes records.
- Privacy/consent messaging reflects implementation; existing edited pages are not overwritten.

### Polls
- Serialize all theme-controlled poll mutations with a MySQL/MariaDB named lock, preserving existing store and counts.
- Check database write success; fresh reads avoid stale object-cache option values.
- Strict option validation, explicit public poll-token checks, correct REST status codes.
- Load scripts wherever poll widgets render and add a real native POST vote handler.
- Respect the existing show-results setting.
- Add Close voting action and SameSite cookie attributes.
- Remove claims of verified one-vote-per-device protection.

### Archives, metadata and caching
- Add leader pagination and upcoming/ongoing versus past event views.
- Use site timezone in event helpers; allow clearing optional dates and reject invalid calendar dates on save.
- Emit explicit archive canonicals, preserving page numbers, and defer theme metadata to recognized SEO plugins.
- Replace direct transient-row deletion with versioned query-cache keys.
- Use conservative private/no-store behavior for active interactive features and token responses.

### Documentation and source safety
- Replace unsupported secure-email claims and remove the ineffective tip-email nonce.
- Correct stale county counts, missing lint-tool references and child-theme instructions.
- Document tested versions, cache tradeoffs, existing pending-link behavior, and external newsletter-provider responsibilities.

### Deliberately not changed
- No removal or overwrite of editorial content, theme settings, existing menus, or historical poll results.
- No automatic migration of durable features into a companion plugin.
- No SMTP service, anonymous submission system, or external mailing-platform synchronization is bundled.
