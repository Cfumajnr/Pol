<?php
/**
 * The footer.
 *
 * Three columns plus a bottom bar, per the site spec:
 *
 *   1. Brand    — wordmark, tagline, one-line descriptor, social icons.
 *   2. Sections — the five shelves plus the election hub.
 *   3. Outlet   — About, Standards, Corrections, Contact, Privacy.
 *
 * Corrections and Contact live here and only here. Corrections in the top nav
 * reads as amateur; omitting it hides accountability. Privacy sits in the footer
 * by legal convention.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?>
</main><!-- .qt-main -->

<footer class="qt-footer">
	<div class="qt-footer__inner">

		<?php /* ---------- Column 1: Brand ---------- */ ?>
		<div class="qt-footer__col qt-footer__col--brand">
			<?php quiettruths_branding(); ?>

			<p class="qt-footer__descriptor"><?php esc_html_e( 'Independent reporting on Kakamega, Vihiga, Bungoma, Busia and Trans Nzoia.', 'quiettruths' ); ?></p>

			<?php quiettruths_social_links(); ?>
		</div>

		<?php /* ---------- Column 2: Sections ---------- */ ?>
		<nav class="qt-footer__col" aria-label="<?php esc_attr_e( 'Sections', 'quiettruths' ); ?>">
			<h2 class="qt-footer__title"><?php esc_html_e( 'Sections', 'quiettruths' ); ?></h2>

			<?php
			quiettruths_nav_menu(
				'footer_sections',
				array( 'menu_class' => 'qt-footer-menu' )
			);
			?>
		</nav>

		<?php /* ---------- Column 3: Outlet ---------- */ ?>
		<nav class="qt-footer__col" aria-label="<?php esc_attr_e( 'About this outlet', 'quiettruths' ); ?>">
			<h2 class="qt-footer__title"><?php esc_html_e( 'Quiet Truths', 'quiettruths' ); ?></h2>

			<?php
			quiettruths_nav_menu(
				'footer_outlet',
				array( 'menu_class' => 'qt-footer-menu' )
			);
			?>

			<?php
			/*
			 * The tip inbox is no longer repeated in the footer. The sidebar CTA
			 * ("Have a document? Tell us.") is the single document prompt, and the
			 * Contact page carries every inbox — repeating it here meant the site
			 * asked for documents two or three times on the same screen.
			 */
			?>
		</nav>
	</div>

	<?php /* ---------- Bottom bar ---------- */ ?>
	<div class="qt-footer__base">
		<div class="qt-footer__base-inner">
			<p class="qt-footer__legal">
				<span class="qt-footer__copy">&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Quiet Truths</span>
				<span class="qt-footer__sep" aria-hidden="true">&middot;</span>
				<span class="qt-footer__tag"><?php esc_html_e( 'The record behind Western Kenya&rsquo;s politics', 'quiettruths' ); ?></span>
				<span class="qt-footer__sep" aria-hidden="true">&middot;</span>
				<a class="qt-footer__corrections" href="<?php echo esc_url( quiettruths_page_url( 'corrections' ) ); ?>"><?php esc_html_e( 'We correct the record', 'quiettruths' ); ?></a>
			</p>

			<?php
			$qt_footer_note = get_theme_mod( 'qt_footer_note', '' );

			if ( $qt_footer_note ) :
				?>
				<p class="qt-footer__note"><?php echo wp_kses_post( $qt_footer_note ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
