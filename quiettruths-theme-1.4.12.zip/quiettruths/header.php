<?php
/**
 * The header.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<script>(function(){try{var t=localStorage.getItem('qt-theme');if(t==='dark'||t==='light'){document.documentElement.setAttribute('data-qt-theme',t);}}catch(e){}}());</script>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#qt-main"><?php esc_html_e( 'Skip to content', 'quiettruths' ); ?></a>

<?php quiettruths_breaking_news(); ?>

<header class="qt-header" id="qt-top">
	<div class="qt-header__inner">
		<?php quiettruths_branding(); ?>

		<button class="qt-nav-toggle" type="button" aria-expanded="false" aria-controls="qt-nav" data-qt-nav-toggle>
			<span class="qt-nav-toggle__bar"></span>
			<span class="qt-nav-toggle__bar"></span>
			<span class="qt-nav-toggle__bar"></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'quiettruths' ); ?></span>
		</button>

		<nav class="qt-nav" id="qt-nav" aria-label="<?php esc_attr_e( 'Primary', 'quiettruths' ); ?>" data-qt-nav>
			<?php quiettruths_nav_menu( 'primary' ); ?>

			<div class="qt-nav__tools">
				<button class="qt-icon-btn qt-search-toggle" type="button" data-qt-search-toggle aria-expanded="false" aria-controls="qt-search-panel">
					<span class="screen-reader-text"><?php esc_html_e( 'Search Quiet Truths', 'quiettruths' ); ?></span>
					<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="M16.5 16.5L21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
				</button>

				<button class="qt-icon-btn" type="button" data-qt-theme-toggle aria-pressed="false">
					<span class="screen-reader-text"><?php esc_html_e( 'Switch colour scheme', 'quiettruths' ); ?></span>
					<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
				</button>

				<a
					class="qt-btn qt-btn--tip"
					href="<?php echo esc_url( quiettruths_page_url( 'contact' ) ); ?>"
					aria-label="<?php esc_attr_e( 'Open the contact page to send a tip', 'quiettruths' ); ?>"
					title="<?php esc_attr_e( 'Choose email, WhatsApp or another contact method', 'quiettruths' ); ?>"
				>
					<?php esc_html_e( 'Send a tip', 'quiettruths' ); ?>
				</a>
			</div>
		</nav>

		<div class="qt-search-panel" id="qt-search-panel" data-qt-search-panel>
			<?php get_search_form(); ?>
		</div>
	</div>

</header>

<main class="qt-main" id="qt-main">
