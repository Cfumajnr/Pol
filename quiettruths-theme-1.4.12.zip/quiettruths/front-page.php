<?php
/**
 * The front page.
 *
 * The homepage is a publication doorway, not a second article stream. Reporting
 * lives in the shelves linked from the navigation; this page keeps the Quiet
 * Truths identity, county directory, launch illustration and contact route in
 * one deliberate place without repeating post cards already available elsewhere.
 *
 * @package QuietTruths
 * @since   1.4.11
 */

get_header();
?>

<div class="qt-home">

	<header class="qt-home-intro" aria-labelledby="qt-home-intro-title">
		<h1 id="qt-home-intro-title" class="qt-home-intro__title">
			<?php esc_html_e( 'Western Kenya’s politics,', 'quiettruths' ); ?> <em><?php esc_html_e( 'on the record', 'quiettruths' ); ?></em>.
		</h1>
		<p class="qt-home-intro__text"><?php esc_html_e( 'Independent reporting on the people, power and public decisions shaping Western Kenya.', 'quiettruths' ); ?></p>
	</header>

	<?php quiettruths_county_grid( true ); ?>

	<div class="qt-home__split">
		<div class="qt-home__primary">
			<?php quiettruths_home_editorial_intro(); ?>
		</div>

		<aside class="qt-home__rail" aria-label="<?php esc_attr_e( 'Sidebar', 'quiettruths' ); ?>">
			<?php
			$qt_active_poll = quiettruths_get_active_poll();

			if ( $qt_active_poll ) :
				?>
				<section class="qt-widget">
					<h2 class="qt-widget__title"><?php esc_html_e( 'Your view', 'quiettruths' ); ?></h2>
					<?php quiettruths_render_poll( $qt_active_poll ); ?>
				</section>
			<?php endif; ?>

			<?php if ( is_active_sidebar( 'sidebar-home' ) ) : ?>
				<?php dynamic_sidebar( 'sidebar-home' ); ?>
			<?php elseif ( quiettruths_newsletter_enabled() ) : ?>
				<section class="qt-widget">
					<h2 class="qt-widget__title"><?php esc_html_e( 'The weekly briefing', 'quiettruths' ); ?></h2>
					<?php quiettruths_newsletter_form( 'home-rail' ); ?>
				</section>
			<?php else : ?>
				<section class="qt-widget">
					<h2 class="qt-widget__title"><?php esc_html_e( 'The weekly briefing', 'quiettruths' ); ?></h2>
					<p class="qt-widget__note"><?php esc_html_e( 'The weekly briefing launches with our first issue. Until then, the fastest way to shape our reporting is to send us a document.', 'quiettruths' ); ?></p>
				</section>
			<?php endif; ?>

			<?php quiettruths_tip_cta(); ?>
		</aside>
	</div>

</div>

<?php
get_footer();
