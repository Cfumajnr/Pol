<?php
/**
 * The article/archive sidebar.
 *
 * Quiet Truths owns this sidebar's public presentation. WordPress installs can
 * carry a default stack of Recent Posts, Comments, Archives and Categories
 * widgets; those generic blocks are not rendered here because they make a
 * newly launched newsroom look unfinished. A child theme can opt into the
 * dashboard widget area with the `quiettruths_use_sidebar_widgets` filter.
 *
 * @package QuietTruths
 * @since   1.4.7
 */

defined( 'ABSPATH' ) || exit;

$qt_use_sidebar_widgets = is_active_sidebar( 'sidebar-1' ) && apply_filters( 'quiettruths_use_sidebar_widgets', false );

if ( $qt_use_sidebar_widgets ) :
	?>
	<aside class="qt-layout__aside" aria-label="<?php esc_attr_e( 'Sidebar', 'quiettruths' ); ?>">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</aside>
	<?php
else :
	?>
	<aside class="qt-layout__aside" aria-label="<?php esc_attr_e( 'Sidebar', 'quiettruths' ); ?>">
		<section class="qt-widget">
			<h2 class="qt-widget__title"><?php esc_html_e( 'The five counties', 'quiettruths' ); ?></h2>
			<ul class="qt-widget-list">
				<?php foreach ( quiettruths_counties() as $qt_county ) : ?>
					<?php $qt_link = quiettruths_county_link( $qt_county['slug'] ); ?>
					<?php if ( '' === $qt_link ) : continue; endif; ?>
					<li>
						<a href="<?php echo esc_url( $qt_link ); ?>">
							<span><?php echo esc_html( $qt_county['name'] ); ?></span>
							<small><?php echo esc_html( quiettruths_number( $qt_county['population'] ) ); ?></small>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>

		<?php if ( is_singular( 'post' ) ) : ?>
			<?php
			$qt_more_posts = quiettruths_cached_query( 'article-sidebar-' . get_the_ID(), array(
				'post_type'           => 'post',
				'post__not_in'        => array( get_the_ID() ),
				'posts_per_page'      => 4,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			) );
			?>

			<?php if ( $qt_more_posts->have_posts() ) : ?>
				<section class="qt-widget qt-widget--more">
					<h2 class="qt-widget__title"><?php esc_html_e( 'More from Quiet Truths', 'quiettruths' ); ?></h2>
					<ul class="qt-widget-list">
						<?php while ( $qt_more_posts->have_posts() ) : $qt_more_posts->the_post(); ?>
							<li>
								<a href="<?php the_permalink(); ?>">
									<span><?php the_title(); ?></span>
									<small><?php echo esc_html( get_the_date() ); ?></small>
								</a>
							</li>
						<?php endwhile; ?>
					</ul>
				</section>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		<?php endif; ?>

		<?php if ( quiettruths_newsletter_enabled() ) : ?>
			<section class="qt-widget">
				<h2 class="qt-widget__title"><?php esc_html_e( 'The weekly briefing', 'quiettruths' ); ?></h2>
				<?php quiettruths_newsletter_form( 'sidebar' ); ?>
			</section>
		<?php endif; ?>

		<?php quiettruths_tip_cta(); ?>
	</aside>
	<?php
endif;

unset( $qt_use_sidebar_widgets );
