<?php
/**
 * Contact choices for the Contact page.
 *
 * The page content explains the three inboxes and source-safety policy. This
 * small dynamic block adds the channels configured in the Customizer without
 * requiring editors to rewrite the seeded page whenever a WhatsApp number or
 * phone line changes.
 *
 * @package QuietTruths
 * @since   1.4.8
 */

defined( 'ABSPATH' ) || exit;

$qt_whatsapp    = (string) get_theme_mod( 'qt_whatsapp', '' );
$qt_phone       = (string) get_theme_mod( 'qt_phone', '' );
$qt_phone_href  = preg_replace( '/[^0-9+]/', '', $qt_phone );
$qt_contact_id  = wp_unique_id( 'qt-contact-options-' );
?>
<section class="qt-contact-options" aria-labelledby="<?php echo esc_attr( $qt_contact_id ); ?>">
	<h2 id="<?php echo esc_attr( $qt_contact_id ); ?>"><?php esc_html_e( 'Choose a contact method', 'quiettruths' ); ?></h2>
	<p><?php esc_html_e( 'For tips and documents, choose the channel that suits you. Read the source-safety guidance below before sending anything sensitive.', 'quiettruths' ); ?></p>

	<ul class="qt-tip__channels">
		<li>
			<a class="qt-btn qt-btn--accent" href="<?php echo esc_url( quiettruths_tip_url() ); ?>">
				<?php esc_html_e( 'Email tips and documents', 'quiettruths' ); ?>
			</a>
		</li>

		<?php if ( $qt_whatsapp ) : ?>
			<li>
				<a class="qt-btn qt-btn--ghost" href="<?php echo esc_url( $qt_whatsapp ); ?>" rel="noopener" target="_blank">
					<?php esc_html_e( 'WhatsApp the desk', 'quiettruths' ); ?>
				</a>
			</li>
		<?php endif; ?>

		<?php if ( $qt_phone_href ) : ?>
			<li>
				<a class="qt-btn qt-btn--ghost" href="tel:<?php echo esc_attr( $qt_phone_href ); ?>">
					<?php esc_html_e( 'Call the desk', 'quiettruths' ); ?>
				</a>
			</li>
		<?php endif; ?>
	</ul>
</section>
<?php
unset( $qt_whatsapp, $qt_phone, $qt_phone_href, $qt_contact_id );
