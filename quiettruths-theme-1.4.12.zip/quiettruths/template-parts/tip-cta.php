<?php
/**
 * Tip contact call to action.
 *
 * The single most important conversion on an accountability site. It sends
 * readers to the contact hub, where the configured channels are available.
 *
 * @package QuietTruths
 * @since   1.0.0
 */

$qt_tip_id      = wp_unique_id( 'qt-tip-title-' );
$qt_whatsapp    = get_theme_mod( 'qt_whatsapp', '' );
$qt_contact_url = quiettruths_page_url( 'contact' );
?>
<section class="qt-tip" aria-labelledby="<?php echo esc_attr( $qt_tip_id ); ?>">
	<h2 id="<?php echo esc_attr( $qt_tip_id ); ?>"><?php esc_html_e( 'Have a document? Tell us.', 'quiettruths' ); ?></h2>

	<p><?php esc_html_e( 'Tender awards, audit queries, land titles, payroll lists, a memo someone hoped you would not read. Send it and we will treat your identity as the most important fact in the story.', 'quiettruths' ); ?></p>

	<ul class="qt-tip__channels">
		<li>
			<a class="qt-btn qt-btn--accent" href="<?php echo esc_url( $qt_contact_url ); ?>">
				<?php esc_html_e( 'Choose a contact method', 'quiettruths' ); ?>
			</a>
		</li>

		<?php if ( $qt_whatsapp ) : ?>
			<li>
				<a class="qt-btn qt-btn--ghost" href="<?php echo esc_url( $qt_whatsapp ); ?>" rel="noopener" target="_blank">
					<?php esc_html_e( 'WhatsApp the desk', 'quiettruths' ); ?>
				</a>
			</li>
		<?php endif; ?>
	</ul>

	<p class="qt-tip__note"><?php esc_html_e( 'Ordinary email is not anonymous or end-to-end encrypted. Avoid work devices and accounts. Contact the desk to discuss safer handling before sending sensitive documents.', 'quiettruths' ); ?></p>
</section>
